const t = document.createElement("script");
t.src = chrome.runtime.getURL("wallet.mjs");
t.type = "module";
t.onload = () => t.remove();
document.head.appendChild(t);
window.addEventListener("message", (e) => {
  e.source === window && e.data?.type?.startsWith("ETHERNAUTA_REQUEST") && chrome.runtime.sendMessage(e.data);
});
chrome.runtime.onMessage.addListener((e) => {
  (e?.type?.startsWith("ETHERNAUTA_RESPONSE") || e?.type?.startsWith("ETHERNAUTA_NOTIFICATION")) && window.postMessage(e, window.location.origin);
});
