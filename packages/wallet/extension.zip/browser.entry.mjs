const t = document.createElement("script")
t.src = chrome.runtime.getURL("wallet.mjs")
t.onload = () => t.remove()
document.head.appendChild(t)
window.addEventListener("message", (e) => {
  e.source === window &&
    e.data?.type?.startsWith("ETHERNAUTA_REQUEST") &&
    (console.log("sending request", e.data),
    chrome.runtime.sendMessage(e.data))
})
chrome.runtime.onMessage.addListener((e) => {
  e?.type?.startsWith("ETHERNAUTA_RESPONSE") &&
    (console.log("receiving response", e),
    window.postMessage(e, "*"))
})
