window.cryptoman = {
  sign: async (t, n) =>
    new Promise((o) => {
      const s = crypto.randomUUID()
      window.addEventListener("message", function i(e) {
        e.data.type.startsWith("ETHERNAUTA_RESPONSE") &&
          e.data.id === s &&
          (window.removeEventListener("message", i),
          o(e.data.signed_transaction))
      })
      const a = {
        type: "ETHERNAUTA_REQUEST_SIGN_TRANSACTION",
        id: s,
        method: t,
        params: n,
      }
      window.postMessage(a, "*")
    }),
  connect: async () =>
    new Promise(() => {
      const n = {
        type: "ETHERNAUTA_REQUEST_CONNECT",
        id: crypto.randomUUID(),
      }
      window.postMessage(n, "*")
    }),
}
