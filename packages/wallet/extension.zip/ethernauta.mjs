window.ethernauta = {
  sign: async (t, e) =>
    new Promise((a) => {
      const s = crypto.randomUUID()
      window.addEventListener("message", function i(n) {
        n.data.type.startsWith("ETHERNAUTA_RESPONSE") &&
          n.data.id === s &&
          (window.removeEventListener("message", i),
          a(n.data.signed_transaction))
      })
      const o = {
        type: "ETHERNAUTA_REQUEST_SIGN_TRANSACTION",
        id: s,
        method: t,
        params: e,
      }
      window.postMessage(o, "*")
    }),
  connect: async () =>
    new Promise(() => {
      const e = {
        type: "ETHERNAUTA_REQUEST_CONNECT",
        id: crypto.randomUUID(),
      }
      window.postMessage(e, "*")
    }),
}
