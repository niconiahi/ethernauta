const t = {
  name: "SKALE Calypso Hub Testnet",
  shortName: "calypso-testnet",
  title: "SKALE Calypso Hub Testnet",
  chain: "giant-half-dual-testnet",
  icon: "calypso",
  rpc: [
    "https://testnet.skalenodes.com/v1/giant-half-dual-testnet"
  ],
  faucets: ["https://www.sfuelstation.com/"],
  nativeCurrency: {
    name: "sFUEL",
    symbol: "sFUEL",
    decimals: 18
  },
  infoURL: "https://calypsohub.network/",
  chainId: 974399131,
  networkId: 974399131,
  slip44: 1,
  explorers: [
    {
      name: "Blockscout",
      url: "https://giant-half-dual-testnet.explorer.testnet.skalenodes.com",
      standard: "EIP3091"
    }
  ]
};
export {
  t as eip155_974399131
};
