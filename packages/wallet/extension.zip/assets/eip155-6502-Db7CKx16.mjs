const e = {
  name: "Peerpay",
  shortName: "Peerpay",
  chain: "P2P",
  rpc: ["https://peerpay.su.gy/p2p"],
  faucets: [],
  nativeCurrency: {
    name: "Peerpay",
    symbol: "P2P",
    decimals: 18
  },
  infoURL: "https://peerpay.su.gy",
  chainId: 6502,
  networkId: 6502,
  explorers: []
};
export {
  e as eip155_6502
};
