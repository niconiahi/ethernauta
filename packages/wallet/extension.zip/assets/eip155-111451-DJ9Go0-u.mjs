const e = {
  name: "eGold Chain Testnet",
  shortName: "egoldchaint",
  chain: "EGC",
  icon: "egoldchain",
  rpc: [
    "https://rpc-testnet.egoldchain.com",
    "wss://rpc-testnet.egoldchain.com"
  ],
  faucets: [],
  nativeCurrency: {
    name: "Aurum",
    symbol: "XAU",
    decimals: 18
  },
  infoURL: "https://www.egoldchain.com",
  chainId: 111451,
  networkId: 111451,
  explorers: [
    {
      name: "eGold Chain Block Explorer",
      url: "http://testnet.egoldscan.io",
      standard: "none"
    }
  ]
};
export {
  e as eip155_111451
};
