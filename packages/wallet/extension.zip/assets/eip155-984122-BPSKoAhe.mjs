const a = {
  name: "Forma",
  shortName: "forma",
  chain: "Forma",
  icon: "forma",
  rpc: ["https://rpc.forma.art"],
  faucets: [],
  features: [
    {
      name: "EIP155"
    },
    {
      name: "EIP1559"
    }
  ],
  nativeCurrency: {
    name: "TIA",
    symbol: "TIA",
    decimals: 18
  },
  infoURL: "https://forma.art",
  chainId: 984122,
  networkId: 984122,
  explorers: [
    {
      name: "blockscout",
      url: "https://explorer.forma.art",
      standard: "EIP3091"
    }
  ]
};
export {
  a as eip155_984122
};
