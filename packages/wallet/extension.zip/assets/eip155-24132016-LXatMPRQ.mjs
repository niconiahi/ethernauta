const t = {
  name: "XMTP",
  shortName: "xmtp",
  chain: "ETH",
  rpc: [],
  faucets: [],
  nativeCurrency: {
    name: "USDC",
    symbol: "USDC",
    decimals: 18
  },
  infoURL: "https://xmtp.org",
  chainId: 24132016,
  networkId: 24132016,
  status: "incubating"
};
export {
  t as eip155_24132016
};
