var Q,
  p,
  Tt,
  Ct,
  T,
  pt,
  At,
  Pt,
  Ut,
  ut,
  nt,
  it,
  I = {},
  Ht = [],
  te =
    /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
  X = Array.isArray
function x(e, t) {
  for (var _ in t) e[_] = t[_]
  return e
}
function st(e) {
  e && e.parentNode && e.parentNode.removeChild(e)
}
function ee(e, t, _) {
  var n,
    r,
    i,
    f = {}
  for (i in t)
    i == "key"
      ? (n = t[i])
      : i == "ref"
        ? (r = t[i])
        : (f[i] = t[i])
  if (
    (arguments.length > 2 &&
      (f.children =
        arguments.length > 3 ? Q.call(arguments, 2) : _),
    typeof e == "function" && e.defaultProps != null)
  )
    for (i in e.defaultProps)
      f[i] === void 0 && (f[i] = e.defaultProps[i])
  return B(e, f, n, r, null)
}
function B(e, t, _, n, r) {
  var i = {
    type: e,
    props: t,
    key: _,
    ref: n,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: r ?? ++Tt,
    __i: -1,
    __u: 0,
  }
  return r == null && p.vnode != null && p.vnode(i), i
}
function W(e) {
  return e.children
}
function F(e, t) {
  ;(this.props = e), (this.context = t)
}
function A(e, t) {
  if (t == null) return e.__ ? A(e.__, e.__i + 1) : null
  for (var _; t < e.__k.length; t++)
    if ((_ = e.__k[t]) != null && _.__e != null)
      return _.__e
  return typeof e.type == "function" ? A(e) : null
}
function Lt(e) {
  var t, _
  if ((e = e.__) != null && e.__c != null) {
    for (
      e.__e = e.__c.base = null, t = 0;
      t < e.__k.length;
      t++
    )
      if ((_ = e.__k[t]) != null && _.__e != null) {
        e.__e = e.__c.base = _.__e
        break
      }
    return Lt(e)
  }
}
function dt(e) {
  ;((!e.__d && (e.__d = !0) && T.push(e) && !Z.__r++) ||
    pt != p.debounceRendering) &&
    ((pt = p.debounceRendering) || At)(Z)
}
function Z() {
  for (var e, t, _, n, r, i, f, u = 1; T.length; )
    T.length > u && T.sort(Pt),
      (e = T.shift()),
      (u = T.length),
      e.__d &&
        ((_ = void 0),
        (r = (n = (t = e).__v).__e),
        (i = []),
        (f = []),
        t.__P &&
          (((_ = x({}, n)).__v = n.__v + 1),
          p.vnode && p.vnode(_),
          lt(
            t.__P,
            _,
            n,
            t.__n,
            t.__P.namespaceURI,
            32 & n.__u ? [r] : null,
            i,
            r ?? A(n),
            !!(32 & n.__u),
            f,
          ),
          (_.__v = n.__v),
          (_.__.__k[_.__i] = _),
          Ft(i, _, f),
          _.__e != r && Lt(_)))
  Z.__r = 0
}
function Ot(e, t, _, n, r, i, f, u, l, s, a) {
  var o,
    h,
    c,
    g,
    S,
    $,
    d = (n && n.__k) || Ht,
    y = t.length
  for (l = _e(_, t, d, l, y), o = 0; o < y; o++)
    (c = _.__k[o]) != null &&
      ((h = c.__i == -1 ? I : d[c.__i] || I),
      (c.__i = o),
      ($ = lt(e, c, h, r, i, f, u, l, s, a)),
      (g = c.__e),
      c.ref &&
        h.ref != c.ref &&
        (h.ref && ct(h.ref, null, c),
        a.push(c.ref, c.__c || g, c)),
      S == null && g != null && (S = g),
      4 & c.__u || h.__k === c.__k
        ? (l = Dt(c, l, e))
        : typeof c.type == "function" && $ !== void 0
          ? (l = $)
          : g && (l = g.nextSibling),
      (c.__u &= -7))
  return (_.__e = S), l
}
function _e(e, t, _, n, r) {
  var i,
    f,
    u,
    l,
    s,
    a = _.length,
    o = a,
    h = 0
  for (e.__k = new Array(r), i = 0; i < r; i++)
    (f = t[i]) != null &&
    typeof f != "boolean" &&
    typeof f != "function"
      ? ((l = i + h),
        ((f = e.__k[i] =
          typeof f == "string" ||
          typeof f == "number" ||
          typeof f == "bigint" ||
          f.constructor == String
            ? B(null, f, null, null, null)
            : X(f)
              ? B(W, { children: f }, null, null, null)
              : f.constructor == null && f.__b > 0
                ? B(
                    f.type,
                    f.props,
                    f.key,
                    f.ref ? f.ref : null,
                    f.__v,
                  )
                : f).__ = e),
        (f.__b = e.__b + 1),
        (u = null),
        (s = f.__i = ne(f, _, l, o)) != -1 &&
          (o--, (u = _[s]) && (u.__u |= 2)),
        u == null || u.__v == null
          ? (s == -1 && (r > a ? h-- : r < a && h++),
            typeof f.type != "function" && (f.__u |= 4))
          : s != l &&
            (s == l - 1
              ? h--
              : s == l + 1
                ? h++
                : (s > l ? h-- : h++, (f.__u |= 4))))
      : (e.__k[i] = null)
  if (o)
    for (i = 0; i < a; i++)
      (u = _[i]) != null &&
        (2 & u.__u) == 0 &&
        (u.__e == n && (n = A(u)), It(u, u))
  return n
}
function Dt(e, t, _) {
  var n, r
  if (typeof e.type == "function") {
    for (n = e.__k, r = 0; n && r < n.length; r++)
      n[r] && ((n[r].__ = e), (t = Dt(n[r], t, _)))
    return t
  }
  e.__e != t &&
    (t && e.type && !_.contains(t) && (t = A(e)),
    _.insertBefore(e.__e, t || null),
    (t = e.__e))
  do t = t && t.nextSibling
  while (t != null && t.nodeType == 8)
  return t
}
function ne(e, t, _, n) {
  var r,
    i,
    f = e.key,
    u = e.type,
    l = t[_]
  if (
    (l === null && e.key == null) ||
    (l && f == l.key && u == l.type && (2 & l.__u) == 0)
  )
    return _
  if (n > (l != null && (2 & l.__u) == 0 ? 1 : 0))
    for (r = _ - 1, i = _ + 1; r >= 0 || i < t.length; ) {
      if (r >= 0) {
        if (
          (l = t[r]) &&
          (2 & l.__u) == 0 &&
          f == l.key &&
          u == l.type
        )
          return r
        r--
      }
      if (i < t.length) {
        if (
          (l = t[i]) &&
          (2 & l.__u) == 0 &&
          f == l.key &&
          u == l.type
        )
          return i
        i++
      }
    }
  return -1
}
function yt(e, t, _) {
  t[0] == "-"
    ? e.setProperty(t, _ ?? "")
    : (e[t] =
        _ == null
          ? ""
          : typeof _ != "number" || te.test(t)
            ? _
            : _ + "px")
}
function j(e, t, _, n, r) {
  var i, f
  t: if (t == "style")
    if (typeof _ == "string") e.style.cssText = _
    else {
      if (
        (typeof n == "string" && (e.style.cssText = n = ""),
        n)
      )
        for (t in n) (_ && t in _) || yt(e.style, t, "")
      if (_)
        for (t in _)
          (n && _[t] == n[t]) || yt(e.style, t, _[t])
    }
  else if (t[0] == "o" && t[1] == "n")
    (i = t != (t = t.replace(Ut, "$1"))),
      (f = t.toLowerCase()),
      (t =
        f in e || t == "onFocusOut" || t == "onFocusIn"
          ? f.slice(2)
          : t.slice(2)),
      e.l || (e.l = {}),
      (e.l[t + i] = _),
      _
        ? n
          ? (_.u = n.u)
          : ((_.u = ut),
            e.addEventListener(t, i ? it : nt, i))
        : e.removeEventListener(t, i ? it : nt, i)
  else {
    if (r == "http://www.w3.org/2000/svg")
      t = t
        .replace(/xlink(H|:h)/, "h")
        .replace(/sName$/, "s")
    else if (
      t != "width" &&
      t != "height" &&
      t != "href" &&
      t != "list" &&
      t != "form" &&
      t != "tabIndex" &&
      t != "download" &&
      t != "rowSpan" &&
      t != "colSpan" &&
      t != "role" &&
      t != "popover" &&
      t in e
    )
      try {
        e[t] = _ ?? ""
        break t
      } catch {}
    typeof _ == "function" ||
      (_ == null || (_ === !1 && t[4] != "-")
        ? e.removeAttribute(t)
        : e.setAttribute(
            t,
            t == "popover" && _ == 1 ? "" : _,
          ))
  }
}
function mt(e) {
  return function (t) {
    if (this.l) {
      var _ = this.l[t.type + e]
      if (t.t == null) t.t = ut++
      else if (t.t < _.u) return
      return _(p.event ? p.event(t) : t)
    }
  }
}
function lt(e, t, _, n, r, i, f, u, l, s) {
  var a,
    o,
    h,
    c,
    g,
    S,
    $,
    d,
    y,
    H,
    E,
    q,
    L,
    vt,
    G,
    O,
    tt,
    k = t.type
  if (t.constructor != null) return null
  128 & _.__u &&
    ((l = !!(32 & _.__u)), (i = [(u = t.__e = _.__e)])),
    (a = p.__b) && a(t)
  t: if (typeof k == "function")
    try {
      if (
        ((d = t.props),
        (y = "prototype" in k && k.prototype.render),
        (H = (a = k.contextType) && n[a.__c]),
        (E = a ? (H ? H.props.value : a.__) : n),
        _.__c
          ? ($ = (o = t.__c = _.__c).__ = o.__E)
          : (y
              ? (t.__c = o = new k(d, E))
              : ((t.__c = o = new F(d, E)),
                (o.constructor = k),
                (o.render = re)),
            H && H.sub(o),
            (o.props = d),
            o.state || (o.state = {}),
            (o.context = E),
            (o.__n = n),
            (h = o.__d = !0),
            (o.__h = []),
            (o._sb = [])),
        y && o.__s == null && (o.__s = o.state),
        y &&
          k.getDerivedStateFromProps != null &&
          (o.__s == o.state && (o.__s = x({}, o.__s)),
          x(o.__s, k.getDerivedStateFromProps(d, o.__s))),
        (c = o.props),
        (g = o.state),
        (o.__v = t),
        h)
      )
        y &&
          k.getDerivedStateFromProps == null &&
          o.componentWillMount != null &&
          o.componentWillMount(),
          y &&
            o.componentDidMount != null &&
            o.__h.push(o.componentDidMount)
      else {
        if (
          (y &&
            k.getDerivedStateFromProps == null &&
            d !== c &&
            o.componentWillReceiveProps != null &&
            o.componentWillReceiveProps(d, E),
          (!o.__e &&
            o.shouldComponentUpdate != null &&
            o.shouldComponentUpdate(d, o.__s, E) === !1) ||
            t.__v == _.__v)
        ) {
          for (
            t.__v != _.__v &&
              ((o.props = d),
              (o.state = o.__s),
              (o.__d = !1)),
              t.__e = _.__e,
              t.__k = _.__k,
              t.__k.some(function (D) {
                D && (D.__ = t)
              }),
              q = 0;
            q < o._sb.length;
            q++
          )
            o.__h.push(o._sb[q])
          ;(o._sb = []), o.__h.length && f.push(o)
          break t
        }
        o.componentWillUpdate != null &&
          o.componentWillUpdate(d, o.__s, E),
          y &&
            o.componentDidUpdate != null &&
            o.__h.push(function () {
              o.componentDidUpdate(c, g, S)
            })
      }
      if (
        ((o.context = E),
        (o.props = d),
        (o.__P = e),
        (o.__e = !1),
        (L = p.__r),
        (vt = 0),
        y)
      ) {
        for (
          o.state = o.__s,
            o.__d = !1,
            L && L(t),
            a = o.render(o.props, o.state, o.context),
            G = 0;
          G < o._sb.length;
          G++
        )
          o.__h.push(o._sb[G])
        o._sb = []
      } else
        do
          (o.__d = !1),
            L && L(t),
            (a = o.render(o.props, o.state, o.context)),
            (o.state = o.__s)
        while (o.__d && ++vt < 25)
      ;(o.state = o.__s),
        o.getChildContext != null &&
          (n = x(x({}, n), o.getChildContext())),
        y &&
          !h &&
          o.getSnapshotBeforeUpdate != null &&
          (S = o.getSnapshotBeforeUpdate(c, g)),
        (O = a),
        a != null &&
          a.type === W &&
          a.key == null &&
          (O = Mt(a.props.children)),
        (u = Ot(
          e,
          X(O) ? O : [O],
          t,
          _,
          n,
          r,
          i,
          f,
          u,
          l,
          s,
        )),
        (o.base = t.__e),
        (t.__u &= -161),
        o.__h.length && f.push(o),
        $ && (o.__E = o.__ = null)
    } catch (D) {
      if (((t.__v = null), l || i != null))
        if (D.then) {
          for (
            t.__u |= l ? 160 : 128;
            u && u.nodeType == 8 && u.nextSibling;
          )
            u = u.nextSibling
          ;(i[i.indexOf(u)] = null), (t.__e = u)
        } else for (tt = i.length; tt--; ) st(i[tt])
      else (t.__e = _.__e), (t.__k = _.__k)
      p.__e(D, t, _)
    }
  else
    i == null && t.__v == _.__v
      ? ((t.__k = _.__k), (t.__e = _.__e))
      : (u = t.__e = ie(_.__e, t, _, n, r, i, f, l, s))
  return (a = p.diffed) && a(t), 128 & t.__u ? void 0 : u
}
function Ft(e, t, _) {
  for (var n = 0; n < _.length; n++)
    ct(_[n], _[++n], _[++n])
  p.__c && p.__c(t, e),
    e.some(function (r) {
      try {
        ;(e = r.__h),
          (r.__h = []),
          e.some(function (i) {
            i.call(r)
          })
      } catch (i) {
        p.__e(i, r.__v)
      }
    })
}
function Mt(e) {
  return typeof e != "object" ||
    e == null ||
    (e.__b && e.__b > 0)
    ? e
    : X(e)
      ? e.map(Mt)
      : x({}, e)
}
function ie(e, t, _, n, r, i, f, u, l) {
  var s,
    a,
    o,
    h,
    c,
    g,
    S,
    $ = _.props,
    d = t.props,
    y = t.type
  if (
    (y == "svg"
      ? (r = "http://www.w3.org/2000/svg")
      : y == "math"
        ? (r = "http://www.w3.org/1998/Math/MathML")
        : r || (r = "http://www.w3.org/1999/xhtml"),
    i != null)
  ) {
    for (s = 0; s < i.length; s++)
      if (
        (c = i[s]) &&
        "setAttribute" in c == !!y &&
        (y ? c.localName == y : c.nodeType == 3)
      ) {
        ;(e = c), (i[s] = null)
        break
      }
  }
  if (e == null) {
    if (y == null) return document.createTextNode(d)
    ;(e = document.createElementNS(r, y, d.is && d)),
      u && (p.__m && p.__m(t, i), (u = !1)),
      (i = null)
  }
  if (y == null)
    $ === d || (u && e.data == d) || (e.data = d)
  else {
    if (
      ((i = i && Q.call(e.childNodes)),
      ($ = _.props || I),
      !u && i != null)
    )
      for ($ = {}, s = 0; s < e.attributes.length; s++)
        $[(c = e.attributes[s]).name] = c.value
    for (s in $)
      if (((c = $[s]), s != "children")) {
        if (s == "dangerouslySetInnerHTML") o = c
        else if (!(s in d)) {
          if (
            (s == "value" && "defaultValue" in d) ||
            (s == "checked" && "defaultChecked" in d)
          )
            continue
          j(e, s, null, c, r)
        }
      }
    for (s in d)
      (c = d[s]),
        s == "children"
          ? (h = c)
          : s == "dangerouslySetInnerHTML"
            ? (a = c)
            : s == "value"
              ? (g = c)
              : s == "checked"
                ? (S = c)
                : (u && typeof c != "function") ||
                  $[s] === c ||
                  j(e, s, c, $[s], r)
    if (a)
      u ||
        (o &&
          (a.__html == o.__html ||
            a.__html == e.innerHTML)) ||
        (e.innerHTML = a.__html),
        (t.__k = [])
    else if (
      (o && (e.innerHTML = ""),
      Ot(
        t.type == "template" ? e.content : e,
        X(h) ? h : [h],
        t,
        _,
        n,
        y == "foreignObject"
          ? "http://www.w3.org/1999/xhtml"
          : r,
        i,
        f,
        i ? i[0] : _.__k && A(_, 0),
        u,
        l,
      ),
      i != null)
    )
      for (s = i.length; s--; ) st(i[s])
    u ||
      ((s = "value"),
      y == "progress" && g == null
        ? e.removeAttribute("value")
        : g != null &&
          (g !== e[s] ||
            (y == "progress" && !g) ||
            (y == "option" && g != $[s])) &&
          j(e, s, g, $[s], r),
      (s = "checked"),
      S != null && S != e[s] && j(e, s, S, $[s], r))
  }
  return e
}
function ct(e, t, _) {
  try {
    if (typeof e == "function") {
      var n = typeof e.__u == "function"
      n && e.__u(), (n && t == null) || (e.__u = e(t))
    } else e.current = t
  } catch (r) {
    p.__e(r, _)
  }
}
function It(e, t, _) {
  var n, r
  if (
    (p.unmount && p.unmount(e),
    (n = e.ref) &&
      ((n.current && n.current != e.__e) || ct(n, null, t)),
    (n = e.__c) != null)
  ) {
    if (n.componentWillUnmount)
      try {
        n.componentWillUnmount()
      } catch (i) {
        p.__e(i, t)
      }
    n.base = n.__P = null
  }
  if ((n = e.__k))
    for (r = 0; r < n.length; r++)
      n[r] && It(n[r], t, _ || typeof e.type != "function")
  _ || st(e.__e), (e.__c = e.__ = e.__e = void 0)
}
function re(e, t, _) {
  return this.constructor(e, _)
}
function we(e, t, _) {
  var n, r, i, f
  t == document && (t = document.documentElement),
    p.__ && p.__(e, t),
    (r = (n = !1) ? null : t.__k),
    (i = []),
    (f = []),
    lt(
      t,
      (e = t.__k = ee(W, null, [e])),
      r || I,
      I,
      t.namespaceURI,
      r ? null : t.firstChild ? Q.call(t.childNodes) : null,
      i,
      r ? r.__e : t.firstChild,
      n,
      f,
    ),
    Ft(i, e, f)
}
;(Q = Ht.slice),
  (p = {
    __e: function (e, t, _, n) {
      for (var r, i, f; (t = t.__); )
        if ((r = t.__c) && !r.__)
          try {
            if (
              ((i = r.constructor) &&
                i.getDerivedStateFromError != null &&
                (r.setState(i.getDerivedStateFromError(e)),
                (f = r.__d)),
              r.componentDidCatch != null &&
                (r.componentDidCatch(e, n || {}),
                (f = r.__d)),
              f)
            )
              return (r.__E = r)
          } catch (u) {
            e = u
          }
      throw e
    },
  }),
  (Tt = 0),
  (Ct = function (e) {
    return e != null && e.constructor == null
  }),
  (F.prototype.setState = function (e, t) {
    var _
    ;(_ =
      this.__s != null && this.__s != this.state
        ? this.__s
        : (this.__s = x({}, this.state))),
      typeof e == "function" &&
        (e = e(x({}, _), this.props)),
      e && x(_, e),
      e != null &&
        this.__v &&
        (t && this._sb.push(t), dt(this))
  }),
  (F.prototype.forceUpdate = function (e) {
    this.__v &&
      ((this.__e = !0), e && this.__h.push(e), dt(this))
  }),
  (F.prototype.render = W),
  (T = []),
  (At =
    typeof Promise == "function"
      ? Promise.prototype.then.bind(Promise.resolve())
      : setTimeout),
  (Pt = function (e, t) {
    return e.__v.__b - t.__v.__b
  }),
  (Z.__r = 0),
  (Ut = /(PointerCapture)$|Capture$/i),
  (ut = 0),
  (nt = mt(!1)),
  (it = mt(!0))
var oe = 0
function ge(e, t, _, n, r, i) {
  t || (t = {})
  var f,
    u,
    l = t
  if ("ref" in l)
    for (u in ((l = {}), t))
      u == "ref" ? (f = t[u]) : (l[u] = t[u])
  var s = {
    type: e,
    props: l,
    key: _,
    ref: f,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: --oe,
    __i: -1,
    __u: 0,
    __source: r,
    __self: i,
  }
  if (typeof e == "function" && (f = e.defaultProps))
    for (u in f) l[u] === void 0 && (l[u] = f[u])
  return p.vnode && p.vnode(s), s
}
var R,
  m,
  et,
  wt,
  rt = 0,
  Rt = [],
  w = p,
  gt = w.__b,
  $t = w.__r,
  bt = w.diffed,
  St = w.__c,
  kt = w.unmount,
  xt = w.__
function at(e, t) {
  w.__h && w.__h(m, e, rt || t), (rt = 0)
  var _ = m.__H || (m.__H = { __: [], __h: [] })
  return e >= _.__.length && _.__.push({}), _.__[e]
}
function fe(e) {
  return (rt = 1), ue(Vt, e)
}
function ue(e, t, _) {
  var n = at(R++, 2)
  if (
    ((n.t = e),
    !n.__c &&
      ((n.__ = [
        Vt(void 0, t),
        function (u) {
          var l = n.__N ? n.__N[0] : n.__[0],
            s = n.t(l, u)
          l !== s &&
            ((n.__N = [s, n.__[1]]), n.__c.setState({}))
        },
      ]),
      (n.__c = m),
      !m.__f))
  ) {
    var r = function (u, l, s) {
      if (!n.__c.__H) return !0
      var a = n.__c.__H.__.filter(function (h) {
        return !!h.__c
      })
      if (
        a.every(function (h) {
          return !h.__N
        })
      )
        return !i || i.call(this, u, l, s)
      var o = n.__c.props !== u
      return (
        a.forEach(function (h) {
          if (h.__N) {
            var c = h.__[0]
            ;(h.__ = h.__N),
              (h.__N = void 0),
              c !== h.__[0] && (o = !0)
          }
        }),
        (i && i.call(this, u, l, s)) || o
      )
    }
    m.__f = !0
    var i = m.shouldComponentUpdate,
      f = m.componentWillUpdate
    ;(m.componentWillUpdate = function (u, l, s) {
      if (this.__e) {
        var a = i
        ;(i = void 0), r(u, l, s), (i = a)
      }
      f && f.call(this, u, l, s)
    }),
      (m.shouldComponentUpdate = r)
  }
  return n.__N || n.__
}
function $e(e, t) {
  var _ = at(R++, 3)
  !w.__s &&
    Wt(_.__H, t) &&
    ((_.__ = e), (_.u = t), m.__H.__h.push(_))
}
function se(e, t) {
  var _ = at(R++, 7)
  return (
    Wt(_.__H, t) &&
      ((_.__ = e()), (_.__H = t), (_.__h = e)),
    _.__
  )
}
function le() {
  for (var e; (e = Rt.shift()); )
    if (e.__P && e.__H)
      try {
        e.__H.__h.forEach(z),
          e.__H.__h.forEach(ot),
          (e.__H.__h = [])
      } catch (t) {
        ;(e.__H.__h = []), w.__e(t, e.__v)
      }
}
;(w.__b = function (e) {
  ;(m = null), gt && gt(e)
}),
  (w.__ = function (e, t) {
    e && t.__k && t.__k.__m && (e.__m = t.__k.__m),
      xt && xt(e, t)
  }),
  (w.__r = function (e) {
    $t && $t(e), (R = 0)
    var t = (m = e.__c).__H
    t &&
      (et === m
        ? ((t.__h = []),
          (m.__h = []),
          t.__.forEach(function (_) {
            _.__N && (_.__ = _.__N), (_.u = _.__N = void 0)
          }))
        : (t.__h.forEach(z),
          t.__h.forEach(ot),
          (t.__h = []),
          (R = 0))),
      (et = m)
  }),
  (w.diffed = function (e) {
    bt && bt(e)
    var t = e.__c
    t &&
      t.__H &&
      (t.__H.__h.length &&
        ((Rt.push(t) !== 1 &&
          wt === w.requestAnimationFrame) ||
          ((wt = w.requestAnimationFrame) || ce)(le)),
      t.__H.__.forEach(function (_) {
        _.u && (_.__H = _.u), (_.u = void 0)
      })),
      (et = m = null)
  }),
  (w.__c = function (e, t) {
    t.some(function (_) {
      try {
        _.__h.forEach(z),
          (_.__h = _.__h.filter(function (n) {
            return !n.__ || ot(n)
          }))
      } catch (n) {
        t.some(function (r) {
          r.__h && (r.__h = [])
        }),
          (t = []),
          w.__e(n, _.__v)
      }
    }),
      St && St(e, t)
  }),
  (w.unmount = function (e) {
    kt && kt(e)
    var t,
      _ = e.__c
    _ &&
      _.__H &&
      (_.__H.__.forEach(function (n) {
        try {
          z(n)
        } catch (r) {
          t = r
        }
      }),
      (_.__H = void 0),
      t && w.__e(t, _.__v))
  })
var Et = typeof requestAnimationFrame == "function"
function ce(e) {
  var t,
    _ = function () {
      clearTimeout(n),
        Et && cancelAnimationFrame(t),
        setTimeout(e)
    },
    n = setTimeout(_, 35)
  Et && (t = requestAnimationFrame(_))
}
function z(e) {
  var t = m,
    _ = e.__c
  typeof _ == "function" && ((e.__c = void 0), _()), (m = t)
}
function ot(e) {
  var t = m
  ;(e.__c = e.__()), (m = t)
}
function Wt(e, t) {
  return (
    !e ||
    e.length !== t.length ||
    t.some(function (_, n) {
      return _ !== e[n]
    })
  )
}
function Vt(e, t) {
  return typeof t == "function" ? t(e) : t
}
var ae = Symbol.for("preact-signals")
function Y() {
  if (N > 1) N--
  else {
    for (var e, t = !1; M !== void 0; ) {
      var _ = M
      for (M = void 0, ft++; _ !== void 0; ) {
        var n = _.o
        if (
          ((_.o = void 0), (_.f &= -3), !(8 & _.f) && Bt(_))
        )
          try {
            _.c()
          } catch (r) {
            t || ((e = r), (t = !0))
          }
        _ = n
      }
    }
    if (((ft = 0), N--, t)) throw e
  }
}
function he(e) {
  if (N > 0) return e()
  N++
  try {
    return e()
  } finally {
    Y()
  }
}
var v = void 0
function qt(e) {
  var t = v
  v = void 0
  try {
    return e()
  } finally {
    v = t
  }
}
var M = void 0,
  N = 0,
  ft = 0,
  J = 0
function Gt(e) {
  if (v !== void 0) {
    var t = e.n
    if (t === void 0 || t.t !== v)
      return (
        (t = {
          i: 0,
          S: e,
          p: v.s,
          n: void 0,
          t: v,
          e: void 0,
          x: void 0,
          r: t,
        }),
        v.s !== void 0 && (v.s.n = t),
        (v.s = t),
        (e.n = t),
        32 & v.f && e.S(t),
        t
      )
    if (t.i === -1)
      return (
        (t.i = 0),
        t.n !== void 0 &&
          ((t.n.p = t.p),
          t.p !== void 0 && (t.p.n = t.n),
          (t.p = v.s),
          (t.n = void 0),
          (v.s.n = t),
          (v.s = t)),
        t
      )
  }
}
function b(e, t) {
  ;(this.v = e),
    (this.i = 0),
    (this.n = void 0),
    (this.t = void 0),
    (this.W = t?.watched),
    (this.Z = t?.unwatched),
    (this.name = t?.name)
}
b.prototype.brand = ae
b.prototype.h = function () {
  return !0
}
b.prototype.S = function (e) {
  var t = this,
    _ = this.t
  _ !== e &&
    e.e === void 0 &&
    ((e.x = _),
    (this.t = e),
    _ !== void 0
      ? (_.e = e)
      : qt(function () {
          var n
          ;(n = t.W) == null || n.call(t)
        }))
}
b.prototype.U = function (e) {
  var t = this
  if (this.t !== void 0) {
    var _ = e.e,
      n = e.x
    _ !== void 0 && ((_.x = n), (e.e = void 0)),
      n !== void 0 && ((n.e = _), (e.x = void 0)),
      e === this.t &&
        ((this.t = n),
        n === void 0 &&
          qt(function () {
            var r
            ;(r = t.Z) == null || r.call(t)
          }))
  }
}
b.prototype.subscribe = function (e) {
  var t = this
  return V(
    function () {
      var _ = t.value,
        n = v
      v = void 0
      try {
        e(_)
      } finally {
        v = n
      }
    },
    { name: "sub" },
  )
}
b.prototype.valueOf = function () {
  return this.value
}
b.prototype.toString = function () {
  return this.value + ""
}
b.prototype.toJSON = function () {
  return this.value
}
b.prototype.peek = function () {
  var e = v
  v = void 0
  try {
    return this.value
  } finally {
    v = e
  }
}
Object.defineProperty(b.prototype, "value", {
  get: function () {
    var e = Gt(this)
    return e !== void 0 && (e.i = this.i), this.v
  },
  set: function (e) {
    if (e !== this.v) {
      if (ft > 100) throw new Error("Cycle detected")
      ;(this.v = e), this.i++, J++, N++
      try {
        for (var t = this.t; t !== void 0; t = t.x) t.t.N()
      } finally {
        Y()
      }
    }
  },
})
function jt(e, t) {
  return new b(e, t)
}
function Bt(e) {
  for (var t = e.s; t !== void 0; t = t.n)
    if (t.S.i !== t.i || !t.S.h() || t.S.i !== t.i)
      return !0
  return !1
}
function zt(e) {
  for (var t = e.s; t !== void 0; t = t.n) {
    var _ = t.S.n
    if (
      (_ !== void 0 && (t.r = _),
      (t.S.n = t),
      (t.i = -1),
      t.n === void 0)
    ) {
      e.s = t
      break
    }
  }
}
function Zt(e) {
  for (var t = e.s, _ = void 0; t !== void 0; ) {
    var n = t.p
    t.i === -1
      ? (t.S.U(t),
        n !== void 0 && (n.n = t.n),
        t.n !== void 0 && (t.n.p = n))
      : (_ = t),
      (t.S.n = t.r),
      t.r !== void 0 && (t.r = void 0),
      (t = n)
  }
  e.s = _
}
function C(e, t) {
  b.call(this, void 0),
    (this.x = e),
    (this.s = void 0),
    (this.g = J - 1),
    (this.f = 4),
    (this.W = t?.watched),
    (this.Z = t?.unwatched),
    (this.name = t?.name)
}
C.prototype = new b()
C.prototype.h = function () {
  if (((this.f &= -3), 1 & this.f)) return !1
  if ((36 & this.f) == 32 || ((this.f &= -5), this.g === J))
    return !0
  if (
    ((this.g = J), (this.f |= 1), this.i > 0 && !Bt(this))
  )
    return (this.f &= -2), !0
  var e = v
  try {
    zt(this), (v = this)
    var t = this.x()
    ;(16 & this.f || this.v !== t || this.i === 0) &&
      ((this.v = t), (this.f &= -17), this.i++)
  } catch (_) {
    ;(this.v = _), (this.f |= 16), this.i++
  }
  return (v = e), Zt(this), (this.f &= -2), !0
}
C.prototype.S = function (e) {
  if (this.t === void 0) {
    this.f |= 36
    for (var t = this.s; t !== void 0; t = t.n) t.S.S(t)
  }
  b.prototype.S.call(this, e)
}
C.prototype.U = function (e) {
  if (
    this.t !== void 0 &&
    (b.prototype.U.call(this, e), this.t === void 0)
  ) {
    this.f &= -33
    for (var t = this.s; t !== void 0; t = t.n) t.S.U(t)
  }
}
C.prototype.N = function () {
  if (!(2 & this.f)) {
    this.f |= 6
    for (var e = this.t; e !== void 0; e = e.x) e.t.N()
  }
}
Object.defineProperty(C.prototype, "value", {
  get: function () {
    if (1 & this.f) throw new Error("Cycle detected")
    var e = Gt(this)
    if (
      (this.h(),
      e !== void 0 && (e.i = this.i),
      16 & this.f)
    )
      throw this.v
    return this.v
  },
})
function Nt(e, t) {
  return new C(e, t)
}
function Jt(e) {
  var t = e.u
  if (((e.u = void 0), typeof t == "function")) {
    N++
    var _ = v
    v = void 0
    try {
      t()
    } catch (n) {
      throw ((e.f &= -2), (e.f |= 8), ht(e), n)
    } finally {
      ;(v = _), Y()
    }
  }
}
function ht(e) {
  for (var t = e.s; t !== void 0; t = t.n) t.S.U(t)
  ;(e.x = void 0), (e.s = void 0), Jt(e)
}
function ve(e) {
  if (v !== this) throw new Error("Out-of-order effect")
  Zt(this),
    (v = e),
    (this.f &= -2),
    8 & this.f && ht(this),
    Y()
}
function P(e, t) {
  ;(this.x = e),
    (this.u = void 0),
    (this.s = void 0),
    (this.o = void 0),
    (this.f = 32),
    (this.name = t?.name)
}
P.prototype.c = function () {
  var e = this.S()
  try {
    if (8 & this.f || this.x === void 0) return
    var t = this.x()
    typeof t == "function" && (this.u = t)
  } finally {
    e()
  }
}
P.prototype.S = function () {
  if (1 & this.f) throw new Error("Cycle detected")
  ;(this.f |= 1), (this.f &= -9), Jt(this), zt(this), N++
  var e = v
  return (v = this), ve.bind(this, e)
}
P.prototype.N = function () {
  2 & this.f || ((this.f |= 2), (this.o = M), (M = this))
}
P.prototype.d = function () {
  ;(this.f |= 8), 1 & this.f || ht(this)
}
P.prototype.dispose = function () {
  this.d()
}
function V(e, t) {
  var _ = new P(e, t)
  try {
    _.c()
  } catch (r) {
    throw (_.d(), r)
  }
  var n = _.d.bind(_)
  return (n[Symbol.dispose] = n), n
}
var Kt,
  _t,
  Qt = []
V(function () {
  Kt = this.N
})()
function U(e, t) {
  p[e] = t.bind(null, p[e] || function () {})
}
function K(e) {
  _t && _t(), (_t = e && e.S())
}
function Xt(e) {
  var t = this,
    _ = e.data,
    n = de(_)
  n.value = _
  var r = se(function () {
      for (var u = t, l = t.__v; (l = l.__); )
        if (l.__c) {
          l.__c.__$f |= 4
          break
        }
      var s = Nt(function () {
          var c = n.value.value
          return c === 0 ? 0 : c === !0 ? "" : c || ""
        }),
        a = Nt(function () {
          return !Array.isArray(s.value) && !Ct(s.value)
        }),
        o = V(function () {
          if (((this.N = Yt), a.value)) {
            var c = s.value
            u.__v &&
              u.__v.__e &&
              u.__v.__e.nodeType === 3 &&
              (u.__v.__e.data = c)
          }
        }),
        h = t.__$u.d
      return (
        (t.__$u.d = function () {
          o(), h.call(this)
        }),
        [a, s]
      )
    }, []),
    i = r[0],
    f = r[1]
  return i.value ? f.peek() : f.value
}
Xt.displayName = "ReactiveTextNode"
Object.defineProperties(b.prototype, {
  constructor: { configurable: !0, value: void 0 },
  type: { configurable: !0, value: Xt },
  props: {
    configurable: !0,
    get: function () {
      return { data: this }
    },
  },
  __b: { configurable: !0, value: 1 },
})
U("__b", function (e, t) {
  if (
    (typeof t.type == "function" &&
      typeof window < "u" &&
      window.__PREACT_SIGNALS_DEVTOOLS__ &&
      window.__PREACT_SIGNALS_DEVTOOLS__.exitComponent(),
    typeof t.type == "string")
  ) {
    var _,
      n = t.props
    for (var r in n)
      if (r !== "children") {
        var i = n[r]
        i instanceof b &&
          (_ || (t.__np = _ = {}),
          (_[r] = i),
          (n[r] = i.peek()))
      }
  }
  e(t)
})
U("__r", function (e, t) {
  if (
    (typeof t.type == "function" &&
      typeof window < "u" &&
      window.__PREACT_SIGNALS_DEVTOOLS__ &&
      window.__PREACT_SIGNALS_DEVTOOLS__.enterComponent(
        t.type.displayName || t.type.name || "Unknown",
      ),
    t.type !== W)
  ) {
    K()
    var _,
      n = t.__c
    n &&
      ((n.__$f &= -2),
      (_ = n.__$u) === void 0 &&
        (n.__$u = _ =
          (function (r) {
            var i
            return (
              V(function () {
                i = this
              }),
              (i.c = function () {
                ;(n.__$f |= 1), n.setState({})
              }),
              i
            )
          })())),
      K(_)
  }
  e(t)
})
U("__e", function (e, t, _, n) {
  typeof window < "u" &&
    window.__PREACT_SIGNALS_DEVTOOLS__ &&
    window.__PREACT_SIGNALS_DEVTOOLS__.exitComponent(),
    K(),
    e(t, _, n)
})
U("diffed", function (e, t) {
  typeof t.type == "function" &&
    typeof window < "u" &&
    window.__PREACT_SIGNALS_DEVTOOLS__ &&
    window.__PREACT_SIGNALS_DEVTOOLS__.exitComponent(),
    K()
  var _
  if (typeof t.type == "string" && (_ = t.__e)) {
    var n = t.__np,
      r = t.props
    if (n) {
      var i = _.U
      if (i)
        for (var f in i) {
          var u = i[f]
          u !== void 0 &&
            !(f in n) &&
            (u.d(), (i[f] = void 0))
        }
      else (i = {}), (_.U = i)
      for (var l in n) {
        var s = i[l],
          a = n[l]
        s === void 0
          ? ((s = pe(_, l, a, r)), (i[l] = s))
          : s.o(a, r)
      }
    }
  }
  e(t)
})
function pe(e, t, _, n) {
  var r = t in e && e.ownerSVGElement === void 0,
    i = jt(_)
  return {
    o: function (f, u) {
      ;(i.value = f), (n = u)
    },
    d: V(function () {
      this.N = Yt
      var f = i.value.value
      n[t] !== f &&
        ((n[t] = f),
        r
          ? (e[t] = f)
          : f
            ? e.setAttribute(t, f)
            : e.removeAttribute(t))
    }),
  }
}
U("unmount", function (e, t) {
  if (typeof t.type == "string") {
    var _ = t.__e
    if (_) {
      var n = _.U
      if (n) {
        _.U = void 0
        for (var r in n) {
          var i = n[r]
          i && i.d()
        }
      }
    }
  } else {
    var f = t.__c
    if (f) {
      var u = f.__$u
      u && ((f.__$u = void 0), u.d())
    }
  }
  e(t)
})
U("__h", function (e, t, _, n) {
  ;(n < 3 || n === 9) && (t.__$f |= 2), e(t, _, n)
})
F.prototype.shouldComponentUpdate = function (e, t) {
  var _ = this.__$u,
    n = _ && _.s !== void 0
  for (var r in t) return !0
  if (
    this.__f ||
    (typeof this.u == "boolean" && this.u === !0)
  ) {
    var i = 2 & this.__$f
    if (!(n || i || 4 & this.__$f) || 1 & this.__$f)
      return !0
  } else if (!(n || 4 & this.__$f) || 3 & this.__$f)
    return !0
  for (var f in e)
    if (f !== "__source" && e[f] !== this.props[f])
      return !0
  for (var u in this.props) if (!(u in e)) return !0
  return !1
}
function de(e, t) {
  return fe(function () {
    return jt(e, t)
  })[0]
}
var ye = function (e) {
  queueMicrotask(function () {
    queueMicrotask(e)
  })
}
function me() {
  he(function () {
    for (var e; (e = Qt.shift()); ) Kt.call(e)
  })
}
function Yt() {
  Qt.push(this) === 1 && (p.requestAnimationFrame || ye)(me)
}
export {
  we as E,
  fe as a,
  jt as d,
  W as k,
  ge as u,
  $e as y,
}
