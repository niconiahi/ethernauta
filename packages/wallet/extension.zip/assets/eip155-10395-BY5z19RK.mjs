const n = {
  name: "WorldLand Testnet",
  shortName: "TWLC",
  chain: "Worldland",
  icon: "worldland",
  rpc: ["https://gwangju.worldland.foundation"],
  faucets: [],
  nativeCurrency: {
    name: "Worldland",
    symbol: "WLC",
    decimals: 18
  },
  infoURL: "https://worldland.foundation",
  chainId: 10395,
  networkId: 10395,
  slip44: 1,
  explorers: [
    {
      name: "Worldland Explorer",
      url: "https://testscan.worldland.foundation",
      standard: "EIP3091"
    }
  ]
};
export {
  n as eip155_10395
};
