const e = {
  name: "CheeseChain",
  shortName: "CheeseChain",
  title: "CheeseChain",
  chain: "CHEESE",
  icon: "cheesechain",
  rpc: ["https://rpc.cheesechain.xyz"],
  faucets: [],
  nativeCurrency: {
    name: "CHEESE",
    symbol: "CHEESE",
    decimals: 18
  },
  infoURL: "https://cheesechain.xyz",
  chainId: 383353,
  networkId: 383353
};
export {
  e as eip155_383353
};
