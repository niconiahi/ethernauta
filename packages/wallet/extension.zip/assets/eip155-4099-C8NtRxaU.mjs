const i = {
  name: "Bitindi Mainnet",
  shortName: "BNIm",
  chain: "BNI",
  icon: "bitindi",
  rpc: ["https://mainnet-rpc.bitindi.org"],
  faucets: ["https://faucet.bitindi.org"],
  nativeCurrency: {
    name: "BNI",
    symbol: "$BNI",
    decimals: 18
  },
  infoURL: "https://bitindi.org",
  chainId: 4099,
  networkId: 4099,
  explorers: [
    {
      name: "Bitindi",
      url: "https://bitindiscan.com",
      standard: "EIP3091"
    }
  ]
};
export {
  i as eip155_4099
};
