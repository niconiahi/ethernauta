const a = {
  name: "CLV Parachain",
  shortName: "clv",
  chain: "CLV",
  rpc: ["https://api-para.clover.finance"],
  faucets: [],
  nativeCurrency: {
    name: "CLV",
    symbol: "CLV",
    decimals: 18
  },
  infoURL: "https://clv.org",
  chainId: 1024,
  networkId: 1024
};
export {
  a as eip155_1024
};
