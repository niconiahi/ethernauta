import {
  y as k,
  d as R,
  u as s,
  k as ve,
  a as Ne,
  E as Ye,
} from "./preact-10.26.9-0icXUSiy.mjs"
import {
  c as I,
  o as p,
  a as d,
  b as w,
  p as E,
  u as Q,
  s as l,
  n as z,
  k as S,
  d as N,
  l as h,
  e as P,
  f as ze,
  r as X,
  g as Xe,
  t as q,
  h as f,
  i as Qe,
  v as Ze,
  m as et,
  H as oe,
  j as tt,
  w as nt,
  q as W,
  x as Ae,
  y as Z,
  z as rt,
  A as pe,
  B as st,
  C as at,
  D as ot,
  E as it,
} from "./vendor-Bb8YCiiY.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const a of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(a)
  new MutationObserver((a) => {
    for (const o of a)
      if (o.type === "childList")
        for (const i of o.addedNodes)
          i.tagName === "LINK" &&
            i.rel === "modulepreload" &&
            r(i)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(a) {
    const o = {}
    return (
      a.integrity && (o.integrity = a.integrity),
      a.referrerPolicy &&
        (o.referrerPolicy = a.referrerPolicy),
      a.crossOrigin === "use-credentials"
        ? (o.credentials = "include")
        : a.crossOrigin === "anonymous"
          ? (o.credentials = "omit")
          : (o.credentials = "same-origin"),
      o
    )
  }
  function r(a) {
    if (a.ep) return
    a.ep = !0
    const o = n(a)
    fetch(a.href, o)
  }
})()
function ct(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const g = I(ct)
function lt(e) {
  return (
    typeof e == "string" &&
    /^0x([0-9,a-f,A-F]?){1,2}$/.test(e)
  )
}
const dt = I(lt)
function ut(e) {
  return typeof e == "string" && /^0x[0-9a-f]*$/.test(e)
}
const he = I(ut)
function mt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const ft = I(mt)
function pt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const ie = I(pt)
function ht(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const b = I(ht)
function gt(e) {
  return (
    typeof e == "string" && /^0x[0-9a-f]{1,64}$/.test(e)
  )
}
const yt = I(gt),
  xt = p({
    chainId: b,
    chainName: l(),
    nativeCurrency: p({
      name: l(),
      symbol: l(),
      decimals: z(),
    }),
    rpcUrls: w(E(l(), Q())),
    blockExplorerUrls: d(w(E(l(), Q()))),
    iconUrls: d(w(E(l(), Q()))),
  }),
  ge = "0123456789abcdef"
function O(e) {
  let t = ""
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    ;(t += ge[r >> 4]), (t += ge[r & 15])
  }
  return `0x${t}`
}
function _t(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
const ye = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15,
}
function v(e) {
  const t = _t(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    const a = ye[t[r]],
      o = ye[t[r + 1]]
    if (a === void 0 || o === void 0)
      throw new Error("Invalid hex character")
    n[r / 2] = (a << 4) | o
  }
  return n
}
function H(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function Ee(...e) {
  let t = 0
  for (const a of e) t += a.length
  const n = new Uint8Array(t)
  let r = 0
  for (const a of e) n.set(a, r), (r += a.length)
  return n
}
function Se(e, t, n) {
  if (!n.has(e) && t[e]) {
    n.add(e)
    for (const r of t[e]) {
      const a = r.type.replace(/(\[\d*\])+$/, "")
      t[a] && Se(a, t, n)
    }
  }
}
function bt(e, t) {
  const n = new Set()
  return (
    Se(e, t, n),
    n.delete(e),
    [e, ...[...n].sort()]
      .map((a) => {
        const o = t[a] ?? []
        return `${a}(${o.map((i) => `${i.type} ${i.name}`).join(",")})`
      })
      .join("")
  )
}
function wt(e, t) {
  return S(new TextEncoder().encode(bt(e, t)))
}
function vt(e) {
  const t = new Uint8Array(32)
  let n = e < 0n ? (1n << 256n) + e : e
  for (let r = 31; r >= 0; r--)
    (t[r] = Number(n & 0xffn)), (n >>= 8n)
  return t
}
function Nt(e) {
  if (typeof e == "bigint") return e
  if (typeof e == "number" || typeof e == "string")
    return BigInt(e)
  throw new Error(
    `cannot coerce ${typeof e} to bigint for 712 numeric type`,
  )
}
function Ie(e, t, n) {
  const r = /(.*)\[(\d*)\]$/.exec(e)
  if (r) {
    const o = r[1],
      c = t.map((u) => Ie(o, u, n))
    return S(Ee(...c))
  }
  if (n[e]) return ce(e, n, t)
  if (e === "string") return S(new TextEncoder().encode(t))
  if (e === "bytes") return S(v(t))
  if (e === "address") {
    const o = new Uint8Array(32),
      i = v(t)
    return o.set(i, 12), o
  }
  if (e === "bool") {
    const o = new Uint8Array(32)
    return (o[31] = t ? 1 : 0), o
  }
  if (/^bytes(\d+)$/.exec(e)) {
    const o = new Uint8Array(32),
      i = v(t)
    return o.set(i, 0), o
  }
  if (/^u?int(\d+)?$/.test(e)) return vt(Nt(t))
  throw new Error(`unsupported 712 type: ${e}`)
}
function At(e, t, n) {
  const r = t[e]
  if (!r)
    throw new Error(`712: type ${e} not defined in types`)
  const a = [wt(e, t)]
  for (const o of r) a.push(Ie(o.type, n[o.name], t))
  return Ee(...a)
}
function ce(e, t, n) {
  return S(At(e, t, n))
}
function Et(e) {
  const t = []
  return (
    e.name !== void 0 &&
      t.push({ name: "name", type: "string" }),
    e.version !== void 0 &&
      t.push({ name: "version", type: "string" }),
    e.chainId !== void 0 &&
      t.push({ name: "chainId", type: "uint256" }),
    e.verifyingContract !== void 0 &&
      t.push({
        name: "verifyingContract",
        type: "address",
      }),
    e.salt !== void 0 &&
      t.push({ name: "salt", type: "bytes32" }),
    t
  )
}
function St(e) {
  const n = { EIP712Domain: Et(e) }
  return ce("EIP712Domain", n, e)
}
function It(e) {
  const t = St(e.domain),
    n = ce(e.primaryType, e.types, e.message),
    r = new Uint8Array(66)
  return (
    (r[0] = 25), (r[1] = 1), r.set(t, 2), r.set(n, 34), S(r)
  )
}
const se = E(
    l(),
    Xe(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  le = N([w(P()), X(l(), P())]),
  de = N([l(), z(), ze()]),
  Tt = p({
    jsonrpc: h("2.0"),
    method: se,
    params: d(le),
    id: de,
  }),
  Ft = p({
    data: d(P()),
    message: l(),
    code: N([
      h(-32e3),
      h(-32300),
      h(-32400),
      h(-32500),
      h(-32600),
      h(-32601),
      h(-32602),
      h(-32603),
      h(-32700),
      h(-32701),
      h(-32702),
    ]),
  }),
  kt = p({ id: de, jsonrpc: h("2.0"), error: Ft }),
  Rt = p({ id: de, jsonrpc: h("2.0"), result: P() }),
  Ct = N([kt, Rt]),
  Te = N([q([se, le]), q([se])])
function $t(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const Pt = I($t)
function Ut(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const Ot = I(Ut)
function Dt(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const Fe = I(Dt),
  Mt = ":"
function Bt({ namespace: e, reference: t }) {
  const n = f(Pt, e),
    r = f(Ot, typeof t == "number" ? String(t) : t),
    a = n + Mt + r
  return f(Fe, a)
}
function jt(e) {
  return async (t) => {
    const [n, r] = t,
      a = f(Tt, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: qt(r),
      }),
      o = await fetch(e, {
        method: "POST",
        body: JSON.stringify(a),
        headers: { "Content-Type": "application/json" },
      })
        .then((c) => c.json())
        .catch((c) => {
          throw new Error(c)
        })
    return f(Ct, o)
  }
}
function qt(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function Ht(e, t) {
  if (e.length !== t.length)
    throw new Error(
      `sequence length mismatch: ${e.length} codecs vs ${t.length} values`,
    )
  const n = e.length * 32,
    r = [],
    a = []
  for (let m = 0; m < e.length; m++) {
    const T = e[m],
      G = t[m]
    T.is_dynamic
      ? (r.push(new Uint8Array(32)), a.push(T.encode(G)))
      : (r.push(T.encode(G)), a.push(new Uint8Array(0)))
  }
  let o = n
  for (let m = 0; m < e.length; m++)
    e[m].is_dynamic &&
      ((r[m] = Kt(BigInt(o))), (o += a[m].length))
  const i = n + a.reduce((m, T) => m + T.length, 0),
    c = new Uint8Array(i)
  let u = 0
  for (const m of r) c.set(m, u), (u += 32)
  for (const m of a)
    m.length !== 0 && (c.set(m, u), (u += m.length))
  return c
}
function Lt(e, t, n) {
  const r = []
  for (let a = 0; a < e.length; a++) {
    const o = e[a],
      i = n + a * 32
    if (o.is_dynamic) {
      const c = Number(Gt(t, i))
      r.push(o.decode(t, n + c))
    } else r.push(o.decode(t, i))
  }
  return r
}
function Gt(e, t) {
  let n = 0n
  for (let r = 0; r < 32; r++)
    n = (n << 8n) | BigInt(e[t + r])
  return n
}
function Kt(e) {
  const t = new Uint8Array(32)
  let n = e
  for (let r = 31; r >= 0; r--)
    (t[r] = Number(n & 0xffn)), (n >>= 8n)
  return t
}
function ke(e, t) {
  const n = v(t)
  if (n.length < 4)
    throw new Error(`calldata too short: ${n.length} bytes`)
  const r = O(n.slice(0, 4)),
    a = n.slice(4),
    o = Lt(e, a, 0)
  return { selector: r, args: o }
}
function Re(e) {
  return S(new TextEncoder().encode(e)).slice(0, 4)
}
function Wt(e, t) {
  return `${e}(${t.map((n) => n.signature).join(",")})`
}
function Vt(e) {
  const { name: t, args: n, values: r } = e,
    a = Wt(t, n),
    o = Re(a),
    i = Ht(n, r),
    c = new Uint8Array(4 + i.length)
  return c.set(o, 0), c.set(i, 4), c
}
function Jt(e, t) {
  let n = 0n
  for (let r = 0; r < 32; r++)
    n = (n << 8n) | BigInt(e[t + r])
  return n
}
function Yt(e) {
  const t = new Uint8Array(32)
  let n = e
  for (let r = 31; r >= 0; r--)
    (t[r] = Number(n & 0xffn)), (n >>= 8n)
  return t
}
function zt(e, t) {
  if (e.length !== t)
    throw new Error(`expected ${t} bytes, got ${e.length}`)
  const n = new Uint8Array(32)
  return n.set(e, 32 - t), n
}
function Xt(e) {
  const t = Math.ceil(e.length / 32) * 32,
    n = new Uint8Array(t)
  return n.set(e, 0), n
}
function Qt() {
  return {
    signature: "address",
    is_dynamic: !1,
    schema: g,
    encode: (e) => {
      const t = e.slice(2),
        n = new Uint8Array(20)
      for (let r = 0; r < 20; r++)
        n[r] = Number.parseInt(
          t.slice(r * 2, r * 2 + 2),
          16,
        )
      return zt(n, 20)
    },
    decode: (e, t) => {
      const n = e.slice(t + 12, t + 32)
      return O(n)
    },
  }
}
function Zt() {
  return {
    signature: "string",
    is_dynamic: !0,
    schema: l(),
    encode: (e) => {
      const t = new TextEncoder().encode(e),
        n = new Uint8Array(32 + Xt(t).length)
      return n.set(Yt(BigInt(t.length)), 0), n.set(t, 32), n
    },
    decode: (e, t) => {
      const n = Number(Jt(e, t))
      return new TextDecoder().decode(
        e.slice(t + 32, t + 32 + n),
      )
    },
  }
}
function en(e, t) {
  const n = e.find((r) => r.chainId === t)
  if (!n) throw new Error(`no chain configured for: ${t}`)
  return n.transports
}
const tn = p({ chain_id: Fe })
function nn(e) {
  return (t) => {
    const n = f(tn, t)
    return [en(e, n.chain_id), n]
  }
}
const rn = p({ signature: l(), names: w(l()) }),
  sn = p({ function: d(rn) }),
  an = p({
    name: d(l()),
    version: d(l()),
    chainId: d(N([Qe(), z(), yt])),
    verifyingContract: d(g),
    salt: d(ft),
  }),
  on = p({ name: l(), type: l() }),
  cn = X(l(), w(on)),
  ln = p({
    domain: an,
    types: cn,
    primaryType: l(),
    message: X(l(), P()),
  }),
  xe = { iterations: 1e5, hash: "SHA-256" },
  _ = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function ee(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function te(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function Ce(e, t, n) {
  const r = new TextEncoder().encode(e),
    a = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: xe.iterations,
      hash: xe.hash,
    },
    a,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function ue() {
  return new Promise((e, t) => {
    const n = indexedDB.open(_.name, _.version)
    ;(n.onupgradeneeded = (r) => {
      const a = r.target.result
      a.objectStoreNames.contains(_.store_name) ||
        a.createObjectStore(_.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function dn(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    a = await Ce(t, n, ["encrypt"]),
    o = new TextEncoder().encode(e),
    i = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      a,
      o,
    ),
    c = {
      salt: ee(n.buffer),
      iv: ee(r.buffer),
      cipher: ee(i),
    },
    u = await ue()
  return new Promise((m, T) => {
    const M = u
      .transaction(_.store_name, "readwrite")
      .objectStore(_.store_name)
      .put(c, _.vault_key)
    ;(M.onsuccess = () => m()),
      (M.onerror = () =>
        T(
          new Error(
            `Failed to save vault: ${M.error?.message}`,
          ),
        ))
  })
}
async function $e(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await ue(),
    n = await new Promise((u, m) => {
      const D = t
        .transaction(_.store_name, "readonly")
        .objectStore(_.store_name)
        .get(_.vault_key)
      ;(D.onsuccess = () => {
        const M = D.result
        u(M)
      }),
        (D.onerror = () =>
          m(
            new Error(
              `Failed to load vault: ${D.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = te(n.salt),
    a = te(n.iv),
    o = te(n.cipher),
    i = await Ce(e, r, ["decrypt"]),
    c = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: a }, i, o)
      .catch((u) => {
        throw u instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unknown error")
      })
  return new TextDecoder().decode(c)
}
async function un() {
  const e = await ue()
  return new Promise((t) => {
    const a = e
      .transaction(_.store_name, "readonly")
      .objectStore(_.store_name)
      .get(_.vault_key)
    ;(a.onsuccess = () => t(!!a.result)),
      (a.onerror = () => t(!1))
  })
}
async function mn(e) {
  try {
    return (await $e(e)) !== void 0
  } catch {
    return !1
  }
}
function fn(e) {
  const t = e.trim().split(/\s+/)
  return [12, 15, 18, 21, 24].includes(t.length)
}
const pn = "password",
  x = k(pn)
async function Pe() {
  const e = Date.now()
  await chrome.storage.local.set({ timestamp: e })
}
async function hn() {
  return f(
    p({ timestamp: d(z()) }),
    await chrome.storage.local.get("timestamp"),
  ).timestamp
}
async function gn() {
  const e = Date.now(),
    t = await hn()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function yn() {
  ;(await un())
    ? (x.value = "password")
    : (x.value = "mnemonics")
}
const xn = p({
    id: l(),
    type: h("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: l(),
    chainId: l(),
    to: d(l()),
    params: d(N([w(P()), X(l(), P())])),
  }),
  _n = xn,
  A = k({
    id: "some-id",
    method: "hello_world",
    params: [],
  }),
  j = k(null),
  Ue = k(null),
  Oe = k(null),
  De = k(null)
function bn(e) {
  if (!Ze(e, nt)) throw new Error("Invalid mnemonic")
  return et(e)
}
function wn(e) {
  return oe.fromMasterSeed(e)
}
function vn(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function Nn(e) {
  const t = tt(e, !1),
    n = S(t.slice(1))
  return O(n.slice(-20))
}
function me(e) {
  const t = e.privateKey
  return H(t, "a private key should exist"), t
}
function V(e) {
  return BigInt(e)
}
const An = p({ address: l(), private_key: l() }),
  C = k({
    address: "",
    key: new oe({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function En(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.local.set({ wallet: t })
}
async function Sn() {
  const t = f(
    p({ wallet: d(An) }),
    await chrome.storage.local.get("wallet"),
  ).wallet
  t &&
    (C.value = {
      address: t.address,
      key: oe.fromExtendedKey(t.private_key),
    })
}
async function In(e) {
  const t = await $e(e)
  H(t, "vault should exist to sign in")
  const n = bn(t),
    r = wn(n),
    a = vn(r),
    o = Nn(a),
    i = r.derive("m/44'/60'/0'/0/0"),
    c = { address: o, key: i }
  ;(C.value = c), En(c)
}
function y({
  children: e,
  class: t,
  variant: n = "primary",
  ...r
}) {
  const [a, o] = R(!1)
  return s("button", {
    type: "button",
    onPointerDown: () => o(!0),
    onPointerUp: () => o(!1),
    onPointerLeave: () => o(!1),
    onTouchCancel: () => o(!1),
    class: [
      "border-2 rounded-md p-2 cursor-pointer text-base transition-colors",
      n === "secondary"
        ? "bg-[color-mix(in_srgb,#FF5005_12%,#faf5f0)] hover:bg-[color-mix(in_srgb,#FF5005_25%,#faf5f0)] border-[#FF5005] text-[#FF5005]"
        : "bg-[#FF5005] hover:bg-[#cc4004] border-[#c73d00] text-white",
      a
        ? "outline outline-2 outline-offset-2 outline-gray-700"
        : "",
      t,
    ]
      .filter(Boolean)
      .join(" "),
    ...r,
    children: e,
  })
}
function Tn() {
  const e = De.value
  if (!e)
    return s("main", {
      className: "p-4 w-80 text-sm text-gray-500",
      children: "No add-chain request pending.",
    })
  const { chain: t } = e
  return s("main", {
    className: "flex flex-col gap-3 p-4 w-80 text-base",
    children: [
      s("header", {
        className: "flex flex-col gap-1 text-center",
        children: [
          s("h1", {
            className: "text-xl font-bold leading-tight",
            children: "Add a new chain?",
          }),
          s("p", {
            className: "text-xs text-gray-500",
            children:
              "EIP-3085 — a site is asking your wallet to know this chain.",
          }),
        ],
      }),
      s("section", {
        className:
          "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2 text-sm",
        children: [
          s(B, { label: "Name", value: t.chainName }),
          s(B, { label: "Chain ID", value: t.chainId }),
          s(B, {
            label: "Native",
            value: `${t.nativeCurrency.name} (${t.nativeCurrency.symbol})`,
          }),
          s(B, {
            label: "RPC",
            value: t.rpcUrls[0] ?? "(none)",
          }),
          t.blockExplorerUrls?.[0] &&
            s(B, {
              label: "Explorer",
              value: t.blockExplorerUrls[0],
            }),
        ],
      }),
      s("div", {
        className: "flex flex-col gap-2",
        children: [
          s(y, {
            onClick: () => {
              const n = {
                id: e.id,
                type: "ETHERNAUTA_RESPONSE_ADD_CHAIN_APPROVED",
              }
              chrome.runtime.sendMessage(n), window.close()
            },
            children: "Approve",
          }),
          s(y, {
            variant: "secondary",
            onClick: () => {
              const n = {
                id: e.id,
                type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
              }
              chrome.runtime.sendMessage(n), window.close()
            },
            children: "Reject",
          }),
        ],
      }),
    ],
  })
}
function B({ label: e, value: t }) {
  return s("div", {
    className: "flex flex-col gap-0.5",
    children: [
      s("span", {
        className:
          "text-xs uppercase tracking-wide text-gray-500",
        children: e,
      }),
      s("span", {
        className: "font-mono break-all",
        children: t,
      }),
    ],
  })
}
function Fn(e) {
  return `${e.slice(0, 6)}…${e.slice(-4)}`
}
function kn() {
  const e = C.value.address
  return s("main", {
    className: "flex flex-col gap-4 p-4 w-80 text-base",
    children: [
      s("header", {
        className: "flex flex-col gap-1 text-center",
        children: [
          s("h1", {
            className: "text-xl font-bold leading-tight",
            children: "Connect to Ethernauta",
          }),
          s("p", {
            className: "text-sm text-gray-600",
            children:
              "A site is requesting access to your address.",
          }),
        ],
      }),
      s("section", {
        className:
          "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3",
        children: [
          s("p", {
            className:
              "text-xs uppercase tracking-wide text-gray-500",
            children: "Address",
          }),
          s("p", {
            className: "font-mono text-base font-semibold",
            title: e,
            children: Fn(e),
          }),
        ],
      }),
      s("div", {
        className: "flex flex-col gap-2",
        children: [
          s(y, {
            onClick: () => {
              const t = {
                id: j.value?.id ?? "",
                type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
                signed_transaction: JSON.stringify([e]),
              }
              chrome.runtime.sendMessage(t),
                (j.value = null),
                window.close()
            },
            children: "Connect",
          }),
          s(y, {
            variant: "secondary",
            onClick: () => {
              const t = {
                id: j.value?.id ?? "",
                type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
              }
              chrome.runtime.sendMessage(t),
                (j.value = null),
                window.close()
            },
            children: "Reject",
          }),
        ],
      }),
    ],
  })
}
const Rn = E(l(), Ae(8)),
  Cn = E(l(), Ae(1))
function $n() {
  const [e, t] = R(""),
    [n, r] = R(""),
    [a, o] = R("")
  return s("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      s("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (i) => {
          const c = i.currentTarget.value
          r(c), o("")
        },
      }),
      s("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (i) => {
          const c = i.currentTarget.value
          t(c), o("")
        },
      }),
      a
        ? s("p", {
            className: "text-red-500 text-sm",
            children: a,
          })
        : null,
      s(y, {
        onClick: async () => {
          const i = W(Cn, n)
          if (!i.success) {
            o(i.issues[0].message)
            return
          }
          if (!fn(i.output)) {
            o(
              "Invalid mnemonic: must be 12, 15, 18, 21, or 24 words",
            )
            return
          }
          const c = W(Rn, e)
          if (!c.success) {
            o(c.issues[0].message)
            return
          }
          await dn(i.output, c.output),
            await Pe(),
            (x.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function Pn() {
  const [e, t] = R(""),
    [n, r] = R("")
  return s("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      s("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const o = a.currentTarget.value
          t(o), r("")
        },
      }),
      n
        ? s("p", {
            className: "text-red-500 text-sm",
            children: n,
          })
        : null,
      s(y, {
        onClick: async () => {
          if (!(await mn(e))) {
            r("Invalid password")
            return
          }
          await Pe(), await In(e), (x.value = "wallet")
        },
        children: "Unlock",
      }),
    ],
  })
}
const Un = p({
    domain: l(),
    address: g,
    statement: d(l()),
    uri: l(),
    version: l(),
    chainId: l(),
    nonce: l(),
    issuedAt: E(l(), Z()),
    expirationTime: d(E(l(), Z())),
    notBefore: d(E(l(), Z())),
    requestId: d(l()),
    resources: d(w(l())),
  }),
  On =
    /^(?<domain>[^\s]+) wants you to sign in with your Ethereum account:\n(?<address>0x[0-9a-fA-F]{40})\n/,
  Dn = [
    ["URI", "uri"],
    ["Version", "version"],
    ["Chain ID", "chainId"],
    ["Nonce", "nonce"],
    ["Issued At", "issuedAt"],
    ["Expiration Time", "expirationTime"],
    ["Not Before", "notBefore"],
    ["Request ID", "requestId"],
  ]
function Mn(e) {
  const t = e.split(`
`),
    n = {}
  let r = 0
  for (; r < t.length; ) {
    const a = t[r] ?? ""
    if (a === "Resources:") {
      const o = []
      for (r += 1; r < t.length; ) {
        const i = t[r] ?? ""
        if (!i.startsWith("- ")) break
        o.push(i.slice(2)), (r += 1)
      }
      n.resources = o
      continue
    }
    for (const [o, i] of Dn) {
      const c = `${o}: `
      if (a.startsWith(c)) {
        n[i] = a.slice(c.length)
        break
      }
    }
    r += 1
  }
  return n
}
function Bn(e) {
  const t = On.exec(e)
  if (!t?.groups) return
  const n = e.slice(t[0].length),
    r = n.split(`

`),
    a = r[0] ?? "",
    o = r.length > 1 && a.trim() !== "" ? a : void 0,
    i =
      r.length > 1
        ? r.slice(1).join(`

`)
        : n,
    c = Mn(i),
    u = {
      domain: t.groups.domain,
      address: t.groups.address,
      statement: o,
      ...c,
    },
    m = W(Un, u)
  if (m.success) return m.output
}
const jn = `Ethereum Signed Message:
`
function Me(e) {
  return new TextEncoder().encode(e)
}
function qn(e) {
  return (
    e.startsWith("0x") &&
    e.length % 2 === 0 &&
    /^0x[0-9a-fA-F]*$/.test(e)
  )
}
function Hn(e) {
  return typeof e != "string" ? e : qn(e) ? v(e) : Me(e)
}
function Ln(e) {
  const t = Hn(e),
    n = Me(`${jn}${t.length}`),
    r = new Uint8Array(n.length + t.length)
  return r.set(n, 0), r.set(t, n.length), r
}
function fe(e, t) {
  return (
    (pe.hmacSha256Sync = (n, ...r) =>
      st(at, n, pe.concatBytes(...r))),
    rt(e, t)
  )
}
function Be(e) {
  const t = new Uint8Array(65),
    n = e.r.toString(16).padStart(64, "0"),
    r = e.s.toString(16).padStart(64, "0")
  for (let a = 0; a < 32; a++)
    (t[a] = Number.parseInt(n.slice(a * 2, a * 2 + 2), 16)),
      (t[32 + a] = Number.parseInt(
        r.slice(a * 2, a * 2 + 2),
        16,
      ))
  return (t[64] = 27 + e.recovery), O(t)
}
function Gn(e, t) {
  const n = S(Ln(e)),
    r = fe(n, t)
  return Be(r)
}
function Kn(e) {
  if (e.startsWith("0x"))
    try {
      const t = new Uint8Array(
        (e.slice(2).match(/.{1,2}/g) ?? []).map((n) =>
          Number.parseInt(n, 16),
        ),
      )
      return new TextDecoder("utf-8", { fatal: !0 }).decode(
        t,
      )
    } catch {
      return e
    }
  return e
}
function Wn({ siwe: e }) {
  return s("section", {
    className:
      "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2 text-sm",
    children: [
      s("p", {
        className:
          "text-xs uppercase tracking-wide text-gray-500",
        children: "Sign in with Ethereum",
      }),
      s($, { label: "Site", value: e.domain }),
      s($, { label: "URI", value: e.uri }),
      s($, { label: "Chain ID", value: e.chainId }),
      s($, { label: "Nonce", value: e.nonce }),
      s($, { label: "Issued", value: e.issuedAt }),
      e.expirationTime &&
        s($, { label: "Expires", value: e.expirationTime }),
      e.statement &&
        s($, { label: "Statement", value: e.statement }),
    ],
  })
}
function $({ label: e, value: t }) {
  return s("div", {
    className: "flex flex-col gap-0.5",
    children: [
      s("span", {
        className:
          "text-xs uppercase tracking-wide text-gray-500",
        children: e,
      }),
      s("span", {
        className: "font-mono break-all",
        children: t,
      }),
    ],
  })
}
function Vn() {
  const e = Oe.value
  if (!e)
    return s("main", {
      className: "p-4 w-80 text-sm text-gray-500",
      children: "No personal-sign request pending.",
    })
  const t = Kn(e.message),
    n = Bn(t)
  return s("main", {
    className: "flex flex-col gap-3 p-4 w-80 text-base",
    children: [
      s("header", {
        className: "flex flex-col gap-1 text-center",
        children: [
          s("h1", {
            className: "text-xl font-bold leading-tight",
            children: "You are about to sign a message",
          }),
          s("p", {
            className: "text-xs text-gray-500",
            children: "EIP-191 — prefixed personal_sign.",
          }),
        ],
      }),
      s("section", {
        className:
          "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2",
        children: [
          s("p", {
            className:
              "text-xs uppercase tracking-wide text-gray-500",
            children: "Account",
          }),
          s("p", {
            className: "font-mono text-xs break-all",
            children: e.address,
          }),
        ],
      }),
      n
        ? s(Wn, { siwe: n })
        : s("section", {
            className:
              "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2",
            children: [
              s("p", {
                className:
                  "text-xs uppercase tracking-wide text-gray-500",
                children: "Message",
              }),
              s("pre", {
                className:
                  "whitespace-pre-wrap break-words text-sm font-mono",
                children: t,
              }),
            ],
          }),
      s("div", {
        className: "flex flex-col gap-2",
        children: [
          s(y, {
            onClick: () => {
              const r = me(C.value.key),
                a = Gn(e.message, r),
                o = {
                  id: e.id,
                  type: "ETHERNAUTA_RESPONSE_PERSONAL_SIGNED",
                  signature: a,
                }
              chrome.runtime.sendMessage(o), window.close()
            },
            children: "Sign",
          }),
          s(y, {
            variant: "secondary",
            onClick: () => {
              const r = {
                id: e.id,
                type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
              }
              chrome.runtime.sendMessage(r), window.close()
            },
            children: "Reject",
          }),
        ],
      }),
    ],
  })
}
const _e = { name: "Ethereum Mainnet", chainId: 1 },
  ae = { name: "Ethereum Sepolia", chainId: 11155111 },
  je = [
    {
      id: ae.chainId,
      name: ae.name,
      rpc_url:
        "https://ethereum-sepolia-rpc.publicnode.com",
    },
    {
      id: _e.chainId,
      name: _e.name,
      rpc_url: "https://ethereum-rpc.publicnode.com",
    },
  ],
  U = k(je[0]),
  Jn = "eip155"
function qe(e) {
  return Bt({ namespace: Jn, reference: e.id })
}
function He(e) {
  const t = qe(e)
  return {
    chain_id: t,
    reader: nn([
      { chainId: t, transports: [jt(e.rpc_url)] },
    ]),
  }
}
function Yn(e) {
  return `0x${e.id.toString(16)}`
}
function zn(e) {
  return je.find((t) => t.id === e)
}
function Xn(e) {
  ;(U.value = e),
    chrome.runtime.sendMessage({
      type: "ETHERNAUTA_NOTIFICATION_CHAIN_SELECTED",
      chainId: Yn(e),
    })
}
function Qn(e) {
  const t = e.trim()
  if (t === "") return
  const n = /^eip155:(\d+)$/.exec(t)
  if (n) return Number(n[1])
  if (/^0x[0-9a-fA-F]+$/.test(t))
    return Number.parseInt(t.slice(2), 16)
  if (/^\d+$/.test(t)) return Number(t)
}
function Zn() {
  const [e, t] = R(""),
    [n, r] = R(null)
  function a(o) {
    o.preventDefault()
    const i = Qn(e)
    if (i === void 0) {
      r(
        "expected decimal (1), hex (0x1), or CAIP-2 (eip155:1)",
      )
      return
    }
    const c = zn(i)
    if (!c) {
      r(`chain ${i} is not in the wallet's registry`)
      return
    }
    Xn(c), (x.value = "wallet")
  }
  return s("main", {
    className: "flex flex-col gap-3 p-4 w-80 text-base",
    children: [
      s("header", {
        className: "flex flex-col gap-1 text-center",
        children: [
          s("h1", {
            className: "text-xl font-bold leading-tight",
            children: "Select a chain",
          }),
          s("p", {
            className: "text-xs text-gray-500",
            children:
              "Type a chain id — decimal, hex, or CAIP-2.",
          }),
        ],
      }),
      s("form", {
        className: "flex flex-col gap-2",
        onSubmit: a,
        children: [
          s("input", {
            type: "text",
            className:
              "bg-white p-2 border-2 rounded-md text-base font-mono",
            value: e,
            placeholder:
              "e.g. 1, 0xaa36a7, eip155:11155111",
            onInput: (o) => {
              t(o.currentTarget.value), r(null)
            },
            autoFocus: !0,
          }),
          n &&
            s("p", {
              className: "text-xs text-red-700",
              children: n,
            }),
          s(y, { type: "submit", children: "Switch" }),
          s(y, {
            variant: "secondary",
            onClick: () => {
              x.value = "wallet"
            },
            children: "Cancel",
          }),
        ],
      }),
    ],
  })
}
const er = {
    "0x00fdd58e": {
      name: "balanceOf",
      signature: "balanceOf(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "id"],
    },
    "0x01e1d114": {
      name: "totalAssets",
      signature: "totalAssets()",
      types: [],
      param_names: [],
    },
    "0x01ffc9a7": {
      name: "supportsInterface",
      signature: "supportsInterface(bytes4)",
      types: ["bytes4"],
      param_names: ["interfaceId"],
    },
    "0x06fdde03": {
      name: "name",
      signature: "name()",
      types: [],
      param_names: [],
    },
    "0x07a2d13a": {
      name: "convertToAssets",
      signature: "convertToAssets(uint256)",
      types: ["uint256"],
      param_names: ["shares"],
    },
    "0x081812fc": {
      name: "getApproved",
      signature: "getApproved(uint256)",
      types: ["uint256"],
      param_names: ["tokenId"],
    },
    "0x095ea7b3": {
      name: "approve",
      signature: "approve(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["spender", "value"],
    },
    "0x0a28a477": {
      name: "previewWithdraw",
      signature: "previewWithdraw(uint256)",
      types: ["uint256"],
      param_names: ["assets"],
    },
    "0x0e89341c": {
      name: "uri",
      signature: "uri(uint256)",
      types: ["uint256"],
      param_names: ["id"],
    },
    "0x141a468c": {
      name: "nonces",
      signature: "nonces(uint256)",
      types: ["uint256"],
      param_names: ["tokenId"],
    },
    "0x18160ddd": {
      name: "totalSupply",
      signature: "totalSupply()",
      types: [],
      param_names: [],
    },
    "0x205c2878": {
      name: "withdrawTo",
      signature: "withdrawTo(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "value"],
    },
    "0x23b872dd": {
      name: "transferFrom",
      signature: "transferFrom(address,address,uint256)",
      types: ["address", "address", "uint256"],
      param_names: ["from", "to", "value"],
    },
    "0x2a55205a": {
      name: "royaltyInfo",
      signature: "royaltyInfo(uint256,uint256)",
      types: ["uint256", "uint256"],
      param_names: ["tokenId", "salePrice"],
    },
    "0x2f4f21e2": {
      name: "depositFor",
      signature: "depositFor(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "value"],
    },
    "0x2f745c59": {
      name: "tokenOfOwnerByIndex",
      signature: "tokenOfOwnerByIndex(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["owner", "index"],
    },
    "0x313ce567": {
      name: "decimals",
      signature: "decimals()",
      types: [],
      param_names: [],
    },
    "0x355274ea": {
      name: "cap",
      signature: "cap()",
      types: [],
      param_names: [],
    },
    "0x3644e515": {
      name: "DOMAIN_SEPARATOR",
      signature: "DOMAIN_SEPARATOR()",
      types: [],
      param_names: [],
    },
    "0x38d52e0f": {
      name: "asset",
      signature: "asset()",
      types: [],
      param_names: [],
    },
    "0x3a46b1a8": {
      name: "getPastVotes",
      signature: "getPastVotes(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "timepoint"],
    },
    "0x3f4ba83a": {
      name: "unpause",
      signature: "unpause()",
      types: [],
      param_names: [],
    },
    "0x402d267d": {
      name: "maxDeposit",
      signature: "maxDeposit(address)",
      types: ["address"],
      param_names: ["receiver"],
    },
    "0x40c10f19": {
      name: "mint",
      signature: "mint(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["to", "value"],
    },
    "0x42842e0e": {
      name: "safeTransferFrom",
      signature:
        "safeTransferFrom(address,address,uint256)",
      types: ["address", "address", "uint256"],
      param_names: ["from", "to", "tokenId"],
    },
    "0x42966c68": {
      name: "burn",
      signature: "burn(uint256)",
      types: ["uint256"],
      param_names: ["value"],
    },
    "0x4cdad506": {
      name: "previewRedeem",
      signature: "previewRedeem(uint256)",
      types: ["uint256"],
      param_names: ["shares"],
    },
    "0x4f6ccce7": {
      name: "tokenByIndex",
      signature: "tokenByIndex(uint256)",
      types: ["uint256"],
      param_names: ["index"],
    },
    "0x587cde1e": {
      name: "delegates",
      signature: "delegates(address)",
      types: ["address"],
      param_names: ["account"],
    },
    "0x5c19a95c": {
      name: "delegate",
      signature: "delegate(address)",
      types: ["address"],
      param_names: ["delegatee"],
    },
    "0x5c975abb": {
      name: "paused",
      signature: "paused()",
      types: [],
      param_names: [],
    },
    "0x5cffe9de": {
      name: "flashLoan",
      signature: "flashLoan(address,address,uint256,bytes)",
      types: ["address", "address", "uint256", "bytes"],
      param_names: ["receiver", "token", "value", "data"],
    },
    "0x613255ab": {
      name: "maxFlashLoan",
      signature: "maxFlashLoan(address)",
      types: ["address"],
      param_names: ["token"],
    },
    "0x6352211e": {
      name: "ownerOf",
      signature: "ownerOf(uint256)",
      types: ["uint256"],
      param_names: ["tokenId"],
    },
    "0x6e553f65": {
      name: "deposit",
      signature: "deposit(uint256,address)",
      types: ["uint256", "address"],
      param_names: ["assets", "receiver"],
    },
    "0x6f307dc3": {
      name: "underlying",
      signature: "underlying()",
      types: [],
      param_names: [],
    },
    "0x70a08231": {
      name: "balanceOf",
      signature: "balanceOf(address)",
      types: ["address"],
      param_names: ["account"],
    },
    "0x745a41bc": {
      name: "permit",
      signature: "permit(address,uint256,uint256,bytes)",
      types: ["address", "uint256", "uint256", "bytes"],
      param_names: [
        "spender",
        "tokenId",
        "deadline",
        "signature",
      ],
    },
    "0x79cc6790": {
      name: "burnFrom",
      signature: "burnFrom(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "value"],
    },
    "0x7ecebe00": {
      name: "nonces",
      signature: "nonces(address)",
      types: ["address"],
      param_names: ["owner"],
    },
    "0x8456cb59": {
      name: "pause",
      signature: "pause()",
      types: [],
      param_names: [],
    },
    "0x8e539e8c": {
      name: "getPastTotalSupply",
      signature: "getPastTotalSupply(uint256)",
      types: ["uint256"],
      param_names: ["timepoint"],
    },
    "0x94bf804d": {
      name: "mint",
      signature: "mint(uint256,address)",
      types: ["uint256", "address"],
      param_names: ["shares", "receiver"],
    },
    "0x95d89b41": {
      name: "symbol",
      signature: "symbol()",
      types: [],
      param_names: [],
    },
    "0x9ab24eb0": {
      name: "getVotes",
      signature: "getVotes(address)",
      types: ["address"],
      param_names: ["account"],
    },
    "0xa22cb465": {
      name: "setApprovalForAll",
      signature: "setApprovalForAll(address,bool)",
      types: ["address", "bool"],
      param_names: ["operator", "approved"],
    },
    "0xa9059cbb": {
      name: "transfer",
      signature: "transfer(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["to", "value"],
    },
    "0xb3d7f6b9": {
      name: "previewMint",
      signature: "previewMint(uint256)",
      types: ["uint256"],
      param_names: ["shares"],
    },
    "0xb460af94": {
      name: "withdraw",
      signature: "withdraw(uint256,address,address)",
      types: ["uint256", "address", "address"],
      param_names: ["assets", "receiver", "owner"],
    },
    "0xb88d4fde": {
      name: "safeTransferFrom",
      signature:
        "safeTransferFrom(address,address,uint256,bytes)",
      types: ["address", "address", "uint256", "bytes"],
      param_names: ["from", "to", "tokenId", "data"],
    },
    "0xba087652": {
      name: "redeem",
      signature: "redeem(uint256,address,address)",
      types: ["uint256", "address", "address"],
      param_names: ["shares", "receiver", "owner"],
    },
    "0xc3cda520": {
      name: "delegateBySig",
      signature:
        "delegateBySig(address,uint256,uint256,uint8,bytes32,bytes32)",
      types: [
        "address",
        "uint256",
        "uint256",
        "uint8",
        "bytes32",
        "bytes32",
      ],
      param_names: [
        "delegatee",
        "nonce",
        "expiry",
        "v",
        "r",
        "s",
      ],
    },
    "0xc63d75b6": {
      name: "maxMint",
      signature: "maxMint(address)",
      types: ["address"],
      param_names: ["receiver"],
    },
    "0xc6e6f592": {
      name: "convertToShares",
      signature: "convertToShares(uint256)",
      types: ["uint256"],
      param_names: ["assets"],
    },
    "0xc87b56dd": {
      name: "tokenURI",
      signature: "tokenURI(uint256)",
      types: ["uint256"],
      param_names: ["tokenId"],
    },
    "0xce96cb77": {
      name: "maxWithdraw",
      signature: "maxWithdraw(address)",
      types: ["address"],
      param_names: ["owner"],
    },
    "0xd505accf": {
      name: "permit",
      signature:
        "permit(address,address,uint256,uint256,uint8,bytes32,bytes32)",
      types: [
        "address",
        "address",
        "uint256",
        "uint256",
        "uint8",
        "bytes32",
        "bytes32",
      ],
      param_names: [
        "owner",
        "spender",
        "value",
        "deadline",
        "v",
        "r",
        "s",
      ],
    },
    "0xd905777e": {
      name: "maxRedeem",
      signature: "maxRedeem(address)",
      types: ["address"],
      param_names: ["owner"],
    },
    "0xd9d98ce4": {
      name: "flashFee",
      signature: "flashFee(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["token", "value"],
    },
    "0xdd62ed3e": {
      name: "allowance",
      signature: "allowance(address,address)",
      types: ["address", "address"],
      param_names: ["owner", "spender"],
    },
    "0xe985e9c5": {
      name: "isApprovedForAll",
      signature: "isApprovedForAll(address,address)",
      types: ["address", "address"],
      param_names: ["account", "operator"],
    },
    "0xef8b30f7": {
      name: "previewDeposit",
      signature: "previewDeposit(uint256)",
      types: ["uint256"],
      param_names: ["assets"],
    },
    "0xf242432a": {
      name: "safeTransferFrom",
      signature:
        "safeTransferFrom(address,address,uint256,uint256,bytes)",
      types: [
        "address",
        "address",
        "uint256",
        "uint256",
        "bytes",
      ],
      param_names: ["from", "to", "id", "value", "data"],
    },
  },
  tr = p({ address: g, storageKeys: w(ie) }),
  nr = w(tr),
  Le = p({
    type: d(dt),
    nonce: d(b),
    to: d(ot(g)),
    from: d(g),
    gas: d(b),
    value: d(b),
    input: d(he),
    gasPrice: d(b),
    maxPriorityFeePerGas: d(b),
    maxFeePerGas: d(b),
    maxFeePerBlobGas: d(b),
    accessList: d(nr),
    blobVersionedHashes: d(w(ie)),
    blobs: d(w(he)),
    chainId: d(b),
    _ethernauta: d(sn),
  }),
  rr = N([
    h("earliest"),
    h("finalized"),
    h("safe"),
    h("latest"),
    h("pending"),
  ]),
  J = N([b, rr, ie]),
  sr = N([
    q([g, J]),
    q([g]),
    p({ address: g, blockNumberOrTagOrHash: J }),
    p({ address: g }),
  ])
function ar(e) {
  return async ([t, n]) => {
    const r = "eth_getBalance",
      a = f(sr, e),
      o = f(Te, [r, a]),
      i = await Promise.any(t.map((u) => u(o)))
    if ("error" in i) throw new Error(i.error.message)
    return f(b, i.result)
  }
}
const or = N([
  q([g, J]),
  p({ address: g, blockNumberOrTagOrHash: J }),
])
function ir(e) {
  return async ([t, n]) => {
    const r = "eth_getTransactionCount",
      a = f(or, e),
      o = f(Te, [r, a]),
      i = await Promise.race(t.map((u) => u(o)))
    if ("error" in i) throw new Error(i.error.message)
    return f(b, i.result)
  }
}
function Ge(e) {
  return Array.isArray(e) ? lr(e) : cr(e)
}
function cr(e) {
  const t = dr(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const o = new Uint8Array(1 + t.length)
    return (o[0] = 128 + t.length), o.set(t, 1), o
  }
  const r = Ke(t.length),
    a = new Uint8Array(1 + r.length + t.length)
  return (
    (a[0] = 183 + r.length),
    a.set(r, 1),
    a.set(t, 1 + r.length),
    a
  )
}
function lr(e) {
  const t = e.map((i) => Ge(i)),
    n = t.reduce((i, c) => i + c.length, 0)
  if (n <= 55) {
    const i = new Uint8Array(1 + n)
    i[0] = 192 + n
    let c = 1
    for (const u of t) i.set(u, c), (c += u.length)
    return i
  }
  const r = Ke(n),
    a = new Uint8Array(1 + r.length + n)
  ;(a[0] = 247 + r.length), a.set(r, 1)
  let o = 1 + r.length
  for (const i of t) a.set(i, o), (o += i.length)
  return a
}
function dr(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? v(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return ur(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function ur(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return v(n)
}
function Ke(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function F(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return v(n)
}
function mr(e) {
  return BigInt(e)
}
async function fr(e, t, n) {
  const a = await ir([e, "latest"])(t({ chain_id: n }))
  return V(a)
}
function pr() {
  return BigInt(ae.chainId)
}
function hr() {
  return 1000000n
}
function gr() {
  return 20000000000n
}
function yr() {
  return 2000000000n
}
function xr(e, t, n) {
  switch (e) {
    case "eth_signTransaction": {
      const r = Array.isArray(t) ? t[0] : t.transaction,
        a = f(Le, r),
        o = a.value ?? "0x0",
        i = a.input ?? "0x",
        c = i === "0x" ? new Uint8Array([]) : v(i)
      return { to: a.to, value: V(o), data: c }
    }
    case "transfer": {
      const r = f(g, t[0]),
        a = f(E(l(), it()), t[1])
      return {
        to: r,
        value: V(a),
        data: new Uint8Array([]),
      }
    }
    case "safeMint": {
      const r = f(g, n),
        a = f(g, t[0]),
        o = f(l(), t[1])
      return {
        to: r,
        value: 0n,
        data: Vt({
          name: "safeMint",
          args: [Qt(), Zt()],
          values: [a, o],
        }),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function _r({
  key: e,
  nonce: t,
  method: n,
  params: r,
  to: a,
}) {
  const { to: o, value: i, data: c } = xr(n, r, a),
    u = {
      to: o,
      data: c,
      value: i,
      nonce: t,
      chain_id: pr(),
      gas_limit: hr(),
      max_fee_per_gas: gr(),
      max_priority_fee_per_gas: yr(),
    },
    m = me(e)
  return wr(u, m)
}
function br(e, t) {
  const n = We(e, t)
  return S(n)
}
function wr(e, t) {
  const n = Ar(e),
    r = be(n),
    a = new Uint8Array([2]),
    o = br(a, r),
    i = fe(o, t),
    c = Nr(n, i),
    u = be(c)
  return We(a, u)
}
function We(...e) {
  let t = 0
  for (const a of e) t += a.length
  const n = new Uint8Array(t)
  let r = 0
  for (const a of e) n.set(a, r), (r += a.length)
  return n
}
function vr(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    H(r, "access list item should exist")
    const a = new Array(r.storage_keys.length)
    for (let o = 0; o < r.storage_keys.length; o++) {
      const i = r.storage_keys[o]
      H(i, "storage key should exist"), (a[o] = v(i))
    }
    t[n] = [v(r.address), a]
  }
  return t
}
function Nr(e, t) {
  const n = new Array(12)
  H(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = mr(t.recovery)
  return (
    (n[9] = F(r)), (n[10] = F(t.r)), (n[11] = F(t.s)), n
  )
}
function Ar(e) {
  const t = new Array(9)
  return (
    (t[0] = F(e.chain_id)),
    (t[1] = F(e.nonce)),
    (t[2] = F(e.max_priority_fee_per_gas)),
    (t[3] = F(e.max_fee_per_gas)),
    (t[4] = F(e.gas_limit)),
    (t[5] = v(e.to)),
    (t[6] = F(e.value)),
    (t[7] = e.data),
    (t[8] = vr([])),
    t
  )
}
function be(e) {
  return Ge(e)
}
function Er(e) {
  return e == null
    ? ""
    : typeof e == "string"
      ? e
      : String(e)
}
function Sr(e) {
  return (
    typeof e == "object" && e !== null && !Array.isArray(e)
  )
}
function Ve(e) {
  return (
    typeof e == "string" &&
    e.startsWith("0x") &&
    e.length >= 10 &&
    (e.length - 2) % 2 === 0
  )
}
function Ir(e) {
  const n = er[e]
  if (n) return { ...n, source: "bundled" }
}
function Tr(e) {
  const t = e.indexOf("("),
    n = e.lastIndexOf(")")
  if (t <= 0 || n <= t || n !== e.length - 1) return
  const r = e.slice(0, t),
    a = e.slice(t + 1, n)
  return a.length === 0
    ? { name: r, types: [] }
    : { name: r, types: a.split(",") }
}
function Fr(e, t) {
  const n = Re(e)
  return O(n) === t.toLowerCase()
}
function kr(e, t) {
  if (!t || !Fr(t.signature, e)) return
  const n = Tr(t.signature)
  if (n)
    return {
      name: n.name,
      signature: t.signature,
      types: n.types,
      param_names: t.names,
      source: "sidecar",
    }
}
function Rr() {
  const e = A.value.params,
    t = Array.isArray(e) ? e[0] : e.transaction,
    n = W(Le, t)
  if (n.success) return n.output._ethernauta?.function
}
function Je(e) {
  const t = e.slice(0, 10).toLowerCase(),
    n = Rr()
  return kr(t, n) ?? Ir(t)
}
function Cr({ hex: e, entry: t, args: n }) {
  const r = Math.max(t.types.length, t.param_names.length),
    a = Array.from(
      { length: r },
      (o, i) => t.param_names[i] || t.types[i] || String(i),
    )
  return s("div", {
    className: "flex flex-col gap-1 text-xs",
    children: [
      s("div", {
        className: "font-mono font-bold break-all",
        children: [
          t.name,
          "(",
          t.types
            .map((o, i) =>
              `${o} ${t.param_names[i] ?? ""}`.trim(),
            )
            .join(", "),
          ")",
        ],
      }),
      s("dl", {
        className:
          "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
        children: a.map((o, i) =>
          s(L, { label: o, value: n[i] }, `${o}-${i}`),
        ),
      }),
      s("details", {
        className: "text-[10px] opacity-70",
        children: [
          s("summary", {
            className: "cursor-pointer",
            children: "raw",
          }),
          s("div", {
            className: "font-mono break-all pt-1",
            children: e,
          }),
        ],
      }),
    ],
  })
}
function L({ label: e, value: t }) {
  if (Ve(t)) {
    const n = Je(t)
    if (n)
      try {
        const { args: r } = ke([...n.types], t)
        return s("div", {
          className: "flex flex-col gap-0.5 text-xs",
          children: [
            s("dt", {
              className: "font-bold",
              children: e,
            }),
            s("dd", {
              children: s(Cr, {
                hex: t,
                entry: n,
                args: r,
              }),
            }),
          ],
        })
      } catch {}
  }
  return Sr(t)
    ? s("div", {
        className: "flex flex-col gap-1 text-xs",
        children: [
          s("span", {
            className: "font-bold",
            children: e,
          }),
          s("dl", {
            className:
              "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
            children: Object.entries(t).map(([n, r]) =>
              s(L, { label: n, value: r }, n),
            ),
          }),
        ],
      })
    : Array.isArray(t)
      ? s("div", {
          className: "flex flex-col gap-1 text-xs",
          children: [
            s("span", {
              className: "font-bold",
              children: e,
            }),
            s("dl", {
              className:
                "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
              children: t.map((n, r) =>
                s(
                  L,
                  { label: String(r), value: n },
                  `${e}-${r}`,
                ),
              ),
            }),
          ],
        })
      : s("div", {
          className: "flex flex-col gap-0.5 text-xs",
          children: [
            s("dt", {
              className: "font-bold",
              children: e,
            }),
            s("dd", {
              className: "font-mono break-all",
              children: Er(t),
            }),
          ],
        })
}
function $r() {
  const e = f(le, A.value.params),
    t = Array.isArray(e)
      ? e.map((n, r) => [String(r), n])
      : Object.entries(e)
  return s("dl", {
    className: "flex flex-col gap-2",
    children: t.map(([n, r]) =>
      s(L, { label: n, value: r }, n),
    ),
  })
}
function Pr() {
  const e = A.value.params
  let t
  if (
    (Array.isArray(e)
      ? (t = e[0])
      : e && typeof e == "object" && (t = e.transaction),
    !t || typeof t != "object")
  )
    return null
  const n = t
  return {
    to: typeof n.to == "string" ? n.to : void 0,
    value: typeof n.value == "string" ? n.value : void 0,
    input: typeof n.input == "string" ? n.input : void 0,
  }
}
function Ur(e) {
  return !e || e === "0x" || e === "0x0"
    ? !0
    : /^0x0+$/.test(e)
}
function Or(e) {
  if (!e || !Ve(e)) return null
  const t = Je(e)
  if (!t) return null
  try {
    const { args: n } = ke([...t.types], e)
    return { entry: t, args: n }
  } catch {
    return null
  }
}
function K({ children: e }) {
  return s("p", {
    className:
      "text-xs uppercase tracking-wide text-gray-500",
    children: e,
  })
}
function ne({ children: e }) {
  return s("p", {
    className: "font-mono text-sm font-semibold break-all",
    children: e,
  })
}
function Dr({
  to: e,
  value: t,
  input: n,
  entry: r,
  args: a,
}) {
  const o =
    r.param_names.length > 0
      ? r.param_names
      : r.types.map((i, c) => String(c))
  return s("section", {
    className:
      "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2",
    children: [
      e &&
        s("div", {
          className: "flex flex-col gap-0.5",
          children: [
            s(K, { children: "To" }),
            s(ne, { children: e }),
          ],
        }),
      !Ur(t) &&
        s("div", {
          className: "flex flex-col gap-0.5",
          children: [
            s(K, { children: "Value" }),
            s(ne, { children: t }),
          ],
        }),
      s("div", {
        className: "flex flex-col gap-0.5",
        children: [
          s(K, { children: "Method" }),
          s(ne, { children: r.name }),
        ],
      }),
      s("div", {
        className: "flex flex-col gap-1",
        children: [
          s(K, { children: "Params" }),
          s("dl", {
            className:
              "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
            children: o.map((i, c) =>
              s(L, { label: i, value: a[c] }, `${i}-${c}`),
            ),
          }),
        ],
      }),
      s("details", {
        className: "text-[10px] opacity-70",
        children: [
          s("summary", {
            className: "cursor-pointer",
            children: "raw",
          }),
          s("div", {
            className: "font-mono break-all pt-1",
            children: n,
          }),
        ],
      }),
    ],
  })
}
function Mr() {
  const e = Pr(),
    t = e ? Or(e.input) : null
  return s("main", {
    className: "flex flex-col gap-3 p-4 w-80 text-base",
    children: [
      s("header", {
        className: "flex flex-col gap-1 text-center",
        children: s("h1", {
          className: "text-xl font-bold leading-tight",
          children: "You are about to sign",
        }),
      }),
      t && e?.input
        ? s(Dr, {
            to: e.to,
            value: e.value,
            input: e.input,
            entry: t.entry,
            args: t.args,
          })
        : s(ve, {
            children: [
              s("section", {
                className:
                  "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3",
                children: [
                  s("p", {
                    className:
                      "text-xs uppercase tracking-wide text-gray-500",
                    children: "Method",
                  }),
                  s("p", {
                    className:
                      "font-mono text-sm font-semibold break-all",
                    children: A.value.method,
                  }),
                ],
              }),
              s("section", {
                className:
                  "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2",
                children: [
                  s("p", {
                    className:
                      "text-xs uppercase tracking-wide text-gray-500",
                    children: "Params",
                  }),
                  s($r, {}),
                ],
              }),
            ],
          }),
      s("div", {
        className: "flex flex-col gap-2",
        children: [
          s(y, {
            onClick: async () => {
              const n = C.value.address,
                r = C.value.key,
                { chain_id: a, reader: o } = He(U.value),
                i = await fr(n, o, a),
                c = await _r({
                  key: r,
                  nonce: i,
                  method: A.value.method,
                  params: A.value.params,
                  to: A.value.to,
                }),
                u = {
                  id: A.value.id,
                  type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
                  signed_transaction: O(c),
                }
              chrome.runtime.sendMessage(u), window.close()
            },
            children: "Sign",
          }),
          s(y, {
            variant: "secondary",
            onClick: () => {
              const n = {
                id: A.value.id,
                type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
              }
              chrome.runtime.sendMessage(n), window.close()
            },
            children: "Reject",
          }),
        ],
      }),
    ],
  })
}
function Br(e, t) {
  const n = It(e),
    r = fe(n, t)
  return Be(r)
}
function jr(e) {
  return e == null
    ? ""
    : typeof e == "bigint"
      ? e.toString()
      : typeof e == "string"
        ? e
        : String(e)
}
function qr(e) {
  return (
    typeof e == "object" && e !== null && !Array.isArray(e)
  )
}
function Y({ label: e, value: t }) {
  return qr(t)
    ? s("div", {
        className: "flex flex-col gap-1 text-xs",
        children: [
          s("span", {
            className: "font-bold",
            children: e,
          }),
          s("dl", {
            className:
              "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
            children: Object.entries(t).map(([n, r]) =>
              s(Y, { label: n, value: r }, n),
            ),
          }),
        ],
      })
    : Array.isArray(t)
      ? s("div", {
          className: "flex flex-col gap-1 text-xs",
          children: [
            s("span", {
              className: "font-bold",
              children: e,
            }),
            s("dl", {
              className:
                "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
              children: t.map((n, r) =>
                s(
                  Y,
                  { label: String(r), value: n },
                  `${e}-${r}`,
                ),
              ),
            }),
          ],
        })
      : s("div", {
          className: "flex flex-col gap-0.5 text-xs",
          children: [
            s("dt", {
              className: "font-bold",
              children: e,
            }),
            s("dd", {
              className: "font-mono break-all",
              children: jr(t),
            }),
          ],
        })
}
function re({ children: e }) {
  return s("p", {
    className:
      "text-xs uppercase tracking-wide text-gray-500",
    children: e,
  })
}
function Hr() {
  const e = Ue.value
  if (!e)
    return s("main", {
      className: "p-4 w-80 text-sm text-gray-500",
      children: "No typed-data request pending.",
    })
  const { typed_data: t } = e
  return s("main", {
    className: "flex flex-col gap-3 p-4 w-80 text-base",
    children: [
      s("header", {
        className: "flex flex-col gap-1 text-center",
        children: [
          s("h1", {
            className: "text-xl font-bold leading-tight",
            children: "You are about to sign typed data",
          }),
          s("p", {
            className: "text-xs text-gray-500",
            children:
              "EIP-712 — verify the domain matches the site you expect.",
          }),
        ],
      }),
      s("section", {
        className:
          "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2",
        children: [
          s(re, { children: "Domain" }),
          s(Y, { label: "Domain", value: t.domain }),
        ],
      }),
      s("section", {
        className:
          "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2",
        children: [
          s(re, { children: "Primary type" }),
          s("p", {
            className:
              "font-mono text-sm font-semibold break-all",
            children: t.primaryType,
          }),
        ],
      }),
      s("section", {
        className:
          "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2",
        children: [
          s(re, { children: "Message" }),
          s(Y, { label: t.primaryType, value: t.message }),
        ],
      }),
      s("div", {
        className: "flex flex-col gap-2",
        children: [
          s(y, {
            onClick: () => {
              const n = me(C.value.key),
                r = Br(t, n),
                a = {
                  id: e.id,
                  type: "ETHERNAUTA_RESPONSE_SIGNED_TYPED_DATA",
                  signature: r,
                }
              chrome.runtime.sendMessage(a), window.close()
            },
            children: "Sign",
          }),
          s(y, {
            variant: "secondary",
            onClick: () => {
              const n = {
                id: e.id,
                type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
              }
              chrome.runtime.sendMessage(n), window.close()
            },
            children: "Reject",
          }),
        ],
      }),
    ],
  })
}
const we = k(0n)
async function Lr(e) {
  const { chain_id: t, reader: n } = He(U.value),
    a = await ar([e, "latest"])(n({ chain_id: t }))
  return V(a)
}
function Gr(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    a = n.toString()
  if (r === 0n) return a
  const o = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${a}.${o}`
}
function Kr() {
  const e = C.value.address
  return (
    Ne(() => {
      async function t() {
        const n = await Lr(e)
        we.value = n
      }
      t()
    }, [U.value]),
    s("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        s("button", {
          type: "button",
          onClick: () => {
            x.value = "select-chain"
          },
          className:
            "self-start bg-white p-2 border-2 rounded-md cursor-pointer text-base",
          children: [qe(U.value), " —", " ", U.value.name],
        }),
        s("p", {
          className: "flex gap-1 text-base",
          children: [
            s("span", { children: "Address:" }),
            s("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: e,
            }),
          ],
        }),
        s("p", {
          className: "flex gap-1 text-base",
          children: [
            s("span", { children: "Balance:" }),
            s("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: Wr(Gr(we.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
      ],
    })
  )
}
function Wr(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function Vr() {
  return (
    Ne(() => {
      chrome.runtime.connect({ name: "popup" }),
        chrome.runtime.sendMessage({
          type: "ETHERNAUTA_NOTIFICATION_POPUP_READY",
        }),
        chrome.runtime.onMessage.addListener(async (e) => {
          const t = f(_n, e)
          if (
            t.type === "ETHERNAUTA_REQUEST_SIGN_TRANSACTION"
          ) {
            const n = await gn()
            if ((await yn(), !n)) return
            if (
              (await Sn(),
              t.method === "eth_requestAccounts")
            ) {
              ;(j.value = { id: t.id }),
                (x.value = "connect")
              return
            }
            if (t.method === "eth_signTypedData_v4") {
              const r = t.params,
                a = f(ln, r[1])
              ;(Ue.value = {
                id: t.id,
                address: r[0],
                typed_data: a,
              }),
                (x.value = "sign-typed-data")
              return
            }
            if (t.method === "personal_sign") {
              const r = t.params
              ;(Oe.value = {
                id: t.id,
                message: r[0],
                address: r[1],
              }),
                (x.value = "personal-sign")
              return
            }
            if (t.method === "wallet_addEthereumChain") {
              const r = t.params,
                a = f(xt, r[0])
              ;(De.value = { id: t.id, chain: a }),
                (x.value = "add-chain")
              return
            }
            ;(A.value = {
              id: t.id,
              method: t.method,
              params: t.params,
              to: t.to,
            }),
              (x.value = "sign")
          }
        })
    }, []),
    s(ve, { children: Jr(x.value) })
  )
}
function Jr(e) {
  switch (e) {
    case "mnemonics":
      return s($n, {})
    case "password":
      return s(Pn, {})
    case "wallet":
      return s(Kr, {})
    case "connect":
      return s(kn, {})
    case "sign":
      return s(Mr, {})
    case "sign-typed-data":
      return s(Hr, {})
    case "personal-sign":
      return s(Vn, {})
    case "add-chain":
      return s(Tn, {})
    case "select-chain":
      return s(Zn, {})
    default:
      return s("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Ye(s(Vr, {}), document.querySelector("#app"))
