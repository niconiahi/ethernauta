const t = {
  name: "KiteAI Testnet",
  shortName: "KiteAITestnet",
  chain: "KiteAI",
  icon: "kite",
  rpc: ["https://rpc-testnet.gokite.ai"],
  faucets: ["https://faucet.gokite.ai/"],
  nativeCurrency: {
    name: "Kite",
    symbol: "KITE",
    decimals: 18
  },
  infoURL: "https://gokite.ai/",
  chainId: 2368,
  networkId: 1,
  slip44: 1,
  explorers: [
    {
      name: "Kitescan",
      url: "https://testnet.kitescan.ai",
      standard: "EIP3091"
    }
  ]
};
export {
  t as eip155_2368
};
