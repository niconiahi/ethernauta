import {
  a as $,
  E as Be,
  y as K,
  d as M,
  k as Oe,
  u,
} from "./preact-10.26.9-BHuVZBHX.mjs"
import {
  u as _,
  k as _e,
  i as b,
  x as De,
  o as d,
  w as Fe,
  r as Ge,
  e as ge,
  v as He,
  l as h,
  q as je,
  z as Ke,
  d as L,
  g as Le,
  p as l,
  m as Me,
  c as O,
  a as p,
  n as pe,
  j as Q,
  h as qe,
  y as re,
  C as se,
  H as V,
  D as Ve,
  b as v,
  B as We,
  s as w,
  f as we,
  t as x,
  A as ze,
} from "./vendor-B10s51OD.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const s of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(s)
  new MutationObserver((s) => {
    for (const a of s)
      if (a.type === "childList")
        for (const c of a.addedNodes)
          c.tagName === "LINK" &&
            c.rel === "modulepreload" &&
            r(c)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(s) {
    const a = {}
    return (
      s.integrity && (a.integrity = s.integrity),
      s.referrerPolicy &&
        (a.referrerPolicy = s.referrerPolicy),
      s.crossOrigin === "use-credentials"
        ? (a.credentials = "include")
        : s.crossOrigin === "anonymous"
          ? (a.credentials = "omit")
          : (a.credentials = "same-origin"),
      a
    )
  }
  function r(s) {
    if (s.ep) return
    s.ep = !0
    const a = n(s)
    fetch(s.href, a)
  }
})()
const ae = { iterations: 1e5, hash: "SHA-256" },
  g = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function j(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function D(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function be(e, t, n) {
  const r = new TextEncoder().encode(e),
    s = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: ae.iterations,
      hash: ae.hash,
    },
    s,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function J() {
  return new Promise((e, t) => {
    const n = indexedDB.open(g.name, g.version)
    ;(n.onupgradeneeded = (r) => {
      const s = r.target.result
      s.objectStoreNames.contains(g.store_name) ||
        s.createObjectStore(g.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Qe(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    s = await be(t, n, ["encrypt"]),
    a = new TextEncoder().encode(e),
    c = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      s,
      a,
    ),
    i = {
      salt: j(n.buffer),
      iv: j(r.buffer),
      cipher: j(c),
    },
    f = await J()
  return new Promise((E, ne) => {
    const C = f
      .transaction(g.store_name, "readwrite")
      .objectStore(g.store_name)
      .put(i, g.vault_key)
    ;(C.onsuccess = () => E()),
      (C.onerror = () =>
        ne(
          new Error(
            `Failed to save vault: ${C.error?.message}`,
          ),
        ))
  })
}
async function ve(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await J(),
    n = await new Promise((f, E) => {
      const R = t
        .transaction(g.store_name, "readonly")
        .objectStore(g.store_name)
        .get(g.vault_key)
      ;(R.onsuccess = () => {
        const C = R.result
        f(C)
      }),
        (R.onerror = () =>
          E(
            new Error(
              `Failed to load vault: ${R.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = D(n.salt),
    s = D(n.iv),
    a = D(n.cipher),
    c = await be(e, r, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: s }, c, a)
      .catch((f) => {
        throw f instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unkwown error")
      })
  return new TextDecoder().decode(i)
}
async function Je() {
  const e = await J()
  return new Promise((t) => {
    const s = e
      .transaction(g.store_name, "readonly")
      .objectStore(g.store_name)
      .get(g.vault_key)
    ;(s.onsuccess = () => t(!!s.result)),
      (s.onerror = () => t(!1))
  })
}
async function Ze(e) {
  try {
    return (await ve(e)) !== void 0
  } catch {
    return !1
  }
}
const Xe = "password",
  A = M(Xe)
async function Se() {
  const e = Date.now()
  await chrome.storage.sync.set({ timestamp: e })
}
async function Ye() {
  return l(
    d({ timestamp: p(pe()) }),
    await chrome.storage.sync.get("timestamp"),
  ).timestamp
}
async function oe() {
  const e = Date.now(),
    t = await Ye()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function ce() {
  ;(await Je())
    ? (A.value = "password")
    : (A.value = "mnemonics")
}
const et = d({
    id: w(),
    type: h("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: w(),
    params: v(O()),
  }),
  tt = d({
    id: w(),
    type: h("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  nt = _([et, tt]),
  k = M({
    id: "some-id",
    method: "hello_world",
    params: [],
  })
function Ee(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += ie[e[n] >> 4]), (t += ie[e[n] & 15])
  return `0x${t}`
}
function rt(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function I(e) {
  const t = rt(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in B)) throw new Error("Invalid character")
    if (!(t[r + 1] in B))
      throw new Error("Invalid character")
    ;(n[r / 2] |= B[t[r]] << 4), (n[r / 2] |= B[t[r + 1]])
  }
  return n
}
const ie = "0123456789abcdef",
  B = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  },
  ue = "Invariant failed"
function T(e, t) {
  if (e) return
  const n = typeof t == "function" ? t() : t,
    r = n ? `${ue}: ${n}` : ue
  throw new Error(r)
}
function st(e) {
  if (!He(e, Fe)) throw new Error("Invalid mnemonic")
  return Me(e)
}
function at(e) {
  return V.fromMasterSeed(e)
}
function ot(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function ct(e) {
  const t = Le(e, !1),
    n = _e(t.slice(1))
  return Ee(n.slice(-20))
}
function it(e) {
  const t = e.privateKey
  return T(t, "a private key should exist"), t
}
function Z(e) {
  return BigInt(e)
}
function ut(e) {
  return `0x${e.toString(16)}`
}
function Ae(e) {
  return Number(e)
}
const lt = d({ address: w(), private_key: w() }),
  P = M({
    address: "",
    key: new V({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function dt(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.sync.set({ wallet: t })
}
async function le() {
  const t = l(
    d({ wallet: p(lt) }),
    await chrome.storage.sync.get("wallet"),
  ).wallet
  t &&
    (P.value = {
      address: t.address,
      key: V.fromExtendedKey(t.private_key),
    })
}
async function ht(e) {
  const t = await ve(e)
  T(t, "vault should exist to sign in")
  const n = st(t),
    r = at(n),
    s = ot(r),
    a = ct(s),
    c = r.derive("m/44'/60'/0'/0/0"),
    i = { address: a, key: c }
  ;(P.value = i), dt(i)
}
const ft = L(w(), ge(8)),
  mt = L(w(), ge(1))
function yt() {
  const [e, t] = $(""),
    [n, r] = $(
      "smile price bomb movie minimum treat hurdle adult wing come space cross",
    )
  return u("main", {
    children: [
      u("input", {
        placeholder: "Mnemonics",
        value: n,
        onInput: (s) => {
          const a = s.currentTarget.value
          r(a)
        },
      }),
      u("input", {
        placeholder: "Password",
        value: e,
        onInput: (s) => {
          const a = s.currentTarget.value
          t(a)
        },
      }),
      u("button", {
        type: "button",
        onClick: async () => {
          const s = l(mt, n),
            a = l(ft, e)
          Qe(s, a), await Se(), (A.value = "password")
        },
        children: "save wallet",
      }),
    ],
  })
}
function pt() {
  const [e, t] = $("")
  return u("div", {
    children: [
      u("input", {
        placeholder: "Password",
        value: e,
        onInput: (n) => {
          const r = n.currentTarget.value
          t(r)
        },
      }),
      u("button", {
        type: "button",
        onClick: async () => {
          ;(await Ze(e)) &&
            (await Se(), await ht(e), (A.value = "wallet"))
        },
        children: "unlock",
      }),
    ],
  })
}
const F = { chainId: 11155111 },
  z = L(
    w(),
    qe(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  ke = _([v(O()), Ge(w(), O())]),
  X = _([w(), pe(), we()]),
  _t = d({
    jsonrpc: h("2.0"),
    method: z,
    params: p(ke),
    id: X,
  }),
  gt = d({
    data: p(O()),
    message: w(),
    code: _([
      h(-32e3),
      h(-32300),
      h(-32400),
      h(-32500),
      h(-32600),
      h(-32601),
      h(-32602),
      h(-32603),
      h(-32700),
      h(-32701),
      h(-32702),
    ]),
  }),
  wt = d({ id: X, jsonrpc: h("2.0"), error: gt }),
  bt = d({ id: X, jsonrpc: h("2.0"), result: O() }),
  vt = _([wt, bt]),
  q = _([x([z, ke]), x([z])])
function St(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const Et = b(St)
function At(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const kt = b(At)
function xt(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const xe = b(xt),
  It = ":"
function Y({ namespace: e, reference: t }) {
  const n = l(Et, e),
    r = l(kt, String(t)),
    s = n + It + r
  return l(xe, s)
}
function ee(e) {
  return async (t) => {
    const [n, r] = t,
      s = l(_t, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: Tt(r),
      }),
      a = await fetch(e, {
        method: "POST",
        body: JSON.stringify(s),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return l(vt, a)
  }
}
function Tt(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function te(e) {
  return (t) => {
    const n = l(xe, t),
      r = e.find(({ chainId: s }) => s === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
function Pt(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const y = b(Pt)
function Ut(e) {
  return (
    typeof e == "string" &&
    /^0x([0-9,a-f,A-F]?){1,2}$/.test(e)
  )
}
const U = b(Ut)
function Nt(e) {
  return typeof e == "string" && /^0x[0-9a-f]*$/.test(e)
}
const N = b(Nt)
function Rt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{16}$/.test(e)
}
const Ct = b(Rt)
function $t(e) {
  return typeof e == "string" && /^0x[0-9a-f]{512}$/.test(e)
}
const Ot = b($t)
function Bt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const m = b(Bt),
  Ht = we()
function Mt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const o = b(Mt)
function Lt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]{0,15})|0$/.test(e)
  )
}
const de = b(Lt)
function Ft(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]{0,31})|0$/.test(e)
  )
}
const qt = b(Ft),
  Gt = d({ address: y, storageKeys: v(m) }),
  G = v(Gt),
  jt = d({
    type: U,
    nonce: o,
    to: Q(y),
    gas: o,
    value: o,
    input: N,
    maxPriorityFeePerGas: o,
    maxFeePerGas: o,
    gasPrice: o,
    accessList: G,
    chainId: o,
    yParity: o,
    r: o,
    s: o,
  }),
  Dt = d({
    type: U,
    nonce: o,
    to: Q(y),
    gas: o,
    value: o,
    input: N,
    gasPrice: o,
    accessList: G,
    chainId: o,
    yParity: o,
    r: o,
    s: o,
  }),
  Kt = d({
    type: U,
    nonce: o,
    to: y,
    gas: o,
    value: o,
    input: N,
    maxPriorityFeePerGas: o,
    maxFeePerGas: o,
    maxFeePerBlobGas: o,
    accessList: G,
    blobVersionedHashes: v(m),
    chainId: o,
    yParity: o,
    r: o,
    s: o,
  }),
  zt = d({
    type: U,
    nonce: o,
    to: y,
    gas: o,
    value: o,
    input: N,
    maxPriorityFeePerGas: o,
    maxFeePerGas: o,
    gasPrice: p(o),
    accessList: G,
    chainId: o,
  }),
  Wt = d({
    ...zt.entries,
    yParity: o,
    v: p(U),
    r: o,
    s: o,
  }),
  Vt = d({
    type: U,
    nonce: o,
    to: Q(y),
    gas: o,
    value: o,
    input: N,
    gasPrice: o,
    chainId: p(o),
  }),
  Qt = d({ ...Vt.entries, v: o, r: o, s: o }),
  Jt = je("type", [jt, Dt, Kt, Wt, Qt]),
  Zt = d({
    blockHash: m,
    blockNumber: o,
    from: y,
    hash: m,
    transactionIndex: o,
  }),
  Ie = De([Zt, Jt]),
  Xt = d({
    index: de,
    validatorIndex: de,
    address: y,
    amount: qt,
  }),
  Te = _([
    h("earliest"),
    h("finalized"),
    h("safe"),
    h("latest"),
    h("pending"),
  ]),
  he = _([o, Te]),
  H = _([o, Te, m]),
  Yt = d({
    hash: m,
    parentHash: m,
    sha3Uncles: m,
    miner: y,
    stateRoot: m,
    transactionsRoot: m,
    receiptsRoot: m,
    logsBloom: Ot,
    difficulty: p(o),
    number: o,
    gasLimit: o,
    gasUsed: o,
    timestamp: o,
    extraData: N,
    mixHash: m,
    nonce: Ct,
    totalDifficulty: p(o),
    baseFeePerGas: p(o),
    withdrawalsRoot: p(m),
    blobGasUsed: p(o),
    excessBlobGas: p(o),
    parentBeaconBlockRoot: p(m),
    size: o,
    transactions: _([v(m), v(Ie)]),
    withdrawals: p(v(Xt)),
    uncles: v(m),
  }),
  en = _([
    x([he, re()]),
    d({ blockNumberOrTag: he, hydratedTransactions: re() }),
  ])
function tn(e) {
  return async (t) => {
    const n = "eth_getBlockByNumber",
      r = l(en, e),
      s = l(q, [n, r]),
      a = await Promise.any(t.map((i) => i(s)))
    if ("error" in a) throw new Error(a.error.message)
    return l(_([Yt, Ht]), a.result)
  }
}
function nn() {
  return async (e) => {
    const n = l(q, ["eth_blockNumber"]),
      r = await Promise.any(e.map((a) => a(n)))
    if ("error" in r) throw new Error(r.error.message)
    return l(o, r.result)
  }
}
const rn = _([
  x([y, H]),
  x([y]),
  d({ address: y, blockNumberOrTagOrHash: H }),
  d({ address: y }),
])
function sn(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = l(rn, e),
      s = l(q, [n, r]),
      a = await Promise.any(t.map((i) => i(s)))
    if ("error" in a) throw new Error(a.error.message)
    return l(o, a.result)
  }
}
const an = _([
  x([y, H]),
  d({ address: y, blockNumberOrTagOrHash: H }),
])
function on(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = l(an, e),
      s = l(q, [n, r]),
      a = await Promise.race(t.map((i) => i(s)))
    if ("error" in a) throw new Error(a.error.message)
    return l(o, a.result)
  }
}
function Pe(e) {
  return Array.isArray(e) ? un(e) : cn(e)
}
function cn(e) {
  const t = ln(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const a = new Uint8Array(1 + t.length)
    return (a[0] = 128 + t.length), a.set(t, 1), a
  }
  const r = Ue(t.length),
    s = new Uint8Array(1 + r.length + t.length)
  return (
    (s[0] = 183 + r.length),
    s.set(r, 1),
    s.set(t, 1 + r.length),
    s
  )
}
function un(e) {
  const t = e.map((c) => Pe(c)),
    n = t.reduce((c, i) => c + i.length, 0)
  if (n <= 55) {
    const c = new Uint8Array(1 + n)
    c[0] = 192 + n
    let i = 1
    for (const f of t) c.set(f, i), (i += f.length)
    return c
  }
  const r = Ue(n),
    s = new Uint8Array(1 + r.length + n)
  ;(s[0] = 247 + r.length), s.set(r, 1)
  let a = 1 + r.length
  for (const c of t) s.set(c, a), (a += c.length)
  return s
}
function ln(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? I(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return dn(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function dn(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return I(n)
}
function Ue(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function S(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return I(n)
}
function hn(e, t) {
  return (
    (se.hmacSha256Sync = (n, ...r) =>
      We(Ve, n, se.concatBytes(...r))),
    ze(e, t)
  )
}
function fn(e) {
  return BigInt(e)
}
async function mn(e, t, n) {
  const s = await on([e, "latest"])(t(n))
  return Z(s)
}
function yn() {
  return BigInt(F.chainId)
}
function pn() {
  return 21000n
}
function _n() {
  return 20000000000n
}
function gn() {
  return 2000000000n
}
function wn(e, t) {
  switch (e) {
    case "transfer": {
      const n = l(y, t[0]),
        r = l(L(w(), Ke()), t[1])
      return {
        to: n,
        value: Z(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function bn({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: s, value: a, data: c } = wn(n, r),
    i = {
      to: s,
      data: c,
      value: a,
      nonce: t,
      chain_id: yn(),
      gas_limit: pn(),
      max_fee_per_gas: _n(),
      max_priority_fee_per_gas: gn(),
    },
    f = it(e)
  return Sn(i, f)
}
function vn(e, t) {
  const n = Ne(e, t)
  return _e(n)
}
function Sn(e, t) {
  const n = kn(e),
    r = fe(n),
    s = new Uint8Array([2]),
    a = vn(s, r),
    c = hn(a, t),
    i = An(n, c),
    f = fe(i)
  return Ne(s, f)
}
function Ne(...e) {
  let t = 0
  for (const s of e) t += s.length
  const n = new Uint8Array(t)
  let r = 0
  for (const s of e) n.set(s, r), (r += s.length)
  return n
}
function En(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    T(r, "access list item should exist")
    const s = new Array(r.storage_keys.length)
    for (let a = 0; a < r.storage_keys.length; a++) {
      const c = r.storage_keys[a]
      T(c, "storage key should exist"), (s[a] = I(c))
    }
    t[n] = [I(r.address), s]
  }
  return t
}
function An(e, t) {
  const n = new Array(12)
  T(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = fn(t.recovery)
  return (
    (n[9] = S(r)), (n[10] = S(t.r)), (n[11] = S(t.s)), n
  )
}
function kn(e) {
  const t = new Array(9)
  return (
    (t[0] = S(e.chain_id)),
    (t[1] = S(e.nonce)),
    (t[2] = S(e.max_priority_fee_per_gas)),
    (t[3] = S(e.max_fee_per_gas)),
    (t[4] = S(e.gas_limit)),
    (t[5] = I(e.to)),
    (t[6] = S(e.value)),
    (t[7] = e.data),
    (t[8] = En([])),
    t
  )
}
function fe(e) {
  return Pe(e)
}
const xn = { ETHEREUM: "eip155" },
  In =
    "https://muddy-radial-borough.ethereum-sepolia.quiknode.pro/e0d1ca422dd966c7b388455f296fb1483f738bef/",
  Re = Y({ namespace: xn.ETHEREUM, reference: F.chainId }),
  Tn = te([{ chainId: Re, transports: [ee(In)] }])
function Pn() {
  return u("div", {
    children: [
      u("h1", { children: "you are about to sign" }),
      u("p", { children: ["method ", k.value.method] }),
      u("p", {
        children: [
          "params",
          " ",
          JSON.stringify(k.value.params, null, 2),
        ],
      }),
      u("button", {
        type: "button",
        onClick: async () => {
          const e = P.value.address,
            t = P.value.key,
            n = await mn(e, Tn, Re),
            r = await bn({
              key: t,
              nonce: n,
              method: k.value.method,
              params: k.value.params,
            }),
            s = {
              id: k.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: Ee(r),
            }
          chrome.runtime.sendMessage(s)
        },
        children: "sign",
      }),
    ],
  })
}
const Un = { ETHEREUM: "eip155" },
  Nn =
    "https://muddy-radial-borough.ethereum-sepolia.quiknode.pro/e0d1ca422dd966c7b388455f296fb1483f738bef/",
  Ce = Y({ namespace: Un.ETHEREUM, reference: F.chainId }),
  Rn = te([{ chainId: Ce, transports: [ee(Nn)] }]),
  me = M(0n)
async function Cn(e) {
  const n = await sn([e, "latest"])(Rn(Ce))
  return Z(n)
}
function $n(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    s = n.toString()
  if (r === 0n) return s
  const a = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${s}.${a}`
}
const On = { ETHEREUM: "eip155" },
  Bn =
    "https://muddy-radial-borough.ethereum-sepolia.quiknode.pro/e0d1ca422dd966c7b388455f296fb1483f738bef/",
  W = Y({ namespace: On.ETHEREUM, reference: F.chainId }),
  ye = te([{ chainId: W, transports: [ee(Bn)] }]),
  Hn = 30
async function Mn() {
  const e = nn(),
    t = Ae(await e(ye(W))),
    n = []
  for (let r = t - Hn; r <= t; r++) {
    const a = await tn([ut(r), !0])(ye(W))
    a && n.push(a)
  }
  return n
}
function Ln() {
  const [e, t] = $(!1),
    [n, r] = $([]),
    s = P.value.address
  return (
    K(() => {
      async function a() {
        const c = await Cn(s)
        me.value = c
      }
      a()
    }, []),
    K(() => {
      async function a() {
        t(!0)
        const c = await Mn(),
          i = l(
            v(Ie),
            c
              .flatMap((f) =>
                f.transactions.map(
                  (E) => (
                    T(
                      typeof E == "object",
                      "transaction should be an object",
                    ),
                    E
                  ),
                ),
              )
              .filter(
                (f) =>
                  f.from === P.value.address &&
                  Ae(f.value) > 0,
              ),
          )
        r(i), t(!1)
      }
      a()
    }, []),
    u("div", {
      children: [
        u("p", {
          children: ["the connected address is ", s],
        }),
        u("p", {
          children: ["it's balance is ", $n(me.value)],
        }),
        e
          ? u("span", {
              children: "loading past transfers",
            })
          : u("ul", {
              children: n.map((a) =>
                u(
                  "li",
                  {
                    children: [
                      u("p", { children: a.from }),
                      u("p", { children: a.to }),
                    ],
                  },
                  `transfer_${a.value}`,
                ),
              ),
            }),
      ],
    })
  )
}
function Fn() {
  return (
    K(() => {
      chrome.runtime.onMessage.addListener(async (e) => {
        const t = l(nt, e)
        switch (t.type) {
          case "ETHERNAUTA_REQUEST_CONNECT": {
            const n = await oe()
            if ((await ce(), n)) {
              await le(), (A.value = "wallet")
              return
            }
            break
          }
          case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
            {
              const n = await oe()
              if ((await ce(), n)) {
                await le(),
                  (k.value = {
                    id: t.id,
                    method: t.method,
                    params: t.params,
                  }),
                  (A.value = "sign")
                return
              }
            }
            break
        }
      })
    }, []),
    u(Oe, { children: qn(A.value) })
  )
}
function qn(e) {
  switch (e) {
    case "mnemonics":
      return u(yt, {})
    case "password":
      return u(pt, {})
    case "wallet":
      return u(Ln, {})
    case "sign":
      return u(Pn, {})
    default:
      return u("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Be(u(Fn, {}), document.querySelector("#app"))
