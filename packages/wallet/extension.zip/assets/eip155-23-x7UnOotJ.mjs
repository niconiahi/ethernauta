const e = {
  name: "ELA-DID-Sidechain Testnet",
  shortName: "eladidt",
  chain: "ETH",
  rpc: [],
  faucets: [],
  nativeCurrency: {
    name: "Elastos",
    symbol: "tELA",
    decimals: 18
  },
  infoURL: "https://elaeth.io/",
  chainId: 23,
  networkId: 23,
  slip44: 1
};
export {
  e as eip155_23
};
