const e = {
  name: "Monad Devnet",
  shortName: "mon-devnet",
  chain: "MON",
  icon: "monad",
  rpc: [],
  faucets: [],
  features: [
    {
      name: "EIP155"
    },
    {
      name: "EIP1559"
    }
  ],
  nativeCurrency: {
    name: "Devnet MON Token",
    symbol: "MON",
    decimals: 18
  },
  infoURL: "https://monad.xyz",
  chainId: 20143,
  networkId: 20143,
  slip44: 1,
  explorers: []
};
export {
  e as eip155_20143
};
