const o = {
  name: "GoodData Mainnet",
  shortName: "GooD",
  chain: "GooD",
  rpc: ["https://rpc.goodata.io"],
  faucets: [],
  nativeCurrency: {
    name: "GoodData Mainnet Ether",
    symbol: "GooD",
    decimals: 18
  },
  infoURL: "https://www.goodata.org",
  chainId: 33,
  networkId: 33
};
export {
  o as eip155_33
};
