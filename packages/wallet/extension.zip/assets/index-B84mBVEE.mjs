import {
  d as U,
  a as N,
  u as o,
  y as ne,
  k as ve,
  E as be,
} from "./preact-10.26.9-DO5-VWXm.mjs"
import {
  p as u,
  o as h,
  a as F,
  n as re,
  u as p,
  s as d,
  l,
  b as ae,
  r as se,
  c as v,
  v as Ee,
  m as Se,
  H as q,
  g as Ae,
  k as oe,
  w as xe,
  d as $,
  e as ce,
  f as Ne,
  h as Te,
  t as T,
  i as E,
  j as ke,
  q as Ie,
  x as Ue,
  y as Q,
  z as Pe,
} from "./vendor-6cAV8jNg.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const a of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(a)
  new MutationObserver((a) => {
    for (const s of a)
      if (s.type === "childList")
        for (const c of s.addedNodes)
          c.tagName === "LINK" &&
            c.rel === "modulepreload" &&
            r(c)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(a) {
    const s = {}
    return (
      a.integrity && (s.integrity = a.integrity),
      a.referrerPolicy &&
        (s.referrerPolicy = a.referrerPolicy),
      a.crossOrigin === "use-credentials"
        ? (s.credentials = "include")
        : a.crossOrigin === "anonymous"
          ? (s.credentials = "omit")
          : (s.credentials = "same-origin"),
      s
    )
  }
  function r(a) {
    if (a.ep) return
    a.ep = !0
    const s = n(a)
    fetch(a.href, s)
  }
})()
const V = { iterations: 1e5, hash: "SHA-256" },
  f = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function H(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function M(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function ie(e, t, n) {
  const r = new TextEncoder().encode(e),
    a = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: V.iterations,
      hash: V.hash,
    },
    a,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function K() {
  return new Promise((e, t) => {
    const n = indexedDB.open(f.name, f.version)
    ;(n.onupgradeneeded = (r) => {
      const a = r.target.result
      a.objectStoreNames.contains(f.store_name) ||
        a.createObjectStore(f.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Ce(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    a = await ie(t, n, ["encrypt"]),
    s = new TextEncoder().encode(e),
    c = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      a,
      s,
    ),
    i = {
      salt: H(n.buffer),
      iv: H(r.buffer),
      cipher: H(c),
    },
    m = await K()
  return new Promise((P, z) => {
    const A = m
      .transaction(f.store_name, "readwrite")
      .objectStore(f.store_name)
      .put(i, f.vault_key)
    ;(A.onsuccess = () => P()),
      (A.onerror = () =>
        z(
          new Error(
            `Failed to save vault: ${A.error?.message}`,
          ),
        ))
  })
}
async function le(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await K(),
    n = await new Promise((m, P) => {
      const S = t
        .transaction(f.store_name, "readonly")
        .objectStore(f.store_name)
        .get(f.vault_key)
      ;(S.onsuccess = () => {
        const A = S.result
        m(A)
      }),
        (S.onerror = () =>
          P(
            new Error(
              `Failed to load vault: ${S.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = M(n.salt),
    a = M(n.iv),
    s = M(n.cipher),
    c = await ie(e, r, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: a }, c, s)
      .catch((m) => {
        throw m instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unkwown error")
      })
  return new TextDecoder().decode(i)
}
async function Re() {
  const e = await K()
  return new Promise((t) => {
    const a = e
      .transaction(f.store_name, "readonly")
      .objectStore(f.store_name)
      .get(f.vault_key)
    ;(a.onsuccess = () => t(!!a.result)),
      (a.onerror = () => t(!1))
  })
}
async function Oe(e) {
  try {
    return (await le(e)) !== void 0
  } catch {
    return !1
  }
}
const Fe = "password",
  w = U(Fe)
async function ue() {
  const e = Date.now()
  await chrome.storage.local.set({ timestamp: e })
}
async function $e() {
  return u(
    h({ timestamp: F(re()) }),
    await chrome.storage.local.get("timestamp"),
  ).timestamp
}
async function J() {
  const e = Date.now(),
    t = await $e()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function Y() {
  ;(await Re())
    ? (w.value = "password")
    : (w.value = "mnemonics")
}
const He = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: d(),
    params: p([ae(v()), se(d(), v())]),
  }),
  Me = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  je = p([He, Me]),
  y = U({
    id: "some-id",
    method: "hello_world",
    params: [],
  })
function k(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function de(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += Z[e[n] >> 4]), (t += Z[e[n] & 15])
  return `0x${t}`
}
function Be(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function b(e) {
  const t = Be(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in C)) throw new Error("Invalid character")
    if (!(t[r + 1] in C))
      throw new Error("Invalid character")
    ;(n[r / 2] |= C[t[r]] << 4), (n[r / 2] |= C[t[r + 1]])
  }
  return n
}
const Z = "0123456789abcdef",
  C = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function De(e) {
  if (!Ee(e, xe)) throw new Error("Invalid mnemonic")
  return Se(e)
}
function qe(e) {
  return q.fromMasterSeed(e)
}
function Ke(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function Le(e) {
  const t = Ae(e, !1),
    n = oe(t.slice(1))
  return de(n.slice(-20))
}
function Ge(e) {
  const t = e.privateKey
  return k(t, "a private key should exist"), t
}
function L(e) {
  return BigInt(e)
}
const We = h({ address: d(), private_key: d() }),
  I = U({
    address: "",
    key: new q({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function ze(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.local.set({ wallet: t })
}
async function X() {
  const t = u(
    h({ wallet: F(We) }),
    await chrome.storage.local.get("wallet"),
  ).wallet
  t &&
    (I.value = {
      address: t.address,
      key: q.fromExtendedKey(t.private_key),
    })
}
async function Qe(e) {
  const t = await le(e)
  k(t, "vault should exist to sign in")
  const n = De(t),
    r = qe(n),
    a = Ke(r),
    s = Le(a),
    c = r.derive("m/44'/60'/0'/0/0"),
    i = { address: s, key: c }
  ;(I.value = i), ze(i)
}
function R({
  children: e,
  class: t,
  variant: n = "primary",
  ...r
}) {
  const [a, s] = N(!1)
  return o("button", {
    type: "button",
    onPointerDown: () => s(!0),
    onPointerUp: () => s(!1),
    onPointerLeave: () => s(!1),
    onTouchCancel: () => s(!1),
    class: [
      "border-2 rounded-md p-2 cursor-pointer text-base transition-colors",
      n === "secondary"
        ? "bg-[color-mix(in_srgb,#FF5005_12%,#faf5f0)] hover:bg-[color-mix(in_srgb,#FF5005_25%,#faf5f0)] border-[#FF5005] text-[#FF5005]"
        : "bg-[#FF5005] hover:bg-[#cc4004] border-[#c73d00] text-white",
      a
        ? "outline outline-2 outline-offset-2 outline-gray-700"
        : "",
      t,
    ]
      .filter(Boolean)
      .join(" "),
    ...r,
    children: e,
  })
}
const Ve = $(d(), ce(8)),
  Je = $(d(), ce(1))
function Ye() {
  const [e, t] = N(""),
    [n, r] = N("")
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          r(s)
        },
      }),
      o("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          t(s)
        },
      }),
      o(R, {
        onClick: async () => {
          const a = u(Je, n),
            s = u(Ve, e)
          Ce(a, s), await ue(), (w.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function Ze() {
  const [e, t] = N(""),
    [n, r] = N("")
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          t(s), r("")
        },
      }),
      n
        ? o("p", {
            className: "text-red-500 text-sm",
            children: n,
          })
        : null,
      o(R, {
        onClick: async () => {
          if (!(await Oe(e))) {
            r("Invalid password")
            return
          }
          await ue(), await Qe(e), (w.value = "wallet")
        },
        children: "Unlock",
      }),
    ],
  })
}
const j = { name: "Ethereum Sepolia", chainId: 11155111 },
  B = $(
    d(),
    Te(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  fe = p([ae(v()), se(d(), v())]),
  G = p([d(), re(), Ne()]),
  Xe = h({
    jsonrpc: l("2.0"),
    method: B,
    params: F(fe),
    id: G,
  }),
  et = h({
    data: F(v()),
    message: d(),
    code: p([
      l(-32e3),
      l(-32300),
      l(-32400),
      l(-32500),
      l(-32600),
      l(-32601),
      l(-32602),
      l(-32603),
      l(-32700),
      l(-32701),
      l(-32702),
    ]),
  }),
  tt = h({ id: G, jsonrpc: l("2.0"), error: et }),
  nt = h({ id: G, jsonrpc: l("2.0"), result: v() }),
  rt = p([tt, nt]),
  me = p([T([B, fe]), T([B])])
function at(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const st = E(at)
function ot(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const ct = E(ot)
function it(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const he = E(it),
  lt = ":"
function ut({ namespace: e, reference: t }) {
  const n = u(st, e),
    r = u(ct, typeof t == "number" ? String(t) : t),
    a = n + lt + r
  return u(he, a)
}
function dt(e) {
  return async (t) => {
    const [n, r] = t,
      a = u(Xe, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: ft(r),
      }),
      s = await fetch(e, {
        method: "POST",
        body: JSON.stringify(a),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return u(rt, s)
  }
}
function ft(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function mt(e) {
  return (t) => {
    const n = u(he, t),
      r = e.find(({ chainId: a }) => a === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
const D = [
    {
      id: j.chainId,
      name: j.name,
      rpc_url:
        "https://ethereum-sepolia-rpc.publicnode.com",
    },
  ],
  x = U(D[0]),
  ht = "eip155"
function pt(e) {
  return ut({ namespace: ht, reference: e.id })
}
function pe(e) {
  const t = pt(e)
  return {
    chain_id: t,
    reader: mt([
      { chainId: t, transports: [dt(e.rpc_url)] },
    ]),
  }
}
function _t(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const g = E(_t)
function yt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const gt = E(yt)
function wt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const W = E(wt),
  vt = p([
    l("earliest"),
    l("finalized"),
    l("safe"),
    l("latest"),
    l("pending"),
  ]),
  O = p([W, vt, gt]),
  bt = p([
    T([g, O]),
    T([g]),
    h({ address: g, blockNumberOrTagOrHash: O }),
    h({ address: g }),
  ])
function Et(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = u(bt, e),
      a = u(me, [n, r]),
      s = await Promise.any(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return u(W, s.result)
  }
}
const St = p([
  T([g, O]),
  h({ address: g, blockNumberOrTagOrHash: O }),
])
function At(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = u(St, e),
      a = u(me, [n, r]),
      s = await Promise.race(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return u(W, s.result)
  }
}
function _e(e) {
  return Array.isArray(e) ? Nt(e) : xt(e)
}
function xt(e) {
  const t = Tt(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const s = new Uint8Array(1 + t.length)
    return (s[0] = 128 + t.length), s.set(t, 1), s
  }
  const r = ye(t.length),
    a = new Uint8Array(1 + r.length + t.length)
  return (
    (a[0] = 183 + r.length),
    a.set(r, 1),
    a.set(t, 1 + r.length),
    a
  )
}
function Nt(e) {
  const t = e.map((c) => _e(c)),
    n = t.reduce((c, i) => c + i.length, 0)
  if (n <= 55) {
    const c = new Uint8Array(1 + n)
    c[0] = 192 + n
    let i = 1
    for (const m of t) c.set(m, i), (i += m.length)
    return c
  }
  const r = ye(n),
    a = new Uint8Array(1 + r.length + n)
  ;(a[0] = 247 + r.length), a.set(r, 1)
  let s = 1 + r.length
  for (const c of t) a.set(c, s), (s += c.length)
  return a
}
function Tt(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? b(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return kt(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function kt(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return b(n)
}
function ye(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function _(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return b(n)
}
function It(e, t) {
  return (
    (Q.hmacSha256Sync = (n, ...r) =>
      Ue(Pe, n, Q.concatBytes(...r))),
    Ie(e, t)
  )
}
function Ut(e) {
  return BigInt(e)
}
async function Pt(e, t, n) {
  const a = await At([e, "latest"])(t(n))
  return L(a)
}
function Ct() {
  return BigInt(j.chainId)
}
function Rt() {
  return 21000n
}
function Ot() {
  return 20000000000n
}
function Ft() {
  return 2000000000n
}
function $t(e, t) {
  switch (e) {
    case "transfer": {
      const n = u(g, t[0]),
        r = u($(d(), ke()), t[1])
      return {
        to: n,
        value: L(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function Ht({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: a, value: s, data: c } = $t(n, r),
    i = {
      to: a,
      data: c,
      value: s,
      nonce: t,
      chain_id: Ct(),
      gas_limit: Rt(),
      max_fee_per_gas: Ot(),
      max_priority_fee_per_gas: Ft(),
    },
    m = Ge(e)
  return jt(i, m)
}
function Mt(e, t) {
  const n = ge(e, t)
  return oe(n)
}
function jt(e, t) {
  const n = qt(e),
    r = ee(n),
    a = new Uint8Array([2]),
    s = Mt(a, r),
    c = It(s, t),
    i = Dt(n, c),
    m = ee(i)
  return ge(a, m)
}
function ge(...e) {
  let t = 0
  for (const a of e) t += a.length
  const n = new Uint8Array(t)
  let r = 0
  for (const a of e) n.set(a, r), (r += a.length)
  return n
}
function Bt(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    k(r, "access list item should exist")
    const a = new Array(r.storage_keys.length)
    for (let s = 0; s < r.storage_keys.length; s++) {
      const c = r.storage_keys[s]
      k(c, "storage key should exist"), (a[s] = b(c))
    }
    t[n] = [b(r.address), a]
  }
  return t
}
function Dt(e, t) {
  const n = new Array(12)
  k(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = Ut(t.recovery)
  return (
    (n[9] = _(r)), (n[10] = _(t.r)), (n[11] = _(t.s)), n
  )
}
function qt(e) {
  const t = new Array(9)
  return (
    (t[0] = _(e.chain_id)),
    (t[1] = _(e.nonce)),
    (t[2] = _(e.max_priority_fee_per_gas)),
    (t[3] = _(e.max_fee_per_gas)),
    (t[4] = _(e.gas_limit)),
    (t[5] = b(e.to)),
    (t[6] = _(e.value)),
    (t[7] = e.data),
    (t[8] = Bt([])),
    t
  )
}
function ee(e) {
  return _e(e)
}
function Kt() {
  return o("main", {
    className: "flex flex-col gap-2 p-2 text-base",
    children: [
      o("h1", {
        className: "text-center",
        children: "You are about to sign",
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Method" }),
          o("p", {
            className: "font-bold",
            children: y.value.method,
          }),
        ],
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Params" }),
          o("ul", {
            children: y.value.params.map((e, t) => {
              const n = u(d(), e),
                r = `param-${n}`
              return o(
                "li",
                {
                  className: "flex gap-2",
                  children: [
                    o("span", {
                      className: "w-2 text-center",
                      children: t,
                    }),
                    o("span", {
                      className: "font-bold",
                      children: n,
                    }),
                  ],
                },
                r,
              )
            }),
          }),
        ],
      }),
      o(R, {
        onClick: async () => {
          const e = I.value.address,
            t = I.value.key,
            { chain_id: n, reader: r } = pe(x.value),
            a = await Pt(e, r, n),
            s = await Ht({
              key: t,
              nonce: a,
              method: y.value.method,
              params: y.value.params,
            }),
            c = {
              id: y.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: de(s),
            }
          chrome.runtime.sendMessage(c), window.close()
        },
        children: "Sign",
      }),
      o(R, {
        onClick: () => {
          const e = {
            id: y.value.id,
            type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
          }
          chrome.runtime.sendMessage(e), window.close()
        },
        children: "Reject",
      }),
    ],
  })
}
const te = U(0n)
async function Lt(e) {
  const { chain_id: t, reader: n } = pe(x.value),
    a = await Et([e, "latest"])(n(t))
  return L(a)
}
function Gt(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    a = n.toString()
  if (r === 0n) return a
  const s = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${a}.${s}`
}
function Wt() {
  const e = I.value.address
  return (
    ne(() => {
      async function t() {
        const n = await Lt(e)
        te.value = n
      }
      t()
    }, [x.value]),
    o("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        o("select", {
          className:
            "p-2 border-2 rounded-md cursor-pointer text-base",
          value: x.value.id,
          onChange: (t) => {
            const n = Number(t.currentTarget.value),
              r = D.find((a) => a.id === n)
            r && (x.value = r)
          },
          children: D.map((t) =>
            o(
              "option",
              { value: t.id, children: t.name },
              t.id,
            ),
          ),
        }),
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Address:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: e,
            }),
          ],
        }),
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Balance:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: zt(Gt(te.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
      ],
    })
  )
}
function zt(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function Qt() {
  return (
    ne(() => {
      chrome.runtime.connect({ name: "popup" }),
        chrome.runtime.sendMessage({
          type: "ETHERNAUTA_POPUP_READY",
        }),
        chrome.runtime.onMessage.addListener(async (e) => {
          const t = u(je, e)
          switch (t.type) {
            case "ETHERNAUTA_REQUEST_CONNECT": {
              const n = await J()
              if ((await Y(), n)) {
                await X(), (w.value = "wallet")
                return
              }
              break
            }
            case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
              {
                const n = await J()
                if ((await Y(), n)) {
                  await X(),
                    (y.value = {
                      id: t.id,
                      method: t.method,
                      params: t.params,
                    }),
                    (w.value = "sign")
                  return
                }
              }
              break
          }
        })
    }, []),
    o(ve, { children: Vt(w.value) })
  )
}
function Vt(e) {
  switch (e) {
    case "mnemonics":
      return o(Ye, {})
    case "password":
      return o(Ze, {})
    case "wallet":
      return o(Wt, {})
    case "sign":
      return o(Kt, {})
    default:
      return o("div", {
        children: ["there is no view for: ", e],
      })
  }
}
be(o(Qt, {}), document.querySelector("#app"))
