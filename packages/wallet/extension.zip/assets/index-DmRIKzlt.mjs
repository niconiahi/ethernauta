import {
  k as be,
  E as Ee,
  y as ee,
  u as i,
  a as M,
  d as R,
} from "./preact-10.26.9-BHuVZBHX.mjs"
import {
  u as _,
  f as A,
  m as Ae,
  i as ae,
  c as b,
  a as C,
  x as Ce,
  y as G,
  o as h,
  d as Ie,
  w as ke,
  p as l,
  s as m,
  j as Ne,
  n as ne,
  b as P,
  z as Pe,
  H as q,
  q as Re,
  h as re,
  v as Se,
  t as T,
  g as Te,
  k as te,
  r as Ue,
  l as u,
  e as xe,
} from "./vendor-CBSW2nM6.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const a of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(a)
  new MutationObserver((a) => {
    for (const s of a)
      if (s.type === "childList")
        for (const o of s.addedNodes)
          o.tagName === "LINK" &&
            o.rel === "modulepreload" &&
            r(o)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(a) {
    const s = {}
    return (
      a.integrity && (s.integrity = a.integrity),
      a.referrerPolicy &&
        (s.referrerPolicy = a.referrerPolicy),
      a.crossOrigin === "use-credentials"
        ? (s.credentials = "include")
        : a.crossOrigin === "anonymous"
          ? (s.credentials = "omit")
          : (s.credentials = "same-origin"),
      s
    )
  }
  function r(a) {
    if (a.ep) return
    a.ep = !0
    const s = n(a)
    fetch(a.href, s)
  }
})()
const W = { iterations: 1e5, hash: "SHA-256" },
  d = {
    name: "cryptoman/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function O(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function $(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function se(e, t, n) {
  const r = new TextEncoder().encode(e),
    a = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: W.iterations,
      hash: W.hash,
    },
    a,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function j() {
  return new Promise((e, t) => {
    const n = indexedDB.open(d.name, d.version)
    ;(n.onupgradeneeded = (r) => {
      const a = r.target.result
      a.objectStoreNames.contains(d.store_name) ||
        a.createObjectStore(d.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Oe(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    a = await se(t, n, ["encrypt"]),
    s = new TextEncoder().encode(e),
    o = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      a,
      s,
    ),
    c = {
      salt: O(n.buffer),
      iv: O(r.buffer),
      cipher: O(o),
    },
    f = await j()
  return new Promise((x, F) => {
    const S = f
      .transaction(d.store_name, "readwrite")
      .objectStore(d.store_name)
      .put(c, d.vault_key)
    ;(S.onsuccess = () => x()),
      (S.onerror = () =>
        F(
          new Error(
            `Failed to save vault: ${S.error?.message}`,
          ),
        ))
  })
}
async function oe(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await j(),
    n = await new Promise((f, x) => {
      const E = t
        .transaction(d.store_name, "readonly")
        .objectStore(d.store_name)
        .get(d.vault_key)
      ;(E.onsuccess = () => {
        const S = E.result
        f(S)
      }),
        (E.onerror = () =>
          x(
            new Error(
              `Failed to load vault: ${E.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = $(n.salt),
    a = $(n.iv),
    s = $(n.cipher),
    o = await se(e, r, ["decrypt"]),
    c = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: a }, o, s)
      .catch((f) => {
        throw f instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unkwown error")
      })
  return new TextDecoder().decode(c)
}
async function $e() {
  const e = await j()
  return new Promise((t) => {
    const a = e
      .transaction(d.store_name, "readonly")
      .objectStore(d.store_name)
      .get(d.vault_key)
    ;(a.onsuccess = () => t(!!a.result)),
      (a.onerror = () => t(!1))
  })
}
async function Me(e) {
  try {
    return (await oe(e)) !== void 0
  } catch {
    return !1
  }
}
const z = "Invariant failed"
function k(e, t) {
  if (e) return
  const n = typeof t == "function" ? t() : t,
    r = n ? `${z}: ${n}` : z
  throw new Error(r)
}
function ce(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += Q[e[n] >> 4]), (t += Q[e[n] & 15])
  return `0x${t}`
}
function He(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function v(e) {
  const t = He(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in U)) throw new Error("Invalid character")
    if (!(t[r + 1] in U))
      throw new Error("Invalid character")
    ;(n[r / 2] |= U[t[r]] << 4), (n[r / 2] |= U[t[r + 1]])
  }
  return n
}
const Q = "0123456789abcdef",
  U = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function qe(e) {
  if (!Se(e, ke)) throw new Error("Invalid mnemonic")
  return Ae(e)
}
function je(e) {
  return q.fromMasterSeed(e)
}
function Ke(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function Be(e) {
  const t = Te(e, !1),
    n = te(t.slice(1))
  return ce(n.slice(-20))
}
function Le(e) {
  const t = e.privateKey
  return k(t, "a private key should exist"), t
}
function K(e) {
  return BigInt(e)
}
const De = h({ address: m(), private_key: m() }),
  I = R({
    address: "",
    key: new q({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function Fe(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.sync.set({ wallet: t })
}
async function V() {
  const t = l(
    h({ wallet: C(De) }),
    await chrome.storage.sync.get("wallet"),
  ).wallet
  t &&
    (I.value = {
      address: t.address,
      key: q.fromExtendedKey(t.private_key),
    })
}
async function Ge(e) {
  const t = await oe(e)
  k(t, "vault should exist to sign in")
  const n = qe(t),
    r = je(n),
    a = Ke(r),
    s = Be(a),
    o = r.derive("m/44'/60'/0'/0/0"),
    c = { address: s, key: o }
  ;(I.value = c), Fe(c)
}
const We = "password",
  w = R(We)
async function ie() {
  const e = Date.now()
  await chrome.storage.sync.set({ timestamp: e })
}
async function ze() {
  return l(
    h({ timestamp: C(ne()) }),
    await chrome.storage.sync.get("timestamp"),
  ).timestamp
}
async function J() {
  const e = Date.now(),
    t = await ze()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function Z() {
  ;(await $e())
    ? (w.value = "password")
    : (w.value = "mnemonics")
}
function Qe() {
  const [e, t] = M("")
  return i("div", {
    children: [
      i("input", {
        placeholder: "Password",
        value: e,
        onInput: (n) => {
          const r = n.currentTarget.value
          t(r)
        },
      }),
      i("button", {
        type: "button",
        onClick: async () => {
          ;(await Me(e)) &&
            (await ie(), await Ge(e), (w.value = "wallet"))
        },
        children: "unlock",
      }),
    ],
  })
}
const B = { chainId: 11155111 }
function Ve(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const y = b(Ve)
function Je(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const Ze = b(Je)
function Xe(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const L = b(Xe),
  Ye = _([
    u("earliest"),
    u("finalized"),
    u("safe"),
    u("latest"),
    u("pending"),
  ]),
  N = _([L, Ye, Ze]),
  H = P(
    m(),
    xe(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  ue = _([re(A()), Ue(m(), A())]),
  D = _([m(), ne(), Ie()]),
  et = h({
    jsonrpc: u("2.0"),
    method: H,
    params: C(ue),
    id: D,
  }),
  tt = h({
    data: C(A()),
    message: m(),
    code: _([
      u(-32e3),
      u(-32300),
      u(-32400),
      u(-32500),
      u(-32600),
      u(-32601),
      u(-32602),
      u(-32603),
      u(-32700),
      u(-32701),
      u(-32702),
    ]),
  }),
  nt = h({ id: D, jsonrpc: u("2.0"), error: tt }),
  rt = h({ id: D, jsonrpc: u("2.0"), result: A() }),
  at = _([nt, rt]),
  le = _([T([H, ue]), T([H])])
function de(e) {
  return async (t) => {
    const [n, r] = t,
      a = l(et, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: st(r),
      }),
      s = await fetch(e, {
        method: "POST",
        body: JSON.stringify(a),
        headers: { "Content-Type": "application/json" },
      })
        .then((c) => c.json())
        .catch((c) => {
          throw new Error(c)
        })
    return l(at, s)
  }
}
function st(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function ot(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const fe = b(ot)
function ct(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const it = b(ct)
function ut(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const lt = b(ut),
  dt = ":"
function he({ namespace: e, reference: t }) {
  const n = l(it, e),
    r = l(lt, String(t)),
    a = n + dt + r
  return l(fe, a)
}
function me(e) {
  return (t) => {
    const n = l(fe, t),
      r = e.find(({ chainId: a }) => a === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
const ft = _([
  T([y, N]),
  T([y]),
  h({ address: y, blockNumberOrTagOrHash: N }),
  h({ address: y }),
])
function ht(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = l(ft, e),
      a = l(le, [n, r]),
      s = await Promise.any(t.map((c) => c(a)))
    if ("error" in s) throw new Error(s.error.message)
    return l(L, s.result)
  }
}
const mt = _([
  T([y, N]),
  h({ address: y, blockNumberOrTagOrHash: N }),
])
function _t(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = l(mt, e),
      a = l(le, [n, r]),
      s = await Promise.race(t.map((c) => c(a)))
    if ("error" in s) throw new Error(s.error.message)
    return l(L, s.result)
  }
}
const pt = { ETHEREUM: "eip155" },
  yt =
    "https://little-bitter-wave.ethereum-sepolia.quiknode.pro/4d40a4c7ec139649d4b1f43f5d536c3756faacc9/",
  _e = he({ namespace: pt.ETHEREUM, reference: B.chainId }),
  wt = me([{ chainId: _e, transports: [de(yt)] }]),
  X = R(0n)
async function gt(e) {
  const n = await ht([e, "latest"])(wt(_e))
  return K(n)
}
function vt(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    a = n.toString()
  if (r === 0n) return a
  const s = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${a}.${s}`
}
function bt() {
  const e = I.value.address
  return (
    ee(() => {
      async function t() {
        const n = await gt(e)
        X.value = n
      }
      t()
    }, []),
    i("div", {
      children: [
        i("p", {
          children: ["the connected address is ", e],
        }),
        i("p", {
          children: ["it's balance is ", vt(X.value)],
        }),
      ],
    })
  )
}
const Et = P(m(), ae(8)),
  St = P(m(), ae(1))
function At() {
  const [e, t] = M(""),
    [n, r] = M(
      "smile price bomb movie minimum treat hurdle adult wing come space cross",
    )
  return i("main", {
    children: [
      i("input", {
        placeholder: "Mnemonics",
        value: n,
        onInput: (a) => {
          const s = a.currentTarget.value
          r(s)
        },
      }),
      i("input", {
        placeholder: "Password",
        value: e,
        onInput: (a) => {
          const s = a.currentTarget.value
          t(s)
        },
      }),
      i("button", {
        type: "button",
        onClick: async () => {
          const a = l(St, n),
            s = l(Et, e)
          Oe(a, s), await ie(), (w.value = "password")
        },
        children: "save wallet",
      }),
    ],
  })
}
const g = R({
  id: "some-id",
  method: "hello_world",
  params: [],
})
function pe(e) {
  return Array.isArray(e) ? kt(e) : Tt(e)
}
function Tt(e) {
  const t = It(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const s = new Uint8Array(1 + t.length)
    return (s[0] = 128 + t.length), s.set(t, 1), s
  }
  const r = ye(t.length),
    a = new Uint8Array(1 + r.length + t.length)
  return (
    (a[0] = 183 + r.length),
    a.set(r, 1),
    a.set(t, 1 + r.length),
    a
  )
}
function kt(e) {
  const t = e.map((o) => pe(o)),
    n = t.reduce((o, c) => o + c.length, 0)
  if (n <= 55) {
    const o = new Uint8Array(1 + n)
    o[0] = 192 + n
    let c = 1
    for (const f of t) o.set(f, c), (c += f.length)
    return o
  }
  const r = ye(n),
    a = new Uint8Array(1 + r.length + n)
  ;(a[0] = 247 + r.length), a.set(r, 1)
  let s = 1 + r.length
  for (const o of t) a.set(o, s), (s += o.length)
  return a
}
function It(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? v(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return xt(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function xt(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return v(n)
}
function ye(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function p(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return v(n)
}
function Ut(e, t) {
  return (
    (G.hmacSha256Sync = (n, ...r) =>
      Ce(Pe, n, G.concatBytes(...r))),
    Re(e, t)
  )
}
function Nt(e) {
  return BigInt(e)
}
async function Rt(e, t, n) {
  const a = await _t([e, "latest"])(t(n))
  return K(a)
}
function Ct() {
  return BigInt(B.chainId)
}
function Pt() {
  return 21000n
}
function Ot() {
  return 20000000000n
}
function $t() {
  return 2000000000n
}
function Mt(e, t) {
  switch (e) {
    case "transfer": {
      const n = l(y, t[0]),
        r = l(P(m(), Ne()), t[1])
      return {
        to: n,
        value: K(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function Ht({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: a, value: s, data: o } = Mt(n, r),
    c = {
      to: a,
      data: o,
      value: s,
      nonce: t,
      chain_id: Ct(),
      gas_limit: Pt(),
      max_fee_per_gas: Ot(),
      max_priority_fee_per_gas: $t(),
    },
    f = Le(e)
  return jt(c, f)
}
function qt(e, t) {
  const n = we(e, t)
  return te(n)
}
function jt(e, t) {
  const n = Lt(e),
    r = Y(n),
    a = new Uint8Array([2]),
    s = qt(a, r),
    o = Ut(s, t),
    c = Bt(n, o),
    f = Y(c)
  return we(a, f)
}
function we(...e) {
  let t = 0
  for (const a of e) t += a.length
  const n = new Uint8Array(t)
  let r = 0
  for (const a of e) n.set(a, r), (r += a.length)
  return n
}
function Kt(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    k(r, "access list item should exist")
    const a = new Array(r.storage_keys.length)
    for (let s = 0; s < r.storage_keys.length; s++) {
      const o = r.storage_keys[s]
      k(o, "storage key should exist"), (a[s] = v(o))
    }
    t[n] = [v(r.address), a]
  }
  return t
}
function Bt(e, t) {
  const n = new Array(12)
  k(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = Nt(t.recovery)
  return (
    (n[9] = p(r)), (n[10] = p(t.r)), (n[11] = p(t.s)), n
  )
}
function Lt(e) {
  const t = new Array(9)
  return (
    (t[0] = p(e.chain_id)),
    (t[1] = p(e.nonce)),
    (t[2] = p(e.max_priority_fee_per_gas)),
    (t[3] = p(e.max_fee_per_gas)),
    (t[4] = p(e.gas_limit)),
    (t[5] = v(e.to)),
    (t[6] = p(e.value)),
    (t[7] = e.data),
    (t[8] = Kt([])),
    t
  )
}
function Y(e) {
  return pe(e)
}
const Dt = { ETHEREUM: "eip155" },
  Ft =
    "https://little-bitter-wave.ethereum-sepolia.quiknode.pro/4d40a4c7ec139649d4b1f43f5d536c3756faacc9/",
  ge = he({ namespace: Dt.ETHEREUM, reference: B.chainId }),
  Gt = me([{ chainId: ge, transports: [de(Ft)] }])
function Wt() {
  return i("div", {
    children: [
      i("h1", { children: "you are about to sign" }),
      i("p", { children: ["method ", g.value.method] }),
      i("p", {
        children: [
          "params",
          " ",
          JSON.stringify(g.value.params, null, 2),
        ],
      }),
      i("button", {
        type: "button",
        onClick: async () => {
          const e = I.value.address,
            t = I.value.key,
            n = await Rt(e, Gt, ge),
            r = await Ht({
              key: t,
              nonce: n,
              method: g.value.method,
              params: g.value.params,
            }),
            a = {
              id: g.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: ce(r),
            }
          chrome.runtime.sendMessage(a)
        },
        children: "sign",
      }),
    ],
  })
}
const zt = h({
    id: m(),
    type: u("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: m(),
    params: re(A()),
  }),
  Qt = h({
    id: m(),
    type: u("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  Vt = _([zt, Qt])
function Jt() {
  return (
    ee(() => {
      chrome.runtime.onMessage.addListener(async (e) => {
        const t = l(Vt, e)
        switch (t.type) {
          case "ETHERNAUTA_REQUEST_CONNECT": {
            const n = await J()
            if ((await Z(), n)) {
              await V(), (w.value = "wallet")
              return
            }
            break
          }
          case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
            {
              const n = await J()
              if ((await Z(), n)) {
                await V(),
                  (g.value = {
                    id: t.id,
                    method: t.method,
                    params: t.params,
                  }),
                  (w.value = "sign")
                return
              }
            }
            break
        }
      })
    }, []),
    i(be, { children: Zt(w.value) })
  )
}
function Zt(e) {
  switch (e) {
    case "mnemonics":
      return i(At, {})
    case "password":
      return i(Qe, {})
    case "wallet":
      return i(bt, {})
    case "sign":
      return i(Wt, {})
    default:
      return i("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Ee(i(Jt, {}), document.querySelector("#app"))
