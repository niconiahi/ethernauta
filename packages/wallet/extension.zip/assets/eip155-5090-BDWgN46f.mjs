const n = {
  name: "Pione Chain Mainnet",
  shortName: "pio",
  chain: "PIO",
  icon: "pio",
  rpc: ["https://rpc.pionescan.com"],
  faucets: [],
  nativeCurrency: {
    name: "Pione",
    symbol: "PIO",
    decimals: 18
  },
  infoURL: "https://pionechain.com",
  chainId: 5090,
  networkId: 5090,
  explorers: [
    {
      name: "Pione Chain Explorer",
      url: "https://pionescan.com",
      standard: "EIP3091"
    }
  ]
};
export {
  n as eip155_5090
};
