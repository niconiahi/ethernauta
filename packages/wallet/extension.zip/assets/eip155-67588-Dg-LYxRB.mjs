const i = {
  name: "Cosmic Chain",
  shortName: "Cosmic",
  chain: "COSMIC",
  rpc: ["http://testnet.cosmicchain.site:3344"],
  faucets: [],
  nativeCurrency: {
    name: "Cosmic Chain",
    symbol: "COSMIC",
    decimals: 18
  },
  infoURL: "https://cosmicchain.site",
  chainId: 67588,
  networkId: 3344
};
export {
  i as eip155_67588
};
