var Q,
  p,
  Ut,
  Et,
  U,
  pt,
  Pt,
  Ct,
  Tt,
  ut,
  it,
  nt,
  O = {},
  At = [],
  ee =
    /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
  X = Array.isArray
function x(e, t) {
  for (var _ in t) e[_] = t[_]
  return e
}
function st(e) {
  e && e.parentNode && e.parentNode.removeChild(e)
}
function _e(e, t, _) {
  var i,
    r,
    n,
    f = {}
  for (n in t)
    n == "key"
      ? (i = t[n])
      : n == "ref"
        ? (r = t[n])
        : (f[n] = t[n])
  if (
    (arguments.length > 2 &&
      (f.children =
        arguments.length > 3 ? Q.call(arguments, 2) : _),
    typeof e == "function" && e.defaultProps != null)
  )
    for (n in e.defaultProps)
      f[n] === void 0 && (f[n] = e.defaultProps[n])
  return V(e, f, i, r, null)
}
function V(e, t, _, i, r) {
  var n = {
    type: e,
    props: t,
    key: _,
    ref: i,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: r ?? ++Ut,
    __i: -1,
    __u: 0,
  }
  return r == null && p.vnode != null && p.vnode(n), n
}
function j(e) {
  return e.children
}
function W(e, t) {
  ;(this.props = e), (this.context = t)
}
function P(e, t) {
  if (t == null) return e.__ ? P(e.__, e.__i + 1) : null
  for (var _; t < e.__k.length; t++)
    if ((_ = e.__k[t]) != null && _.__e != null)
      return _.__e
  return typeof e.type == "function" ? P(e) : null
}
function Ft(e) {
  var t, _
  if ((e = e.__) != null && e.__c != null) {
    for (
      e.__e = e.__c.base = null, t = 0;
      t < e.__k.length;
      t++
    )
      if ((_ = e.__k[t]) != null && _.__e != null) {
        e.__e = e.__c.base = _.__e
        break
      }
    return Ft(e)
  }
}
function dt(e) {
  ;((!e.__d && (e.__d = !0) && U.push(e) && !G.__r++) ||
    pt != p.debounceRendering) &&
    ((pt = p.debounceRendering) || Pt)(G)
}
function G() {
  for (var e, t, _, i, r, n, f, u = 1; U.length; )
    U.length > u && U.sort(Ct),
      (e = U.shift()),
      (u = U.length),
      e.__d &&
        ((_ = void 0),
        (r = (i = (t = e).__v).__e),
        (n = []),
        (f = []),
        t.__P &&
          (((_ = x({}, i)).__v = i.__v + 1),
          p.vnode && p.vnode(_),
          lt(
            t.__P,
            _,
            i,
            t.__n,
            t.__P.namespaceURI,
            32 & i.__u ? [r] : null,
            n,
            r ?? P(i),
            !!(32 & i.__u),
            f,
          ),
          (_.__v = i.__v),
          (_.__.__k[_.__i] = _),
          Wt(n, _, f),
          _.__e != r && Ft(_)))
  G.__r = 0
}
function Mt(e, t, _, i, r, n, f, u, l, s, a) {
  var o,
    h,
    c,
    $,
    k,
    b,
    d = (i && i.__k) || At,
    y = t.length
  for (l = ie(_, t, d, l, y), o = 0; o < y; o++)
    (c = _.__k[o]) != null &&
      ((h = c.__i == -1 ? O : d[c.__i] || O),
      (c.__i = o),
      (b = lt(e, c, h, r, n, f, u, l, s, a)),
      ($ = c.__e),
      c.ref &&
        h.ref != c.ref &&
        (h.ref && ct(h.ref, null, c),
        a.push(c.ref, c.__c || $, c)),
      k == null && $ != null && (k = $),
      4 & c.__u || h.__k === c.__k
        ? (l = Dt(c, l, e))
        : typeof c.type == "function" && b !== void 0
          ? (l = b)
          : $ && (l = $.nextSibling),
      (c.__u &= -7))
  return (_.__e = k), l
}
function ie(e, t, _, i, r) {
  var n,
    f,
    u,
    l,
    s,
    a = _.length,
    o = a,
    h = 0
  for (e.__k = new Array(r), n = 0; n < r; n++)
    (f = t[n]) != null &&
    typeof f != "boolean" &&
    typeof f != "function"
      ? ((l = n + h),
        ((f = e.__k[n] =
          typeof f == "string" ||
          typeof f == "number" ||
          typeof f == "bigint" ||
          f.constructor == String
            ? V(null, f, null, null, null)
            : X(f)
              ? V(j, { children: f }, null, null, null)
              : f.constructor == null && f.__b > 0
                ? V(
                    f.type,
                    f.props,
                    f.key,
                    f.ref ? f.ref : null,
                    f.__v,
                  )
                : f).__ = e),
        (f.__b = e.__b + 1),
        (u = null),
        (s = f.__i = ne(f, _, l, o)) != -1 &&
          (o--, (u = _[s]) && (u.__u |= 2)),
        u == null || u.__v == null
          ? (s == -1 && (r > a ? h-- : r < a && h++),
            typeof f.type != "function" && (f.__u |= 4))
          : s != l &&
            (s == l - 1
              ? h--
              : s == l + 1
                ? h++
                : (s > l ? h-- : h++, (f.__u |= 4))))
      : (e.__k[n] = null)
  if (o)
    for (n = 0; n < a; n++)
      (u = _[n]) != null &&
        (2 & u.__u) == 0 &&
        (u.__e == i && (i = P(u)), Ot(u, u))
  return i
}
function Dt(e, t, _) {
  var i, r
  if (typeof e.type == "function") {
    for (i = e.__k, r = 0; i && r < i.length; r++)
      i[r] && ((i[r].__ = e), (t = Dt(i[r], t, _)))
    return t
  }
  e.__e != t &&
    (t && e.type && !_.contains(t) && (t = P(e)),
    _.insertBefore(e.__e, t || null),
    (t = e.__e))
  do t = t && t.nextSibling
  while (t != null && t.nodeType == 8)
  return t
}
function ne(e, t, _, i) {
  var r,
    n,
    f = e.key,
    u = e.type,
    l = t[_]
  if (
    (l === null && e.key == null) ||
    (l && f == l.key && u == l.type && (2 & l.__u) == 0)
  )
    return _
  if (i > (l != null && (2 & l.__u) == 0 ? 1 : 0))
    for (r = _ - 1, n = _ + 1; r >= 0 || n < t.length; ) {
      if (r >= 0) {
        if (
          (l = t[r]) &&
          (2 & l.__u) == 0 &&
          f == l.key &&
          u == l.type
        )
          return r
        r--
      }
      if (n < t.length) {
        if (
          (l = t[n]) &&
          (2 & l.__u) == 0 &&
          f == l.key &&
          u == l.type
        )
          return n
        n++
      }
    }
  return -1
}
function yt(e, t, _) {
  t[0] == "-"
    ? e.setProperty(t, _ ?? "")
    : (e[t] =
        _ == null
          ? ""
          : typeof _ != "number" || ee.test(t)
            ? _
            : _ + "px")
}
function z(e, t, _, i, r) {
  var n, f
  t: if (t == "style")
    if (typeof _ == "string") e.style.cssText = _
    else {
      if (
        (typeof i == "string" && (e.style.cssText = i = ""),
        i)
      )
        for (t in i) (_ && t in _) || yt(e.style, t, "")
      if (_)
        for (t in _)
          (i && _[t] == i[t]) || yt(e.style, t, _[t])
    }
  else if (t[0] == "o" && t[1] == "n")
    (n = t != (t = t.replace(Tt, "$1"))),
      (f = t.toLowerCase()),
      (t =
        f in e || t == "onFocusOut" || t == "onFocusIn"
          ? f.slice(2)
          : t.slice(2)),
      e.l || (e.l = {}),
      (e.l[t + n] = _),
      _
        ? i
          ? (_.u = i.u)
          : ((_.u = ut),
            e.addEventListener(t, n ? nt : it, n))
        : e.removeEventListener(t, n ? nt : it, n)
  else {
    if (r == "http://www.w3.org/2000/svg")
      t = t
        .replace(/xlink(H|:h)/, "h")
        .replace(/sName$/, "s")
    else if (
      t != "width" &&
      t != "height" &&
      t != "href" &&
      t != "list" &&
      t != "form" &&
      t != "tabIndex" &&
      t != "download" &&
      t != "rowSpan" &&
      t != "colSpan" &&
      t != "role" &&
      t != "popover" &&
      t in e
    )
      try {
        e[t] = _ ?? ""
        break t
      } catch {}
    typeof _ == "function" ||
      (_ == null || (_ === !1 && t[4] != "-")
        ? e.removeAttribute(t)
        : e.setAttribute(
            t,
            t == "popover" && _ == 1 ? "" : _,
          ))
  }
}
function mt(e) {
  return function (t) {
    if (this.l) {
      var _ = this.l[t.type + e]
      if (t.t == null) t.t = ut++
      else if (t.t < _.u) return
      return _(p.event ? p.event(t) : t)
    }
  }
}
function lt(e, t, _, i, r, n, f, u, l, s) {
  var a,
    o,
    h,
    c,
    $,
    k,
    b,
    d,
    y,
    A,
    N,
    R,
    F,
    vt,
    B,
    M,
    tt,
    S = t.type
  if (t.constructor != null) return null
  128 & _.__u &&
    ((l = !!(32 & _.__u)), (n = [(u = t.__e = _.__e)])),
    (a = p.__b) && a(t)
  t: if (typeof S == "function")
    try {
      if (
        ((d = t.props),
        (y = "prototype" in S && S.prototype.render),
        (A = (a = S.contextType) && i[a.__c]),
        (N = a ? (A ? A.props.value : a.__) : i),
        _.__c
          ? (b = (o = t.__c = _.__c).__ = o.__E)
          : (y
              ? (t.__c = o = new S(d, N))
              : ((t.__c = o = new W(d, N)),
                (o.constructor = S),
                (o.render = oe)),
            A && A.sub(o),
            (o.props = d),
            o.state || (o.state = {}),
            (o.context = N),
            (o.__n = i),
            (h = o.__d = !0),
            (o.__h = []),
            (o._sb = [])),
        y && o.__s == null && (o.__s = o.state),
        y &&
          S.getDerivedStateFromProps != null &&
          (o.__s == o.state && (o.__s = x({}, o.__s)),
          x(o.__s, S.getDerivedStateFromProps(d, o.__s))),
        (c = o.props),
        ($ = o.state),
        (o.__v = t),
        h)
      )
        y &&
          S.getDerivedStateFromProps == null &&
          o.componentWillMount != null &&
          o.componentWillMount(),
          y &&
            o.componentDidMount != null &&
            o.__h.push(o.componentDidMount)
      else {
        if (
          (y &&
            S.getDerivedStateFromProps == null &&
            d !== c &&
            o.componentWillReceiveProps != null &&
            o.componentWillReceiveProps(d, N),
          (!o.__e &&
            o.shouldComponentUpdate != null &&
            o.shouldComponentUpdate(d, o.__s, N) === !1) ||
            t.__v == _.__v)
        ) {
          for (
            t.__v != _.__v &&
              ((o.props = d),
              (o.state = o.__s),
              (o.__d = !1)),
              t.__e = _.__e,
              t.__k = _.__k,
              t.__k.some(function (D) {
                D && (D.__ = t)
              }),
              R = 0;
            R < o._sb.length;
            R++
          )
            o.__h.push(o._sb[R])
          ;(o._sb = []), o.__h.length && f.push(o)
          break t
        }
        o.componentWillUpdate != null &&
          o.componentWillUpdate(d, o.__s, N),
          y &&
            o.componentDidUpdate != null &&
            o.__h.push(function () {
              o.componentDidUpdate(c, $, k)
            })
      }
      if (
        ((o.context = N),
        (o.props = d),
        (o.__P = e),
        (o.__e = !1),
        (F = p.__r),
        (vt = 0),
        y)
      ) {
        for (
          o.state = o.__s,
            o.__d = !1,
            F && F(t),
            a = o.render(o.props, o.state, o.context),
            B = 0;
          B < o._sb.length;
          B++
        )
          o.__h.push(o._sb[B])
        o._sb = []
      } else
        do
          (o.__d = !1),
            F && F(t),
            (a = o.render(o.props, o.state, o.context)),
            (o.state = o.__s)
        while (o.__d && ++vt < 25)
      ;(o.state = o.__s),
        o.getChildContext != null &&
          (i = x(x({}, i), o.getChildContext())),
        y &&
          !h &&
          o.getSnapshotBeforeUpdate != null &&
          (k = o.getSnapshotBeforeUpdate(c, $)),
        (M = a),
        a != null &&
          a.type === j &&
          a.key == null &&
          (M = Lt(a.props.children)),
        (u = Mt(
          e,
          X(M) ? M : [M],
          t,
          _,
          i,
          r,
          n,
          f,
          u,
          l,
          s,
        )),
        (o.base = t.__e),
        (t.__u &= -161),
        o.__h.length && f.push(o),
        b && (o.__E = o.__ = null)
    } catch (D) {
      if (((t.__v = null), l || n != null))
        if (D.then) {
          for (
            t.__u |= l ? 160 : 128;
            u && u.nodeType == 8 && u.nextSibling;
          )
            u = u.nextSibling
          ;(n[n.indexOf(u)] = null), (t.__e = u)
        } else for (tt = n.length; tt--; ) st(n[tt])
      else (t.__e = _.__e), (t.__k = _.__k)
      p.__e(D, t, _)
    }
  else
    n == null && t.__v == _.__v
      ? ((t.__k = _.__k), (t.__e = _.__e))
      : (u = t.__e = re(_.__e, t, _, i, r, n, f, l, s))
  return (a = p.diffed) && a(t), 128 & t.__u ? void 0 : u
}
function Wt(e, t, _) {
  for (var i = 0; i < _.length; i++)
    ct(_[i], _[++i], _[++i])
  p.__c && p.__c(t, e),
    e.some(function (r) {
      try {
        ;(e = r.__h),
          (r.__h = []),
          e.some(function (n) {
            n.call(r)
          })
      } catch (n) {
        p.__e(n, r.__v)
      }
    })
}
function Lt(e) {
  return typeof e != "object" ||
    e == null ||
    (e.__b && e.__b > 0)
    ? e
    : X(e)
      ? e.map(Lt)
      : x({}, e)
}
function re(e, t, _, i, r, n, f, u, l) {
  var s,
    a,
    o,
    h,
    c,
    $,
    k,
    b = _.props,
    d = t.props,
    y = t.type
  if (
    (y == "svg"
      ? (r = "http://www.w3.org/2000/svg")
      : y == "math"
        ? (r = "http://www.w3.org/1998/Math/MathML")
        : r || (r = "http://www.w3.org/1999/xhtml"),
    n != null)
  ) {
    for (s = 0; s < n.length; s++)
      if (
        (c = n[s]) &&
        "setAttribute" in c == !!y &&
        (y ? c.localName == y : c.nodeType == 3)
      ) {
        ;(e = c), (n[s] = null)
        break
      }
  }
  if (e == null) {
    if (y == null) return document.createTextNode(d)
    ;(e = document.createElementNS(r, y, d.is && d)),
      u && (p.__m && p.__m(t, n), (u = !1)),
      (n = null)
  }
  if (y == null)
    b === d || (u && e.data == d) || (e.data = d)
  else {
    if (
      ((n = n && Q.call(e.childNodes)),
      (b = _.props || O),
      !u && n != null)
    )
      for (b = {}, s = 0; s < e.attributes.length; s++)
        b[(c = e.attributes[s]).name] = c.value
    for (s in b)
      if (((c = b[s]), s != "children")) {
        if (s == "dangerouslySetInnerHTML") o = c
        else if (!(s in d)) {
          if (
            (s == "value" && "defaultValue" in d) ||
            (s == "checked" && "defaultChecked" in d)
          )
            continue
          z(e, s, null, c, r)
        }
      }
    for (s in d)
      (c = d[s]),
        s == "children"
          ? (h = c)
          : s == "dangerouslySetInnerHTML"
            ? (a = c)
            : s == "value"
              ? ($ = c)
              : s == "checked"
                ? (k = c)
                : (u && typeof c != "function") ||
                  b[s] === c ||
                  z(e, s, c, b[s], r)
    if (a)
      u ||
        (o &&
          (a.__html == o.__html ||
            a.__html == e.innerHTML)) ||
        (e.innerHTML = a.__html),
        (t.__k = [])
    else if (
      (o && (e.innerHTML = ""),
      Mt(
        t.type == "template" ? e.content : e,
        X(h) ? h : [h],
        t,
        _,
        i,
        y == "foreignObject"
          ? "http://www.w3.org/1999/xhtml"
          : r,
        n,
        f,
        n ? n[0] : _.__k && P(_, 0),
        u,
        l,
      ),
      n != null)
    )
      for (s = n.length; s--; ) st(n[s])
    u ||
      ((s = "value"),
      y == "progress" && $ == null
        ? e.removeAttribute("value")
        : $ != null &&
          ($ !== e[s] ||
            (y == "progress" && !$) ||
            (y == "option" && $ != b[s])) &&
          z(e, s, $, b[s], r),
      (s = "checked"),
      k != null && k != e[s] && z(e, s, k, b[s], r))
  }
  return e
}
function ct(e, t, _) {
  try {
    if (typeof e == "function") {
      var i = typeof e.__u == "function"
      i && e.__u(), (i && t == null) || (e.__u = e(t))
    } else e.current = t
  } catch (r) {
    p.__e(r, _)
  }
}
function Ot(e, t, _) {
  var i, r
  if (
    (p.unmount && p.unmount(e),
    (i = e.ref) &&
      ((i.current && i.current != e.__e) || ct(i, null, t)),
    (i = e.__c) != null)
  ) {
    if (i.componentWillUnmount)
      try {
        i.componentWillUnmount()
      } catch (n) {
        p.__e(n, t)
      }
    i.base = i.__P = null
  }
  if ((i = e.__k))
    for (r = 0; r < i.length; r++)
      i[r] && Ot(i[r], t, _ || typeof e.type != "function")
  _ || st(e.__e), (e.__c = e.__ = e.__e = void 0)
}
function oe(e, t, _) {
  return this.constructor(e, _)
}
function me(e, t, _) {
  var i, r, n, f
  t == document && (t = document.documentElement),
    p.__ && p.__(e, t),
    (r = (i = !1) ? null : t.__k),
    (n = []),
    (f = []),
    lt(
      t,
      (e = t.__k = _e(j, null, [e])),
      r || O,
      O,
      t.namespaceURI,
      r ? null : t.firstChild ? Q.call(t.childNodes) : null,
      n,
      r ? r.__e : t.firstChild,
      i,
      f,
    ),
    Wt(n, e, f)
}
;(Q = At.slice),
  (p = {
    __e: function (e, t, _, i) {
      for (var r, n, f; (t = t.__); )
        if ((r = t.__c) && !r.__)
          try {
            if (
              ((n = r.constructor) &&
                n.getDerivedStateFromError != null &&
                (r.setState(n.getDerivedStateFromError(e)),
                (f = r.__d)),
              r.componentDidCatch != null &&
                (r.componentDidCatch(e, i || {}),
                (f = r.__d)),
              f)
            )
              return (r.__E = r)
          } catch (u) {
            e = u
          }
      throw e
    },
  }),
  (Ut = 0),
  (Et = function (e) {
    return e != null && e.constructor == null
  }),
  (W.prototype.setState = function (e, t) {
    var _
    ;(_ =
      this.__s != null && this.__s != this.state
        ? this.__s
        : (this.__s = x({}, this.state))),
      typeof e == "function" &&
        (e = e(x({}, _), this.props)),
      e && x(_, e),
      e != null &&
        this.__v &&
        (t && this._sb.push(t), dt(this))
  }),
  (W.prototype.forceUpdate = function (e) {
    this.__v &&
      ((this.__e = !0), e && this.__h.push(e), dt(this))
  }),
  (W.prototype.render = j),
  (U = []),
  (Pt =
    typeof Promise == "function"
      ? Promise.prototype.then.bind(Promise.resolve())
      : setTimeout),
  (Ct = function (e, t) {
    return e.__v.__b - t.__v.__b
  }),
  (G.__r = 0),
  (Tt = /(PointerCapture)$|Capture$/i),
  (ut = 0),
  (it = mt(!1)),
  (nt = mt(!0))
var fe = 0
function ge(e, t, _, i, r, n) {
  t || (t = {})
  var f,
    u,
    l = t
  if ("ref" in l)
    for (u in ((l = {}), t))
      u == "ref" ? (f = t[u]) : (l[u] = t[u])
  var s = {
    type: e,
    props: l,
    key: _,
    ref: f,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: --fe,
    __i: -1,
    __u: 0,
    __source: r,
    __self: n,
  }
  if (typeof e == "function" && (f = e.defaultProps))
    for (u in f) l[u] === void 0 && (l[u] = f[u])
  return p.vnode && p.vnode(s), s
}
var q,
  m,
  et,
  gt,
  rt = 0,
  qt = [],
  g = p,
  $t = g.__b,
  bt = g.__r,
  wt = g.diffed,
  kt = g.__c,
  St = g.unmount,
  xt = g.__
function at(e, t) {
  g.__h && g.__h(m, e, rt || t), (rt = 0)
  var _ = m.__H || (m.__H = { __: [], __h: [] })
  return e >= _.__.length && _.__.push({}), _.__[e]
}
function $e(e) {
  return (rt = 1), ue(Rt, e)
}
function ue(e, t, _) {
  var i = at(q++, 2)
  if (
    ((i.t = e),
    !i.__c &&
      ((i.__ = [
        Rt(void 0, t),
        function (u) {
          var l = i.__N ? i.__N[0] : i.__[0],
            s = i.t(l, u)
          l !== s &&
            ((i.__N = [s, i.__[1]]), i.__c.setState({}))
        },
      ]),
      (i.__c = m),
      !m.__f))
  ) {
    var r = function (u, l, s) {
      if (!i.__c.__H) return !0
      var a = i.__c.__H.__.filter(function (h) {
        return !!h.__c
      })
      if (
        a.every(function (h) {
          return !h.__N
        })
      )
        return !n || n.call(this, u, l, s)
      var o = i.__c.props !== u
      return (
        a.forEach(function (h) {
          if (h.__N) {
            var c = h.__[0]
            ;(h.__ = h.__N),
              (h.__N = void 0),
              c !== h.__[0] && (o = !0)
          }
        }),
        (n && n.call(this, u, l, s)) || o
      )
    }
    m.__f = !0
    var n = m.shouldComponentUpdate,
      f = m.componentWillUpdate
    ;(m.componentWillUpdate = function (u, l, s) {
      if (this.__e) {
        var a = n
        ;(n = void 0), r(u, l, s), (n = a)
      }
      f && f.call(this, u, l, s)
    }),
      (m.shouldComponentUpdate = r)
  }
  return i.__N || i.__
}
function be(e, t) {
  var _ = at(q++, 3)
  !g.__s &&
    It(_.__H, t) &&
    ((_.__ = e), (_.u = t), m.__H.__h.push(_))
}
function jt(e, t) {
  var _ = at(q++, 7)
  return (
    It(_.__H, t) &&
      ((_.__ = e()), (_.__H = t), (_.__h = e)),
    _.__
  )
}
function se() {
  for (var e; (e = qt.shift()); )
    if (e.__P && e.__H)
      try {
        e.__H.__h.forEach(Z),
          e.__H.__h.forEach(ot),
          (e.__H.__h = [])
      } catch (t) {
        ;(e.__H.__h = []), g.__e(t, e.__v)
      }
}
;(g.__b = function (e) {
  ;(m = null), $t && $t(e)
}),
  (g.__ = function (e, t) {
    e && t.__k && t.__k.__m && (e.__m = t.__k.__m),
      xt && xt(e, t)
  }),
  (g.__r = function (e) {
    bt && bt(e), (q = 0)
    var t = (m = e.__c).__H
    t &&
      (et === m
        ? ((t.__h = []),
          (m.__h = []),
          t.__.forEach(function (_) {
            _.__N && (_.__ = _.__N), (_.u = _.__N = void 0)
          }))
        : (t.__h.forEach(Z),
          t.__h.forEach(ot),
          (t.__h = []),
          (q = 0))),
      (et = m)
  }),
  (g.diffed = function (e) {
    wt && wt(e)
    var t = e.__c
    t &&
      t.__H &&
      (t.__H.__h.length &&
        ((qt.push(t) !== 1 &&
          gt === g.requestAnimationFrame) ||
          ((gt = g.requestAnimationFrame) || le)(se)),
      t.__H.__.forEach(function (_) {
        _.u && (_.__H = _.u), (_.u = void 0)
      })),
      (et = m = null)
  }),
  (g.__c = function (e, t) {
    t.some(function (_) {
      try {
        _.__h.forEach(Z),
          (_.__h = _.__h.filter(function (i) {
            return !i.__ || ot(i)
          }))
      } catch (i) {
        t.some(function (r) {
          r.__h && (r.__h = [])
        }),
          (t = []),
          g.__e(i, _.__v)
      }
    }),
      kt && kt(e, t)
  }),
  (g.unmount = function (e) {
    St && St(e)
    var t,
      _ = e.__c
    _ &&
      _.__H &&
      (_.__H.__.forEach(function (i) {
        try {
          Z(i)
        } catch (r) {
          t = r
        }
      }),
      (_.__H = void 0),
      t && g.__e(t, _.__v))
  })
var Nt = typeof requestAnimationFrame == "function"
function le(e) {
  var t,
    _ = function () {
      clearTimeout(i),
        Nt && cancelAnimationFrame(t),
        setTimeout(e)
    },
    i = setTimeout(_, 35)
  Nt && (t = requestAnimationFrame(_))
}
function Z(e) {
  var t = m,
    _ = e.__c
  typeof _ == "function" && ((e.__c = void 0), _()), (m = t)
}
function ot(e) {
  var t = m
  ;(e.__c = e.__()), (m = t)
}
function It(e, t) {
  return (
    !e ||
    e.length !== t.length ||
    t.some(function (_, i) {
      return _ !== e[i]
    })
  )
}
function Rt(e, t) {
  return typeof t == "function" ? t(e) : t
}
var ce = Symbol.for("preact-signals")
function Y() {
  if (H > 1) H--
  else {
    for (var e, t = !1; L !== void 0; ) {
      var _ = L
      for (L = void 0, ft++; _ !== void 0; ) {
        var i = _.o
        if (
          ((_.o = void 0), (_.f &= -3), !(8 & _.f) && Zt(_))
        )
          try {
            _.c()
          } catch (r) {
            t || ((e = r), (t = !0))
          }
        _ = i
      }
    }
    if (((ft = 0), H--, t)) throw e
  }
}
function ae(e) {
  if (H > 0) return e()
  H++
  try {
    return e()
  } finally {
    Y()
  }
}
var v = void 0
function Bt(e) {
  var t = v
  v = void 0
  try {
    return e()
  } finally {
    v = t
  }
}
var L = void 0,
  H = 0,
  ft = 0,
  J = 0
function zt(e) {
  if (v !== void 0) {
    var t = e.n
    if (t === void 0 || t.t !== v)
      return (
        (t = {
          i: 0,
          S: e,
          p: v.s,
          n: void 0,
          t: v,
          e: void 0,
          x: void 0,
          r: t,
        }),
        v.s !== void 0 && (v.s.n = t),
        (v.s = t),
        (e.n = t),
        32 & v.f && e.S(t),
        t
      )
    if (t.i === -1)
      return (
        (t.i = 0),
        t.n !== void 0 &&
          ((t.n.p = t.p),
          t.p !== void 0 && (t.p.n = t.n),
          (t.p = v.s),
          (t.n = void 0),
          (v.s.n = t),
          (v.s = t)),
        t
      )
  }
}
function w(e, t) {
  ;(this.v = e),
    (this.i = 0),
    (this.n = void 0),
    (this.t = void 0),
    (this.W = t?.watched),
    (this.Z = t?.unwatched)
}
w.prototype.brand = ce
w.prototype.h = function () {
  return !0
}
w.prototype.S = function (e) {
  var t = this,
    _ = this.t
  _ !== e &&
    e.e === void 0 &&
    ((e.x = _),
    (this.t = e),
    _ !== void 0
      ? (_.e = e)
      : Bt(function () {
          var i
          ;(i = t.W) == null || i.call(t)
        }))
}
w.prototype.U = function (e) {
  var t = this
  if (this.t !== void 0) {
    var _ = e.e,
      i = e.x
    _ !== void 0 && ((_.x = i), (e.e = void 0)),
      i !== void 0 && ((i.e = _), (e.x = void 0)),
      e === this.t &&
        ((this.t = i),
        i === void 0 &&
          Bt(function () {
            var r
            ;(r = t.Z) == null || r.call(t)
          }))
  }
}
w.prototype.subscribe = function (e) {
  var t = this
  return I(function () {
    var _ = t.value,
      i = v
    v = void 0
    try {
      e(_)
    } finally {
      v = i
    }
  })
}
w.prototype.valueOf = function () {
  return this.value
}
w.prototype.toString = function () {
  return this.value + ""
}
w.prototype.toJSON = function () {
  return this.value
}
w.prototype.peek = function () {
  var e = v
  v = void 0
  try {
    return this.value
  } finally {
    v = e
  }
}
Object.defineProperty(w.prototype, "value", {
  get: function () {
    var e = zt(this)
    return e !== void 0 && (e.i = this.i), this.v
  },
  set: function (e) {
    if (e !== this.v) {
      if (ft > 100) throw new Error("Cycle detected")
      ;(this.v = e), this.i++, J++, H++
      try {
        for (var t = this.t; t !== void 0; t = t.x) t.t.N()
      } finally {
        Y()
      }
    }
  },
})
function Vt(e, t) {
  return new w(e, t)
}
function Zt(e) {
  for (var t = e.s; t !== void 0; t = t.n)
    if (t.S.i !== t.i || !t.S.h() || t.S.i !== t.i)
      return !0
  return !1
}
function Gt(e) {
  for (var t = e.s; t !== void 0; t = t.n) {
    var _ = t.S.n
    if (
      (_ !== void 0 && (t.r = _),
      (t.S.n = t),
      (t.i = -1),
      t.n === void 0)
    ) {
      e.s = t
      break
    }
  }
}
function Jt(e) {
  for (var t = e.s, _ = void 0; t !== void 0; ) {
    var i = t.p
    t.i === -1
      ? (t.S.U(t),
        i !== void 0 && (i.n = t.n),
        t.n !== void 0 && (t.n.p = i))
      : (_ = t),
      (t.S.n = t.r),
      t.r !== void 0 && (t.r = void 0),
      (t = i)
  }
  e.s = _
}
function E(e, t) {
  w.call(this, void 0),
    (this.x = e),
    (this.s = void 0),
    (this.g = J - 1),
    (this.f = 4),
    (this.W = t?.watched),
    (this.Z = t?.unwatched)
}
E.prototype = new w()
E.prototype.h = function () {
  if (((this.f &= -3), 1 & this.f)) return !1
  if ((36 & this.f) == 32 || ((this.f &= -5), this.g === J))
    return !0
  if (
    ((this.g = J), (this.f |= 1), this.i > 0 && !Zt(this))
  )
    return (this.f &= -2), !0
  var e = v
  try {
    Gt(this), (v = this)
    var t = this.x()
    ;(16 & this.f || this.v !== t || this.i === 0) &&
      ((this.v = t), (this.f &= -17), this.i++)
  } catch (_) {
    ;(this.v = _), (this.f |= 16), this.i++
  }
  return (v = e), Jt(this), (this.f &= -2), !0
}
E.prototype.S = function (e) {
  if (this.t === void 0) {
    this.f |= 36
    for (var t = this.s; t !== void 0; t = t.n) t.S.S(t)
  }
  w.prototype.S.call(this, e)
}
E.prototype.U = function (e) {
  if (
    this.t !== void 0 &&
    (w.prototype.U.call(this, e), this.t === void 0)
  ) {
    this.f &= -33
    for (var t = this.s; t !== void 0; t = t.n) t.S.U(t)
  }
}
E.prototype.N = function () {
  if (!(2 & this.f)) {
    this.f |= 6
    for (var e = this.t; e !== void 0; e = e.x) e.t.N()
  }
}
Object.defineProperty(E.prototype, "value", {
  get: function () {
    if (1 & this.f) throw new Error("Cycle detected")
    var e = zt(this)
    if (
      (this.h(),
      e !== void 0 && (e.i = this.i),
      16 & this.f)
    )
      throw this.v
    return this.v
  },
})
function Ht(e, t) {
  return new E(e, t)
}
function Kt(e) {
  var t = e.u
  if (((e.u = void 0), typeof t == "function")) {
    H++
    var _ = v
    v = void 0
    try {
      t()
    } catch (i) {
      throw ((e.f &= -2), (e.f |= 8), ht(e), i)
    } finally {
      ;(v = _), Y()
    }
  }
}
function ht(e) {
  for (var t = e.s; t !== void 0; t = t.n) t.S.U(t)
  ;(e.x = void 0), (e.s = void 0), Kt(e)
}
function he(e) {
  if (v !== this) throw new Error("Out-of-order effect")
  Jt(this),
    (v = e),
    (this.f &= -2),
    8 & this.f && ht(this),
    Y()
}
function C(e) {
  ;(this.x = e),
    (this.u = void 0),
    (this.s = void 0),
    (this.o = void 0),
    (this.f = 32)
}
C.prototype.c = function () {
  var e = this.S()
  try {
    if (8 & this.f || this.x === void 0) return
    var t = this.x()
    typeof t == "function" && (this.u = t)
  } finally {
    e()
  }
}
C.prototype.S = function () {
  if (1 & this.f) throw new Error("Cycle detected")
  ;(this.f |= 1), (this.f &= -9), Kt(this), Gt(this), H++
  var e = v
  return (v = this), he.bind(this, e)
}
C.prototype.N = function () {
  2 & this.f || ((this.f |= 2), (this.o = L), (L = this))
}
C.prototype.d = function () {
  ;(this.f |= 8), 1 & this.f || ht(this)
}
C.prototype.dispose = function () {
  this.d()
}
function I(e) {
  var t = new C(e)
  try {
    t.c()
  } catch (i) {
    throw (t.d(), i)
  }
  var _ = t.d.bind(t)
  return (_[Symbol.dispose] = _), _
}
var Qt,
  _t,
  Xt = []
I(function () {
  Qt = this.N
})()
function T(e, t) {
  p[e] = t.bind(null, p[e] || function () {})
}
function K(e) {
  _t && _t(), (_t = e && e.S())
}
function Yt(e) {
  var t = this,
    _ = e.data,
    i = pe(_)
  i.value = _
  var r = jt(function () {
      for (var u = t, l = t.__v; (l = l.__); )
        if (l.__c) {
          l.__c.__$f |= 4
          break
        }
      var s = Ht(function () {
          var c = i.value.value
          return c === 0 ? 0 : c === !0 ? "" : c || ""
        }),
        a = Ht(function () {
          return !Array.isArray(s.value) && !Et(s.value)
        }),
        o = I(function () {
          if (((this.N = te), a.value)) {
            var c = s.value
            u.__v &&
              u.__v.__e &&
              u.__v.__e.nodeType === 3 &&
              (u.__v.__e.data = c)
          }
        }),
        h = t.__$u.d
      return (
        (t.__$u.d = function () {
          o(), h.call(this)
        }),
        [a, s]
      )
    }, []),
    n = r[0],
    f = r[1]
  return n.value ? f.peek() : f.value
}
Yt.displayName = "_st"
Object.defineProperties(w.prototype, {
  constructor: { configurable: !0, value: void 0 },
  type: { configurable: !0, value: Yt },
  props: {
    configurable: !0,
    get: function () {
      return { data: this }
    },
  },
  __b: { configurable: !0, value: 1 },
})
T("__b", function (e, t) {
  if (typeof t.type == "string") {
    var _,
      i = t.props
    for (var r in i)
      if (r !== "children") {
        var n = i[r]
        n instanceof w &&
          (_ || (t.__np = _ = {}),
          (_[r] = n),
          (i[r] = n.peek()))
      }
  }
  e(t)
})
T("__r", function (e, t) {
  if (t.type !== j) {
    K()
    var _,
      i = t.__c
    i &&
      ((i.__$f &= -2),
      (_ = i.__$u) === void 0 &&
        (i.__$u = _ =
          (function (r) {
            var n
            return (
              I(function () {
                n = this
              }),
              (n.c = function () {
                ;(i.__$f |= 1), i.setState({})
              }),
              n
            )
          })())),
      K(_)
  }
  e(t)
})
T("__e", function (e, t, _, i) {
  K(), e(t, _, i)
})
T("diffed", function (e, t) {
  K()
  var _
  if (typeof t.type == "string" && (_ = t.__e)) {
    var i = t.__np,
      r = t.props
    if (i) {
      var n = _.U
      if (n)
        for (var f in n) {
          var u = n[f]
          u !== void 0 &&
            !(f in i) &&
            (u.d(), (n[f] = void 0))
        }
      else (n = {}), (_.U = n)
      for (var l in i) {
        var s = n[l],
          a = i[l]
        s === void 0
          ? ((s = ve(_, l, a, r)), (n[l] = s))
          : s.o(a, r)
      }
    }
  }
  e(t)
})
function ve(e, t, _, i) {
  var r = t in e && e.ownerSVGElement === void 0,
    n = Vt(_)
  return {
    o: function (f, u) {
      ;(n.value = f), (i = u)
    },
    d: I(function () {
      this.N = te
      var f = n.value.value
      i[t] !== f &&
        ((i[t] = f),
        r
          ? (e[t] = f)
          : f
            ? e.setAttribute(t, f)
            : e.removeAttribute(t))
    }),
  }
}
T("unmount", function (e, t) {
  if (typeof t.type == "string") {
    var _ = t.__e
    if (_) {
      var i = _.U
      if (i) {
        _.U = void 0
        for (var r in i) {
          var n = i[r]
          n && n.d()
        }
      }
    }
  } else {
    var f = t.__c
    if (f) {
      var u = f.__$u
      u && ((f.__$u = void 0), u.d())
    }
  }
  e(t)
})
T("__h", function (e, t, _, i) {
  ;(i < 3 || i === 9) && (t.__$f |= 2), e(t, _, i)
})
W.prototype.shouldComponentUpdate = function (e, t) {
  var _ = this.__$u,
    i = _ && _.s !== void 0
  for (var r in t) return !0
  if (
    this.__f ||
    (typeof this.u == "boolean" && this.u === !0)
  ) {
    var n = 2 & this.__$f
    if (!(i || n || 4 & this.__$f) || 1 & this.__$f)
      return !0
  } else if (!(i || 4 & this.__$f) || 3 & this.__$f)
    return !0
  for (var f in e)
    if (f !== "__source" && e[f] !== this.props[f])
      return !0
  for (var u in this.props) if (!(u in e)) return !0
  return !1
}
function pe(e, t) {
  return jt(function () {
    return Vt(e, t)
  }, [])
}
var de = function (e) {
  queueMicrotask(function () {
    queueMicrotask(e)
  })
}
function ye() {
  ae(function () {
    for (var e; (e = Xt.shift()); ) Qt.call(e)
  })
}
function te() {
  Xt.push(this) === 1 && (p.requestAnimationFrame || de)(ye)
}
export {
  me as E,
  $e as a,
  Vt as d,
  j as k,
  ge as u,
  be as y,
}
