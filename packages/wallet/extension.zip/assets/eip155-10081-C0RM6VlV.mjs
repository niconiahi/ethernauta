const n = {
  name: "Japan Open Chain Testnet",
  shortName: "joct",
  chain: "JOCT",
  icon: "joct",
  rpc: [
    "https://rpc-1.testnet.japanopenchain.org:8545",
    "https://rpc-2.testnet.japanopenchain.org:8545",
    "https://rpc-3.testnet.japanopenchain.org"
  ],
  faucets: [],
  nativeCurrency: {
    name: "Japan Open Chain Testnet Token",
    symbol: "JOCT",
    decimals: 18
  },
  infoURL: "https://www.japanopenchain.org/",
  chainId: 10081,
  networkId: 10081,
  slip44: 1,
  explorers: [
    {
      name: "Testnet Block Explorer",
      url: "https://explorer.testnet.japanopenchain.org",
      standard: "EIP3091"
    }
  ]
};
export {
  n as eip155_10081
};
