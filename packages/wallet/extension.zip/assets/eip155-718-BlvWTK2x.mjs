const n = {
  name: "UXLINK ONE Mainnet",
  shortName: "uxlink1",
  chain: "UXLINK ONE",
  icon: "uxlinkone",
  rpc: ["https://rpc.uxlinkone.com"],
  faucets: [],
  features: [
    {
      name: "EIP155"
    },
    {
      name: "EIP1559"
    }
  ],
  nativeCurrency: {
    name: "UXLINK",
    symbol: "UXLINK",
    decimals: 18
  },
  infoURL: "https://www.uxlinkone.com",
  chainId: 718,
  networkId: 718,
  explorers: [
    {
      name: "UXLINK ONE Mainnet Explorer",
      url: "https://sepolia.uxlinkone.com",
      standard: "EIP3091"
    }
  ]
};
export {
  n as eip155_718
};
