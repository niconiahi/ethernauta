var tt,
  v,
  Ct,
  Tt,
  H,
  mt,
  At,
  Ft,
  Mt,
  lt,
  rt,
  ot,
  O = {},
  Dt = [],
  ie =
    /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
  et = Array.isArray
function x(e, t) {
  for (var _ in t) e[_] = t[_]
  return e
}
function at(e) {
  e && e.parentNode && e.parentNode.removeChild(e)
}
function ne(e, t, _) {
  var i,
    n,
    r,
    f = {}
  for (r in t)
    r == "key"
      ? (i = t[r])
      : r == "ref"
        ? (n = t[r])
        : (f[r] = t[r])
  if (
    (arguments.length > 2 &&
      (f.children =
        arguments.length > 3 ? tt.call(arguments, 2) : _),
    typeof e == "function" && e.defaultProps != null)
  )
    for (r in e.defaultProps)
      f[r] === void 0 && (f[r] = e.defaultProps[r])
  return Z(e, f, i, n, null)
}
function Z(e, t, _, i, n) {
  var r = {
    type: e,
    props: t,
    key: _,
    ref: i,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: n ?? ++Ct,
    __i: -1,
    __u: 0,
  }
  return n == null && v.vnode != null && v.vnode(r), r
}
function q(e) {
  return e.children
}
function L(e, t) {
  ;(this.props = e), (this.context = t)
}
function P(e, t) {
  if (t == null) return e.__ ? P(e.__, e.__i + 1) : null
  for (var _; t < e.__k.length; t++)
    if ((_ = e.__k[t]) != null && _.__e != null)
      return _.__e
  return typeof e.type == "function" ? P(e) : null
}
function Lt(e) {
  var t, _
  if ((e = e.__) != null && e.__c != null) {
    for (
      e.__e = e.__c.base = null, t = 0;
      t < e.__k.length;
      t++
    )
      if ((_ = e.__k[t]) != null && _.__e != null) {
        e.__e = e.__c.base = _.__e
        break
      }
    return Lt(e)
  }
}
function gt(e) {
  ;((!e.__d && (e.__d = !0) && H.push(e) && !J.__r++) ||
    mt != v.debounceRendering) &&
    ((mt = v.debounceRendering) || At)(J)
}
function J() {
  for (var e, t, _, i, n, r, f, u = 1; H.length; )
    H.length > u && H.sort(Ft),
      (e = H.shift()),
      (u = H.length),
      e.__d &&
        ((_ = void 0),
        (n = (i = (t = e).__v).__e),
        (r = []),
        (f = []),
        t.__P &&
          (((_ = x({}, i)).__v = i.__v + 1),
          v.vnode && v.vnode(_),
          ct(
            t.__P,
            _,
            i,
            t.__n,
            t.__P.namespaceURI,
            32 & i.__u ? [n] : null,
            r,
            n ?? P(i),
            !!(32 & i.__u),
            f,
          ),
          (_.__v = i.__v),
          (_.__.__k[_.__i] = _),
          jt(r, _, f),
          _.__e != n && Lt(_)))
  J.__r = 0
}
function Wt(e, t, _, i, n, r, f, u, l, s, c) {
  var o,
    h,
    a,
    $,
    k,
    b,
    d = (i && i.__k) || Dt,
    y = t.length
  for (l = re(_, t, d, l, y), o = 0; o < y; o++)
    (a = _.__k[o]) != null &&
      ((h = a.__i == -1 ? O : d[a.__i] || O),
      (a.__i = o),
      (b = ct(e, a, h, n, r, f, u, l, s, c)),
      ($ = a.__e),
      a.ref &&
        h.ref != a.ref &&
        (h.ref && ht(h.ref, null, a),
        c.push(a.ref, a.__c || $, a)),
      k == null && $ != null && (k = $),
      4 & a.__u || h.__k === a.__k
        ? (l = Ot(a, l, e))
        : typeof a.type == "function" && b !== void 0
          ? (l = b)
          : $ && (l = $.nextSibling),
      (a.__u &= -7))
  return (_.__e = k), l
}
function re(e, t, _, i, n) {
  var r,
    f,
    u,
    l,
    s,
    c = _.length,
    o = c,
    h = 0
  for (e.__k = new Array(n), r = 0; r < n; r++)
    (f = t[r]) != null &&
    typeof f != "boolean" &&
    typeof f != "function"
      ? ((l = r + h),
        ((f = e.__k[r] =
          typeof f == "string" ||
          typeof f == "number" ||
          typeof f == "bigint" ||
          f.constructor == String
            ? Z(null, f, null, null, null)
            : et(f)
              ? Z(q, { children: f }, null, null, null)
              : f.constructor == null && f.__b > 0
                ? Z(
                    f.type,
                    f.props,
                    f.key,
                    f.ref ? f.ref : null,
                    f.__v,
                  )
                : f).__ = e),
        (f.__b = e.__b + 1),
        (u = null),
        (s = f.__i = oe(f, _, l, o)) != -1 &&
          (o--, (u = _[s]) && (u.__u |= 2)),
        u == null || u.__v == null
          ? (s == -1 && (n > c ? h-- : n < c && h++),
            typeof f.type != "function" && (f.__u |= 4))
          : s != l &&
            (s == l - 1
              ? h--
              : s == l + 1
                ? h++
                : (s > l ? h-- : h++, (f.__u |= 4))))
      : (e.__k[r] = null)
  if (o)
    for (r = 0; r < c; r++)
      (u = _[r]) != null &&
        (2 & u.__u) == 0 &&
        (u.__e == i && (i = P(u)), Rt(u, u))
  return i
}
function Ot(e, t, _) {
  var i, n
  if (typeof e.type == "function") {
    for (i = e.__k, n = 0; i && n < i.length; n++)
      i[n] && ((i[n].__ = e), (t = Ot(i[n], t, _)))
    return t
  }
  e.__e != t &&
    (t && e.type && !_.contains(t) && (t = P(e)),
    _.insertBefore(e.__e, t || null),
    (t = e.__e))
  do t = t && t.nextSibling
  while (t != null && t.nodeType == 8)
  return t
}
function oe(e, t, _, i) {
  var n,
    r,
    f = e.key,
    u = e.type,
    l = t[_]
  if (
    (l === null && e.key == null) ||
    (l && f == l.key && u == l.type && (2 & l.__u) == 0)
  )
    return _
  if (i > (l != null && (2 & l.__u) == 0 ? 1 : 0))
    for (n = _ - 1, r = _ + 1; n >= 0 || r < t.length; ) {
      if (n >= 0) {
        if (
          (l = t[n]) &&
          (2 & l.__u) == 0 &&
          f == l.key &&
          u == l.type
        )
          return n
        n--
      }
      if (r < t.length) {
        if (
          (l = t[r]) &&
          (2 & l.__u) == 0 &&
          f == l.key &&
          u == l.type
        )
          return r
        r++
      }
    }
  return -1
}
function $t(e, t, _) {
  t[0] == "-"
    ? e.setProperty(t, _ ?? "")
    : (e[t] =
        _ == null
          ? ""
          : typeof _ != "number" || ie.test(t)
            ? _
            : _ + "px")
}
function V(e, t, _, i, n) {
  var r, f
  t: if (t == "style")
    if (typeof _ == "string") e.style.cssText = _
    else {
      if (
        (typeof i == "string" && (e.style.cssText = i = ""),
        i)
      )
        for (t in i) (_ && t in _) || $t(e.style, t, "")
      if (_)
        for (t in _)
          (i && _[t] == i[t]) || $t(e.style, t, _[t])
    }
  else if (t[0] == "o" && t[1] == "n")
    (r = t != (t = t.replace(Mt, "$1"))),
      (f = t.toLowerCase()),
      (t =
        f in e || t == "onFocusOut" || t == "onFocusIn"
          ? f.slice(2)
          : t.slice(2)),
      e.l || (e.l = {}),
      (e.l[t + r] = _),
      _
        ? i
          ? (_.u = i.u)
          : ((_.u = lt),
            e.addEventListener(t, r ? ot : rt, r))
        : e.removeEventListener(t, r ? ot : rt, r)
  else {
    if (n == "http://www.w3.org/2000/svg")
      t = t
        .replace(/xlink(H|:h)/, "h")
        .replace(/sName$/, "s")
    else if (
      t != "width" &&
      t != "height" &&
      t != "href" &&
      t != "list" &&
      t != "form" &&
      t != "tabIndex" &&
      t != "download" &&
      t != "rowSpan" &&
      t != "colSpan" &&
      t != "role" &&
      t != "popover" &&
      t in e
    )
      try {
        e[t] = _ ?? ""
        break t
      } catch {}
    typeof _ == "function" ||
      (_ == null || (_ === !1 && t[4] != "-")
        ? e.removeAttribute(t)
        : e.setAttribute(
            t,
            t == "popover" && _ == 1 ? "" : _,
          ))
  }
}
function bt(e) {
  return function (t) {
    if (this.l) {
      var _ = this.l[t.type + e]
      if (t.t == null) t.t = lt++
      else if (t.t < _.u) return
      return _(v.event ? v.event(t) : t)
    }
  }
}
function ct(e, t, _, i, n, r, f, u, l, s) {
  var c,
    o,
    h,
    a,
    $,
    k,
    b,
    d,
    y,
    A,
    E,
    I,
    F,
    yt,
    B,
    M,
    it,
    S = t.type
  if (t.constructor != null) return null
  128 & _.__u &&
    ((l = !!(32 & _.__u)), (r = [(u = t.__e = _.__e)])),
    (c = v.__b) && c(t)
  t: if (typeof S == "function")
    try {
      if (
        ((d = t.props),
        (y = "prototype" in S && S.prototype.render),
        (A = (c = S.contextType) && i[c.__c]),
        (E = c ? (A ? A.props.value : c.__) : i),
        _.__c
          ? (b = (o = t.__c = _.__c).__ = o.__E)
          : (y
              ? (t.__c = o = new S(d, E))
              : ((t.__c = o = new L(d, E)),
                (o.constructor = S),
                (o.render = ue)),
            A && A.sub(o),
            (o.props = d),
            o.state || (o.state = {}),
            (o.context = E),
            (o.__n = i),
            (h = o.__d = !0),
            (o.__h = []),
            (o._sb = [])),
        y && o.__s == null && (o.__s = o.state),
        y &&
          S.getDerivedStateFromProps != null &&
          (o.__s == o.state && (o.__s = x({}, o.__s)),
          x(o.__s, S.getDerivedStateFromProps(d, o.__s))),
        (a = o.props),
        ($ = o.state),
        (o.__v = t),
        h)
      )
        y &&
          S.getDerivedStateFromProps == null &&
          o.componentWillMount != null &&
          o.componentWillMount(),
          y &&
            o.componentDidMount != null &&
            o.__h.push(o.componentDidMount)
      else {
        if (
          (y &&
            S.getDerivedStateFromProps == null &&
            d !== a &&
            o.componentWillReceiveProps != null &&
            o.componentWillReceiveProps(d, E),
          (!o.__e &&
            o.shouldComponentUpdate != null &&
            o.shouldComponentUpdate(d, o.__s, E) === !1) ||
            t.__v == _.__v)
        ) {
          for (
            t.__v != _.__v &&
              ((o.props = d),
              (o.state = o.__s),
              (o.__d = !1)),
              t.__e = _.__e,
              t.__k = _.__k,
              t.__k.some(function (D) {
                D && (D.__ = t)
              }),
              I = 0;
            I < o._sb.length;
            I++
          )
            o.__h.push(o._sb[I])
          ;(o._sb = []), o.__h.length && f.push(o)
          break t
        }
        o.componentWillUpdate != null &&
          o.componentWillUpdate(d, o.__s, E),
          y &&
            o.componentDidUpdate != null &&
            o.__h.push(function () {
              o.componentDidUpdate(a, $, k)
            })
      }
      if (
        ((o.context = E),
        (o.props = d),
        (o.__P = e),
        (o.__e = !1),
        (F = v.__r),
        (yt = 0),
        y)
      ) {
        for (
          o.state = o.__s,
            o.__d = !1,
            F && F(t),
            c = o.render(o.props, o.state, o.context),
            B = 0;
          B < o._sb.length;
          B++
        )
          o.__h.push(o._sb[B])
        o._sb = []
      } else
        do
          (o.__d = !1),
            F && F(t),
            (c = o.render(o.props, o.state, o.context)),
            (o.state = o.__s)
        while (o.__d && ++yt < 25)
      ;(o.state = o.__s),
        o.getChildContext != null &&
          (i = x(x({}, i), o.getChildContext())),
        y &&
          !h &&
          o.getSnapshotBeforeUpdate != null &&
          (k = o.getSnapshotBeforeUpdate(a, $)),
        (M = c),
        c != null &&
          c.type === q &&
          c.key == null &&
          (M = qt(c.props.children)),
        (u = Wt(
          e,
          et(M) ? M : [M],
          t,
          _,
          i,
          n,
          r,
          f,
          u,
          l,
          s,
        )),
        (o.base = t.__e),
        (t.__u &= -161),
        o.__h.length && f.push(o),
        b && (o.__E = o.__ = null)
    } catch (D) {
      if (((t.__v = null), l || r != null))
        if (D.then) {
          for (
            t.__u |= l ? 160 : 128;
            u && u.nodeType == 8 && u.nextSibling;
          )
            u = u.nextSibling
          ;(r[r.indexOf(u)] = null), (t.__e = u)
        } else for (it = r.length; it--; ) at(r[it])
      else (t.__e = _.__e), (t.__k = _.__k)
      v.__e(D, t, _)
    }
  else
    r == null && t.__v == _.__v
      ? ((t.__k = _.__k), (t.__e = _.__e))
      : (u = t.__e = fe(_.__e, t, _, i, n, r, f, l, s))
  return (c = v.diffed) && c(t), 128 & t.__u ? void 0 : u
}
function jt(e, t, _) {
  for (var i = 0; i < _.length; i++)
    ht(_[i], _[++i], _[++i])
  v.__c && v.__c(t, e),
    e.some(function (n) {
      try {
        ;(e = n.__h),
          (n.__h = []),
          e.some(function (r) {
            r.call(n)
          })
      } catch (r) {
        v.__e(r, n.__v)
      }
    })
}
function qt(e) {
  return typeof e != "object" ||
    e == null ||
    (e.__b && e.__b > 0)
    ? e
    : et(e)
      ? e.map(qt)
      : x({}, e)
}
function fe(e, t, _, i, n, r, f, u, l) {
  var s,
    c,
    o,
    h,
    a,
    $,
    k,
    b = _.props,
    d = t.props,
    y = t.type
  if (
    (y == "svg"
      ? (n = "http://www.w3.org/2000/svg")
      : y == "math"
        ? (n = "http://www.w3.org/1998/Math/MathML")
        : n || (n = "http://www.w3.org/1999/xhtml"),
    r != null)
  ) {
    for (s = 0; s < r.length; s++)
      if (
        (a = r[s]) &&
        "setAttribute" in a == !!y &&
        (y ? a.localName == y : a.nodeType == 3)
      ) {
        ;(e = a), (r[s] = null)
        break
      }
  }
  if (e == null) {
    if (y == null) return document.createTextNode(d)
    ;(e = document.createElementNS(n, y, d.is && d)),
      u && (v.__m && v.__m(t, r), (u = !1)),
      (r = null)
  }
  if (y == null)
    b === d || (u && e.data == d) || (e.data = d)
  else {
    if (
      ((r = r && tt.call(e.childNodes)),
      (b = _.props || O),
      !u && r != null)
    )
      for (b = {}, s = 0; s < e.attributes.length; s++)
        b[(a = e.attributes[s]).name] = a.value
    for (s in b)
      if (((a = b[s]), s != "children")) {
        if (s == "dangerouslySetInnerHTML") o = a
        else if (!(s in d)) {
          if (
            (s == "value" && "defaultValue" in d) ||
            (s == "checked" && "defaultChecked" in d)
          )
            continue
          V(e, s, null, a, n)
        }
      }
    for (s in d)
      (a = d[s]),
        s == "children"
          ? (h = a)
          : s == "dangerouslySetInnerHTML"
            ? (c = a)
            : s == "value"
              ? ($ = a)
              : s == "checked"
                ? (k = a)
                : (u && typeof a != "function") ||
                  b[s] === a ||
                  V(e, s, a, b[s], n)
    if (c)
      u ||
        (o &&
          (c.__html == o.__html ||
            c.__html == e.innerHTML)) ||
        (e.innerHTML = c.__html),
        (t.__k = [])
    else if (
      (o && (e.innerHTML = ""),
      Wt(
        t.type == "template" ? e.content : e,
        et(h) ? h : [h],
        t,
        _,
        i,
        y == "foreignObject"
          ? "http://www.w3.org/1999/xhtml"
          : n,
        r,
        f,
        r ? r[0] : _.__k && P(_, 0),
        u,
        l,
      ),
      r != null)
    )
      for (s = r.length; s--; ) at(r[s])
    u ||
      ((s = "value"),
      y == "progress" && $ == null
        ? e.removeAttribute("value")
        : $ != null &&
          ($ !== e[s] ||
            (y == "progress" && !$) ||
            (y == "option" && $ != b[s])) &&
          V(e, s, $, b[s], n),
      (s = "checked"),
      k != null && k != e[s] && V(e, s, k, b[s], n))
  }
  return e
}
function ht(e, t, _) {
  try {
    if (typeof e == "function") {
      var i = typeof e.__u == "function"
      i && e.__u(), (i && t == null) || (e.__u = e(t))
    } else e.current = t
  } catch (n) {
    v.__e(n, _)
  }
}
function Rt(e, t, _) {
  var i, n
  if (
    (v.unmount && v.unmount(e),
    (i = e.ref) &&
      ((i.current && i.current != e.__e) || ht(i, null, t)),
    (i = e.__c) != null)
  ) {
    if (i.componentWillUnmount)
      try {
        i.componentWillUnmount()
      } catch (r) {
        v.__e(r, t)
      }
    i.base = i.__P = null
  }
  if ((i = e.__k))
    for (n = 0; n < i.length; n++)
      i[n] && Rt(i[n], t, _ || typeof e.type != "function")
  _ || at(e.__e), (e.__c = e.__ = e.__e = void 0)
}
function ue(e, t, _) {
  return this.constructor(e, _)
}
function we(e, t, _) {
  var i, n, r, f
  t == document && (t = document.documentElement),
    v.__ && v.__(e, t),
    (n = (i = !1) ? null : t.__k),
    (r = []),
    (f = []),
    ct(
      t,
      (e = t.__k = ne(q, null, [e])),
      n || O,
      O,
      t.namespaceURI,
      n
        ? null
        : t.firstChild
          ? tt.call(t.childNodes)
          : null,
      r,
      n ? n.__e : t.firstChild,
      i,
      f,
    ),
    jt(r, e, f)
}
;(tt = Dt.slice),
  (v = {
    __e: function (e, t, _, i) {
      for (var n, r, f; (t = t.__); )
        if ((n = t.__c) && !n.__)
          try {
            if (
              ((r = n.constructor) &&
                r.getDerivedStateFromError != null &&
                (n.setState(r.getDerivedStateFromError(e)),
                (f = n.__d)),
              n.componentDidCatch != null &&
                (n.componentDidCatch(e, i || {}),
                (f = n.__d)),
              f)
            )
              return (n.__E = n)
          } catch (u) {
            e = u
          }
      throw e
    },
  }),
  (Ct = 0),
  (Tt = function (e) {
    return e != null && e.constructor == null
  }),
  (L.prototype.setState = function (e, t) {
    var _
    ;(_ =
      this.__s != null && this.__s != this.state
        ? this.__s
        : (this.__s = x({}, this.state))),
      typeof e == "function" &&
        (e = e(x({}, _), this.props)),
      e && x(_, e),
      e != null &&
        this.__v &&
        (t && this._sb.push(t), gt(this))
  }),
  (L.prototype.forceUpdate = function (e) {
    this.__v &&
      ((this.__e = !0), e && this.__h.push(e), gt(this))
  }),
  (L.prototype.render = q),
  (H = []),
  (At =
    typeof Promise == "function"
      ? Promise.prototype.then.bind(Promise.resolve())
      : setTimeout),
  (Ft = function (e, t) {
    return e.__v.__b - t.__v.__b
  }),
  (J.__r = 0),
  (Mt = /(PointerCapture)$|Capture$/i),
  (lt = 0),
  (rt = bt(!1)),
  (ot = bt(!0))
var se = 0
function ke(e, t, _, i, n, r) {
  t || (t = {})
  var f,
    u,
    l = t
  if ("ref" in l)
    for (u in ((l = {}), t))
      u == "ref" ? (f = t[u]) : (l[u] = t[u])
  var s = {
    type: e,
    props: l,
    key: _,
    ref: f,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: --se,
    __i: -1,
    __u: 0,
    __source: n,
    __self: r,
  }
  if (typeof e == "function" && (f = e.defaultProps))
    for (u in f) l[u] === void 0 && (l[u] = f[u])
  return v.vnode && v.vnode(s), s
}
var j,
  m,
  nt,
  wt,
  ft = 0,
  It = [],
  g = v,
  kt = g.__b,
  St = g.__r,
  xt = g.diffed,
  Nt = g.__c,
  Et = g.unmount,
  Ht = g.__
function vt(e, t) {
  g.__h && g.__h(m, e, ft || t), (ft = 0)
  var _ = m.__H || (m.__H = { __: [], __h: [] })
  return e >= _.__.length && _.__.push({}), _.__[e]
}
function Se(e) {
  return (ft = 1), le(zt, e)
}
function le(e, t, _) {
  var i = vt(j++, 2)
  if (
    ((i.t = e),
    !i.__c &&
      ((i.__ = [
        zt(void 0, t),
        function (u) {
          var l = i.__N ? i.__N[0] : i.__[0],
            s = i.t(l, u)
          l !== s &&
            ((i.__N = [s, i.__[1]]), i.__c.setState({}))
        },
      ]),
      (i.__c = m),
      !m.__f))
  ) {
    var n = function (u, l, s) {
      if (!i.__c.__H) return !0
      var c = i.__c.__H.__.filter(function (h) {
        return !!h.__c
      })
      if (
        c.every(function (h) {
          return !h.__N
        })
      )
        return !r || r.call(this, u, l, s)
      var o = i.__c.props !== u
      return (
        c.forEach(function (h) {
          if (h.__N) {
            var a = h.__[0]
            ;(h.__ = h.__N),
              (h.__N = void 0),
              a !== h.__[0] && (o = !0)
          }
        }),
        (r && r.call(this, u, l, s)) || o
      )
    }
    m.__f = !0
    var r = m.shouldComponentUpdate,
      f = m.componentWillUpdate
    ;(m.componentWillUpdate = function (u, l, s) {
      if (this.__e) {
        var c = r
        ;(r = void 0), n(u, l, s), (r = c)
      }
      f && f.call(this, u, l, s)
    }),
      (m.shouldComponentUpdate = n)
  }
  return i.__N || i.__
}
function xe(e, t) {
  var _ = vt(j++, 3)
  !g.__s &&
    Vt(_.__H, t) &&
    ((_.__ = e), (_.u = t), m.__H.__h.push(_))
}
function Bt(e, t) {
  var _ = vt(j++, 7)
  return (
    Vt(_.__H, t) &&
      ((_.__ = e()), (_.__H = t), (_.__h = e)),
    _.__
  )
}
function ae() {
  for (var e; (e = It.shift()); )
    if (e.__P && e.__H)
      try {
        e.__H.__h.forEach(G),
          e.__H.__h.forEach(ut),
          (e.__H.__h = [])
      } catch (t) {
        ;(e.__H.__h = []), g.__e(t, e.__v)
      }
}
;(g.__b = function (e) {
  ;(m = null), kt && kt(e)
}),
  (g.__ = function (e, t) {
    e && t.__k && t.__k.__m && (e.__m = t.__k.__m),
      Ht && Ht(e, t)
  }),
  (g.__r = function (e) {
    St && St(e), (j = 0)
    var t = (m = e.__c).__H
    t &&
      (nt === m
        ? ((t.__h = []),
          (m.__h = []),
          t.__.forEach(function (_) {
            _.__N && (_.__ = _.__N), (_.u = _.__N = void 0)
          }))
        : (t.__h.forEach(G),
          t.__h.forEach(ut),
          (t.__h = []),
          (j = 0))),
      (nt = m)
  }),
  (g.diffed = function (e) {
    xt && xt(e)
    var t = e.__c
    t &&
      t.__H &&
      (t.__H.__h.length &&
        ((It.push(t) !== 1 &&
          wt === g.requestAnimationFrame) ||
          ((wt = g.requestAnimationFrame) || ce)(ae)),
      t.__H.__.forEach(function (_) {
        _.u && (_.__H = _.u), (_.u = void 0)
      })),
      (nt = m = null)
  }),
  (g.__c = function (e, t) {
    t.some(function (_) {
      try {
        _.__h.forEach(G),
          (_.__h = _.__h.filter(function (i) {
            return !i.__ || ut(i)
          }))
      } catch (i) {
        t.some(function (n) {
          n.__h && (n.__h = [])
        }),
          (t = []),
          g.__e(i, _.__v)
      }
    }),
      Nt && Nt(e, t)
  }),
  (g.unmount = function (e) {
    Et && Et(e)
    var t,
      _ = e.__c
    _ &&
      _.__H &&
      (_.__H.__.forEach(function (i) {
        try {
          G(i)
        } catch (n) {
          t = n
        }
      }),
      (_.__H = void 0),
      t && g.__e(t, _.__v))
  })
var Ut = typeof requestAnimationFrame == "function"
function ce(e) {
  var t,
    _ = function () {
      clearTimeout(i),
        Ut && cancelAnimationFrame(t),
        setTimeout(e)
    },
    i = setTimeout(_, 35)
  Ut && (t = requestAnimationFrame(_))
}
function G(e) {
  var t = m,
    _ = e.__c
  typeof _ == "function" && ((e.__c = void 0), _()), (m = t)
}
function ut(e) {
  var t = m
  ;(e.__c = e.__()), (m = t)
}
function Vt(e, t) {
  return (
    !e ||
    e.length !== t.length ||
    t.some(function (_, i) {
      return _ !== e[i]
    })
  )
}
function zt(e, t) {
  return typeof t == "function" ? t(e) : t
}
var he = Symbol.for("preact-signals")
function _t() {
  if (N > 1) N--
  else {
    var e,
      t = !1
    for (
      (function () {
        var n = Q
        for (Q = void 0; n !== void 0; )
          n.S.v === n.v && (n.S.i = n.i), (n = n.o)
      })();
      W !== void 0;
    ) {
      var _ = W
      for (W = void 0, K++; _ !== void 0; ) {
        var i = _.u
        if (
          ((_.u = void 0), (_.f &= -3), !(8 & _.f) && Jt(_))
        )
          try {
            _.c()
          } catch (n) {
            t || ((e = n), (t = !0))
          }
        _ = i
      }
    }
    if (((K = 0), N--, t)) throw e
  }
}
function ve(e) {
  if (N > 0) return e()
  ;(st = ++pe), N++
  try {
    return e()
  } finally {
    _t()
  }
}
var p = void 0
function pt(e) {
  var t = p
  p = void 0
  try {
    return e()
  } finally {
    p = t
  }
}
var W = void 0,
  N = 0,
  K = 0,
  pe = 0,
  st = 0,
  Q = void 0,
  X = 0
function Zt(e) {
  if (p !== void 0) {
    var t = e.n
    if (t === void 0 || t.t !== p)
      return (
        (t = {
          i: 0,
          S: e,
          p: p.s,
          n: void 0,
          t: p,
          e: void 0,
          x: void 0,
          r: t,
        }),
        p.s !== void 0 && (p.s.n = t),
        (p.s = t),
        (e.n = t),
        32 & p.f && e.S(t),
        t
      )
    if (t.i === -1)
      return (
        (t.i = 0),
        t.n !== void 0 &&
          ((t.n.p = t.p),
          t.p !== void 0 && (t.p.n = t.n),
          (t.p = p.s),
          (t.n = void 0),
          (p.s.n = t),
          (p.s = t)),
        t
      )
  }
}
function w(e, t) {
  ;(this.v = e),
    (this.i = 0),
    (this.n = void 0),
    (this.t = void 0),
    (this.l = 0),
    (this.W = t?.watched),
    (this.Z = t?.unwatched),
    (this.name = t?.name)
}
w.prototype.brand = he
w.prototype.h = function () {
  return !0
}
w.prototype.S = function (e) {
  var t = this,
    _ = this.t
  _ !== e &&
    e.e === void 0 &&
    ((e.x = _),
    (this.t = e),
    _ !== void 0
      ? (_.e = e)
      : pt(function () {
          var i
          ;(i = t.W) == null || i.call(t)
        }))
}
w.prototype.U = function (e) {
  var t = this
  if (this.t !== void 0) {
    var _ = e.e,
      i = e.x
    _ !== void 0 && ((_.x = i), (e.e = void 0)),
      i !== void 0 && ((i.e = _), (e.x = void 0)),
      e === this.t &&
        ((this.t = i),
        i === void 0 &&
          pt(function () {
            var n
            ;(n = t.Z) == null || n.call(t)
          }))
  }
}
w.prototype.subscribe = function (e) {
  var t = this
  return R(
    function () {
      var _ = t.value,
        i = p
      p = void 0
      try {
        e(_)
      } finally {
        p = i
      }
    },
    { name: "sub" },
  )
}
w.prototype.valueOf = function () {
  return this.value
}
w.prototype.toString = function () {
  return this.value + ""
}
w.prototype.toJSON = function () {
  return this.value
}
w.prototype.peek = function () {
  var e = this
  return pt(function () {
    return e.value
  })
}
Object.defineProperty(w.prototype, "value", {
  get: function () {
    var e = Zt(this)
    return e !== void 0 && (e.i = this.i), this.v
  },
  set: function (e) {
    if (e !== this.v) {
      if (K > 100) throw new Error("Cycle detected")
      ;(function (_) {
        N !== 0 &&
          K === 0 &&
          _.l !== st &&
          ((_.l = st), (Q = { S: _, v: _.v, i: _.i, o: Q }))
      })(this),
        (this.v = e),
        this.i++,
        X++,
        N++
      try {
        for (var t = this.t; t !== void 0; t = t.x) t.t.N()
      } finally {
        _t()
      }
    }
  },
})
function Gt(e, t) {
  return new w(e, t)
}
function Jt(e) {
  for (var t = e.s; t !== void 0; t = t.n)
    if (t.S.i !== t.i || !t.S.h() || t.S.i !== t.i)
      return !0
  return !1
}
function Kt(e) {
  for (var t = e.s; t !== void 0; t = t.n) {
    var _ = t.S.n
    if (
      (_ !== void 0 && (t.r = _),
      (t.S.n = t),
      (t.i = -1),
      t.n === void 0)
    ) {
      e.s = t
      break
    }
  }
}
function Qt(e) {
  for (var t = e.s, _ = void 0; t !== void 0; ) {
    var i = t.p
    t.i === -1
      ? (t.S.U(t),
        i !== void 0 && (i.n = t.n),
        t.n !== void 0 && (t.n.p = i))
      : (_ = t),
      (t.S.n = t.r),
      t.r !== void 0 && (t.r = void 0),
      (t = i)
  }
  e.s = _
}
function U(e, t) {
  w.call(this, void 0),
    (this.x = e),
    (this.s = void 0),
    (this.g = X - 1),
    (this.f = 4),
    (this.W = t?.watched),
    (this.Z = t?.unwatched),
    (this.name = t?.name)
}
U.prototype = new w()
U.prototype.h = function () {
  if (((this.f &= -3), 1 & this.f)) return !1
  if ((36 & this.f) == 32 || ((this.f &= -5), this.g === X))
    return !0
  if (
    ((this.g = X), (this.f |= 1), this.i > 0 && !Jt(this))
  )
    return (this.f &= -2), !0
  var e = p
  try {
    Kt(this), (p = this)
    var t = this.x()
    ;(16 & this.f || this.v !== t || this.i === 0) &&
      ((this.v = t), (this.f &= -17), this.i++)
  } catch (_) {
    ;(this.v = _), (this.f |= 16), this.i++
  }
  return (p = e), Qt(this), (this.f &= -2), !0
}
U.prototype.S = function (e) {
  if (this.t === void 0) {
    this.f |= 36
    for (var t = this.s; t !== void 0; t = t.n) t.S.S(t)
  }
  w.prototype.S.call(this, e)
}
U.prototype.U = function (e) {
  if (
    this.t !== void 0 &&
    (w.prototype.U.call(this, e), this.t === void 0)
  ) {
    this.f &= -33
    for (var t = this.s; t !== void 0; t = t.n) t.S.U(t)
  }
}
U.prototype.N = function () {
  if (!(2 & this.f)) {
    this.f |= 6
    for (var e = this.t; e !== void 0; e = e.x) e.t.N()
  }
}
Object.defineProperty(U.prototype, "value", {
  get: function () {
    if (1 & this.f) throw new Error("Cycle detected")
    var e = Zt(this)
    if (
      (this.h(),
      e !== void 0 && (e.i = this.i),
      16 & this.f)
    )
      throw this.v
    return this.v
  },
})
function Pt(e, t) {
  return new U(e, t)
}
function Xt(e) {
  var t = e.m
  if (((e.m = void 0), typeof t == "function")) {
    N++
    var _ = p
    p = void 0
    try {
      t()
    } catch (i) {
      throw ((e.f &= -2), (e.f |= 8), dt(e), i)
    } finally {
      ;(p = _), _t()
    }
  }
}
function dt(e) {
  for (var t = e.s; t !== void 0; t = t.n) t.S.U(t)
  ;(e.x = void 0), (e.s = void 0), Xt(e)
}
function de(e) {
  if (p !== this) throw new Error("Out-of-order effect")
  Qt(this),
    (p = e),
    (this.f &= -2),
    8 & this.f && dt(this),
    _t()
}
function C(e, t) {
  ;(this.x = e),
    (this.m = void 0),
    (this.s = void 0),
    (this.u = void 0),
    (this.f = 32),
    (this.name = t?.name)
}
C.prototype.c = function () {
  var e = this.S()
  try {
    if (8 & this.f || this.x === void 0) return
    var t = this.x()
    typeof t == "function" && (this.m = t)
  } finally {
    e()
  }
}
C.prototype.S = function () {
  if (1 & this.f) throw new Error("Cycle detected")
  ;(this.f |= 1), (this.f &= -9), Xt(this), Kt(this), N++
  var e = p
  return (p = this), de.bind(this, e)
}
C.prototype.N = function () {
  2 & this.f || ((this.f |= 2), (this.u = W), (W = this))
}
C.prototype.d = function () {
  ;(this.f |= 8), 1 & this.f || dt(this)
}
C.prototype.dispose = function () {
  this.d()
}
function R(e, t) {
  var _ = new C(e, t)
  try {
    _.c()
  } catch (n) {
    throw (_.d(), n)
  }
  var i = _.d.bind(_)
  return (i[Symbol.dispose] = i), i
}
var Yt,
  z,
  ye =
    typeof window < "u" &&
    !!window.__PREACT_SIGNALS_DEVTOOLS__,
  te = []
R(function () {
  Yt = this.N
})()
function T(e, t) {
  v[e] = t.bind(null, v[e] || function () {})
}
function Y(e) {
  if (z) {
    var t = z
    ;(z = void 0), t()
  }
  z = e && e.S()
}
function ee(e) {
  var t = this,
    _ = e.data,
    i = ge(_)
  i.value = _
  var n = Bt(function () {
      for (var u = t, l = t.__v; (l = l.__); )
        if (l.__c) {
          l.__c.__$f |= 4
          break
        }
      var s = Pt(function () {
          var a = i.value.value
          return a === 0 ? 0 : a === !0 ? "" : a || ""
        }),
        c = Pt(function () {
          return !Array.isArray(s.value) && !Tt(s.value)
        }),
        o = R(function () {
          if (((this.N = _e), c.value)) {
            var a = s.value
            u.__v &&
              u.__v.__e &&
              u.__v.__e.nodeType === 3 &&
              (u.__v.__e.data = a)
          }
        }),
        h = t.__$u.d
      return (
        (t.__$u.d = function () {
          o(), h.call(this)
        }),
        [c, s]
      )
    }, []),
    r = n[0],
    f = n[1]
  return r.value ? f.peek() : f.value
}
ee.displayName = "ReactiveTextNode"
Object.defineProperties(w.prototype, {
  constructor: { configurable: !0, value: void 0 },
  type: { configurable: !0, value: ee },
  props: {
    configurable: !0,
    get: function () {
      var e = this
      return {
        data: {
          get value() {
            return e.value
          },
        },
      }
    },
  },
  __b: { configurable: !0, value: 1 },
})
T("__b", function (e, t) {
  if (typeof t.type == "string") {
    var _,
      i = t.props
    for (var n in i)
      if (n !== "children") {
        var r = i[n]
        r instanceof w &&
          (_ || (t.__np = _ = {}),
          (_[n] = r),
          (i[n] = r.peek()))
      }
  }
  e(t)
})
T("__r", function (e, t) {
  if ((e(t), t.type !== q)) {
    Y()
    var _,
      i = t.__c
    i &&
      ((i.__$f &= -2),
      (_ = i.__$u) === void 0 &&
        (i.__$u = _ =
          (function (n, r) {
            var f
            return (
              R(
                function () {
                  f = this
                },
                { name: r },
              ),
              (f.c = n),
              f
            )
          })(
            function () {
              var n
              ye && ((n = _.y) == null || n.call(_)),
                (i.__$f |= 1),
                i.setState({})
            },
            typeof t.type == "function"
              ? t.type.displayName || t.type.name
              : "",
          ))),
      Y(_)
  }
})
T("__e", function (e, t, _, i) {
  Y(), e(t, _, i)
})
T("diffed", function (e, t) {
  Y()
  var _
  if (typeof t.type == "string" && (_ = t.__e)) {
    var i = t.__np,
      n = t.props
    if (i) {
      var r = _.U
      if (r)
        for (var f in r) {
          var u = r[f]
          u !== void 0 &&
            !(f in i) &&
            (u.d(), (r[f] = void 0))
        }
      else (r = {}), (_.U = r)
      for (var l in i) {
        var s = r[l],
          c = i[l]
        s === void 0
          ? ((s = me(_, l, c)), (r[l] = s))
          : s.o(c, n)
      }
      for (var o in i) n[o] = i[o]
    }
  }
  e(t)
})
function me(e, t, _, i) {
  var n = t in e && e.ownerSVGElement === void 0,
    r = Gt(_),
    f = _.peek()
  return {
    o: function (u, l) {
      ;(r.value = u), (f = u.peek())
    },
    d: R(function () {
      this.N = _e
      var u = r.value.value
      f !== u
        ? ((f = void 0),
          n
            ? (e[t] = u)
            : u != null && (u !== !1 || t[4] === "-")
              ? e.setAttribute(t, u)
              : e.removeAttribute(t))
        : (f = void 0)
    }),
  }
}
T("unmount", function (e, t) {
  if (typeof t.type == "string") {
    var _ = t.__e
    if (_) {
      var i = _.U
      if (i) {
        _.U = void 0
        for (var n in i) {
          var r = i[n]
          r && r.d()
        }
      }
    }
    t.__np = void 0
  } else {
    var f = t.__c
    if (f) {
      var u = f.__$u
      u && ((f.__$u = void 0), u.d())
    }
  }
  e(t)
})
T("__h", function (e, t, _, i) {
  ;(i < 3 || i === 9) && (t.__$f |= 2), e(t, _, i)
})
L.prototype.shouldComponentUpdate = function (e, t) {
  if (this.__R) return !0
  var _ = this.__$u,
    i = _ && _.s !== void 0
  for (var n in t) return !0
  if (
    this.__f ||
    (typeof this.u == "boolean" && this.u === !0)
  ) {
    var r = 2 & this.__$f
    if (!(i || r || 4 & this.__$f) || 1 & this.__$f)
      return !0
  } else if (!(i || 4 & this.__$f) || 3 & this.__$f)
    return !0
  for (var f in e)
    if (f !== "__source" && e[f] !== this.props[f])
      return !0
  for (var u in this.props) if (!(u in e)) return !0
  return !1
}
function ge(e, t) {
  return Bt(function () {
    return Gt(e, t)
  }, [])
}
var $e = function (e) {
  queueMicrotask(function () {
    queueMicrotask(e)
  })
}
function be() {
  ve(function () {
    for (var e; (e = te.shift()); ) Yt.call(e)
  })
}
function _e() {
  te.push(this) === 1 && (v.requestAnimationFrame || $e)(be)
}
export {
  we as E,
  xe as a,
  Se as d,
  q as k,
  ke as u,
  Gt as y,
}
