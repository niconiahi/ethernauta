const n = {
  name: "NFB Chain",
  shortName: "nfbchain",
  chain: "NFB Chain",
  rpc: ["https://node.nfbchain.com"],
  faucets: [],
  nativeCurrency: {
    name: "NFBCoin",
    symbol: "NFBC",
    decimals: 18
  },
  infoURL: "https://nfbchain.com/",
  chainId: 632,
  networkId: 632,
  explorers: [
    {
      name: "NFB Chain Explorer",
      url: "https://scan.nfbchain.com",
      standard: "none"
    }
  ]
};
export {
  n as eip155_632
};
