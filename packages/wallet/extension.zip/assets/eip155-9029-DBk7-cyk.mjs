const t = {
  name: "Qubetics Testnet",
  shortName: "Qubetics",
  chain: "Qubetics Testnet",
  icon: "qubetics",
  rpc: ["https://rpc-testnet.qubetics.work/"],
  faucets: ["https://testnet.qubetics.work/faucet"],
  nativeCurrency: {
    name: "Qubetics Testnet Token",
    symbol: "TICS",
    decimals: 18
  },
  infoURL: "https://www.qubetics.com/",
  chainId: 9029,
  networkId: 9029,
  explorers: [
    {
      name: "Qubetics Testnet Explorer",
      url: "https://testnet.qubetics.work",
      standard: "none"
    }
  ]
};
export {
  t as eip155_9029
};
