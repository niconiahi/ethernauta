const e = {
  name: "EtherInc",
  shortName: "eti",
  chain: "ETI",
  rpc: ["https://api.einc.io/jsonrpc/mainnet"],
  faucets: [],
  nativeCurrency: {
    name: "EtherInc Ether",
    symbol: "ETI",
    decimals: 18
  },
  infoURL: "https://einc.io",
  chainId: 101,
  networkId: 1,
  slip44: 464
};
export {
  e as eip155_101
};
