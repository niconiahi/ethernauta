import {
  d as U,
  a as N,
  u as o,
  y as ne,
  k as ve,
  E as be,
} from "./preact-10.26.9-DO5-VWXm.mjs"
import {
  p as u,
  o as h,
  a as F,
  n as re,
  u as p,
  s as d,
  l,
  b as ae,
  r as se,
  c as v,
  v as Se,
  m as Ee,
  H as q,
  g as xe,
  k as oe,
  w as Ae,
  d as R,
  e as ce,
  f as Ne,
  h as Te,
  t as T,
  i as S,
  j as ke,
  q as Ie,
  x as Ue,
  y as Q,
  z as Pe,
} from "./vendor-6cAV8jNg.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const a of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(a)
  new MutationObserver((a) => {
    for (const s of a)
      if (s.type === "childList")
        for (const c of s.addedNodes)
          c.tagName === "LINK" &&
            c.rel === "modulepreload" &&
            r(c)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(a) {
    const s = {}
    return (
      a.integrity && (s.integrity = a.integrity),
      a.referrerPolicy &&
        (s.referrerPolicy = a.referrerPolicy),
      a.crossOrigin === "use-credentials"
        ? (s.credentials = "include")
        : a.crossOrigin === "anonymous"
          ? (s.credentials = "omit")
          : (s.credentials = "same-origin"),
      s
    )
  }
  function r(a) {
    if (a.ep) return
    a.ep = !0
    const s = n(a)
    fetch(a.href, s)
  }
})()
const V = { iterations: 1e5, hash: "SHA-256" },
  f = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function $(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function H(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function ie(e, t, n) {
  const r = new TextEncoder().encode(e),
    a = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: V.iterations,
      hash: V.hash,
    },
    a,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function D() {
  return new Promise((e, t) => {
    const n = indexedDB.open(f.name, f.version)
    ;(n.onupgradeneeded = (r) => {
      const a = r.target.result
      a.objectStoreNames.contains(f.store_name) ||
        a.createObjectStore(f.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Ce(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    a = await ie(t, n, ["encrypt"]),
    s = new TextEncoder().encode(e),
    c = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      a,
      s,
    ),
    i = {
      salt: $(n.buffer),
      iv: $(r.buffer),
      cipher: $(c),
    },
    m = await D()
  return new Promise((P, z) => {
    const x = m
      .transaction(f.store_name, "readwrite")
      .objectStore(f.store_name)
      .put(i, f.vault_key)
    ;(x.onsuccess = () => P()),
      (x.onerror = () =>
        z(
          new Error(
            `Failed to save vault: ${x.error?.message}`,
          ),
        ))
  })
}
async function le(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await D(),
    n = await new Promise((m, P) => {
      const E = t
        .transaction(f.store_name, "readonly")
        .objectStore(f.store_name)
        .get(f.vault_key)
      ;(E.onsuccess = () => {
        const x = E.result
        m(x)
      }),
        (E.onerror = () =>
          P(
            new Error(
              `Failed to load vault: ${E.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = H(n.salt),
    a = H(n.iv),
    s = H(n.cipher),
    c = await ie(e, r, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: a }, c, s)
      .catch((m) => {
        throw m instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unkwown error")
      })
  return new TextDecoder().decode(i)
}
async function Oe() {
  const e = await D()
  return new Promise((t) => {
    const a = e
      .transaction(f.store_name, "readonly")
      .objectStore(f.store_name)
      .get(f.vault_key)
    ;(a.onsuccess = () => t(!!a.result)),
      (a.onerror = () => t(!1))
  })
}
async function Fe(e) {
  try {
    return (await le(e)) !== void 0
  } catch {
    return !1
  }
}
const Re = "password",
  g = U(Re)
async function ue() {
  const e = Date.now()
  await chrome.storage.local.set({ timestamp: e })
}
async function $e() {
  return u(
    h({ timestamp: F(re()) }),
    await chrome.storage.local.get("timestamp"),
  ).timestamp
}
async function J() {
  const e = Date.now(),
    t = await $e()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function Y() {
  ;(await Oe())
    ? (g.value = "password")
    : (g.value = "mnemonics")
}
const He = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: d(),
    params: p([ae(v()), se(d(), v())]),
  }),
  Me = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  Be = p([He, Me]),
  w = U({
    id: "some-id",
    method: "hello_world",
    params: [],
  })
function k(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function de(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += Z[e[n] >> 4]), (t += Z[e[n] & 15])
  return `0x${t}`
}
function je(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function b(e) {
  const t = je(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in C)) throw new Error("Invalid character")
    if (!(t[r + 1] in C))
      throw new Error("Invalid character")
    ;(n[r / 2] |= C[t[r]] << 4), (n[r / 2] |= C[t[r + 1]])
  }
  return n
}
const Z = "0123456789abcdef",
  C = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function qe(e) {
  if (!Se(e, Ae)) throw new Error("Invalid mnemonic")
  return Ee(e)
}
function De(e) {
  return q.fromMasterSeed(e)
}
function Ke(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function Le(e) {
  const t = xe(e, !1),
    n = oe(t.slice(1))
  return de(n.slice(-20))
}
function Ge(e) {
  const t = e.privateKey
  return k(t, "a private key should exist"), t
}
function K(e) {
  return BigInt(e)
}
const We = h({ address: d(), private_key: d() }),
  I = U({
    address: "",
    key: new q({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function ze(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.local.set({ wallet: t })
}
async function X() {
  const t = u(
    h({ wallet: F(We) }),
    await chrome.storage.local.get("wallet"),
  ).wallet
  t &&
    (I.value = {
      address: t.address,
      key: q.fromExtendedKey(t.private_key),
    })
}
async function Qe(e) {
  const t = await le(e)
  k(t, "vault should exist to sign in")
  const n = qe(t),
    r = De(n),
    a = Ke(r),
    s = Le(a),
    c = r.derive("m/44'/60'/0'/0/0"),
    i = { address: s, key: c }
  ;(I.value = i), ze(i)
}
function L({
  children: e,
  class: t,
  variant: n = "primary",
  ...r
}) {
  const [a, s] = N(!1)
  return o("button", {
    type: "button",
    onPointerDown: () => s(!0),
    onPointerUp: () => s(!1),
    onPointerLeave: () => s(!1),
    onTouchCancel: () => s(!1),
    class: [
      "border-2 rounded-md p-2 cursor-pointer text-base transition-colors",
      n === "secondary"
        ? "bg-[color-mix(in_srgb,#FF5005_12%,#faf5f0)] hover:bg-[color-mix(in_srgb,#FF5005_25%,#faf5f0)] border-[#FF5005] text-[#FF5005]"
        : "bg-[#FF5005] hover:bg-[#cc4004] border-[#c73d00] text-white",
      a
        ? "outline outline-2 outline-offset-2 outline-gray-700"
        : "",
      t,
    ]
      .filter(Boolean)
      .join(" "),
    ...r,
    children: e,
  })
}
const Ve = R(d(), ce(8)),
  Je = R(d(), ce(1))
function Ye() {
  const [e, t] = N(""),
    [n, r] = N("")
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          r(s)
        },
      }),
      o("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          t(s)
        },
      }),
      o(L, {
        onClick: async () => {
          const a = u(Je, n),
            s = u(Ve, e)
          Ce(a, s), await ue(), (g.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function Ze() {
  const [e, t] = N(""),
    [n, r] = N("")
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          t(s), r("")
        },
      }),
      n
        ? o("p", {
            className: "text-red-500 text-sm",
            children: n,
          })
        : null,
      o(L, {
        onClick: async () => {
          if (!(await Fe(e))) {
            r("Invalid password")
            return
          }
          await ue(), await Qe(e), (g.value = "wallet")
        },
        children: "Unlock",
      }),
    ],
  })
}
const M = { name: "Ethereum Sepolia", chainId: 11155111 },
  B = R(
    d(),
    Te(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  fe = p([ae(v()), se(d(), v())]),
  G = p([d(), re(), Ne()]),
  Xe = h({
    jsonrpc: l("2.0"),
    method: B,
    params: F(fe),
    id: G,
  }),
  et = h({
    data: F(v()),
    message: d(),
    code: p([
      l(-32e3),
      l(-32300),
      l(-32400),
      l(-32500),
      l(-32600),
      l(-32601),
      l(-32602),
      l(-32603),
      l(-32700),
      l(-32701),
      l(-32702),
    ]),
  }),
  tt = h({ id: G, jsonrpc: l("2.0"), error: et }),
  nt = h({ id: G, jsonrpc: l("2.0"), result: v() }),
  rt = p([tt, nt]),
  me = p([T([B, fe]), T([B])])
function at(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const st = S(at)
function ot(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const ct = S(ot)
function it(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const he = S(it),
  lt = ":"
function ut({ namespace: e, reference: t }) {
  const n = u(st, e),
    r = u(ct, typeof t == "number" ? String(t) : t),
    a = n + lt + r
  return u(he, a)
}
function dt(e) {
  return async (t) => {
    const [n, r] = t,
      a = u(Xe, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: ft(r),
      }),
      s = await fetch(e, {
        method: "POST",
        body: JSON.stringify(a),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return u(rt, s)
  }
}
function ft(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function mt(e) {
  return (t) => {
    const n = u(he, t),
      r = e.find(({ chainId: a }) => a === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
const j = [
    {
      id: M.chainId,
      name: M.name,
      rpc_url:
        "https://ethereum-sepolia-rpc.publicnode.com",
    },
  ],
  A = U(j[0]),
  ht = "eip155"
function pt(e) {
  return ut({ namespace: ht, reference: e.id })
}
function pe(e) {
  const t = pt(e)
  return {
    chain_id: t,
    reader: mt([
      { chainId: t, transports: [dt(e.rpc_url)] },
    ]),
  }
}
function _t(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const y = S(_t)
function yt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const gt = S(yt)
function wt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const W = S(wt),
  vt = p([
    l("earliest"),
    l("finalized"),
    l("safe"),
    l("latest"),
    l("pending"),
  ]),
  O = p([W, vt, gt]),
  bt = p([
    T([y, O]),
    T([y]),
    h({ address: y, blockNumberOrTagOrHash: O }),
    h({ address: y }),
  ])
function St(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = u(bt, e),
      a = u(me, [n, r]),
      s = await Promise.any(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return u(W, s.result)
  }
}
const Et = p([
  T([y, O]),
  h({ address: y, blockNumberOrTagOrHash: O }),
])
function xt(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = u(Et, e),
      a = u(me, [n, r]),
      s = await Promise.race(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return u(W, s.result)
  }
}
function _e(e) {
  return Array.isArray(e) ? Nt(e) : At(e)
}
function At(e) {
  const t = Tt(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const s = new Uint8Array(1 + t.length)
    return (s[0] = 128 + t.length), s.set(t, 1), s
  }
  const r = ye(t.length),
    a = new Uint8Array(1 + r.length + t.length)
  return (
    (a[0] = 183 + r.length),
    a.set(r, 1),
    a.set(t, 1 + r.length),
    a
  )
}
function Nt(e) {
  const t = e.map((c) => _e(c)),
    n = t.reduce((c, i) => c + i.length, 0)
  if (n <= 55) {
    const c = new Uint8Array(1 + n)
    c[0] = 192 + n
    let i = 1
    for (const m of t) c.set(m, i), (i += m.length)
    return c
  }
  const r = ye(n),
    a = new Uint8Array(1 + r.length + n)
  ;(a[0] = 247 + r.length), a.set(r, 1)
  let s = 1 + r.length
  for (const c of t) a.set(c, s), (s += c.length)
  return a
}
function Tt(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? b(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return kt(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function kt(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return b(n)
}
function ye(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function _(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return b(n)
}
function It(e, t) {
  return (
    (Q.hmacSha256Sync = (n, ...r) =>
      Ue(Pe, n, Q.concatBytes(...r))),
    Ie(e, t)
  )
}
function Ut(e) {
  return BigInt(e)
}
async function Pt(e, t, n) {
  const a = await xt([e, "latest"])(t(n))
  return K(a)
}
function Ct() {
  return BigInt(M.chainId)
}
function Ot() {
  return 21000n
}
function Ft() {
  return 20000000000n
}
function Rt() {
  return 2000000000n
}
function $t(e, t) {
  switch (e) {
    case "transfer": {
      const n = u(y, t[0]),
        r = u(R(d(), ke()), t[1])
      return {
        to: n,
        value: K(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function Ht({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: a, value: s, data: c } = $t(n, r),
    i = {
      to: a,
      data: c,
      value: s,
      nonce: t,
      chain_id: Ct(),
      gas_limit: Ot(),
      max_fee_per_gas: Ft(),
      max_priority_fee_per_gas: Rt(),
    },
    m = Ge(e)
  return Bt(i, m)
}
function Mt(e, t) {
  const n = ge(e, t)
  return oe(n)
}
function Bt(e, t) {
  const n = Dt(e),
    r = ee(n),
    a = new Uint8Array([2]),
    s = Mt(a, r),
    c = It(s, t),
    i = qt(n, c),
    m = ee(i)
  return ge(a, m)
}
function ge(...e) {
  let t = 0
  for (const a of e) t += a.length
  const n = new Uint8Array(t)
  let r = 0
  for (const a of e) n.set(a, r), (r += a.length)
  return n
}
function jt(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    k(r, "access list item should exist")
    const a = new Array(r.storage_keys.length)
    for (let s = 0; s < r.storage_keys.length; s++) {
      const c = r.storage_keys[s]
      k(c, "storage key should exist"), (a[s] = b(c))
    }
    t[n] = [b(r.address), a]
  }
  return t
}
function qt(e, t) {
  const n = new Array(12)
  k(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = Ut(t.recovery)
  return (
    (n[9] = _(r)), (n[10] = _(t.r)), (n[11] = _(t.s)), n
  )
}
function Dt(e) {
  const t = new Array(9)
  return (
    (t[0] = _(e.chain_id)),
    (t[1] = _(e.nonce)),
    (t[2] = _(e.max_priority_fee_per_gas)),
    (t[3] = _(e.max_fee_per_gas)),
    (t[4] = _(e.gas_limit)),
    (t[5] = b(e.to)),
    (t[6] = _(e.value)),
    (t[7] = e.data),
    (t[8] = jt([])),
    t
  )
}
function ee(e) {
  return _e(e)
}
function Kt() {
  return o("main", {
    className: "flex flex-col gap-2 p-2 text-base",
    children: [
      o("h1", {
        className: "text-center",
        children: "You are about to sign",
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Method" }),
          o("p", {
            className: "font-bold",
            children: w.value.method,
          }),
        ],
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Params" }),
          o("ul", {
            children: w.value.params.map((e, t) => {
              const n = u(d(), e),
                r = `param-${n}`
              return o(
                "li",
                {
                  className: "flex gap-2",
                  children: [
                    o("span", {
                      className: "w-2 text-center",
                      children: t,
                    }),
                    o("span", {
                      className: "font-bold",
                      children: n,
                    }),
                  ],
                },
                r,
              )
            }),
          }),
        ],
      }),
      o(L, {
        onClick: async () => {
          const e = I.value.address,
            t = I.value.key,
            { chain_id: n, reader: r } = pe(A.value),
            a = await Pt(e, r, n),
            s = await Ht({
              key: t,
              nonce: a,
              method: w.value.method,
              params: w.value.params,
            }),
            c = {
              id: w.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: de(s),
            }
          chrome.runtime.sendMessage(c)
        },
        children: "Sign",
      }),
    ],
  })
}
const te = U(0n)
async function Lt(e) {
  const { chain_id: t, reader: n } = pe(A.value),
    a = await St([e, "latest"])(n(t))
  return K(a)
}
function Gt(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    a = n.toString()
  if (r === 0n) return a
  const s = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${a}.${s}`
}
function Wt() {
  const e = I.value.address
  return (
    ne(() => {
      async function t() {
        const n = await Lt(e)
        te.value = n
      }
      t()
    }, [A.value]),
    o("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        o("select", {
          className:
            "p-2 border-2 rounded-md cursor-pointer text-base",
          value: A.value.id,
          onChange: (t) => {
            const n = Number(t.currentTarget.value),
              r = j.find((a) => a.id === n)
            r && (A.value = r)
          },
          children: j.map((t) =>
            o(
              "option",
              { value: t.id, children: t.name },
              t.id,
            ),
          ),
        }),
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Address:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: e,
            }),
          ],
        }),
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Balance:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: zt(Gt(te.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
      ],
    })
  )
}
function zt(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function Qt() {
  return (
    ne(() => {
      chrome.runtime.sendMessage({
        type: "ETHERNAUTA_POPUP_READY",
      }),
        chrome.runtime.onMessage.addListener(async (e) => {
          const t = u(Be, e)
          switch (t.type) {
            case "ETHERNAUTA_REQUEST_CONNECT": {
              const n = await J()
              if ((await Y(), n)) {
                await X(), (g.value = "wallet")
                return
              }
              break
            }
            case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
              {
                const n = await J()
                if ((await Y(), n)) {
                  await X(),
                    (w.value = {
                      id: t.id,
                      method: t.method,
                      params: t.params,
                    }),
                    (g.value = "sign")
                  return
                }
              }
              break
          }
        })
    }, []),
    o(ve, { children: Vt(g.value) })
  )
}
function Vt(e) {
  switch (e) {
    case "mnemonics":
      return o(Ye, {})
    case "password":
      return o(Ze, {})
    case "wallet":
      return o(Wt, {})
    case "sign":
      return o(Kt, {})
    default:
      return o("div", {
        children: ["there is no view for: ", e],
      })
  }
}
be(o(Qt, {}), document.querySelector("#app"))
