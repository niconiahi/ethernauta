const a = {
  name: "Safe(AnWang) Mainnet",
  shortName: "SafeMainnet",
  chain: "Safe(AnWang)",
  icon: "safe-anwang",
  rpc: ["https://safe4.anwang.com/rpc"],
  faucets: [],
  nativeCurrency: {
    name: "SAFE(AnWang)",
    symbol: "SAFE",
    decimals: 18
  },
  infoURL: "https://www.anwang.com",
  chainId: 6666665,
  networkId: 6666665,
  explorers: [
    {
      name: "Safe(AnWang) Explorer",
      url: "https://safe4.anwang.com",
      standard: "EIP3091"
    }
  ]
};
export {
  a as eip155_6666665
};
