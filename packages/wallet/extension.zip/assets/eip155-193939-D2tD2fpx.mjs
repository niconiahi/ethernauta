const a = {
  name: "R0AR Chain",
  shortName: "R0AR-Chain",
  chain: "R0AR Chain",
  icon: "r0ar",
  rpc: ["https://rpc-r0ar.io"],
  faucets: [],
  nativeCurrency: {
    name: "Ethereum",
    symbol: "ETH",
    decimals: 18
  },
  infoURL: "https://r0arscan.io",
  chainId: 193939,
  networkId: 193939,
  explorers: [
    {
      name: "tracehawk",
      url: "https://r0arscan.io",
      standard: "none"
    }
  ]
};
export {
  a as eip155_193939
};
