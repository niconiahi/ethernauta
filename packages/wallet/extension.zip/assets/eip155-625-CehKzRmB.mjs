const e = {
  name: "Binary Sepolia",
  shortName: "thebinaryholdings-sepolia",
  chain: "The Binary Holdings",
  rpc: ["https://rpc.testnet.thebinaryholdings.com"],
  faucets: [],
  nativeCurrency: {
    name: "Test BNRY",
    symbol: "BNRY",
    decimals: 18
  },
  infoURL: "",
  chainId: 625,
  networkId: 625,
  explorers: [
    {
      name: "Tracehawk",
      url: "https://explorer.sepolia.thebinaryholdings.com",
      standard: "none"
    }
  ]
};
export {
  e as eip155_625
};
