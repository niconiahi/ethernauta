const e = {
  name: "Help The Homeless",
  shortName: "hth",
  chain: "mainnet",
  icon: "hth",
  rpc: [],
  faucets: [],
  nativeCurrency: {
    name: "Help The Homeless Coin",
    symbol: "HTH",
    decimals: 18
  },
  infoURL: "https://hth.world",
  chainId: 7118,
  networkId: 7118,
  explorers: [],
  status: "incubating"
};
export {
  e as eip155_7118
};
