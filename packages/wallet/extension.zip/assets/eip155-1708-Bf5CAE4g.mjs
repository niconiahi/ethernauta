const t = {
  name: "TBSI Testnet",
  shortName: "tTBSI",
  title: "Thai Blockchain Service Infrastructure Testnet",
  chain: "TBSI",
  rpc: ["https://rpc.testnet.blockchain.or.th"],
  faucets: ["https://faucet.blockchain.or.th"],
  nativeCurrency: {
    name: "Jinda",
    symbol: "JINDA",
    decimals: 18
  },
  infoURL: "https://blockchain.or.th",
  chainId: 1708,
  networkId: 1708,
  slip44: 1,
  explorers: [
    {
      name: "blockscout",
      url: "https://exp.testnet.blockchain.or.th",
      standard: "EIP3091"
    }
  ]
};
export {
  t as eip155_1708
};
