import {
  d as U,
  a as v,
  u as c,
  y as re,
  k as Ee,
  E as Se,
} from "./preact-10.26.9.mjs"
import {
  p as u,
  o as h,
  a as F,
  n as se,
  u as p,
  s as d,
  l,
  b as ae,
  r as oe,
  c as b,
  v as xe,
  m as Ae,
  H as q,
  g as Ne,
  k as ce,
  w as Te,
  d as Q,
  e as $,
  f as ie,
  h as ke,
  i as Ie,
  t as T,
  j as S,
  q as Ue,
  x as Pe,
  y as Ce,
  z as V,
  A as Re,
} from "./vendor.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const s of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(s)
  new MutationObserver((s) => {
    for (const a of s)
      if (a.type === "childList")
        for (const o of a.addedNodes)
          o.tagName === "LINK" &&
            o.rel === "modulepreload" &&
            r(o)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(s) {
    const a = {}
    return (
      s.integrity && (a.integrity = s.integrity),
      s.referrerPolicy &&
        (a.referrerPolicy = s.referrerPolicy),
      s.crossOrigin === "use-credentials"
        ? (a.credentials = "include")
        : s.crossOrigin === "anonymous"
          ? (a.credentials = "omit")
          : (a.credentials = "same-origin"),
      a
    )
  }
  function r(s) {
    if (s.ep) return
    s.ep = !0
    const a = n(s)
    fetch(s.href, a)
  }
})()
const J = { iterations: 1e5, hash: "SHA-256" },
  f = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function H(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function M(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function le(e, t, n) {
  const r = new TextEncoder().encode(e),
    s = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: J.iterations,
      hash: J.hash,
    },
    s,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function K() {
  return new Promise((e, t) => {
    const n = indexedDB.open(f.name, f.version)
    ;(n.onupgradeneeded = (r) => {
      const s = r.target.result
      s.objectStoreNames.contains(f.store_name) ||
        s.createObjectStore(f.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Oe(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    s = await le(t, n, ["encrypt"]),
    a = new TextEncoder().encode(e),
    o = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      s,
      a,
    ),
    i = {
      salt: H(n.buffer),
      iv: H(r.buffer),
      cipher: H(o),
    },
    m = await K()
  return new Promise((P, z) => {
    const A = m
      .transaction(f.store_name, "readwrite")
      .objectStore(f.store_name)
      .put(i, f.vault_key)
    ;(A.onsuccess = () => P()),
      (A.onerror = () =>
        z(
          new Error(
            `Failed to save vault: ${A.error?.message}`,
          ),
        ))
  })
}
async function ue(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await K(),
    n = await new Promise((m, P) => {
      const x = t
        .transaction(f.store_name, "readonly")
        .objectStore(f.store_name)
        .get(f.vault_key)
      ;(x.onsuccess = () => {
        const A = x.result
        m(A)
      }),
        (x.onerror = () =>
          P(
            new Error(
              `Failed to load vault: ${x.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = M(n.salt),
    s = M(n.iv),
    a = M(n.cipher),
    o = await le(e, r, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: s }, o, a)
      .catch((m) => {
        throw m instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unknown error")
      })
  return new TextDecoder().decode(i)
}
async function Fe() {
  const e = await K()
  return new Promise((t) => {
    const s = e
      .transaction(f.store_name, "readonly")
      .objectStore(f.store_name)
      .get(f.vault_key)
    ;(s.onsuccess = () => t(!!s.result)),
      (s.onerror = () => t(!1))
  })
}
async function $e(e) {
  try {
    return (await ue(e)) !== void 0
  } catch {
    return !1
  }
}
function He(e) {
  const t = e.trim().split(/\s+/)
  return [12, 15, 18, 21, 24].includes(t.length)
}
const Me = "password",
  w = U(Me)
async function de() {
  const e = Date.now()
  await chrome.storage.local.set({ timestamp: e })
}
async function je() {
  return u(
    h({ timestamp: F(se()) }),
    await chrome.storage.local.get("timestamp"),
  ).timestamp
}
async function Y() {
  const e = Date.now(),
    t = await je()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function Z() {
  ;(await Fe())
    ? (w.value = "password")
    : (w.value = "mnemonics")
}
const Be = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: d(),
    params: p([ae(b()), oe(d(), b())]),
  }),
  De = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  qe = p([Be, De]),
  y = U({
    id: "some-id",
    method: "hello_world",
    params: [],
  })
function k(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function fe(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += X[e[n] >> 4]), (t += X[e[n] & 15])
  return `0x${t}`
}
function Ke(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function E(e) {
  const t = Ke(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in C)) throw new Error("Invalid character")
    if (!(t[r + 1] in C))
      throw new Error("Invalid character")
    ;(n[r / 2] |= C[t[r]] << 4), (n[r / 2] |= C[t[r + 1]])
  }
  return n
}
const X = "0123456789abcdef",
  C = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function Le(e) {
  if (!xe(e, Te)) throw new Error("Invalid mnemonic")
  return Ae(e)
}
function Ge(e) {
  return q.fromMasterSeed(e)
}
function We(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function ze(e) {
  const t = Ne(e, !1),
    n = ce(t.slice(1))
  return fe(n.slice(-20))
}
function Qe(e) {
  const t = e.privateKey
  return k(t, "a private key should exist"), t
}
function L(e) {
  return BigInt(e)
}
const Ve = h({ address: d(), private_key: d() }),
  I = U({
    address: "",
    key: new q({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function Je(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.local.set({ wallet: t })
}
async function ee() {
  const t = u(
    h({ wallet: F(Ve) }),
    await chrome.storage.local.get("wallet"),
  ).wallet
  t &&
    (I.value = {
      address: t.address,
      key: q.fromExtendedKey(t.private_key),
    })
}
async function Ye(e) {
  const t = await ue(e)
  k(t, "vault should exist to sign in")
  const n = Le(t),
    r = Ge(n),
    s = We(r),
    a = ze(s),
    o = r.derive("m/44'/60'/0'/0/0"),
    i = { address: a, key: o }
  ;(I.value = i), Je(i)
}
function R({
  children: e,
  class: t,
  variant: n = "primary",
  ...r
}) {
  const [s, a] = v(!1)
  return c("button", {
    type: "button",
    onPointerDown: () => a(!0),
    onPointerUp: () => a(!1),
    onPointerLeave: () => a(!1),
    onTouchCancel: () => a(!1),
    class: [
      "border-2 rounded-md p-2 cursor-pointer text-base transition-colors",
      n === "secondary"
        ? "bg-[color-mix(in_srgb,#FF5005_12%,#faf5f0)] hover:bg-[color-mix(in_srgb,#FF5005_25%,#faf5f0)] border-[#FF5005] text-[#FF5005]"
        : "bg-[#FF5005] hover:bg-[#cc4004] border-[#c73d00] text-white",
      s
        ? "outline outline-2 outline-offset-2 outline-gray-700"
        : "",
      t,
    ]
      .filter(Boolean)
      .join(" "),
    ...r,
    children: e,
  })
}
const Ze = $(d(), ie(8)),
  Xe = $(d(), ie(1))
function et() {
  const [e, t] = v(""),
    [n, r] = v(""),
    [s, a] = v("")
  return c("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      c("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (o) => {
          const i = o.currentTarget.value
          r(i), a("")
        },
      }),
      c("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (o) => {
          const i = o.currentTarget.value
          t(i), a("")
        },
      }),
      s
        ? c("p", {
            className: "text-red-500 text-sm",
            children: s,
          })
        : null,
      c(R, {
        onClick: async () => {
          const o = Q(Xe, n)
          if (!o.success) {
            a(o.issues[0].message)
            return
          }
          if (!He(o.output)) {
            a(
              "Invalid mnemonic: must be 12, 15, 18, 21, or 24 words",
            )
            return
          }
          const i = Q(Ze, e)
          if (!i.success) {
            a(i.issues[0].message)
            return
          }
          await Oe(o.output, i.output),
            await de(),
            (w.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function tt() {
  const [e, t] = v(""),
    [n, r] = v("")
  return c("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      c("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (s) => {
          const a = s.currentTarget.value
          t(a), r("")
        },
      }),
      n
        ? c("p", {
            className: "text-red-500 text-sm",
            children: n,
          })
        : null,
      c(R, {
        onClick: async () => {
          if (!(await $e(e))) {
            r("Invalid password")
            return
          }
          await de(), await Ye(e), (w.value = "wallet")
        },
        children: "Unlock",
      }),
    ],
  })
}
const j = { name: "Ethereum Sepolia", chainId: 11155111 },
  B = $(
    d(),
    Ie(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  me = p([ae(b()), oe(d(), b())]),
  G = p([d(), se(), ke()]),
  nt = h({
    jsonrpc: l("2.0"),
    method: B,
    params: F(me),
    id: G,
  }),
  rt = h({
    data: F(b()),
    message: d(),
    code: p([
      l(-32e3),
      l(-32300),
      l(-32400),
      l(-32500),
      l(-32600),
      l(-32601),
      l(-32602),
      l(-32603),
      l(-32700),
      l(-32701),
      l(-32702),
    ]),
  }),
  st = h({ id: G, jsonrpc: l("2.0"), error: rt }),
  at = h({ id: G, jsonrpc: l("2.0"), result: b() }),
  ot = p([st, at]),
  he = p([T([B, me]), T([B])])
function ct(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const it = S(ct)
function lt(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const ut = S(lt)
function dt(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const pe = S(dt),
  ft = ":"
function mt({ namespace: e, reference: t }) {
  const n = u(it, e),
    r = u(ut, typeof t == "number" ? String(t) : t),
    s = n + ft + r
  return u(pe, s)
}
function ht(e) {
  return async (t) => {
    const [n, r] = t,
      s = u(nt, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: pt(r),
      }),
      a = await fetch(e, {
        method: "POST",
        body: JSON.stringify(s),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return u(ot, a)
  }
}
function pt(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function _t(e) {
  return (t) => {
    const n = u(pe, t),
      r = e.find(({ chainId: s }) => s === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
const D = [
    {
      id: j.chainId,
      name: j.name,
      rpc_url:
        "https://ethereum-sepolia-rpc.publicnode.com",
    },
  ],
  N = U(D[0]),
  yt = "eip155"
function _e(e) {
  return mt({ namespace: yt, reference: e.id })
}
function ye(e) {
  const t = _e(e)
  return {
    chain_id: t,
    reader: _t([
      { chainId: t, transports: [ht(e.rpc_url)] },
    ]),
  }
}
function gt(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const g = S(gt)
function wt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const vt = S(wt)
function bt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const W = S(bt),
  Et = p([
    l("earliest"),
    l("finalized"),
    l("safe"),
    l("latest"),
    l("pending"),
  ]),
  O = p([W, Et, vt]),
  St = p([
    T([g, O]),
    T([g]),
    h({ address: g, blockNumberOrTagOrHash: O }),
    h({ address: g }),
  ])
function xt(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = u(St, e),
      s = u(he, [n, r]),
      a = await Promise.any(t.map((i) => i(s)))
    if ("error" in a) throw new Error(a.error.message)
    return u(W, a.result)
  }
}
const At = p([
  T([g, O]),
  h({ address: g, blockNumberOrTagOrHash: O }),
])
function Nt(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = u(At, e),
      s = u(he, [n, r]),
      a = await Promise.race(t.map((i) => i(s)))
    if ("error" in a) throw new Error(a.error.message)
    return u(W, a.result)
  }
}
function ge(e) {
  return Array.isArray(e) ? kt(e) : Tt(e)
}
function Tt(e) {
  const t = It(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const a = new Uint8Array(1 + t.length)
    return (a[0] = 128 + t.length), a.set(t, 1), a
  }
  const r = we(t.length),
    s = new Uint8Array(1 + r.length + t.length)
  return (
    (s[0] = 183 + r.length),
    s.set(r, 1),
    s.set(t, 1 + r.length),
    s
  )
}
function kt(e) {
  const t = e.map((o) => ge(o)),
    n = t.reduce((o, i) => o + i.length, 0)
  if (n <= 55) {
    const o = new Uint8Array(1 + n)
    o[0] = 192 + n
    let i = 1
    for (const m of t) o.set(m, i), (i += m.length)
    return o
  }
  const r = we(n),
    s = new Uint8Array(1 + r.length + n)
  ;(s[0] = 247 + r.length), s.set(r, 1)
  let a = 1 + r.length
  for (const o of t) s.set(o, a), (a += o.length)
  return s
}
function It(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? E(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return Ut(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function Ut(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return E(n)
}
function we(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function _(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return E(n)
}
function Pt(e, t) {
  return (
    (V.hmacSha256Sync = (n, ...r) =>
      Ce(Re, n, V.concatBytes(...r))),
    Pe(e, t)
  )
}
function Ct(e) {
  return BigInt(e)
}
async function Rt(e, t, n) {
  const s = await Nt([e, "latest"])(t(n))
  return L(s)
}
function Ot() {
  return BigInt(j.chainId)
}
function Ft() {
  return 21000n
}
function $t() {
  return 20000000000n
}
function Ht() {
  return 2000000000n
}
function Mt(e, t) {
  switch (e) {
    case "transfer": {
      const n = u(g, t[0]),
        r = u($(d(), Ue()), t[1])
      return {
        to: n,
        value: L(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function jt({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: s, value: a, data: o } = Mt(n, r),
    i = {
      to: s,
      data: o,
      value: a,
      nonce: t,
      chain_id: Ot(),
      gas_limit: Ft(),
      max_fee_per_gas: $t(),
      max_priority_fee_per_gas: Ht(),
    },
    m = Qe(e)
  return Dt(i, m)
}
function Bt(e, t) {
  const n = ve(e, t)
  return ce(n)
}
function Dt(e, t) {
  const n = Lt(e),
    r = te(n),
    s = new Uint8Array([2]),
    a = Bt(s, r),
    o = Pt(a, t),
    i = Kt(n, o),
    m = te(i)
  return ve(s, m)
}
function ve(...e) {
  let t = 0
  for (const s of e) t += s.length
  const n = new Uint8Array(t)
  let r = 0
  for (const s of e) n.set(s, r), (r += s.length)
  return n
}
function qt(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    k(r, "access list item should exist")
    const s = new Array(r.storage_keys.length)
    for (let a = 0; a < r.storage_keys.length; a++) {
      const o = r.storage_keys[a]
      k(o, "storage key should exist"), (s[a] = E(o))
    }
    t[n] = [E(r.address), s]
  }
  return t
}
function Kt(e, t) {
  const n = new Array(12)
  k(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = Ct(t.recovery)
  return (
    (n[9] = _(r)), (n[10] = _(t.r)), (n[11] = _(t.s)), n
  )
}
function Lt(e) {
  const t = new Array(9)
  return (
    (t[0] = _(e.chain_id)),
    (t[1] = _(e.nonce)),
    (t[2] = _(e.max_priority_fee_per_gas)),
    (t[3] = _(e.max_fee_per_gas)),
    (t[4] = _(e.gas_limit)),
    (t[5] = E(e.to)),
    (t[6] = _(e.value)),
    (t[7] = e.data),
    (t[8] = qt([])),
    t
  )
}
function te(e) {
  return ge(e)
}
function Gt() {
  return c("main", {
    className: "flex flex-col gap-2 p-2 text-base",
    children: [
      c("h1", {
        className: "text-center",
        children: "You are about to sign",
      }),
      c("fieldset", {
        children: [
          c("legend", { children: "Method" }),
          c("p", {
            className: "font-bold",
            children: y.value.method,
          }),
        ],
      }),
      c("fieldset", {
        children: [
          c("legend", { children: "Params" }),
          c("ul", {
            children: y.value.params.map((e, t) => {
              const n = u(d(), e),
                r = `param-${n}`
              return c(
                "li",
                {
                  className: "flex gap-2",
                  children: [
                    c("span", {
                      className: "w-2 text-center",
                      children: t,
                    }),
                    c("span", {
                      className: "font-bold",
                      children: n,
                    }),
                  ],
                },
                r,
              )
            }),
          }),
        ],
      }),
      c(R, {
        onClick: async () => {
          const e = I.value.address,
            t = I.value.key,
            { chain_id: n, reader: r } = ye(N.value),
            s = await Rt(e, r, n),
            a = await jt({
              key: t,
              nonce: s,
              method: y.value.method,
              params: y.value.params,
            }),
            o = {
              id: y.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: fe(a),
            }
          chrome.runtime.sendMessage(o), window.close()
        },
        children: "Sign",
      }),
      c(R, {
        onClick: () => {
          const e = {
            id: y.value.id,
            type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
          }
          chrome.runtime.sendMessage(e), window.close()
        },
        children: "Reject",
      }),
    ],
  })
}
const ne = U(0n)
async function Wt(e) {
  const { chain_id: t, reader: n } = ye(N.value),
    s = await xt([e, "latest"])(n(t))
  return L(s)
}
function zt(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    s = n.toString()
  if (r === 0n) return s
  const a = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${s}.${a}`
}
function Qt() {
  const e = I.value.address
  return (
    re(() => {
      async function t() {
        const n = await Wt(e)
        ne.value = n
      }
      t()
    }, [N.value]),
    c("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        c("select", {
          className:
            "self-start bg-white p-2 border-2 rounded-md cursor-pointer text-base",
          value: N.value.id,
          onChange: (t) => {
            const n = Number(t.currentTarget.value),
              r = D.find((s) => s.id === n)
            r && (N.value = r)
          },
          children: D.map((t) =>
            c(
              "option",
              {
                value: t.id,
                children: [_e(t), " — ", t.name],
              },
              t.id,
            ),
          ),
        }),
        c("p", {
          className: "flex gap-1 text-base",
          children: [
            c("span", { children: "Address:" }),
            c("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: e,
            }),
          ],
        }),
        c("p", {
          className: "flex gap-1 text-base",
          children: [
            c("span", { children: "Balance:" }),
            c("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: Vt(zt(ne.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
      ],
    })
  )
}
function Vt(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function Jt() {
  return (
    re(() => {
      chrome.runtime.connect({ name: "popup" }),
        chrome.runtime.sendMessage({
          type: "ETHERNAUTA_POPUP_READY",
        }),
        chrome.runtime.onMessage.addListener(async (e) => {
          const t = u(qe, e)
          switch (t.type) {
            case "ETHERNAUTA_REQUEST_CONNECT": {
              const n = await Y()
              if ((await Z(), n)) {
                await ee(), (w.value = "wallet")
                return
              }
              break
            }
            case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
              {
                const n = await Y()
                if ((await Z(), n)) {
                  await ee(),
                    (y.value = {
                      id: t.id,
                      method: t.method,
                      params: t.params,
                    }),
                    (w.value = "sign")
                  return
                }
              }
              break
          }
        })
    }, []),
    c(Ee, { children: Yt(w.value) })
  )
}
function Yt(e) {
  switch (e) {
    case "mnemonics":
      return c(et, {})
    case "password":
      return c(tt, {})
    case "wallet":
      return c(Qt, {})
    case "sign":
      return c(Gt, {})
    default:
      return c("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Se(c(Jt, {}), document.querySelector("#app"))
