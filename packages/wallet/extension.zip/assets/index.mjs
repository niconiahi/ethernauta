import {
  d as H,
  a as O,
  u as c,
  y as q,
  k as Oe,
  E as Fe,
} from "./preact-10.26.9.mjs"
import {
  p as u,
  o as d,
  a as y,
  n as pe,
  u as _,
  s as g,
  l as m,
  b as v,
  r as ye,
  c as N,
  v as Be,
  m as He,
  H as V,
  g as Me,
  k as _e,
  w as Le,
  d as M,
  e as ge,
  f as we,
  h as Ge,
  t as k,
  i as b,
  j as Q,
  q as je,
  x as De,
  y as re,
  z as Ke,
  A as qe,
  B as ze,
  C as se,
  D as We,
} from "./vendor.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const s of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(s)
  new MutationObserver((s) => {
    for (const a of s)
      if (a.type === "childList")
        for (const i of a.addedNodes)
          i.tagName === "LINK" &&
            i.rel === "modulepreload" &&
            r(i)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(s) {
    const a = {}
    return (
      s.integrity && (a.integrity = s.integrity),
      s.referrerPolicy &&
        (a.referrerPolicy = s.referrerPolicy),
      s.crossOrigin === "use-credentials"
        ? (a.credentials = "include")
        : s.crossOrigin === "anonymous"
          ? (a.credentials = "omit")
          : (a.credentials = "same-origin"),
      a
    )
  }
  function r(s) {
    if (s.ep) return
    s.ep = !0
    const a = n(s)
    fetch(s.href, a)
  }
})()
const ae = { iterations: 1e5, hash: "SHA-256" },
  w = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function D(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function K(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function be(e, t, n) {
  const r = new TextEncoder().encode(e),
    s = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: ae.iterations,
      hash: ae.hash,
    },
    s,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function J() {
  return new Promise((e, t) => {
    const n = indexedDB.open(w.name, w.version)
    ;(n.onupgradeneeded = (r) => {
      const s = r.target.result
      s.objectStoreNames.contains(w.store_name) ||
        s.createObjectStore(w.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Ve(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    s = await be(t, n, ["encrypt"]),
    a = new TextEncoder().encode(e),
    i = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      s,
      a,
    ),
    l = {
      salt: D(n.buffer),
      iv: D(r.buffer),
      cipher: D(i),
    },
    h = await J()
  return new Promise((E, ne) => {
    const C = h
      .transaction(w.store_name, "readwrite")
      .objectStore(w.store_name)
      .put(l, w.vault_key)
    ;(C.onsuccess = () => E()),
      (C.onerror = () =>
        ne(
          new Error(
            `Failed to save vault: ${C.error?.message}`,
          ),
        ))
  })
}
async function ve(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await J(),
    n = await new Promise((h, E) => {
      const $ = t
        .transaction(w.store_name, "readonly")
        .objectStore(w.store_name)
        .get(w.vault_key)
      ;($.onsuccess = () => {
        const C = $.result
        h(C)
      }),
        ($.onerror = () =>
          E(
            new Error(
              `Failed to load vault: ${$.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = K(n.salt),
    s = K(n.iv),
    a = K(n.cipher),
    i = await be(e, r, ["decrypt"]),
    l = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: s }, i, a)
      .catch((h) => {
        throw h instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unkwown error")
      })
  return new TextDecoder().decode(l)
}
async function Qe() {
  const e = await J()
  return new Promise((t) => {
    const s = e
      .transaction(w.store_name, "readonly")
      .objectStore(w.store_name)
      .get(w.vault_key)
    ;(s.onsuccess = () => t(!!s.result)),
      (s.onerror = () => t(!1))
  })
}
async function Je(e) {
  try {
    return (await ve(e)) !== void 0
  } catch {
    return !1
  }
}
const Ze = "password",
  x = H(Ze)
async function Se() {
  const e = Date.now()
  await chrome.storage.sync.set({ timestamp: e })
}
async function Ye() {
  return u(
    d({ timestamp: y(pe()) }),
    await chrome.storage.sync.get("timestamp"),
  ).timestamp
}
async function oe() {
  const e = Date.now(),
    t = await Ye()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function ce() {
  ;(await Qe())
    ? (x.value = "password")
    : (x.value = "mnemonics")
}
const Xe = d({
    id: g(),
    type: m("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: g(),
    params: _([v(N()), ye(g(), N())]),
  }),
  et = d({
    id: g(),
    type: m("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  tt = _([Xe, et]),
  A = H({
    id: "some-id",
    method: "hello_world",
    params: [],
  })
function T(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function Ee(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += ie[e[n] >> 4]), (t += ie[e[n] & 15])
  return `0x${t}`
}
function nt(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function I(e) {
  const t = nt(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in F)) throw new Error("Invalid character")
    if (!(t[r + 1] in F))
      throw new Error("Invalid character")
    ;(n[r / 2] |= F[t[r]] << 4), (n[r / 2] |= F[t[r + 1]])
  }
  return n
}
const ie = "0123456789abcdef",
  F = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function rt(e) {
  if (!Be(e, Le)) throw new Error("Invalid mnemonic")
  return He(e)
}
function st(e) {
  return V.fromMasterSeed(e)
}
function at(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function ot(e) {
  const t = Me(e, !1),
    n = _e(t.slice(1))
  return Ee(n.slice(-20))
}
function ct(e) {
  const t = e.privateKey
  return T(t, "a private key should exist"), t
}
function Z(e) {
  return BigInt(e)
}
function it(e) {
  return `0x${e.toString(16)}`
}
function xe(e) {
  return Number(e)
}
const lt = d({ address: g(), private_key: g() }),
  P = H({
    address: "",
    key: new V({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function ut(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.sync.set({ wallet: t })
}
async function le() {
  const t = u(
    d({ wallet: y(lt) }),
    await chrome.storage.sync.get("wallet"),
  ).wallet
  t &&
    (P.value = {
      address: t.address,
      key: V.fromExtendedKey(t.private_key),
    })
}
async function dt(e) {
  const t = await ve(e)
  T(t, "vault should exist to sign in")
  const n = rt(t),
    r = st(n),
    s = at(r),
    a = ot(s),
    i = r.derive("m/44'/60'/0'/0/0"),
    l = { address: a, key: i }
  ;(P.value = l), ut(l)
}
const mt = M(g(), ge(8)),
  ht = M(g(), ge(1))
function ft() {
  const [e, t] = O(""),
    [n, r] = O(
      "smile price bomb movie minimum treat hurdle adult wing come space cross",
    )
  return c("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      c("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (s) => {
          const a = s.currentTarget.value
          r(a)
        },
      }),
      c("input", {
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (s) => {
          const a = s.currentTarget.value
          t(a)
        },
      }),
      c("button", {
        type: "button",
        className:
          "bg-[#FF5005] border-2 rounded-md p-2 cursor-pointer text-base",
        onClick: async () => {
          const s = u(ht, n),
            a = u(mt, e)
          Ve(s, a), await Se(), (x.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function pt() {
  const [e, t] = O("")
  return c("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      c("input", {
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (n) => {
          const r = n.currentTarget.value
          t(r)
        },
      }),
      c("button", {
        type: "button",
        className:
          "bg-[#FF5005] border-2 rounded-md p-2 cursor-pointer text-base",
        onClick: async () => {
          ;(await Je(e)) &&
            (await Se(), await dt(e), (x.value = "wallet"))
        },
        children: "Unlock",
      }),
    ],
  })
}
const L = { chainId: 11155111 },
  z = M(
    g(),
    Ge(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  Ae = _([v(N()), ye(g(), N())]),
  Y = _([g(), pe(), we()]),
  yt = d({
    jsonrpc: m("2.0"),
    method: z,
    params: y(Ae),
    id: Y,
  }),
  _t = d({
    data: y(N()),
    message: g(),
    code: _([
      m(-32e3),
      m(-32300),
      m(-32400),
      m(-32500),
      m(-32600),
      m(-32601),
      m(-32602),
      m(-32603),
      m(-32700),
      m(-32701),
      m(-32702),
    ]),
  }),
  gt = d({ id: Y, jsonrpc: m("2.0"), error: _t }),
  wt = d({ id: Y, jsonrpc: m("2.0"), result: N() }),
  bt = _([gt, wt]),
  G = _([k([z, Ae]), k([z])])
function vt(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const St = b(vt)
function Et(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const xt = b(Et)
function At(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const Ne = b(At),
  Nt = ":"
function X({ namespace: e, reference: t }) {
  const n = u(St, e),
    r = u(xt, String(t)),
    s = n + Nt + r
  return u(Ne, s)
}
function ee(e) {
  return async (t) => {
    const [n, r] = t,
      s = u(yt, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: kt(r),
      }),
      a = await fetch(e, {
        method: "POST",
        body: JSON.stringify(s),
        headers: { "Content-Type": "application/json" },
      })
        .then((l) => l.json())
        .catch((l) => {
          throw new Error(l)
        })
    return u(bt, a)
  }
}
function kt(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function te(e) {
  return (t) => {
    const n = u(Ne, t),
      r = e.find(({ chainId: s }) => s === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
function Tt(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const p = b(Tt)
function It(e) {
  return (
    typeof e == "string" &&
    /^0x([0-9,a-f,A-F]?){1,2}$/.test(e)
  )
}
const U = b(It)
function Pt(e) {
  return typeof e == "string" && /^0x[0-9a-f]*$/.test(e)
}
const R = b(Pt)
function Ut(e) {
  return typeof e == "string" && /^0x[0-9a-f]{16}$/.test(e)
}
const Rt = b(Ut)
function $t(e) {
  return typeof e == "string" && /^0x[0-9a-f]{512}$/.test(e)
}
const Ct = b($t)
function Ot(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const f = b(Ot),
  Ft = we()
function Bt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const o = b(Bt)
function Ht(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]{0,15})|0$/.test(e)
  )
}
const ue = b(Ht)
function Mt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]{0,31})|0$/.test(e)
  )
}
const Lt = b(Mt),
  Gt = d({ address: p, storageKeys: v(f) }),
  j = v(Gt),
  jt = d({
    type: U,
    nonce: o,
    to: Q(p),
    gas: o,
    value: o,
    input: R,
    maxPriorityFeePerGas: o,
    maxFeePerGas: o,
    gasPrice: o,
    accessList: j,
    chainId: o,
    yParity: o,
    r: o,
    s: o,
  }),
  Dt = d({
    type: U,
    nonce: o,
    to: Q(p),
    gas: o,
    value: o,
    input: R,
    gasPrice: o,
    accessList: j,
    chainId: o,
    yParity: o,
    r: o,
    s: o,
  }),
  Kt = d({
    type: U,
    nonce: o,
    to: p,
    gas: o,
    value: o,
    input: R,
    maxPriorityFeePerGas: o,
    maxFeePerGas: o,
    maxFeePerBlobGas: o,
    accessList: j,
    blobVersionedHashes: v(f),
    chainId: o,
    yParity: o,
    r: o,
    s: o,
  }),
  qt = d({
    type: U,
    nonce: o,
    to: p,
    gas: o,
    value: o,
    input: R,
    maxPriorityFeePerGas: o,
    maxFeePerGas: o,
    gasPrice: y(o),
    accessList: j,
    chainId: o,
  }),
  zt = d({
    ...qt.entries,
    yParity: o,
    v: y(U),
    r: o,
    s: o,
  }),
  Wt = d({
    type: U,
    nonce: o,
    to: Q(p),
    gas: o,
    value: o,
    input: R,
    gasPrice: o,
    chainId: y(o),
  }),
  Vt = d({ ...Wt.entries, v: o, r: o, s: o }),
  Qt = je("type", [jt, Dt, Kt, zt, Vt]),
  Jt = d({
    blockHash: f,
    blockNumber: o,
    from: p,
    hash: f,
    transactionIndex: o,
  }),
  ke = De([Jt, Qt]),
  Zt = d({
    index: ue,
    validatorIndex: ue,
    address: p,
    amount: Lt,
  }),
  Te = _([
    m("earliest"),
    m("finalized"),
    m("safe"),
    m("latest"),
    m("pending"),
  ]),
  de = _([o, Te]),
  B = _([o, Te, f]),
  Yt = d({
    hash: f,
    parentHash: f,
    sha3Uncles: f,
    miner: p,
    stateRoot: f,
    transactionsRoot: f,
    receiptsRoot: f,
    logsBloom: Ct,
    difficulty: y(o),
    number: o,
    gasLimit: o,
    gasUsed: o,
    timestamp: o,
    extraData: R,
    mixHash: f,
    nonce: Rt,
    totalDifficulty: y(o),
    baseFeePerGas: y(o),
    withdrawalsRoot: y(f),
    blobGasUsed: y(o),
    excessBlobGas: y(o),
    parentBeaconBlockRoot: y(f),
    size: o,
    transactions: _([v(f), v(ke)]),
    withdrawals: y(v(Zt)),
    uncles: v(f),
  }),
  Xt = _([
    k([de, re()]),
    d({ blockNumberOrTag: de, hydratedTransactions: re() }),
  ])
function en(e) {
  return async (t) => {
    const n = "eth_getBlockByNumber",
      r = u(Xt, e),
      s = u(G, [n, r]),
      a = await Promise.any(t.map((l) => l(s)))
    if ("error" in a) throw new Error(a.error.message)
    return u(_([Yt, Ft]), a.result)
  }
}
function tn() {
  return async (e) => {
    const n = u(G, ["eth_blockNumber"]),
      r = await Promise.any(e.map((a) => a(n)))
    if ("error" in r) throw new Error(r.error.message)
    return u(o, r.result)
  }
}
const nn = _([
  k([p, B]),
  k([p]),
  d({ address: p, blockNumberOrTagOrHash: B }),
  d({ address: p }),
])
function rn(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = u(nn, e),
      s = u(G, [n, r]),
      a = await Promise.any(t.map((l) => l(s)))
    if ("error" in a) throw new Error(a.error.message)
    return u(o, a.result)
  }
}
const sn = _([
  k([p, B]),
  d({ address: p, blockNumberOrTagOrHash: B }),
])
function an(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = u(sn, e),
      s = u(G, [n, r]),
      a = await Promise.race(t.map((l) => l(s)))
    if ("error" in a) throw new Error(a.error.message)
    return u(o, a.result)
  }
}
function Ie(e) {
  return Array.isArray(e) ? cn(e) : on(e)
}
function on(e) {
  const t = ln(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const a = new Uint8Array(1 + t.length)
    return (a[0] = 128 + t.length), a.set(t, 1), a
  }
  const r = Pe(t.length),
    s = new Uint8Array(1 + r.length + t.length)
  return (
    (s[0] = 183 + r.length),
    s.set(r, 1),
    s.set(t, 1 + r.length),
    s
  )
}
function cn(e) {
  const t = e.map((i) => Ie(i)),
    n = t.reduce((i, l) => i + l.length, 0)
  if (n <= 55) {
    const i = new Uint8Array(1 + n)
    i[0] = 192 + n
    let l = 1
    for (const h of t) i.set(h, l), (l += h.length)
    return i
  }
  const r = Pe(n),
    s = new Uint8Array(1 + r.length + n)
  ;(s[0] = 247 + r.length), s.set(r, 1)
  let a = 1 + r.length
  for (const i of t) s.set(i, a), (a += i.length)
  return s
}
function ln(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? I(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return un(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function un(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return I(n)
}
function Pe(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function S(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return I(n)
}
function dn(e, t) {
  return (
    (se.hmacSha256Sync = (n, ...r) =>
      ze(We, n, se.concatBytes(...r))),
    qe(e, t)
  )
}
function mn(e) {
  return BigInt(e)
}
async function hn(e, t, n) {
  const s = await an([e, "latest"])(t(n))
  return Z(s)
}
function fn() {
  return BigInt(L.chainId)
}
function pn() {
  return 21000n
}
function yn() {
  return 20000000000n
}
function _n() {
  return 2000000000n
}
function gn(e, t) {
  switch (e) {
    case "transfer": {
      const n = u(p, t[0]),
        r = u(M(g(), Ke()), t[1])
      return {
        to: n,
        value: Z(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function wn({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: s, value: a, data: i } = gn(n, r),
    l = {
      to: s,
      data: i,
      value: a,
      nonce: t,
      chain_id: fn(),
      gas_limit: pn(),
      max_fee_per_gas: yn(),
      max_priority_fee_per_gas: _n(),
    },
    h = ct(e)
  return vn(l, h)
}
function bn(e, t) {
  const n = Ue(e, t)
  return _e(n)
}
function vn(e, t) {
  const n = xn(e),
    r = me(n),
    s = new Uint8Array([2]),
    a = bn(s, r),
    i = dn(a, t),
    l = En(n, i),
    h = me(l)
  return Ue(s, h)
}
function Ue(...e) {
  let t = 0
  for (const s of e) t += s.length
  const n = new Uint8Array(t)
  let r = 0
  for (const s of e) n.set(s, r), (r += s.length)
  return n
}
function Sn(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    T(r, "access list item should exist")
    const s = new Array(r.storage_keys.length)
    for (let a = 0; a < r.storage_keys.length; a++) {
      const i = r.storage_keys[a]
      T(i, "storage key should exist"), (s[a] = I(i))
    }
    t[n] = [I(r.address), s]
  }
  return t
}
function En(e, t) {
  const n = new Array(12)
  T(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = mn(t.recovery)
  return (
    (n[9] = S(r)), (n[10] = S(t.r)), (n[11] = S(t.s)), n
  )
}
function xn(e) {
  const t = new Array(9)
  return (
    (t[0] = S(e.chain_id)),
    (t[1] = S(e.nonce)),
    (t[2] = S(e.max_priority_fee_per_gas)),
    (t[3] = S(e.max_fee_per_gas)),
    (t[4] = S(e.gas_limit)),
    (t[5] = I(e.to)),
    (t[6] = S(e.value)),
    (t[7] = e.data),
    (t[8] = Sn([])),
    t
  )
}
function me(e) {
  return Ie(e)
}
const An = { ETHEREUM: "eip155" },
  Nn = "https://ethereum-sepolia-rpc.publicnode.com",
  Re = X({ namespace: An.ETHEREUM, reference: L.chainId }),
  kn = te([{ chainId: Re, transports: [ee(Nn)] }])
function Tn() {
  return c("main", {
    className: "flex flex-col gap-2 p-2 text-base",
    children: [
      c("h1", {
        className: "text-center",
        children: "You are about to sign",
      }),
      c("fieldset", {
        children: [
          c("legend", { children: "Method" }),
          c("p", {
            className: "font-bold",
            children: A.value.method,
          }),
        ],
      }),
      c("fieldset", {
        children: [
          c("legend", { children: "Params" }),
          c("ul", {
            children: A.value.params.map((e, t) => {
              const n = u(g(), e),
                r = `param-${n}`
              return c(
                "li",
                {
                  className: "flex gap-2",
                  children: [
                    c("span", {
                      className: "w-2 text-center",
                      children: t,
                    }),
                    c("span", {
                      className: "font-bold",
                      children: n,
                    }),
                  ],
                },
                r,
              )
            }),
          }),
        ],
      }),
      c("button", {
        type: "button",
        className:
          "bg-[#FF5005] border-2 rounded-md p-2 cursor-pointer text-base",
        onClick: async () => {
          const e = P.value.address,
            t = P.value.key,
            n = await hn(e, kn, Re),
            r = await wn({
              key: t,
              nonce: n,
              method: A.value.method,
              params: A.value.params,
            }),
            s = {
              id: A.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: Ee(r),
            }
          chrome.runtime.sendMessage(s)
        },
        children: "Sign",
      }),
    ],
  })
}
const In = { ETHEREUM: "eip155" },
  Pn = "https://ethereum-sepolia-rpc.publicnode.com",
  $e = X({ namespace: In.ETHEREUM, reference: L.chainId }),
  Un = te([{ chainId: $e, transports: [ee(Pn)] }]),
  he = H(0n)
async function Rn(e) {
  const t = rn([e, "latest"])
  console.log("readable", t)
  const n = await t(Un($e))
  return Z(n)
}
function $n(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    s = n.toString()
  if (r === 0n) return s
  const a = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${s}.${a}`
}
const Cn = { ETHEREUM: "eip155" },
  On = "https://ethereum-sepolia-rpc.publicnode.com",
  W = X({ namespace: Cn.ETHEREUM, reference: L.chainId }),
  fe = te([{ chainId: W, transports: [ee(On)] }]),
  Fn = 30
async function Bn() {
  const e = tn(),
    t = xe(await e(fe(W))),
    n = []
  for (let r = t - Fn; r <= t; r++) {
    const a = await en([it(r), !0])(fe(W))
    a && n.push(a)
  }
  return n
}
function Hn() {
  const [e, t] = O(!1),
    [n, r] = O([]),
    s = P.value.address
  return (
    q(() => {
      async function a() {
        const i = await Rn(s)
        he.value = i
      }
      a()
    }, []),
    q(() => {
      async function a() {
        t(!0)
        const i = await Bn(),
          l = u(
            v(ke),
            i
              .flatMap((h) =>
                h.transactions.map(
                  (E) => (
                    T(
                      typeof E == "object",
                      "transaction should be an object",
                    ),
                    E
                  ),
                ),
              )
              .filter(
                (h) =>
                  h.from === P.value.address &&
                  xe(h.value) > 0,
              ),
          )
        r(l), t(!1)
      }
      a()
    }, []),
    c("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        c("p", {
          className: "flex gap-1 text-base",
          children: [
            c("span", { children: "Address:" }),
            c("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: s,
            }),
          ],
        }),
        c("p", {
          className: "flex gap-1 text-base",
          children: [
            c("span", { children: "Balance:" }),
            c("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: Mn($n(he.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
        e
          ? c("span", {
              children: "loading past transfers",
            })
          : c("ul", {
              children: n.map((a) =>
                c(
                  "li",
                  {
                    children: [
                      c("p", { children: a.from }),
                      c("p", { children: a.to }),
                    ],
                  },
                  `transfer_${a.value}`,
                ),
              ),
            }),
      ],
    })
  )
}
function Mn(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function Ln() {
  return (
    q(() => {
      chrome.runtime.onMessage.addListener(async (e) => {
        const t = u(tt, e)
        switch (t.type) {
          case "ETHERNAUTA_REQUEST_CONNECT": {
            const n = await oe()
            if ((await ce(), n)) {
              await le(), (x.value = "wallet")
              return
            }
            break
          }
          case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
            {
              const n = await oe()
              if ((await ce(), n)) {
                await le(),
                  (A.value = {
                    id: t.id,
                    method: t.method,
                    params: t.params,
                  }),
                  (x.value = "sign")
                return
              }
            }
            break
        }
      })
    }, []),
    c(Oe, { children: Gn(x.value) })
  )
}
function Gn(e) {
  switch (e) {
    case "mnemonics":
      return c(ft, {})
    case "password":
      return c(pt, {})
    case "wallet":
      return c(Hn, {})
    case "sign":
      return c(Tn, {})
    default:
      return c("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Fe(c(Ln, {}), document.querySelector("#app"))
