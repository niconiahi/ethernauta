import {
  E as Ae,
  a as q,
  d as R,
  y as re,
  k as Se,
  u,
} from "./preact-10.26.9-BHuVZBHX.mjs"
import {
  A as $e,
  i as A,
  l as a,
  n as ae,
  d as b,
  c as Ce,
  o as d,
  s as f,
  m as Ie,
  H as j,
  t as k,
  v as ke,
  p as l,
  y as Me,
  f as Ne,
  e as O,
  x as Oe,
  j as oe,
  h as Pe,
  u as p,
  r as Re,
  k as se,
  g as Te,
  a as U,
  q as Ue,
  b as x,
  w as xe,
  z as Y,
} from "./vendor-BbX1x4RV.mjs"
;(() => {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const s of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(s)
  new MutationObserver((s) => {
    for (const o of s)
      if (o.type === "childList")
        for (const c of o.addedNodes)
          c.tagName === "LINK" &&
            c.rel === "modulepreload" &&
            r(c)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(s) {
    const o = {}
    return (
      s.integrity && (o.integrity = s.integrity),
      s.referrerPolicy &&
        (o.referrerPolicy = s.referrerPolicy),
      s.crossOrigin === "use-credentials"
        ? (o.credentials = "include")
        : s.crossOrigin === "anonymous"
          ? (o.credentials = "omit")
          : (o.credentials = "same-origin"),
      o
    )
  }
  function r(s) {
    if (s.ep) return
    s.ep = !0
    const o = n(s)
    fetch(s.href, o)
  }
})()
const Q = { iterations: 1e5, hash: "SHA-256" },
  h = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function M(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function $(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function ce(e, t, n) {
  const r = new TextEncoder().encode(e),
    s = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: Q.iterations,
      hash: Q.hash,
    },
    s,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function K() {
  return new Promise((e, t) => {
    const n = indexedDB.open(h.name, h.version)
    ;(n.onupgradeneeded = (r) => {
      const s = r.target.result
      s.objectStoreNames.contains(h.store_name) ||
        s.createObjectStore(h.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function qe(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    s = await ce(t, n, ["encrypt"]),
    o = new TextEncoder().encode(e),
    c = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      s,
      o,
    ),
    i = {
      salt: M(n.buffer),
      iv: M(r.buffer),
      cipher: M(c),
    },
    m = await K()
  return new Promise((C, z) => {
    const S = m
      .transaction(h.store_name, "readwrite")
      .objectStore(h.store_name)
      .put(i, h.vault_key)
    ;(S.onsuccess = () => C()),
      (S.onerror = () =>
        z(
          new Error(
            `Failed to save vault: ${S.error?.message}`,
          ),
        ))
  })
}
async function ie(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await K(),
    n = await new Promise((m, C) => {
      const E = t
        .transaction(h.store_name, "readonly")
        .objectStore(h.store_name)
        .get(h.vault_key)
      ;(E.onsuccess = () => {
        const S = E.result
        m(S)
      }),
        (E.onerror = () =>
          C(
            new Error(
              `Failed to load vault: ${E.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = $(n.salt),
    s = $(n.iv),
    o = $(n.cipher),
    c = await ce(e, r, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: s }, c, o)
      .catch((m) => {
        throw m instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unkwown error")
      })
  return new TextDecoder().decode(i)
}
async function He() {
  const e = await K()
  return new Promise((t) => {
    const s = e
      .transaction(h.store_name, "readonly")
      .objectStore(h.store_name)
      .get(h.vault_key)
    ;(s.onsuccess = () => t(!!s.result)),
      (s.onerror = () => t(!1))
  })
}
async function je(e) {
  try {
    return (await ie(e)) !== void 0
  } catch {
    return !1
  }
}
const V = "Invariant failed"
function I(e, t) {
  if (e) return
  const n = typeof t == "function" ? t() : t,
    r = n ? `${V}: ${n}` : V
  throw new Error(r)
}
function ue(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += J[e[n] >> 4]), (t += J[e[n] & 15])
  return `0x${t}`
}
function Ke(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function v(e) {
  const t = Ke(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in N)) throw new Error("Invalid character")
    if (!(t[r + 1] in N))
      throw new Error("Invalid character")
    ;(n[r / 2] |= N[t[r]] << 4), (n[r / 2] |= N[t[r + 1]])
  }
  return n
}
const J = "0123456789abcdef",
  N = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function Be(e) {
  if (!ke(e, xe)) throw new Error("Invalid mnemonic")
  return Ie(e)
}
function Le(e) {
  return j.fromMasterSeed(e)
}
function De(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function Fe(e) {
  const t = Te(e, !1),
    n = se(t.slice(1))
  return ue(n.slice(-20))
}
function Ge(e) {
  const t = e.privateKey
  return I(t, "a private key should exist"), t
}
function B(e) {
  return BigInt(e)
}
const We = d({ address: f(), private_key: f() }),
  T = R({
    address: "",
    key: new j({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function ze(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.sync.set({ wallet: t })
}
async function Z() {
  const t = l(
    d({ wallet: U(We) }),
    await chrome.storage.sync.get("wallet"),
  ).wallet
  t &&
    (T.value = {
      address: t.address,
      key: j.fromExtendedKey(t.private_key),
    })
}
async function Ye(e) {
  const t = await ie(e)
  I(t, "vault should exist to sign in")
  const n = Be(t),
    r = Le(n),
    s = De(r),
    o = Fe(s),
    c = r.derive("m/44'/60'/0'/0/0"),
    i = { address: o, key: c }
  ;(T.value = i), ze(i)
}
const Qe = "password",
  w = R(Qe)
async function le() {
  const e = Date.now()
  await chrome.storage.sync.set({ timestamp: e })
}
async function Ve() {
  return l(
    d({ timestamp: U(ae()) }),
    await chrome.storage.sync.get("timestamp"),
  ).timestamp
}
async function X() {
  const e = Date.now(),
    t = await Ve()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function ee() {
  ;(await He())
    ? (w.value = "password")
    : (w.value = "mnemonics")
}
function Je() {
  const [e, t] = q("")
  return u("div", {
    children: [
      u("input", {
        placeholder: "Password",
        value: e,
        onInput: (n) => {
          const r = n.currentTarget.value
          t(r)
        },
      }),
      u("button", {
        type: "button",
        onClick: async () => {
          ;(await je(e)) &&
            (await le(), await Ye(e), (w.value = "wallet"))
        },
        children: "unlock",
      }),
    ],
  })
}
const L = { chainId: 11155111 },
  D = p([
    a("bool"),
    a("bool[]"),
    a("string"),
    a("string[]"),
    a("address"),
    a("address[]"),
    a("byte"),
    a("byte[]"),
    a("bytes"),
    a("bytes[]"),
    a("bytes8"),
    a("bytes8[]"),
    a("bytes32"),
    a("bytes32[]"),
    a("bytes48"),
    a("bytes48[]"),
    a("bytes65"),
    a("bytes65[]"),
    a("bytes256"),
    a("bytes256[]"),
    a("bytesMax32"),
    a("bytesMax32[]"),
    a("hash32"),
    a("hash32[]"),
    a("uint"),
    a("uint[]"),
    a("uint8"),
    a("uint8[]"),
    a("uint64"),
    a("uint64[]"),
    a("uint256"),
    a("uint256[]"),
  ]),
  F = d({ name: f(), type: p([a("tuple"), a("tuple[]")]) })
d({
  ...F.entries,
  components: x(d({ name: f(), type: D })),
})
d({
  ...F.entries,
  components: x(d({ name: f(), type: D })),
  indexed: Ce(),
})
d({
  ...F.entries,
  components: x(d({ name: f(), type: D })),
})
function Ze(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const _ = b(Ze)
function Xe(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const et = b(Xe)
function tt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const G = b(tt),
  nt = p([
    a("earliest"),
    a("finalized"),
    a("safe"),
    a("latest"),
    a("pending"),
  ]),
  P = p([G, nt, et]),
  H = O(
    f(),
    Pe(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  de = p([x(A()), Re(f(), A())]),
  W = p([f(), ae(), Ne()]),
  rt = d({
    jsonrpc: a("2.0"),
    method: H,
    params: U(de),
    id: W,
  }),
  st = d({
    data: U(A()),
    message: f(),
    code: p([
      a(-32e3),
      a(-32300),
      a(-32400),
      a(-32500),
      a(-32600),
      a(-32601),
      a(-32602),
      a(-32603),
      a(-32700),
      a(-32701),
      a(-32702),
    ]),
  }),
  at = d({ id: W, jsonrpc: a("2.0"), error: st }),
  ot = d({ id: W, jsonrpc: a("2.0"), result: A() }),
  ct = p([at, ot]),
  fe = p([k([H, de]), k([H])])
function he(e) {
  return async (t) => {
    const [n, r] = t,
      s = l(rt, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: it(r),
      }),
      o = await fetch(e, {
        method: "POST",
        body: JSON.stringify(s),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return l(ct, o)
  }
}
function it(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function ut(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const me = b(ut)
function lt(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const dt = b(lt)
function ft(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const ht = b(ft),
  mt = ":"
function pe({ namespace: e, reference: t }) {
  const n = l(dt, e),
    r = l(ht, String(t)),
    s = n + mt + r
  return l(me, s)
}
function ye(e) {
  return (t) => {
    const n = l(me, t),
      r = e.find(({ chainId: s }) => s === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
const pt = p([
  k([_, P]),
  k([_]),
  d({ address: _, blockNumberOrTagOrHash: P }),
  d({ address: _ }),
])
function yt(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = l(pt, e),
      s = l(fe, [n, r]),
      o = await Promise.any(t.map((i) => i(s)))
    if ("error" in o) throw new Error(o.error.message)
    return l(G, o.result)
  }
}
const _t = p([
  k([_, P]),
  d({ address: _, blockNumberOrTagOrHash: P }),
])
function wt(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = l(_t, e),
      s = l(fe, [n, r]),
      o = await Promise.race(t.map((i) => i(s)))
    if ("error" in o) throw new Error(o.error.message)
    return l(G, o.result)
  }
}
const gt = { ETHEREUM: "eip155" },
  vt =
    "https://little-bitter-wave.ethereum-sepolia.quiknode.pro/4d40a4c7ec139649d4b1f43f5d536c3756faacc9/",
  _e = pe({ namespace: gt.ETHEREUM, reference: L.chainId }),
  bt = ye([{ chainId: _e, transports: [he(vt)] }]),
  te = R(0n)
async function Et(e) {
  const n = await yt([e, "latest"])(bt(_e))
  return B(n)
}
function St(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    s = n.toString()
  if (r === 0n) return s
  const o = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${s}.${o}`
}
function At() {
  const e = T.value.address
  return (
    re(() => {
      async function t() {
        const n = await Et(e)
        te.value = n
      }
      t()
    }, []),
    u("div", {
      children: [
        u("p", {
          children: ["the connected address is ", e],
        }),
        u("p", {
          children: ["it's balance is ", St(te.value)],
        }),
      ],
    })
  )
}
const kt = O(f(), oe(8)),
  It = O(f(), oe(1))
function Tt() {
  const [e, t] = q(""),
    [n, r] = q(
      "smile price bomb movie minimum treat hurdle adult wing come space cross",
    )
  return u("main", {
    children: [
      u("input", {
        placeholder: "Mnemonics",
        value: n,
        onInput: (s) => {
          const o = s.currentTarget.value
          r(o)
        },
      }),
      u("input", {
        placeholder: "Password",
        value: e,
        onInput: (s) => {
          const o = s.currentTarget.value
          t(o)
        },
      }),
      u("button", {
        type: "button",
        onClick: async () => {
          const s = l(It, n),
            o = l(kt, e)
          qe(s, o), await le(), (w.value = "password")
        },
        children: "save wallet",
      }),
    ],
  })
}
const g = R({
  id: "some-id",
  method: "hello_world",
  params: [],
})
function we(e) {
  return Array.isArray(e) ? Ct(e) : xt(e)
}
function xt(e) {
  const t = Nt(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const o = new Uint8Array(1 + t.length)
    return (o[0] = 128 + t.length), o.set(t, 1), o
  }
  const r = ge(t.length),
    s = new Uint8Array(1 + r.length + t.length)
  return (
    (s[0] = 183 + r.length),
    s.set(r, 1),
    s.set(t, 1 + r.length),
    s
  )
}
function Ct(e) {
  const t = e.map((c) => we(c)),
    n = t.reduce((c, i) => c + i.length, 0)
  if (n <= 55) {
    const c = new Uint8Array(1 + n)
    c[0] = 192 + n
    let i = 1
    for (const m of t) c.set(m, i), (i += m.length)
    return c
  }
  const r = ge(n),
    s = new Uint8Array(1 + r.length + n)
  ;(s[0] = 247 + r.length), s.set(r, 1)
  let o = 1 + r.length
  for (const c of t) s.set(c, o), (o += c.length)
  return s
}
function Nt(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? v(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return Pt(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function Pt(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return v(n)
}
function ge(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function y(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return v(n)
}
function Rt(e, t) {
  return (
    (Y.hmacSha256Sync = (n, ...r) =>
      Me($e, n, Y.concatBytes(...r))),
    Oe(e, t)
  )
}
function Ut(e) {
  return BigInt(e)
}
async function Ot(e, t, n) {
  const s = await wt([e, "latest"])(t(n))
  return B(s)
}
function Mt() {
  return BigInt(L.chainId)
}
function $t() {
  return 21000n
}
function qt() {
  return 20000000000n
}
function Ht() {
  return 2000000000n
}
function jt(e, t) {
  switch (e) {
    case "transfer": {
      const n = l(_, t[0]),
        r = l(O(f(), Ue()), t[1])
      return {
        to: n,
        value: B(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function Kt({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: s, value: o, data: c } = jt(n, r),
    i = {
      to: s,
      data: c,
      value: o,
      nonce: t,
      chain_id: Mt(),
      gas_limit: $t(),
      max_fee_per_gas: qt(),
      max_priority_fee_per_gas: Ht(),
    },
    m = Ge(e)
  return Lt(i, m)
}
function Bt(e, t) {
  const n = ve(e, t)
  return se(n)
}
function Lt(e, t) {
  const n = Gt(e),
    r = ne(n),
    s = new Uint8Array([2]),
    o = Bt(s, r),
    c = Rt(o, t),
    i = Ft(n, c),
    m = ne(i)
  return ve(s, m)
}
function ve(...e) {
  let t = 0
  for (const s of e) t += s.length
  const n = new Uint8Array(t)
  let r = 0
  for (const s of e) n.set(s, r), (r += s.length)
  return n
}
function Dt(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    I(r, "access list item should exist")
    const s = new Array(r.storage_keys.length)
    for (let o = 0; o < r.storage_keys.length; o++) {
      const c = r.storage_keys[o]
      I(c, "storage key should exist"), (s[o] = v(c))
    }
    t[n] = [v(r.address), s]
  }
  return t
}
function Ft(e, t) {
  const n = new Array(12)
  I(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = Ut(t.recovery)
  return (
    (n[9] = y(r)), (n[10] = y(t.r)), (n[11] = y(t.s)), n
  )
}
function Gt(e) {
  const t = new Array(9)
  return (
    (t[0] = y(e.chain_id)),
    (t[1] = y(e.nonce)),
    (t[2] = y(e.max_priority_fee_per_gas)),
    (t[3] = y(e.max_fee_per_gas)),
    (t[4] = y(e.gas_limit)),
    (t[5] = v(e.to)),
    (t[6] = y(e.value)),
    (t[7] = e.data),
    (t[8] = Dt([])),
    t
  )
}
function ne(e) {
  return we(e)
}
const Wt = { ETHEREUM: "eip155" },
  zt =
    "https://little-bitter-wave.ethereum-sepolia.quiknode.pro/4d40a4c7ec139649d4b1f43f5d536c3756faacc9/",
  be = pe({ namespace: Wt.ETHEREUM, reference: L.chainId }),
  Yt = ye([{ chainId: be, transports: [he(zt)] }])
function Qt() {
  return u("div", {
    children: [
      u("h1", { children: "you are about to sign" }),
      u("p", { children: ["method ", g.value.method] }),
      u("p", {
        children: [
          "params",
          " ",
          JSON.stringify(g.value.params, null, 2),
        ],
      }),
      u("button", {
        type: "button",
        onClick: async () => {
          const e = T.value.address,
            t = T.value.key,
            n = await Ot(e, Yt, be),
            r = await Kt({
              key: t,
              nonce: n,
              method: g.value.method,
              params: g.value.params,
            }),
            s = {
              id: g.value.id,
              type: "CRYPTOMAN_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: ue(r),
            }
          chrome.runtime.sendMessage(s)
        },
        children: "sign",
      }),
    ],
  })
}
const Vt = d({
    id: f(),
    type: a("CRYPTOMAN_REQUEST_SIGN_TRANSACTION"),
    method: f(),
    params: x(A()),
  }),
  Jt = d({ id: f(), type: a("CRYPTOMAN_REQUEST_CONNECT") }),
  Zt = p([Vt, Jt])
function Xt() {
  return (
    re(() => {
      chrome.runtime.onMessage.addListener(async (e) => {
        const t = l(Zt, e)
        switch (t.type) {
          case "CRYPTOMAN_REQUEST_CONNECT": {
            const n = await X()
            if ((await ee(), n)) {
              await Z(), (w.value = "wallet")
              return
            }
            break
          }
          case "CRYPTOMAN_REQUEST_SIGN_TRANSACTION":
            {
              const n = await X()
              if ((await ee(), n)) {
                await Z(),
                  (g.value = {
                    id: t.id,
                    method: t.method,
                    params: t.params,
                  }),
                  (w.value = "sign")
                return
              }
            }
            break
        }
      })
    }, []),
    u(Se, { children: en(w.value) })
  )
}
function en(e) {
  switch (e) {
    case "mnemonics":
      return u(Tt, {})
    case "password":
      return u(Je, {})
    case "wallet":
      return u(At, {})
    case "sign":
      return u(Qt, {})
    default:
      return u("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Ae(u(Xt, {}), document.querySelector("#app"))
