const e = {
  name: "RUNEVM Testnet",
  shortName: "runevm-test",
  chain: "RuneVM",
  rpc: ["https://rpc.runevm.io/"],
  faucets: ["https://faucet.runevm.io/"],
  nativeCurrency: {
    name: "Test Bitcoin",
    symbol: "tBTC",
    decimals: 8
  },
  infoURL: "",
  chainId: 84e4,
  networkId: 84e4,
  explorers: [
    {
      name: "Tracehawk",
      url: "https://explorer.runevm.io",
      standard: "none"
    }
  ]
};
export {
  e as eip155_840000
};
