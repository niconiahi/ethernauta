const t = {
  name: "Joys Digital Mainnet",
  shortName: "JOYS",
  chain: "JOYS",
  rpc: ["https://node.joys.digital"],
  faucets: [],
  nativeCurrency: {
    name: "JOYS",
    symbol: "JOYS",
    decimals: 18
  },
  infoURL: "https://joys.digital",
  chainId: 35855456,
  networkId: 35855456
};
export {
  t as eip155_35855456
};
