const t = {
  name: "IOLite",
  shortName: "ilt",
  chain: "ILT",
  rpc: ["https://net.iolite.io"],
  faucets: [],
  nativeCurrency: {
    name: "IOLite Ether",
    symbol: "ILT",
    decimals: 18
  },
  infoURL: "https://iolite.io",
  chainId: 18289463,
  networkId: 18289463
};
export {
  t as eip155_18289463
};
