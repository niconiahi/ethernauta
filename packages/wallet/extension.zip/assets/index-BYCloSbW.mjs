var h
// @__NO_SIDE_EFFECTS__
function g(s) {
  return {
    lang: h?.lang,
    message: s?.message,
    abortEarly: h?.abortEarly,
    abortPipeEarly: h?.abortPipeEarly,
  }
}
var k
// @__NO_SIDE_EFFECTS__
function d(s) {
  return k?.get(s)
}
var E
// @__NO_SIDE_EFFECTS__
function j(s) {
  return E?.get(s)
}
var x
// @__NO_SIDE_EFFECTS__
function _(s, r) {
  return x?.get(s)?.get(r)
}
// @__NO_SIDE_EFFECTS__
function b(s) {
  const r = typeof s
  return r === "string"
    ? `"${s}"`
    : r === "number" || r === "bigint" || r === "boolean"
      ? `${s}`
      : r === "object" || r === "function"
        ? ((s &&
            Object.getPrototypeOf(s)?.constructor?.name) ??
          "null")
        : r
}
function f(s, r, e, n, u) {
  const t = u && "input" in u ? u.input : e.value,
    i = u?.expected ?? s.expects ?? null,
    a = u?.received ?? /* @__PURE__ */ b(t),
    l = {
      kind: s.kind,
      type: s.type,
      input: t,
      expected: i,
      received: a,
      message: `Invalid ${r}: ${i ? `Expected ${i} but r` : "R"}eceived ${a}`,
      requirement: s.requirement,
      path: u?.path,
      issues: u?.issues,
      lang: n.lang,
      abortEarly: n.abortEarly,
      abortPipeEarly: n.abortPipeEarly,
    },
    o = s.kind === "schema",
    p =
      u?.message ??
      s.message ??
      /* @__PURE__ */ _(s.reference, l.lang) ??
      (o ? /* @__PURE__ */ j(l.lang) : null) ??
      n.message ??
      /* @__PURE__ */ d(l.lang)
  p !== void 0 &&
    (l.message =
      typeof p == "function"
        ? // @ts-expect-error
          p(l)
        : p),
    o && (e.typed = !1),
    e.issues ? e.issues.push(l) : (e.issues = [l])
}
// @__NO_SIDE_EFFECTS__
function c(s) {
  return {
    version: 1,
    vendor: "valibot",
    validate(r) {
      return s["~run"]({ value: r }, /* @__PURE__ */ g())
    },
  }
}
// @__NO_SIDE_EFFECTS__
function $(s, r) {
  return (
    Object.hasOwn(s, r) &&
    r !== "__proto__" &&
    r !== "prototype" &&
    r !== "constructor"
  )
}
// @__NO_SIDE_EFFECTS__
function D(s, r) {
  const e = [...new Set(s)]
  return e.length > 1
    ? `(${e.join(` ${r} `)})`
    : (e[0] ?? "never")
}
var w = class extends Error {
  /**
   * Creates a Valibot error with useful information.
   *
   * @param issues The error issues.
   */
  constructor(s) {
    super(s[0].message),
      (this.name = "ValiError"),
      (this.issues = s)
  }
}
// @__NO_SIDE_EFFECTS__
function I(s, r, e) {
  return typeof s.fallback == "function"
    ? // @ts-expect-error
      s.fallback(r, e)
    : // @ts-expect-error
      s.fallback
}
// @__NO_SIDE_EFFECTS__
function m(s, r, e) {
  return typeof s.default == "function"
    ? // @ts-expect-error
      s.default(r, e)
    : // @ts-expect-error
      s.default
}
// @__NO_SIDE_EFFECTS__
function O(s, r) {
  return {
    kind: "schema",
    type: "array",
    reference: O,
    expects: "Array",
    async: !1,
    item: s,
    message: r,
    get "~standard"() {
      return /* @__PURE__ */ c(this)
    },
    "~run"(e, n) {
      const u = e.value
      if (Array.isArray(u)) {
        ;(e.typed = !0), (e.value = [])
        for (let t = 0; t < u.length; t++) {
          const i = u[t],
            a = this.item["~run"]({ value: i }, n)
          if (a.issues) {
            const l = {
              type: "array",
              origin: "value",
              input: u,
              key: t,
              value: i,
            }
            for (const o of a.issues)
              o.path ? o.path.unshift(l) : (o.path = [l]),
                e.issues?.push(o)
            if (
              (e.issues || (e.issues = a.issues),
              n.abortEarly)
            ) {
              e.typed = !1
              break
            }
          }
          a.typed || (e.typed = !1), e.value.push(a.value)
        }
      } else f(this, "type", e, n)
      return e
    },
  }
}
// @__NO_SIDE_EFFECTS__
function P(s, r) {
  return {
    kind: "schema",
    type: "instance",
    reference: P,
    expects: s.name,
    async: !1,
    class: s,
    message: r,
    get "~standard"() {
      return /* @__PURE__ */ c(this)
    },
    "~run"(e, n) {
      return (
        e.value instanceof this.class
          ? (e.typed = !0)
          : f(this, "type", e, n),
        e
      )
    },
  }
}
// @__NO_SIDE_EFFECTS__
function S(s, r) {
  return {
    kind: "schema",
    type: "literal",
    reference: S,
    expects: /* @__PURE__ */ b(s),
    async: !1,
    literal: s,
    message: r,
    get "~standard"() {
      return /* @__PURE__ */ c(this)
    },
    "~run"(e, n) {
      return (
        e.value === this.literal
          ? (e.typed = !0)
          : f(this, "type", e, n),
        e
      )
    },
  }
}
// @__NO_SIDE_EFFECTS__
function V(s, r) {
  return {
    kind: "schema",
    type: "object",
    reference: V,
    expects: "Object",
    async: !1,
    entries: s,
    message: r,
    get "~standard"() {
      return /* @__PURE__ */ c(this)
    },
    "~run"(e, n) {
      const u = e.value
      if (u && typeof u == "object") {
        ;(e.typed = !0), (e.value = {})
        for (const t in this.entries) {
          const i = this.entries[t]
          if (
            t in u ||
            ((i.type === "exact_optional" ||
              i.type === "optional" ||
              i.type === "nullish") && // @ts-expect-error
              i.default !== void 0)
          ) {
            const a =
                t in u
                  ? // @ts-expect-error
                    u[t]
                  : /* @__PURE__ */ m(i),
              l = i["~run"]({ value: a }, n)
            if (l.issues) {
              const o = {
                type: "object",
                origin: "value",
                input: u,
                key: t,
                value: a,
              }
              for (const p of l.issues)
                p.path ? p.path.unshift(o) : (p.path = [o]),
                  e.issues?.push(p)
              if (
                (e.issues || (e.issues = l.issues),
                n.abortEarly)
              ) {
                e.typed = !1
                break
              }
            }
            l.typed || (e.typed = !1),
              (e.value[t] = l.value)
          } else if (i.fallback !== void 0)
            e.value[t] = /* @__PURE__ */ I(i)
          else if (
            i.type !== "exact_optional" &&
            i.type !== "optional" &&
            i.type !== "nullish" &&
            (f(this, "key", e, n, {
              input: void 0,
              expected: `"${t}"`,
              path: [
                {
                  type: "object",
                  origin: "key",
                  input: u,
                  key: t,
                  // @ts-expect-error
                  value: u[t],
                },
              ],
            }),
            n.abortEarly)
          )
            break
        }
      } else f(this, "type", e, n)
      return e
    },
  }
}
// @__NO_SIDE_EFFECTS__
function A(s, r) {
  return {
    kind: "schema",
    type: "optional",
    reference: A,
    expects: `(${s.expects} | undefined)`,
    async: !1,
    wrapped: s,
    default: r,
    get "~standard"() {
      return /* @__PURE__ */ c(this)
    },
    "~run"(e, n) {
      return e.value === void 0 &&
        (this.default !== void 0 &&
          (e.value = /* @__PURE__ */ m(this, e, n)),
        e.value === void 0)
        ? ((e.typed = !0), e)
        : this.wrapped["~run"](e, n)
    },
  }
}
// @__NO_SIDE_EFFECTS__
function M(s, r, e) {
  return {
    kind: "schema",
    type: "record",
    reference: M,
    expects: "Object",
    async: !1,
    key: s,
    value: r,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ c(this)
    },
    "~run"(n, u) {
      const t = n.value
      if (t && typeof t == "object") {
        ;(n.typed = !0), (n.value = {})
        for (const i in t)
          if (/* @__PURE__ */ $(t, i)) {
            const a = t[i],
              l = this.key["~run"]({ value: i }, u)
            if (l.issues) {
              const p = {
                type: "object",
                origin: "key",
                input: t,
                key: i,
                value: a,
              }
              for (const y of l.issues)
                (y.path = [p]), n.issues?.push(y)
              if (
                (n.issues || (n.issues = l.issues),
                u.abortEarly)
              ) {
                n.typed = !1
                break
              }
            }
            const o = this.value["~run"]({ value: a }, u)
            if (o.issues) {
              const p = {
                type: "object",
                origin: "value",
                input: t,
                key: i,
                value: a,
              }
              for (const y of o.issues)
                y.path ? y.path.unshift(p) : (y.path = [p]),
                  n.issues?.push(y)
              if (
                (n.issues || (n.issues = o.issues),
                u.abortEarly)
              ) {
                n.typed = !1
                break
              }
            }
            ;(!l.typed || !o.typed) && (n.typed = !1),
              l.typed && (n.value[l.value] = o.value)
          }
      } else f(this, "type", n, u)
      return n
    },
  }
}
// @__NO_SIDE_EFFECTS__
function q(s) {
  return {
    kind: "schema",
    type: "string",
    reference: q,
    expects: "string",
    async: !1,
    message: s,
    get "~standard"() {
      return /* @__PURE__ */ c(this)
    },
    "~run"(r, e) {
      return (
        typeof r.value == "string"
          ? (r.typed = !0)
          : f(this, "type", r, e),
        r
      )
    },
  }
}
// @__NO_SIDE_EFFECTS__
function v(s) {
  let r
  if (s)
    for (const e of s)
      r ? r.push(...e.issues) : (r = e.issues)
  return r
}
// @__NO_SIDE_EFFECTS__
function G(s, r) {
  return {
    kind: "schema",
    type: "union",
    reference: G,
    expects: /* @__PURE__ */ D(
      s.map((e) => e.expects),
      "|",
    ),
    async: !1,
    options: s,
    message: r,
    get "~standard"() {
      return /* @__PURE__ */ c(this)
    },
    "~run"(e, n) {
      let u, t, i
      for (const a of this.options) {
        const l = a["~run"]({ value: e.value }, n)
        if (l.typed)
          if (l.issues) t ? t.push(l) : (t = [l])
          else {
            u = l
            break
          }
        else i ? i.push(l) : (i = [l])
      }
      if (u) return u
      if (t) {
        if (t.length === 1) return t[0]
        f(this, "type", e, n, {
          issues: /* @__PURE__ */ v(t),
        }),
          (e.typed = !0)
      } else {
        if (i?.length === 1) return i[0]
        f(this, "type", e, n, {
          issues: /* @__PURE__ */ v(i),
        })
      }
      return e
    },
  }
}
// @__NO_SIDE_EFFECTS__
function K() {
  return {
    kind: "schema",
    type: "unknown",
    reference: K,
    expects: "unknown",
    async: !1,
    get "~standard"() {
      return /* @__PURE__ */ c(this)
    },
    "~run"(s) {
      return (s.typed = !0), s
    },
  }
}
function C(s, r, e) {
  const n = s["~run"]({ value: r }, /* @__PURE__ */ g(e))
  if (n.issues) throw new w(n.issues)
  return n.value
}
export {
  A as a,
  O as b,
  K as c,
  P as i,
  S as l,
  V as o,
  C as p,
  M as r,
  q as s,
  G as u,
}
