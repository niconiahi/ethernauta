import {
  d as R,
  a as U,
  u as o,
  y as ee,
  k as Ee,
  E as Se,
} from "./preact-10.26.9-DO5-VWXm.mjs"
import {
  p as u,
  o as h,
  a as C,
  n as te,
  u as p,
  s as d,
  l,
  b as ne,
  r as re,
  c as v,
  v as Ae,
  m as xe,
  H as F,
  g as Te,
  k as se,
  w as Ne,
  d as O,
  e as ae,
  f as ke,
  h as Ie,
  t as x,
  i as E,
  j as Ue,
  q as Pe,
  x as Re,
  y as W,
  z as Ce,
} from "./vendor-6cAV8jNg.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const r of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    s(r)
  new MutationObserver((r) => {
    for (const a of r)
      if (a.type === "childList")
        for (const c of a.addedNodes)
          c.tagName === "LINK" &&
            c.rel === "modulepreload" &&
            s(c)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(r) {
    const a = {}
    return (
      r.integrity && (a.integrity = r.integrity),
      r.referrerPolicy &&
        (a.referrerPolicy = r.referrerPolicy),
      r.crossOrigin === "use-credentials"
        ? (a.credentials = "include")
        : r.crossOrigin === "anonymous"
          ? (a.credentials = "omit")
          : (a.credentials = "same-origin"),
      a
    )
  }
  function s(r) {
    if (r.ep) return
    r.ep = !0
    const a = n(r)
    fetch(r.href, a)
  }
})()
const z = { iterations: 1e5, hash: "SHA-256" },
  f = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function M(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function $(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function oe(e, t, n) {
  const s = new TextEncoder().encode(e),
    r = await crypto.subtle.importKey(
      "raw",
      s,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: z.iterations,
      hash: z.hash,
    },
    r,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function B() {
  return new Promise((e, t) => {
    const n = indexedDB.open(f.name, f.version)
    ;(n.onupgradeneeded = (s) => {
      const r = s.target.result
      r.objectStoreNames.contains(f.store_name) ||
        r.createObjectStore(f.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Oe(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    s = crypto.getRandomValues(new Uint8Array(12)),
    r = await oe(t, n, ["encrypt"]),
    a = new TextEncoder().encode(e),
    c = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: s },
      r,
      a,
    ),
    i = {
      salt: M(n.buffer),
      iv: M(s.buffer),
      cipher: M(c),
    },
    m = await B()
  return new Promise((k, G) => {
    const A = m
      .transaction(f.store_name, "readwrite")
      .objectStore(f.store_name)
      .put(i, f.vault_key)
    ;(A.onsuccess = () => k()),
      (A.onerror = () =>
        G(
          new Error(
            `Failed to save vault: ${A.error?.message}`,
          ),
        ))
  })
}
async function ce(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await B(),
    n = await new Promise((m, k) => {
      const S = t
        .transaction(f.store_name, "readonly")
        .objectStore(f.store_name)
        .get(f.vault_key)
      ;(S.onsuccess = () => {
        const A = S.result
        m(A)
      }),
        (S.onerror = () =>
          k(
            new Error(
              `Failed to load vault: ${S.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const s = $(n.salt),
    r = $(n.iv),
    a = $(n.cipher),
    c = await oe(e, s, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: r }, c, a)
      .catch((m) => {
        throw m instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unkwown error")
      })
  return new TextDecoder().decode(i)
}
async function Me() {
  const e = await B()
  return new Promise((t) => {
    const r = e
      .transaction(f.store_name, "readonly")
      .objectStore(f.store_name)
      .get(f.vault_key)
    ;(r.onsuccess = () => t(!!r.result)),
      (r.onerror = () => t(!1))
  })
}
async function $e(e) {
  try {
    return (await ce(e)) !== void 0
  } catch {
    return !1
  }
}
const He = "password",
  g = R(He)
async function ie() {
  const e = Date.now()
  await chrome.storage.sync.set({ timestamp: e })
}
async function Fe() {
  return u(
    h({ timestamp: C(te()) }),
    await chrome.storage.sync.get("timestamp"),
  ).timestamp
}
async function Q() {
  const e = Date.now(),
    t = await Fe()
  if (!t) return !1
  const n = e - t,
    s = 300 * 1e3
  return n < s
}
async function V() {
  ;(await Me())
    ? (g.value = "password")
    : (g.value = "mnemonics")
}
const Be = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: d(),
    params: p([ne(v()), re(d(), v())]),
  }),
  je = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  qe = p([Be, je]),
  w = R({
    id: "some-id",
    method: "hello_world",
    params: [],
  })
function T(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function le(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += J[e[n] >> 4]), (t += J[e[n] & 15])
  return `0x${t}`
}
function De(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function b(e) {
  const t = De(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let s = 0; s < t.length; s += 2) {
    if (!(t[s] in I)) throw new Error("Invalid character")
    if (!(t[s + 1] in I))
      throw new Error("Invalid character")
    ;(n[s / 2] |= I[t[s]] << 4), (n[s / 2] |= I[t[s + 1]])
  }
  return n
}
const J = "0123456789abcdef",
  I = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function Ke(e) {
  if (!Ae(e, Ne)) throw new Error("Invalid mnemonic")
  return xe(e)
}
function Le(e) {
  return F.fromMasterSeed(e)
}
function Ge(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function We(e) {
  const t = Te(e, !1),
    n = se(t.slice(1))
  return le(n.slice(-20))
}
function ze(e) {
  const t = e.privateKey
  return T(t, "a private key should exist"), t
}
function j(e) {
  return BigInt(e)
}
const Qe = h({ address: d(), private_key: d() }),
  N = R({
    address: "",
    key: new F({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function Ve(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.sync.set({ wallet: t })
}
async function Y() {
  const t = u(
    h({ wallet: C(Qe) }),
    await chrome.storage.sync.get("wallet"),
  ).wallet
  t &&
    (N.value = {
      address: t.address,
      key: F.fromExtendedKey(t.private_key),
    })
}
async function Je(e) {
  const t = await ce(e)
  T(t, "vault should exist to sign in")
  const n = Ke(t),
    s = Le(n),
    r = Ge(s),
    a = We(r),
    c = s.derive("m/44'/60'/0'/0/0"),
    i = { address: a, key: c }
  ;(N.value = i), Ve(i)
}
function q({ children: e, class: t, ...n }) {
  const [s, r] = U(!1)
  return o("button", {
    type: "button",
    onPointerDown: () => r(!0),
    onPointerUp: () => r(!1),
    onPointerLeave: () => r(!1),
    onTouchCancel: () => r(!1),
    class: [
      "bg-[#FF5005] border-2 rounded-md p-2 cursor-pointer text-base hover:bg-[#cc4004] transition-colors",
      s
        ? "outline outline-2 outline-offset-2 outline-gray-700"
        : "",
      t,
    ]
      .filter(Boolean)
      .join(" "),
    ...n,
    children: e,
  })
}
const Ye = O(d(), ae(8)),
  Ze = O(d(), ae(1))
function Xe() {
  const [e, t] = U(""),
    [n, s] = U(
      "smile price bomb movie minimum treat hurdle adult wing come space cross",
    )
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (r) => {
          const a = r.currentTarget.value
          s(a)
        },
      }),
      o("input", {
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (r) => {
          const a = r.currentTarget.value
          t(a)
        },
      }),
      o(q, {
        onClick: async () => {
          const r = u(Ze, n),
            a = u(Ye, e)
          Oe(r, a), await ie(), (g.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function et() {
  const [e, t] = U("")
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (n) => {
          const s = n.currentTarget.value
          t(s)
        },
      }),
      o(q, {
        onClick: async () => {
          ;(await $e(e)) &&
            (await ie(), await Je(e), (g.value = "wallet"))
        },
        children: "Unlock",
      }),
    ],
  })
}
const D = { chainId: 11155111 },
  H = O(
    d(),
    Ie(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  ue = p([ne(v()), re(d(), v())]),
  K = p([d(), te(), ke()]),
  tt = h({
    jsonrpc: l("2.0"),
    method: H,
    params: C(ue),
    id: K,
  }),
  nt = h({
    data: C(v()),
    message: d(),
    code: p([
      l(-32e3),
      l(-32300),
      l(-32400),
      l(-32500),
      l(-32600),
      l(-32601),
      l(-32602),
      l(-32603),
      l(-32700),
      l(-32701),
      l(-32702),
    ]),
  }),
  rt = h({ id: K, jsonrpc: l("2.0"), error: nt }),
  st = h({ id: K, jsonrpc: l("2.0"), result: v() }),
  at = p([rt, st]),
  de = p([x([H, ue]), x([H])])
function ot(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const ct = E(ot)
function it(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const lt = E(it)
function ut(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const fe = E(ut),
  dt = ":"
function me({ namespace: e, reference: t }) {
  const n = u(ct, e),
    s = u(lt, String(t)),
    r = n + dt + s
  return u(fe, r)
}
function he(e) {
  return async (t) => {
    const [n, s] = t,
      r = u(tt, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: ft(s),
      }),
      a = await fetch(e, {
        method: "POST",
        body: JSON.stringify(r),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return u(at, a)
  }
}
function ft(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function pe(e) {
  return (t) => {
    const n = u(fe, t),
      s = e.find(({ chainId: r }) => r === n)
    if (!s)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return s.transports
  }
}
function mt(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const y = E(mt)
function ht(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const pt = E(ht)
function _t(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const L = E(_t),
  yt = p([
    l("earliest"),
    l("finalized"),
    l("safe"),
    l("latest"),
    l("pending"),
  ]),
  P = p([L, yt, pt]),
  gt = p([
    x([y, P]),
    x([y]),
    h({ address: y, blockNumberOrTagOrHash: P }),
    h({ address: y }),
  ])
function wt(e) {
  return async (t) => {
    const n = "eth_getBalance",
      s = u(gt, e),
      r = u(de, [n, s]),
      a = await Promise.any(t.map((i) => i(r)))
    if ("error" in a) throw new Error(a.error.message)
    return u(L, a.result)
  }
}
const vt = p([
  x([y, P]),
  h({ address: y, blockNumberOrTagOrHash: P }),
])
function bt(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      s = u(vt, e),
      r = u(de, [n, s]),
      a = await Promise.race(t.map((i) => i(r)))
    if ("error" in a) throw new Error(a.error.message)
    return u(L, a.result)
  }
}
function _e(e) {
  return Array.isArray(e) ? St(e) : Et(e)
}
function Et(e) {
  const t = At(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const a = new Uint8Array(1 + t.length)
    return (a[0] = 128 + t.length), a.set(t, 1), a
  }
  const s = ye(t.length),
    r = new Uint8Array(1 + s.length + t.length)
  return (
    (r[0] = 183 + s.length),
    r.set(s, 1),
    r.set(t, 1 + s.length),
    r
  )
}
function St(e) {
  const t = e.map((c) => _e(c)),
    n = t.reduce((c, i) => c + i.length, 0)
  if (n <= 55) {
    const c = new Uint8Array(1 + n)
    c[0] = 192 + n
    let i = 1
    for (const m of t) c.set(m, i), (i += m.length)
    return c
  }
  const s = ye(n),
    r = new Uint8Array(1 + s.length + n)
  ;(r[0] = 247 + s.length), r.set(s, 1)
  let a = 1 + s.length
  for (const c of t) r.set(c, a), (a += c.length)
  return r
}
function At(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? b(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return xt(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function xt(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return b(n)
}
function ye(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function _(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return b(n)
}
function Tt(e, t) {
  return (
    (W.hmacSha256Sync = (n, ...s) =>
      Re(Ce, n, W.concatBytes(...s))),
    Pe(e, t)
  )
}
function Nt(e) {
  return BigInt(e)
}
async function kt(e, t, n) {
  const r = await bt([e, "latest"])(t(n))
  return j(r)
}
function It() {
  return BigInt(D.chainId)
}
function Ut() {
  return 21000n
}
function Pt() {
  return 20000000000n
}
function Rt() {
  return 2000000000n
}
function Ct(e, t) {
  switch (e) {
    case "transfer": {
      const n = u(y, t[0]),
        s = u(O(d(), Ue()), t[1])
      return {
        to: n,
        value: j(s),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function Ot({
  key: e,
  nonce: t,
  method: n,
  params: s,
}) {
  const { to: r, value: a, data: c } = Ct(n, s),
    i = {
      to: r,
      data: c,
      value: a,
      nonce: t,
      chain_id: It(),
      gas_limit: Ut(),
      max_fee_per_gas: Pt(),
      max_priority_fee_per_gas: Rt(),
    },
    m = ze(e)
  return $t(i, m)
}
function Mt(e, t) {
  const n = ge(e, t)
  return se(n)
}
function $t(e, t) {
  const n = Bt(e),
    s = Z(n),
    r = new Uint8Array([2]),
    a = Mt(r, s),
    c = Tt(a, t),
    i = Ft(n, c),
    m = Z(i)
  return ge(r, m)
}
function ge(...e) {
  let t = 0
  for (const r of e) t += r.length
  const n = new Uint8Array(t)
  let s = 0
  for (const r of e) n.set(r, s), (s += r.length)
  return n
}
function Ht(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const s = e[n]
    T(s, "access list item should exist")
    const r = new Array(s.storage_keys.length)
    for (let a = 0; a < s.storage_keys.length; a++) {
      const c = s.storage_keys[a]
      T(c, "storage key should exist"), (r[a] = b(c))
    }
    t[n] = [b(s.address), r]
  }
  return t
}
function Ft(e, t) {
  const n = new Array(12)
  T(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const s = Nt(t.recovery)
  return (
    (n[9] = _(s)), (n[10] = _(t.r)), (n[11] = _(t.s)), n
  )
}
function Bt(e) {
  const t = new Array(9)
  return (
    (t[0] = _(e.chain_id)),
    (t[1] = _(e.nonce)),
    (t[2] = _(e.max_priority_fee_per_gas)),
    (t[3] = _(e.max_fee_per_gas)),
    (t[4] = _(e.gas_limit)),
    (t[5] = b(e.to)),
    (t[6] = _(e.value)),
    (t[7] = e.data),
    (t[8] = Ht([])),
    t
  )
}
function Z(e) {
  return _e(e)
}
const jt = { ETHEREUM: "eip155" },
  qt = "https://ethereum-sepolia-rpc.publicnode.com",
  we = me({ namespace: jt.ETHEREUM, reference: D.chainId }),
  Dt = pe([{ chainId: we, transports: [he(qt)] }])
function Kt() {
  return o("main", {
    className: "flex flex-col gap-2 p-2 text-base",
    children: [
      o("h1", {
        className: "text-center",
        children: "You are about to sign",
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Method" }),
          o("p", {
            className: "font-bold",
            children: w.value.method,
          }),
        ],
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Params" }),
          o("ul", {
            children: w.value.params.map((e, t) => {
              const n = u(d(), e),
                s = `param-${n}`
              return o(
                "li",
                {
                  className: "flex gap-2",
                  children: [
                    o("span", {
                      className: "w-2 text-center",
                      children: t,
                    }),
                    o("span", {
                      className: "font-bold",
                      children: n,
                    }),
                  ],
                },
                s,
              )
            }),
          }),
        ],
      }),
      o(q, {
        onClick: async () => {
          const e = N.value.address,
            t = N.value.key,
            n = await kt(e, Dt, we),
            s = await Ot({
              key: t,
              nonce: n,
              method: w.value.method,
              params: w.value.params,
            }),
            r = {
              id: w.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: le(s),
            }
          chrome.runtime.sendMessage(r)
        },
        children: "Sign",
      }),
    ],
  })
}
const Lt = { ETHEREUM: "eip155" },
  Gt = "https://ethereum-sepolia-rpc.publicnode.com",
  ve = me({ namespace: Lt.ETHEREUM, reference: D.chainId }),
  Wt = pe([{ chainId: ve, transports: [he(Gt)] }]),
  X = R(0n)
async function zt(e) {
  const t = wt([e, "latest"])
  console.log("readable", t)
  const n = await t(Wt(ve))
  return j(n)
}
function Qt(e) {
  const t = 10n ** 18n,
    n = e / t,
    s = e % t,
    r = n.toString()
  if (s === 0n) return r
  const a = s
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${r}.${a}`
}
function Vt() {
  const e = N.value.address
  return (
    ee(() => {
      async function t() {
        const n = await zt(e)
        X.value = n
      }
      t()
    }, []),
    o("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Address:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: e,
            }),
          ],
        }),
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Balance:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: Jt(Qt(X.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
      ],
    })
  )
}
function Jt(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function Yt() {
  return (
    ee(() => {
      chrome.runtime.sendMessage({
        type: "ETHERNAUTA_POPUP_READY",
      }),
        chrome.runtime.onMessage.addListener(async (e) => {
          const t = u(qe, e)
          switch (t.type) {
            case "ETHERNAUTA_REQUEST_CONNECT": {
              const n = await Q()
              if ((await V(), n)) {
                await Y(), (g.value = "wallet")
                return
              }
              break
            }
            case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
              {
                const n = await Q()
                if ((await V(), n)) {
                  await Y(),
                    (w.value = {
                      id: t.id,
                      method: t.method,
                      params: t.params,
                    }),
                    (g.value = "sign")
                  return
                }
              }
              break
          }
        })
    }, []),
    o(Ee, { children: Zt(g.value) })
  )
}
function Zt(e) {
  switch (e) {
    case "mnemonics":
      return o(Xe, {})
    case "password":
      return o(et, {})
    case "wallet":
      return o(Vt, {})
    case "sign":
      return o(Kt, {})
    default:
      return o("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Se(o(Yt, {}), document.querySelector("#app"))
