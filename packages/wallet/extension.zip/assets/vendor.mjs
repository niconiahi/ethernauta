var Ut
function $n(t) {
  return {
    lang: Ut?.lang,
    message: t?.message,
    abortEarly: Ut?.abortEarly,
    abortPipeEarly: Ut?.abortPipeEarly,
  }
}
var Zr
function Dr(t) {
  return Zr?.get(t)
}
var Mr
function Fr(t) {
  return Mr?.get(t)
}
var Yr
function Pr(t, e) {
  return Yr?.get(t)?.get(e)
}
function Wt(t) {
  const e = typeof t
  return e === "string"
    ? `"${t}"`
    : e === "number" || e === "bigint" || e === "boolean"
      ? `${t}`
      : e === "object" || e === "function"
        ? ((t &&
            Object.getPrototypeOf(t)?.constructor?.name) ??
          "null")
        : e
}
function C(t, e, n, r, s) {
  const i = s && "input" in s ? s.input : n.value,
    o = s?.expected ?? t.expects ?? null,
    c = s?.received ?? Wt(i),
    a = {
      kind: t.kind,
      type: t.type,
      input: i,
      expected: o,
      received: c,
      message: `Invalid ${e}: ${o ? `Expected ${o} but r` : "R"}eceived ${c}`,
      requirement: t.requirement,
      path: s?.path,
      issues: s?.issues,
      lang: r.lang,
      abortEarly: r.abortEarly,
      abortPipeEarly: r.abortPipeEarly,
    },
    u = t.kind === "schema",
    d =
      s?.message ??
      t.message ??
      Pr(t.reference, a.lang) ??
      (u ? Fr(a.lang) : null) ??
      r.message ??
      Dr(a.lang)
  d !== void 0 &&
    (a.message = typeof d == "function" ? d(a) : d),
    u && (n.typed = !1),
    n.issues ? n.issues.push(a) : (n.issues = [a])
}
function D(t) {
  return {
    version: 1,
    vendor: "valibot",
    validate(e) {
      return t["~run"]({ value: e }, $n())
    },
  }
}
function Gr(t, e) {
  return (
    Object.hasOwn(t, e) &&
    e !== "__proto__" &&
    e !== "prototype" &&
    e !== "constructor"
  )
}
function Jt(t, e) {
  const n = [...new Set(t)]
  return n.length > 1
    ? `(${n.join(` ${e} `)})`
    : (n[0] ?? "never")
}
var Xr = class extends Error {
    constructor(t) {
      super(t[0].message),
        (this.name = "ValiError"),
        (this.issues = t)
    }
  },
  Wr = /^(?:0[hx])?[\da-fA-F]+$/u
function Jr(t, e) {
  const n = Wt(t)
  return {
    kind: "validation",
    type: "excludes",
    reference: Jr,
    async: !1,
    expects: `!${n}`,
    requirement: t,
    message: e,
    "~run"(r, s) {
      return (
        r.typed &&
          r.value.includes(this.requirement) &&
          C(this, "content", r, s, { received: n }),
        r
      )
    },
  }
}
function Qr(t) {
  return {
    kind: "validation",
    type: "hexadecimal",
    reference: Qr,
    async: !1,
    expects: null,
    requirement: Wr,
    message: t,
    "~run"(e, n) {
      return (
        e.typed &&
          !this.requirement.test(e.value) &&
          C(this, "hexadecimal", e, n),
        e
      )
    },
  }
}
function es(t, e) {
  return {
    kind: "validation",
    type: "min_length",
    reference: es,
    async: !1,
    expects: `>=${t}`,
    requirement: t,
    message: e,
    "~run"(n, r) {
      return (
        n.typed &&
          n.value.length < this.requirement &&
          C(this, "length", n, r, {
            received: `${n.value.length}`,
          }),
        n
      )
    },
  }
}
function ts(t, e, n) {
  return typeof t.fallback == "function"
    ? t.fallback(e, n)
    : t.fallback
}
function Qt(t, e, n) {
  return typeof t.default == "function"
    ? t.default(e, n)
    : t.default
}
function ns(t, e) {
  return {
    kind: "schema",
    type: "array",
    reference: ns,
    expects: "Array",
    async: !1,
    item: t,
    message: e,
    get "~standard"() {
      return D(this)
    },
    "~run"(n, r) {
      const s = n.value
      if (Array.isArray(s)) {
        ;(n.typed = !0), (n.value = [])
        for (let i = 0; i < s.length; i++) {
          const o = s[i],
            c = this.item["~run"]({ value: o }, r)
          if (c.issues) {
            const a = {
              type: "array",
              origin: "value",
              input: s,
              key: i,
              value: o,
            }
            for (const u of c.issues)
              u.path ? u.path.unshift(a) : (u.path = [a]),
                n.issues?.push(u)
            if (
              (n.issues || (n.issues = c.issues),
              r.abortEarly)
            ) {
              n.typed = !1
              break
            }
          }
          c.typed || (n.typed = !1), n.value.push(c.value)
        }
      } else C(this, "type", n, r)
      return n
    },
  }
}
function rs(t) {
  return {
    kind: "schema",
    type: "boolean",
    reference: rs,
    expects: "boolean",
    async: !1,
    message: t,
    get "~standard"() {
      return D(this)
    },
    "~run"(e, n) {
      return (
        typeof e.value == "boolean"
          ? (e.typed = !0)
          : C(this, "type", e, n),
        e
      )
    },
  }
}
function ss(t, e) {
  return {
    kind: "schema",
    type: "custom",
    reference: ss,
    expects: "unknown",
    async: !1,
    check: t,
    message: e,
    get "~standard"() {
      return D(this)
    },
    "~run"(n, r) {
      return (
        this.check(n.value)
          ? (n.typed = !0)
          : C(this, "type", n, r),
        n
      )
    },
  }
}
function $t(t, e) {
  if (typeof t == typeof e) {
    if (
      t === e ||
      (t instanceof Date && e instanceof Date && +t == +e)
    )
      return { value: t }
    if (
      t &&
      e &&
      t.constructor === Object &&
      e.constructor === Object
    ) {
      for (const n in e)
        if (n in t) {
          const r = $t(t[n], e[n])
          if (r.issue) return r
          t[n] = r.value
        } else t[n] = e[n]
      return { value: t }
    }
    if (
      Array.isArray(t) &&
      Array.isArray(e) &&
      t.length === e.length
    ) {
      for (let n = 0; n < t.length; n++) {
        const r = $t(t[n], e[n])
        if (r.issue) return r
        t[n] = r.value
      }
      return { value: t }
    }
  }
  return { issue: !0 }
}
function is(t, e) {
  return {
    kind: "schema",
    type: "intersect",
    reference: is,
    expects: Jt(
      t.map((n) => n.expects),
      "&",
    ),
    async: !1,
    options: t,
    message: e,
    get "~standard"() {
      return D(this)
    },
    "~run"(n, r) {
      if (this.options.length) {
        const s = n.value
        let i
        n.typed = !0
        for (const o of this.options) {
          const c = o["~run"]({ value: s }, r)
          if (
            c.issues &&
            (n.issues
              ? n.issues.push(...c.issues)
              : (n.issues = c.issues),
            r.abortEarly)
          ) {
            n.typed = !1
            break
          }
          c.typed || (n.typed = !1),
            n.typed &&
              (i ? i.push(c.value) : (i = [c.value]))
        }
        if (n.typed) {
          n.value = i[0]
          for (let o = 1; o < i.length; o++) {
            const c = $t(n.value, i[o])
            if (c.issue) {
              C(this, "type", n, r, { received: "unknown" })
              break
            }
            n.value = c.value
          }
        }
      } else C(this, "type", n, r)
      return n
    },
  }
}
function os(t, e) {
  return {
    kind: "schema",
    type: "literal",
    reference: os,
    expects: Wt(t),
    async: !1,
    literal: t,
    message: e,
    get "~standard"() {
      return D(this)
    },
    "~run"(n, r) {
      return (
        n.value === this.literal
          ? (n.typed = !0)
          : C(this, "type", n, r),
        n
      )
    },
  }
}
function cs(t) {
  return {
    kind: "schema",
    type: "null",
    reference: cs,
    expects: "null",
    async: !1,
    message: t,
    get "~standard"() {
      return D(this)
    },
    "~run"(e, n) {
      return (
        e.value === null
          ? (e.typed = !0)
          : C(this, "type", e, n),
        e
      )
    },
  }
}
function as(t, e) {
  return {
    kind: "schema",
    type: "nullable",
    reference: as,
    expects: `(${t.expects} | null)`,
    async: !1,
    wrapped: t,
    default: e,
    get "~standard"() {
      return D(this)
    },
    "~run"(n, r) {
      return n.value === null &&
        (this.default !== void 0 &&
          (n.value = Qt(this, n, r)),
        n.value === null)
        ? ((n.typed = !0), n)
        : this.wrapped["~run"](n, r)
    },
  }
}
function ls(t) {
  return {
    kind: "schema",
    type: "number",
    reference: ls,
    expects: "number",
    async: !1,
    message: t,
    get "~standard"() {
      return D(this)
    },
    "~run"(e, n) {
      return (
        typeof e.value == "number" && !isNaN(e.value)
          ? (e.typed = !0)
          : C(this, "type", e, n),
        e
      )
    },
  }
}
function us(t, e) {
  return {
    kind: "schema",
    type: "object",
    reference: us,
    expects: "Object",
    async: !1,
    entries: t,
    message: e,
    get "~standard"() {
      return D(this)
    },
    "~run"(n, r) {
      const s = n.value
      if (s && typeof s == "object") {
        ;(n.typed = !0), (n.value = {})
        for (const i in this.entries) {
          const o = this.entries[i]
          if (
            i in s ||
            ((o.type === "exact_optional" ||
              o.type === "optional" ||
              o.type === "nullish") &&
              o.default !== void 0)
          ) {
            const c = i in s ? s[i] : Qt(o),
              a = o["~run"]({ value: c }, r)
            if (a.issues) {
              const u = {
                type: "object",
                origin: "value",
                input: s,
                key: i,
                value: c,
              }
              for (const d of a.issues)
                d.path ? d.path.unshift(u) : (d.path = [u]),
                  n.issues?.push(d)
              if (
                (n.issues || (n.issues = a.issues),
                r.abortEarly)
              ) {
                n.typed = !1
                break
              }
            }
            a.typed || (n.typed = !1),
              (n.value[i] = a.value)
          } else if (o.fallback !== void 0)
            n.value[i] = ts(o)
          else if (
            o.type !== "exact_optional" &&
            o.type !== "optional" &&
            o.type !== "nullish" &&
            (C(this, "key", n, r, {
              input: void 0,
              expected: `"${i}"`,
              path: [
                {
                  type: "object",
                  origin: "key",
                  input: s,
                  key: i,
                  value: s[i],
                },
              ],
            }),
            r.abortEarly)
          )
            break
        }
      } else C(this, "type", n, r)
      return n
    },
  }
}
function fs(t, e) {
  return {
    kind: "schema",
    type: "optional",
    reference: fs,
    expects: `(${t.expects} | undefined)`,
    async: !1,
    wrapped: t,
    default: e,
    get "~standard"() {
      return D(this)
    },
    "~run"(n, r) {
      return n.value === void 0 &&
        (this.default !== void 0 &&
          (n.value = Qt(this, n, r)),
        n.value === void 0)
        ? ((n.typed = !0), n)
        : this.wrapped["~run"](n, r)
    },
  }
}
function ds(t, e, n) {
  return {
    kind: "schema",
    type: "record",
    reference: ds,
    expects: "Object",
    async: !1,
    key: t,
    value: e,
    message: n,
    get "~standard"() {
      return D(this)
    },
    "~run"(r, s) {
      const i = r.value
      if (i && typeof i == "object") {
        ;(r.typed = !0), (r.value = {})
        for (const o in i)
          if (Gr(i, o)) {
            const c = i[o],
              a = this.key["~run"]({ value: o }, s)
            if (a.issues) {
              const d = {
                type: "object",
                origin: "key",
                input: i,
                key: o,
                value: c,
              }
              for (const h of a.issues)
                (h.path = [d]), r.issues?.push(h)
              if (
                (r.issues || (r.issues = a.issues),
                s.abortEarly)
              ) {
                r.typed = !1
                break
              }
            }
            const u = this.value["~run"]({ value: c }, s)
            if (u.issues) {
              const d = {
                type: "object",
                origin: "value",
                input: i,
                key: o,
                value: c,
              }
              for (const h of u.issues)
                h.path ? h.path.unshift(d) : (h.path = [d]),
                  r.issues?.push(h)
              if (
                (r.issues || (r.issues = u.issues),
                s.abortEarly)
              ) {
                r.typed = !1
                break
              }
            }
            ;(!a.typed || !u.typed) && (r.typed = !1),
              a.typed && (r.value[a.value] = u.value)
          }
      } else C(this, "type", r, s)
      return r
    },
  }
}
function hs(t) {
  return {
    kind: "schema",
    type: "string",
    reference: hs,
    expects: "string",
    async: !1,
    message: t,
    get "~standard"() {
      return D(this)
    },
    "~run"(e, n) {
      return (
        typeof e.value == "string"
          ? (e.typed = !0)
          : C(this, "type", e, n),
        e
      )
    },
  }
}
function ps(t, e) {
  return {
    kind: "schema",
    type: "tuple",
    reference: ps,
    expects: "Array",
    async: !1,
    items: t,
    message: e,
    get "~standard"() {
      return D(this)
    },
    "~run"(n, r) {
      const s = n.value
      if (Array.isArray(s)) {
        ;(n.typed = !0), (n.value = [])
        for (let i = 0; i < this.items.length; i++) {
          const o = s[i],
            c = this.items[i]["~run"]({ value: o }, r)
          if (c.issues) {
            const a = {
              type: "array",
              origin: "value",
              input: s,
              key: i,
              value: o,
            }
            for (const u of c.issues)
              u.path ? u.path.unshift(a) : (u.path = [a]),
                n.issues?.push(u)
            if (
              (n.issues || (n.issues = c.issues),
              r.abortEarly)
            ) {
              n.typed = !1
              break
            }
          }
          c.typed || (n.typed = !1), n.value.push(c.value)
        }
      } else C(this, "type", n, r)
      return n
    },
  }
}
function bn(t) {
  let e
  if (t)
    for (const n of t)
      e ? e.push(...n.issues) : (e = n.issues)
  return e
}
function ys(t, e) {
  return {
    kind: "schema",
    type: "union",
    reference: ys,
    expects: Jt(
      t.map((n) => n.expects),
      "|",
    ),
    async: !1,
    options: t,
    message: e,
    get "~standard"() {
      return D(this)
    },
    "~run"(n, r) {
      let s, i, o
      for (const c of this.options) {
        const a = c["~run"]({ value: n.value }, r)
        if (a.typed)
          if (a.issues) i ? i.push(a) : (i = [a])
          else {
            s = a
            break
          }
        else o ? o.push(a) : (o = [a])
      }
      if (s) return s
      if (i) {
        if (i.length === 1) return i[0]
        C(this, "type", n, r, { issues: bn(i) }),
          (n.typed = !0)
      } else {
        if (o?.length === 1) return o[0]
        C(this, "type", n, r, { issues: bn(o) })
      }
      return n
    },
  }
}
function bs() {
  return {
    kind: "schema",
    type: "unknown",
    reference: bs,
    expects: "unknown",
    async: !1,
    get "~standard"() {
      return D(this)
    },
    "~run"(t) {
      return (t.typed = !0), t
    },
  }
}
function gs(t, e, n) {
  return {
    kind: "schema",
    type: "variant",
    reference: gs,
    expects: "Object",
    async: !1,
    key: t,
    options: e,
    message: n,
    get "~standard"() {
      return D(this)
    },
    "~run"(r, s) {
      const i = r.value
      if (i && typeof i == "object") {
        let o,
          c = 0,
          a = this.key,
          u = []
        const d = (h, l) => {
          for (const f of h.options) {
            if (f.type === "variant")
              d(f, new Set(l).add(f.key))
            else {
              let y = !0,
                m = 0
              for (const v of l) {
                const A = f.entries[v]
                if (
                  v in i
                    ? A["~run"](
                        { typed: !1, value: i[v] },
                        { abortEarly: !0 },
                      ).issues
                    : A.type !== "exact_optional" &&
                      A.type !== "optional" &&
                      A.type !== "nullish"
                ) {
                  ;(y = !1),
                    a !== v &&
                      (c < m ||
                        (c === m && v in i && !(a in i))) &&
                      ((c = m), (a = v), (u = [])),
                    a === v && u.push(f.entries[v].expects)
                  break
                }
                m++
              }
              if (y) {
                const v = f["~run"]({ value: i }, s)
                ;(!o || (!o.typed && v.typed)) && (o = v)
              }
            }
            if (o && !o.issues) break
          }
        }
        if ((d(this, new Set([this.key])), o)) return o
        C(this, "type", r, s, {
          input: i[a],
          expected: Jt(u, "|"),
          path: [
            {
              type: "object",
              origin: "value",
              input: i,
              key: a,
              value: i[a],
            },
          ],
        })
      } else C(this, "type", r, s)
      return r
    },
  }
}
function xo(t, e, n) {
  const r = t["~run"]({ value: e }, $n(n))
  if (r.issues) throw new Xr(r.issues)
  return r.value
}
function Eo(...t) {
  return {
    ...t[0],
    pipe: t,
    get "~standard"() {
      return D(this)
    },
    "~run"(e, n) {
      for (const r of t)
        if (r.kind !== "metadata") {
          if (
            e.issues &&
            (r.kind === "schema" ||
              r.kind === "transformation")
          ) {
            e.typed = !1
            break
          }
          ;(!e.issues ||
            (!n.abortEarly && !n.abortPipeEarly)) &&
            (e = r["~run"](e, n))
        }
      return e
    },
  }
}
const qe =
  typeof globalThis == "object" && "crypto" in globalThis
    ? globalThis.crypto
    : void 0 /*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
function Et(t) {
  return (
    t instanceof Uint8Array ||
    (ArrayBuffer.isView(t) &&
      t.constructor.name === "Uint8Array")
  )
}
function Ee(t) {
  if (!Number.isSafeInteger(t) || t < 0)
    throw new Error("positive integer expected, got " + t)
}
function Z(t, ...e) {
  if (!Et(t)) throw new Error("Uint8Array expected")
  if (e.length > 0 && !e.includes(t.length))
    throw new Error(
      "Uint8Array expected of length " +
        e +
        ", got length=" +
        t.length,
    )
}
function en(t) {
  if (
    typeof t != "function" ||
    typeof t.create != "function"
  )
    throw new Error(
      "Hash should be wrapped by utils.createHasher",
    )
  Ee(t.outputLen), Ee(t.blockLen)
}
function Ze(t, e = !0) {
  if (t.destroyed)
    throw new Error("Hash instance has been destroyed")
  if (e && t.finished)
    throw new Error("Hash#digest() has already been called")
}
function zn(t, e) {
  Z(t)
  const n = e.outputLen
  if (t.length < n)
    throw new Error(
      "digestInto() expects output buffer of length at least " +
        n,
    )
}
function ms(t) {
  return new Uint32Array(
    t.buffer,
    t.byteOffset,
    Math.floor(t.byteLength / 4),
  )
}
function ie(...t) {
  for (let e = 0; e < t.length; e++) t[e].fill(0)
}
function _e(t) {
  return new DataView(t.buffer, t.byteOffset, t.byteLength)
}
function oe(t, e) {
  return (t << (32 - e)) | (t >>> e)
}
function nt(t, e) {
  return (t << e) | ((t >>> (32 - e)) >>> 0)
}
const ws =
  new Uint8Array(new Uint32Array([287454020]).buffer)[0] ===
  68
function vs(t) {
  return (
    ((t << 24) & 4278190080) |
    ((t << 8) & 16711680) |
    ((t >>> 8) & 65280) |
    ((t >>> 24) & 255)
  )
}
function xs(t) {
  for (let e = 0; e < t.length; e++) t[e] = vs(t[e])
  return t
}
const gn = ws ? (t) => t : xs,
  Vn =
    typeof Uint8Array.from([]).toHex == "function" &&
    typeof Uint8Array.fromHex == "function",
  Es = Array.from({ length: 256 }, (t, e) =>
    e.toString(16).padStart(2, "0"),
  )
function Ue(t) {
  if ((Z(t), Vn)) return t.toHex()
  let e = ""
  for (let n = 0; n < t.length; n++) e += Es[t[n]]
  return e
}
const ae = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 }
function mn(t) {
  if (t >= ae._0 && t <= ae._9) return t - ae._0
  if (t >= ae.A && t <= ae.F) return t - (ae.A - 10)
  if (t >= ae.a && t <= ae.f) return t - (ae.a - 10)
}
function Ge(t) {
  if (typeof t != "string")
    throw new Error("hex string expected, got " + typeof t)
  if (Vn) return Uint8Array.fromHex(t)
  const e = t.length,
    n = e / 2
  if (e % 2)
    throw new Error(
      "hex string expected, got unpadded hex of length " +
        e,
    )
  const r = new Uint8Array(n)
  for (let s = 0, i = 0; s < n; s++, i += 2) {
    const o = mn(t.charCodeAt(i)),
      c = mn(t.charCodeAt(i + 1))
    if (o === void 0 || c === void 0) {
      const a = t[i] + t[i + 1]
      throw new Error(
        'hex string expected, got non-hex character "' +
          a +
          '" at index ' +
          i,
      )
    }
    r[s] = o * 16 + c
  }
  return r
}
function tn(t) {
  if (typeof t != "string")
    throw new Error("string expected")
  return new Uint8Array(new TextEncoder().encode(t))
}
function kt(t) {
  return typeof t == "string" && (t = tn(t)), Z(t), t
}
function wn(t) {
  return typeof t == "string" && (t = tn(t)), Z(t), t
}
function ne(...t) {
  let e = 0
  for (let r = 0; r < t.length; r++) {
    const s = t[r]
    Z(s), (e += s.length)
  }
  const n = new Uint8Array(e)
  for (let r = 0, s = 0; r < t.length; r++) {
    const i = t[r]
    n.set(i, s), (s += i.length)
  }
  return n
}
function ks(t, e) {
  if (
    e !== void 0 &&
    {}.toString.call(e) !== "[object Object]"
  )
    throw new Error("options should be object or undefined")
  return Object.assign(t, e)
}
class nn {}
function Bt(t) {
  const e = (r) => t().update(kt(r)).digest(),
    n = t()
  return (
    (e.outputLen = n.outputLen),
    (e.blockLen = n.blockLen),
    (e.create = () => t()),
    e
  )
}
function Zn(t = 32) {
  if (qe && typeof qe.getRandomValues == "function")
    return qe.getRandomValues(new Uint8Array(t))
  if (qe && typeof qe.randomBytes == "function")
    return Uint8Array.from(qe.randomBytes(t))
  throw new Error("crypto.getRandomValues must be defined")
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const rn = BigInt(0),
  zt = BigInt(1)
function dt(t, e = "") {
  if (typeof t != "boolean") {
    const n = e && `"${e}"`
    throw new Error(
      n + "expected boolean, got type=" + typeof t,
    )
  }
  return t
}
function Ae(t, e, n = "") {
  const r = Et(t),
    s = t?.length,
    i = e !== void 0
  if (!r || (i && s !== e)) {
    const o = n && `"${n}" `,
      c = i ? ` of length ${e}` : "",
      a = r ? `length=${s}` : `type=${typeof t}`
    throw new Error(
      o + "expected Uint8Array" + c + ", got " + a,
    )
  }
  return t
}
function rt(t) {
  const e = t.toString(16)
  return e.length & 1 ? "0" + e : e
}
function Dn(t) {
  if (typeof t != "string")
    throw new Error("hex string expected, got " + typeof t)
  return t === "" ? rn : BigInt("0x" + t)
}
function At(t) {
  return Dn(Ue(t))
}
function Mn(t) {
  return Z(t), Dn(Ue(Uint8Array.from(t).reverse()))
}
function sn(t, e) {
  return Ge(t.toString(16).padStart(e * 2, "0"))
}
function Fn(t, e) {
  return sn(t, e).reverse()
}
function W(t, e, n) {
  let r
  if (typeof e == "string")
    try {
      r = Ge(e)
    } catch (s) {
      throw new Error(
        t +
          " must be hex string or Uint8Array, cause: " +
          s,
      )
    }
  else if (Et(e)) r = Uint8Array.from(e)
  else
    throw new Error(t + " must be hex string or Uint8Array")
  return r.length, r
}
const Ht = (t) => typeof t == "bigint" && rn <= t
function Bs(t, e, n) {
  return Ht(t) && Ht(e) && Ht(n) && e <= t && t < n
}
function As(t, e, n, r) {
  if (!Bs(e, n, r))
    throw new Error(
      "expected valid " +
        t +
        ": " +
        n +
        " <= n < " +
        r +
        ", got " +
        e,
    )
}
function Yn(t) {
  let e
  for (e = 0; t > rn; t >>= zt, e += 1);
  return e
}
const We = (t) => (zt << BigInt(t)) - zt
function Ss(t, e, n) {
  if (typeof t != "number" || t < 2)
    throw new Error("hashLen must be a number")
  if (typeof e != "number" || e < 2)
    throw new Error("qByteLen must be a number")
  if (typeof n != "function")
    throw new Error("hmacFn must be a function")
  const r = (f) => new Uint8Array(f),
    s = (f) => Uint8Array.of(f)
  let i = r(t),
    o = r(t),
    c = 0
  const a = () => {
      i.fill(1), o.fill(0), (c = 0)
    },
    u = (...f) => n(o, i, ...f),
    d = (f = r(0)) => {
      ;(o = u(s(0), f)),
        (i = u()),
        f.length !== 0 && ((o = u(s(1), f)), (i = u()))
    },
    h = () => {
      if (c++ >= 1e3)
        throw new Error("drbg: tried 1000 values")
      let f = 0
      const y = []
      for (; f < e; ) {
        i = u()
        const m = i.slice()
        y.push(m), (f += i.length)
      }
      return ne(...y)
    }
  return (f, y) => {
    a(), d(f)
    let m
    for (; !(m = y(h())); ) d()
    return a(), m
  }
}
function on(t, e, n = {}) {
  if (!t || typeof t != "object")
    throw new Error("expected valid options object")
  function r(s, i, o) {
    const c = t[s]
    if (o && c === void 0) return
    const a = typeof c
    if (a !== i || c === null)
      throw new Error(
        `param "${s}" is invalid: expected ${i}, got ${a}`,
      )
  }
  Object.entries(e).forEach(([s, i]) => r(s, i, !1)),
    Object.entries(n).forEach(([s, i]) => r(s, i, !0))
}
function vn(t) {
  const e = new WeakMap()
  return (n, ...r) => {
    const s = e.get(n)
    if (s !== void 0) return s
    const i = t(n, ...r)
    return e.set(n, i), i
  }
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const J = BigInt(0),
  P = BigInt(1),
  Se = BigInt(2),
  Pn = BigInt(3),
  Gn = BigInt(4),
  Xn = BigInt(5),
  Is = BigInt(7),
  Wn = BigInt(8),
  _s = BigInt(9),
  Jn = BigInt(16)
function te(t, e) {
  const n = t % e
  return n >= J ? n : e + n
}
function ee(t, e, n) {
  let r = t
  for (; e-- > J; ) (r *= r), (r %= n)
  return r
}
function xn(t, e) {
  if (t === J)
    throw new Error("invert: expected non-zero number")
  if (e <= J)
    throw new Error(
      "invert: expected positive modulus, got " + e,
    )
  let n = te(t, e),
    r = e,
    s = J,
    i = P
  for (; n !== J; ) {
    const c = r / n,
      a = r % n,
      u = s - i * c
    ;(r = n), (n = a), (s = i), (i = u)
  }
  if (r !== P) throw new Error("invert: does not exist")
  return te(s, e)
}
function cn(t, e, n) {
  if (!t.eql(t.sqr(e), n))
    throw new Error("Cannot find square root")
}
function Qn(t, e) {
  const n = (t.ORDER + P) / Gn,
    r = t.pow(e, n)
  return cn(t, r, e), r
}
function Us(t, e) {
  const n = (t.ORDER - Xn) / Wn,
    r = t.mul(e, Se),
    s = t.pow(r, n),
    i = t.mul(e, s),
    o = t.mul(t.mul(i, Se), s),
    c = t.mul(i, t.sub(o, t.ONE))
  return cn(t, c, e), c
}
function Hs(t) {
  const e = Je(t),
    n = er(t),
    r = n(e, e.neg(e.ONE)),
    s = n(e, r),
    i = n(e, e.neg(r)),
    o = (t + Is) / Jn
  return (c, a) => {
    let u = c.pow(a, o),
      d = c.mul(u, r)
    const h = c.mul(u, s),
      l = c.mul(u, i),
      f = c.eql(c.sqr(d), a),
      y = c.eql(c.sqr(h), a)
    ;(u = c.cmov(u, d, f)), (d = c.cmov(l, h, y))
    const m = c.eql(c.sqr(d), a),
      v = c.cmov(u, d, m)
    return cn(c, v, a), v
  }
}
function er(t) {
  if (t < Pn)
    throw new Error("sqrt is not defined for small field")
  let e = t - P,
    n = 0
  for (; e % Se === J; ) (e /= Se), n++
  let r = Se
  const s = Je(t)
  for (; En(s, r) === 1; )
    if (r++ > 1e3)
      throw new Error(
        "Cannot find square root: probably non-prime P",
      )
  if (n === 1) return Qn
  let i = s.pow(r, e)
  const o = (e + P) / Se
  return function (a, u) {
    if (a.is0(u)) return u
    if (En(a, u) !== 1)
      throw new Error("Cannot find square root")
    let d = n,
      h = a.mul(a.ONE, i),
      l = a.pow(u, e),
      f = a.pow(u, o)
    for (; !a.eql(l, a.ONE); ) {
      if (a.is0(l)) return a.ZERO
      let y = 1,
        m = a.sqr(l)
      for (; !a.eql(m, a.ONE); )
        if ((y++, (m = a.sqr(m)), y === d))
          throw new Error("Cannot find square root")
      const v = P << BigInt(d - y - 1),
        A = a.pow(h, v)
      ;(d = y),
        (h = a.sqr(A)),
        (l = a.mul(l, h)),
        (f = a.mul(f, A))
    }
    return f
  }
}
function Os(t) {
  return t % Gn === Pn
    ? Qn
    : t % Wn === Xn
      ? Us
      : t % Jn === _s
        ? Hs(t)
        : er(t)
}
const Ks = [
  "create",
  "isValid",
  "is0",
  "neg",
  "inv",
  "sqrt",
  "sqr",
  "eql",
  "add",
  "sub",
  "mul",
  "pow",
  "div",
  "addN",
  "subN",
  "mulN",
  "sqrN",
]
function Rs(t) {
  const e = {
      ORDER: "bigint",
      MASK: "bigint",
      BYTES: "number",
      BITS: "number",
    },
    n = Ks.reduce((r, s) => ((r[s] = "function"), r), e)
  return on(t, n), t
}
function Ns(t, e, n) {
  if (n < J)
    throw new Error(
      "invalid exponent, negatives unsupported",
    )
  if (n === J) return t.ONE
  if (n === P) return e
  let r = t.ONE,
    s = e
  for (; n > J; )
    n & P && (r = t.mul(r, s)), (s = t.sqr(s)), (n >>= P)
  return r
}
function tr(t, e, n = !1) {
  const r = new Array(e.length).fill(n ? t.ZERO : void 0),
    s = e.reduce(
      (o, c, a) =>
        t.is0(c) ? o : ((r[a] = o), t.mul(o, c)),
      t.ONE,
    ),
    i = t.inv(s)
  return (
    e.reduceRight(
      (o, c, a) =>
        t.is0(c)
          ? o
          : ((r[a] = t.mul(o, r[a])), t.mul(o, c)),
      i,
    ),
    r
  )
}
function En(t, e) {
  const n = (t.ORDER - P) / Se,
    r = t.pow(e, n),
    s = t.eql(r, t.ONE),
    i = t.eql(r, t.ZERO),
    o = t.eql(r, t.neg(t.ONE))
  if (!s && !i && !o)
    throw new Error("invalid Legendre symbol result")
  return s ? 1 : i ? 0 : -1
}
function nr(t, e) {
  e !== void 0 && Ee(e)
  const n = e !== void 0 ? e : t.toString(2).length,
    r = Math.ceil(n / 8)
  return { nBitLength: n, nByteLength: r }
}
function Je(t, e, n = !1, r = {}) {
  if (t <= J)
    throw new Error(
      "invalid field: expected ORDER > 0, got " + t,
    )
  let s,
    i,
    o = !1,
    c
  if (typeof e == "object" && e != null) {
    if (r.sqrt || n)
      throw new Error(
        "cannot specify opts in two arguments",
      )
    const l = e
    l.BITS && (s = l.BITS),
      l.sqrt && (i = l.sqrt),
      typeof l.isLE == "boolean" && (n = l.isLE),
      typeof l.modFromBytes == "boolean" &&
        (o = l.modFromBytes),
      (c = l.allowedLengths)
  } else
    typeof e == "number" && (s = e), r.sqrt && (i = r.sqrt)
  const { nBitLength: a, nByteLength: u } = nr(t, s)
  if (u > 2048)
    throw new Error(
      "invalid field: expected ORDER of <= 2048 bytes",
    )
  let d
  const h = Object.freeze({
    ORDER: t,
    isLE: n,
    BITS: a,
    BYTES: u,
    MASK: We(a),
    ZERO: J,
    ONE: P,
    allowedLengths: c,
    create: (l) => te(l, t),
    isValid: (l) => {
      if (typeof l != "bigint")
        throw new Error(
          "invalid field element: expected bigint, got " +
            typeof l,
        )
      return J <= l && l < t
    },
    is0: (l) => l === J,
    isValidNot0: (l) => !h.is0(l) && h.isValid(l),
    isOdd: (l) => (l & P) === P,
    neg: (l) => te(-l, t),
    eql: (l, f) => l === f,
    sqr: (l) => te(l * l, t),
    add: (l, f) => te(l + f, t),
    sub: (l, f) => te(l - f, t),
    mul: (l, f) => te(l * f, t),
    pow: (l, f) => Ns(h, l, f),
    div: (l, f) => te(l * xn(f, t), t),
    sqrN: (l) => l * l,
    addN: (l, f) => l + f,
    subN: (l, f) => l - f,
    mulN: (l, f) => l * f,
    inv: (l) => xn(l, t),
    sqrt: i || ((l) => (d || (d = Os(t)), d(h, l))),
    toBytes: (l) => (n ? Fn(l, u) : sn(l, u)),
    fromBytes: (l, f = !0) => {
      if (c) {
        if (!c.includes(l.length) || l.length > u)
          throw new Error(
            "Field.fromBytes: expected " +
              c +
              " bytes, got " +
              l.length,
          )
        const m = new Uint8Array(u)
        m.set(l, n ? 0 : m.length - l.length), (l = m)
      }
      if (l.length !== u)
        throw new Error(
          "Field.fromBytes: expected " +
            u +
            " bytes, got " +
            l.length,
        )
      let y = n ? Mn(l) : At(l)
      if ((o && (y = te(y, t)), !f && !h.isValid(y)))
        throw new Error(
          "invalid field element: outside of range 0..ORDER",
        )
      return y
    },
    invertBatch: (l) => tr(h, l),
    cmov: (l, f, y) => (y ? f : l),
  })
  return Object.freeze(h)
}
function rr(t) {
  if (typeof t != "bigint")
    throw new Error("field order must be bigint")
  const e = t.toString(2).length
  return Math.ceil(e / 8)
}
function sr(t) {
  const e = rr(t)
  return e + Math.ceil(e / 2)
}
function qs(t, e, n = !1) {
  const r = t.length,
    s = rr(e),
    i = sr(e)
  if (r < 16 || r < i || r > 1024)
    throw new Error(
      "expected " + i + "-1024 bytes of input, got " + r,
    )
  const o = n ? Mn(t) : At(t),
    c = te(o, e - P) + P
  return n ? Fn(c, s) : sn(c, s)
}
function js(t, e, n, r) {
  if (typeof t.setBigUint64 == "function")
    return t.setBigUint64(e, n, r)
  const s = BigInt(32),
    i = BigInt(4294967295),
    o = Number((n >> s) & i),
    c = Number(n & i),
    a = r ? 4 : 0,
    u = r ? 0 : 4
  t.setUint32(e + a, o, r), t.setUint32(e + u, c, r)
}
function Ls(t, e, n) {
  return (t & e) ^ (~t & n)
}
function Cs(t, e, n) {
  return (t & e) ^ (t & n) ^ (e & n)
}
class an extends nn {
  constructor(e, n, r, s) {
    super(),
      (this.finished = !1),
      (this.length = 0),
      (this.pos = 0),
      (this.destroyed = !1),
      (this.blockLen = e),
      (this.outputLen = n),
      (this.padOffset = r),
      (this.isLE = s),
      (this.buffer = new Uint8Array(e)),
      (this.view = _e(this.buffer))
  }
  update(e) {
    Ze(this), (e = kt(e)), Z(e)
    const { view: n, buffer: r, blockLen: s } = this,
      i = e.length
    for (let o = 0; o < i; ) {
      const c = Math.min(s - this.pos, i - o)
      if (c === s) {
        const a = _e(e)
        for (; s <= i - o; o += s) this.process(a, o)
        continue
      }
      r.set(e.subarray(o, o + c), this.pos),
        (this.pos += c),
        (o += c),
        this.pos === s &&
          (this.process(n, 0), (this.pos = 0))
    }
    return (
      (this.length += e.length), this.roundClean(), this
    )
  }
  digestInto(e) {
    Ze(this), zn(e, this), (this.finished = !0)
    const {
      buffer: n,
      view: r,
      blockLen: s,
      isLE: i,
    } = this
    let { pos: o } = this
    ;(n[o++] = 128),
      ie(this.buffer.subarray(o)),
      this.padOffset > s - o &&
        (this.process(r, 0), (o = 0))
    for (let h = o; h < s; h++) n[h] = 0
    js(r, s - 8, BigInt(this.length * 8), i),
      this.process(r, 0)
    const c = _e(e),
      a = this.outputLen
    if (a % 4)
      throw new Error(
        "_sha2: outputLen should be aligned to 32bit",
      )
    const u = a / 4,
      d = this.get()
    if (u > d.length)
      throw new Error("_sha2: outputLen bigger than state")
    for (let h = 0; h < u; h++) c.setUint32(4 * h, d[h], i)
  }
  digest() {
    const { buffer: e, outputLen: n } = this
    this.digestInto(e)
    const r = e.slice(0, n)
    return this.destroy(), r
  }
  _cloneInto(e) {
    e || (e = new this.constructor()), e.set(...this.get())
    const {
      blockLen: n,
      buffer: r,
      length: s,
      finished: i,
      destroyed: o,
      pos: c,
    } = this
    return (
      (e.destroyed = o),
      (e.finished = i),
      (e.length = s),
      (e.pos = c),
      s % n && e.buffer.set(r),
      e
    )
  }
  clone() {
    return this._cloneInto()
  }
}
const me = Uint32Array.from([
    1779033703, 3144134277, 1013904242, 2773480762,
    1359893119, 2600822924, 528734635, 1541459225,
  ]),
  Y = Uint32Array.from([
    1779033703, 4089235720, 3144134277, 2227873595,
    1013904242, 4271175723, 2773480762, 1595750129,
    1359893119, 2917565137, 2600822924, 725511199,
    528734635, 4215389547, 1541459225, 327033209,
  ]),
  st = BigInt(2 ** 32 - 1),
  kn = BigInt(32)
function Ts(t, e = !1) {
  return e
    ? { h: Number(t & st), l: Number((t >> kn) & st) }
    : {
        h: Number((t >> kn) & st) | 0,
        l: Number(t & st) | 0,
      }
}
function ir(t, e = !1) {
  const n = t.length
  let r = new Uint32Array(n),
    s = new Uint32Array(n)
  for (let i = 0; i < n; i++) {
    const { h: o, l: c } = Ts(t[i], e)
    ;[r[i], s[i]] = [o, c]
  }
  return [r, s]
}
const Bn = (t, e, n) => t >>> n,
  An = (t, e, n) => (t << (32 - n)) | (e >>> n),
  je = (t, e, n) => (t >>> n) | (e << (32 - n)),
  Le = (t, e, n) => (t << (32 - n)) | (e >>> n),
  it = (t, e, n) => (t << (64 - n)) | (e >>> (n - 32)),
  ot = (t, e, n) => (t >>> (n - 32)) | (e << (64 - n)),
  $s = (t, e, n) => (t << n) | (e >>> (32 - n)),
  zs = (t, e, n) => (e << n) | (t >>> (32 - n)),
  Vs = (t, e, n) => (e << (n - 32)) | (t >>> (64 - n)),
  Zs = (t, e, n) => (t << (n - 32)) | (e >>> (64 - n))
function le(t, e, n, r) {
  const s = (e >>> 0) + (r >>> 0)
  return { h: (t + n + ((s / 2 ** 32) | 0)) | 0, l: s | 0 }
}
const Ds = (t, e, n) => (t >>> 0) + (e >>> 0) + (n >>> 0),
  Ms = (t, e, n, r) =>
    (e + n + r + ((t / 2 ** 32) | 0)) | 0,
  Fs = (t, e, n, r) =>
    (t >>> 0) + (e >>> 0) + (n >>> 0) + (r >>> 0),
  Ys = (t, e, n, r, s) =>
    (e + n + r + s + ((t / 2 ** 32) | 0)) | 0,
  Ps = (t, e, n, r, s) =>
    (t >>> 0) +
    (e >>> 0) +
    (n >>> 0) +
    (r >>> 0) +
    (s >>> 0),
  Gs = (t, e, n, r, s, i) =>
    (e + n + r + s + i + ((t / 2 ** 32) | 0)) | 0,
  Xs = Uint32Array.from([
    1116352408, 1899447441, 3049323471, 3921009573,
    961987163, 1508970993, 2453635748, 2870763221,
    3624381080, 310598401, 607225278, 1426881987,
    1925078388, 2162078206, 2614888103, 3248222580,
    3835390401, 4022224774, 264347078, 604807628, 770255983,
    1249150122, 1555081692, 1996064986, 2554220882,
    2821834349, 2952996808, 3210313671, 3336571891,
    3584528711, 113926993, 338241895, 666307205, 773529912,
    1294757372, 1396182291, 1695183700, 1986661051,
    2177026350, 2456956037, 2730485921, 2820302411,
    3259730800, 3345764771, 3516065817, 3600352804,
    4094571909, 275423344, 430227734, 506948616, 659060556,
    883997877, 958139571, 1322822218, 1537002063,
    1747873779, 1955562222, 2024104815, 2227730452,
    2361852424, 2428436474, 2756734187, 3204031479,
    3329325298,
  ]),
  we = new Uint32Array(64)
class Ws extends an {
  constructor(e = 32) {
    super(64, e, 8, !1),
      (this.A = me[0] | 0),
      (this.B = me[1] | 0),
      (this.C = me[2] | 0),
      (this.D = me[3] | 0),
      (this.E = me[4] | 0),
      (this.F = me[5] | 0),
      (this.G = me[6] | 0),
      (this.H = me[7] | 0)
  }
  get() {
    const {
      A: e,
      B: n,
      C: r,
      D: s,
      E: i,
      F: o,
      G: c,
      H: a,
    } = this
    return [e, n, r, s, i, o, c, a]
  }
  set(e, n, r, s, i, o, c, a) {
    ;(this.A = e | 0),
      (this.B = n | 0),
      (this.C = r | 0),
      (this.D = s | 0),
      (this.E = i | 0),
      (this.F = o | 0),
      (this.G = c | 0),
      (this.H = a | 0)
  }
  process(e, n) {
    for (let h = 0; h < 16; h++, n += 4)
      we[h] = e.getUint32(n, !1)
    for (let h = 16; h < 64; h++) {
      const l = we[h - 15],
        f = we[h - 2],
        y = oe(l, 7) ^ oe(l, 18) ^ (l >>> 3),
        m = oe(f, 17) ^ oe(f, 19) ^ (f >>> 10)
      we[h] = (m + we[h - 7] + y + we[h - 16]) | 0
    }
    let {
      A: r,
      B: s,
      C: i,
      D: o,
      E: c,
      F: a,
      G: u,
      H: d,
    } = this
    for (let h = 0; h < 64; h++) {
      const l = oe(c, 6) ^ oe(c, 11) ^ oe(c, 25),
        f = (d + l + Ls(c, a, u) + Xs[h] + we[h]) | 0,
        m =
          ((oe(r, 2) ^ oe(r, 13) ^ oe(r, 22)) +
            Cs(r, s, i)) |
          0
      ;(d = u),
        (u = a),
        (a = c),
        (c = (o + f) | 0),
        (o = i),
        (i = s),
        (s = r),
        (r = (f + m) | 0)
    }
    ;(r = (r + this.A) | 0),
      (s = (s + this.B) | 0),
      (i = (i + this.C) | 0),
      (o = (o + this.D) | 0),
      (c = (c + this.E) | 0),
      (a = (a + this.F) | 0),
      (u = (u + this.G) | 0),
      (d = (d + this.H) | 0),
      this.set(r, s, i, o, c, a, u, d)
  }
  roundClean() {
    ie(we)
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0), ie(this.buffer)
  }
}
const or = ir(
    [
      "0x428a2f98d728ae22",
      "0x7137449123ef65cd",
      "0xb5c0fbcfec4d3b2f",
      "0xe9b5dba58189dbbc",
      "0x3956c25bf348b538",
      "0x59f111f1b605d019",
      "0x923f82a4af194f9b",
      "0xab1c5ed5da6d8118",
      "0xd807aa98a3030242",
      "0x12835b0145706fbe",
      "0x243185be4ee4b28c",
      "0x550c7dc3d5ffb4e2",
      "0x72be5d74f27b896f",
      "0x80deb1fe3b1696b1",
      "0x9bdc06a725c71235",
      "0xc19bf174cf692694",
      "0xe49b69c19ef14ad2",
      "0xefbe4786384f25e3",
      "0x0fc19dc68b8cd5b5",
      "0x240ca1cc77ac9c65",
      "0x2de92c6f592b0275",
      "0x4a7484aa6ea6e483",
      "0x5cb0a9dcbd41fbd4",
      "0x76f988da831153b5",
      "0x983e5152ee66dfab",
      "0xa831c66d2db43210",
      "0xb00327c898fb213f",
      "0xbf597fc7beef0ee4",
      "0xc6e00bf33da88fc2",
      "0xd5a79147930aa725",
      "0x06ca6351e003826f",
      "0x142929670a0e6e70",
      "0x27b70a8546d22ffc",
      "0x2e1b21385c26c926",
      "0x4d2c6dfc5ac42aed",
      "0x53380d139d95b3df",
      "0x650a73548baf63de",
      "0x766a0abb3c77b2a8",
      "0x81c2c92e47edaee6",
      "0x92722c851482353b",
      "0xa2bfe8a14cf10364",
      "0xa81a664bbc423001",
      "0xc24b8b70d0f89791",
      "0xc76c51a30654be30",
      "0xd192e819d6ef5218",
      "0xd69906245565a910",
      "0xf40e35855771202a",
      "0x106aa07032bbd1b8",
      "0x19a4c116b8d2d0c8",
      "0x1e376c085141ab53",
      "0x2748774cdf8eeb99",
      "0x34b0bcb5e19b48a8",
      "0x391c0cb3c5c95a63",
      "0x4ed8aa4ae3418acb",
      "0x5b9cca4f7763e373",
      "0x682e6ff3d6b2b8a3",
      "0x748f82ee5defb2fc",
      "0x78a5636f43172f60",
      "0x84c87814a1f0ab72",
      "0x8cc702081a6439ec",
      "0x90befffa23631e28",
      "0xa4506cebde82bde9",
      "0xbef9a3f7b2c67915",
      "0xc67178f2e372532b",
      "0xca273eceea26619c",
      "0xd186b8c721c0c207",
      "0xeada7dd6cde0eb1e",
      "0xf57d4f7fee6ed178",
      "0x06f067aa72176fba",
      "0x0a637dc5a2c898a6",
      "0x113f9804bef90dae",
      "0x1b710b35131c471b",
      "0x28db77f523047d84",
      "0x32caab7b40c72493",
      "0x3c9ebe0a15c9bebc",
      "0x431d67c49c100d4c",
      "0x4cc5d4becb3e42b6",
      "0x597f299cfc657e2a",
      "0x5fcb6fab3ad6faec",
      "0x6c44198c4a475817",
    ].map((t) => BigInt(t)),
  ),
  Js = or[0],
  Qs = or[1],
  ve = new Uint32Array(80),
  xe = new Uint32Array(80)
class ei extends an {
  constructor(e = 64) {
    super(128, e, 16, !1),
      (this.Ah = Y[0] | 0),
      (this.Al = Y[1] | 0),
      (this.Bh = Y[2] | 0),
      (this.Bl = Y[3] | 0),
      (this.Ch = Y[4] | 0),
      (this.Cl = Y[5] | 0),
      (this.Dh = Y[6] | 0),
      (this.Dl = Y[7] | 0),
      (this.Eh = Y[8] | 0),
      (this.El = Y[9] | 0),
      (this.Fh = Y[10] | 0),
      (this.Fl = Y[11] | 0),
      (this.Gh = Y[12] | 0),
      (this.Gl = Y[13] | 0),
      (this.Hh = Y[14] | 0),
      (this.Hl = Y[15] | 0)
  }
  get() {
    const {
      Ah: e,
      Al: n,
      Bh: r,
      Bl: s,
      Ch: i,
      Cl: o,
      Dh: c,
      Dl: a,
      Eh: u,
      El: d,
      Fh: h,
      Fl: l,
      Gh: f,
      Gl: y,
      Hh: m,
      Hl: v,
    } = this
    return [e, n, r, s, i, o, c, a, u, d, h, l, f, y, m, v]
  }
  set(e, n, r, s, i, o, c, a, u, d, h, l, f, y, m, v) {
    ;(this.Ah = e | 0),
      (this.Al = n | 0),
      (this.Bh = r | 0),
      (this.Bl = s | 0),
      (this.Ch = i | 0),
      (this.Cl = o | 0),
      (this.Dh = c | 0),
      (this.Dl = a | 0),
      (this.Eh = u | 0),
      (this.El = d | 0),
      (this.Fh = h | 0),
      (this.Fl = l | 0),
      (this.Gh = f | 0),
      (this.Gl = y | 0),
      (this.Hh = m | 0),
      (this.Hl = v | 0)
  }
  process(e, n) {
    for (let x = 0; x < 16; x++, n += 4)
      (ve[x] = e.getUint32(n)),
        (xe[x] = e.getUint32((n += 4)))
    for (let x = 16; x < 80; x++) {
      const V = ve[x - 15] | 0,
        N = xe[x - 15] | 0,
        G = je(V, N, 1) ^ je(V, N, 8) ^ Bn(V, N, 7),
        ge = Le(V, N, 1) ^ Le(V, N, 8) ^ An(V, N, 7),
        M = ve[x - 2] | 0,
        U = xe[x - 2] | 0,
        ce = je(M, U, 19) ^ it(M, U, 61) ^ Bn(M, U, 6),
        se = Le(M, U, 19) ^ ot(M, U, 61) ^ An(M, U, 6),
        O = Fs(ge, se, xe[x - 7], xe[x - 16]),
        g = Ys(O, G, ce, ve[x - 7], ve[x - 16])
      ;(ve[x] = g | 0), (xe[x] = O | 0)
    }
    let {
      Ah: r,
      Al: s,
      Bh: i,
      Bl: o,
      Ch: c,
      Cl: a,
      Dh: u,
      Dl: d,
      Eh: h,
      El: l,
      Fh: f,
      Fl: y,
      Gh: m,
      Gl: v,
      Hh: A,
      Hl: K,
    } = this
    for (let x = 0; x < 80; x++) {
      const V = je(h, l, 14) ^ je(h, l, 18) ^ it(h, l, 41),
        N = Le(h, l, 14) ^ Le(h, l, 18) ^ ot(h, l, 41),
        G = (h & f) ^ (~h & m),
        ge = (l & y) ^ (~l & v),
        M = Ps(K, N, ge, Qs[x], xe[x]),
        U = Gs(M, A, V, G, Js[x], ve[x]),
        ce = M | 0,
        se = je(r, s, 28) ^ it(r, s, 34) ^ it(r, s, 39),
        O = Le(r, s, 28) ^ ot(r, s, 34) ^ ot(r, s, 39),
        g = (r & i) ^ (r & c) ^ (i & c),
        b = (s & o) ^ (s & a) ^ (o & a)
      ;(A = m | 0),
        (K = v | 0),
        (m = f | 0),
        (v = y | 0),
        (f = h | 0),
        (y = l | 0),
        ({ h, l } = le(u | 0, d | 0, U | 0, ce | 0)),
        (u = c | 0),
        (d = a | 0),
        (c = i | 0),
        (a = o | 0),
        (i = r | 0),
        (o = s | 0)
      const p = Ds(ce, O, b)
      ;(r = Ms(p, U, se, g)), (s = p | 0)
    }
    ;({ h: r, l: s } = le(
      this.Ah | 0,
      this.Al | 0,
      r | 0,
      s | 0,
    )),
      ({ h: i, l: o } = le(
        this.Bh | 0,
        this.Bl | 0,
        i | 0,
        o | 0,
      )),
      ({ h: c, l: a } = le(
        this.Ch | 0,
        this.Cl | 0,
        c | 0,
        a | 0,
      )),
      ({ h: u, l: d } = le(
        this.Dh | 0,
        this.Dl | 0,
        u | 0,
        d | 0,
      )),
      ({ h, l } = le(
        this.Eh | 0,
        this.El | 0,
        h | 0,
        l | 0,
      )),
      ({ h: f, l: y } = le(
        this.Fh | 0,
        this.Fl | 0,
        f | 0,
        y | 0,
      )),
      ({ h: m, l: v } = le(
        this.Gh | 0,
        this.Gl | 0,
        m | 0,
        v | 0,
      )),
      ({ h: A, l: K } = le(
        this.Hh | 0,
        this.Hl | 0,
        A | 0,
        K | 0,
      )),
      this.set(
        r,
        s,
        i,
        o,
        c,
        a,
        u,
        d,
        h,
        l,
        f,
        y,
        m,
        v,
        A,
        K,
      )
  }
  roundClean() {
    ie(ve, xe)
  }
  destroy() {
    ie(this.buffer),
      this.set(
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
      )
  }
}
const St = Bt(() => new Ws()),
  Vt = Bt(() => new ei())
class cr extends nn {
  constructor(e, n) {
    super(),
      (this.finished = !1),
      (this.destroyed = !1),
      en(e)
    const r = kt(n)
    if (
      ((this.iHash = e.create()),
      typeof this.iHash.update != "function")
    )
      throw new Error(
        "Expected instance of class which extends utils.Hash",
      )
    ;(this.blockLen = this.iHash.blockLen),
      (this.outputLen = this.iHash.outputLen)
    const s = this.blockLen,
      i = new Uint8Array(s)
    i.set(r.length > s ? e.create().update(r).digest() : r)
    for (let o = 0; o < i.length; o++) i[o] ^= 54
    this.iHash.update(i), (this.oHash = e.create())
    for (let o = 0; o < i.length; o++) i[o] ^= 106
    this.oHash.update(i), ie(i)
  }
  update(e) {
    return Ze(this), this.iHash.update(e), this
  }
  digestInto(e) {
    Ze(this),
      Z(e, this.outputLen),
      (this.finished = !0),
      this.iHash.digestInto(e),
      this.oHash.update(e),
      this.oHash.digestInto(e),
      this.destroy()
  }
  digest() {
    const e = new Uint8Array(this.oHash.outputLen)
    return this.digestInto(e), e
  }
  _cloneInto(e) {
    e ||
      (e = Object.create(Object.getPrototypeOf(this), {}))
    const {
      oHash: n,
      iHash: r,
      finished: s,
      destroyed: i,
      blockLen: o,
      outputLen: c,
    } = this
    return (
      (e = e),
      (e.finished = s),
      (e.destroyed = i),
      (e.blockLen = o),
      (e.outputLen = c),
      (e.oHash = n._cloneInto(e.oHash)),
      (e.iHash = r._cloneInto(e.iHash)),
      e
    )
  }
  clone() {
    return this._cloneInto()
  }
  destroy() {
    ;(this.destroyed = !0),
      this.oHash.destroy(),
      this.iHash.destroy()
  }
}
const Xe = (t, e, n) => new cr(t, e).update(n).digest()
Xe.create = (t, e) =>
  new cr(
    t,
    e,
  ) /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const De = BigInt(0),
  Ie = BigInt(1)
function ht(t, e) {
  const n = e.negate()
  return t ? n : e
}
function Ot(t, e) {
  const n = tr(
    t.Fp,
    e.map((r) => r.Z),
  )
  return e.map((r, s) => t.fromAffine(r.toAffine(n[s])))
}
function ar(t, e) {
  if (!Number.isSafeInteger(t) || t <= 0 || t > e)
    throw new Error(
      "invalid window size, expected [1.." +
        e +
        "], got W=" +
        t,
    )
}
function Kt(t, e) {
  ar(t, e)
  const n = Math.ceil(e / t) + 1,
    r = 2 ** (t - 1),
    s = 2 ** t,
    i = We(t),
    o = BigInt(t)
  return {
    windows: n,
    windowSize: r,
    mask: i,
    maxNumber: s,
    shiftBy: o,
  }
}
function Sn(t, e, n) {
  const {
    windowSize: r,
    mask: s,
    maxNumber: i,
    shiftBy: o,
  } = n
  let c = Number(t & s),
    a = t >> o
  c > r && ((c -= i), (a += Ie))
  const u = e * r,
    d = u + Math.abs(c) - 1,
    h = c === 0,
    l = c < 0,
    f = e % 2 !== 0
  return {
    nextN: a,
    offset: d,
    isZero: h,
    isNeg: l,
    isNegF: f,
    offsetF: u,
  }
}
function ti(t, e) {
  if (!Array.isArray(t)) throw new Error("array expected")
  t.forEach((n, r) => {
    if (!(n instanceof e))
      throw new Error("invalid point at index " + r)
  })
}
function ni(t, e) {
  if (!Array.isArray(t))
    throw new Error("array of scalars expected")
  t.forEach((n, r) => {
    if (!e.isValid(n))
      throw new Error("invalid scalar at index " + r)
  })
}
const Rt = new WeakMap(),
  lr = new WeakMap()
function Nt(t) {
  return lr.get(t) || 1
}
function In(t) {
  if (t !== De) throw new Error("invalid wNAF")
}
let ri = class {
  constructor(e, n) {
    ;(this.BASE = e.BASE),
      (this.ZERO = e.ZERO),
      (this.Fn = e.Fn),
      (this.bits = n)
  }
  _unsafeLadder(e, n, r = this.ZERO) {
    let s = e
    for (; n > De; )
      n & Ie && (r = r.add(s)), (s = s.double()), (n >>= Ie)
    return r
  }
  precomputeWindow(e, n) {
    const { windows: r, windowSize: s } = Kt(n, this.bits),
      i = []
    let o = e,
      c = o
    for (let a = 0; a < r; a++) {
      ;(c = o), i.push(c)
      for (let u = 1; u < s; u++) (c = c.add(o)), i.push(c)
      o = c.double()
    }
    return i
  }
  wNAF(e, n, r) {
    if (!this.Fn.isValid(r))
      throw new Error("invalid scalar")
    let s = this.ZERO,
      i = this.BASE
    const o = Kt(e, this.bits)
    for (let c = 0; c < o.windows; c++) {
      const {
        nextN: a,
        offset: u,
        isZero: d,
        isNeg: h,
        isNegF: l,
        offsetF: f,
      } = Sn(r, c, o)
      ;(r = a),
        d
          ? (i = i.add(ht(l, n[f])))
          : (s = s.add(ht(h, n[u])))
    }
    return In(r), { p: s, f: i }
  }
  wNAFUnsafe(e, n, r, s = this.ZERO) {
    const i = Kt(e, this.bits)
    for (let o = 0; o < i.windows && r !== De; o++) {
      const {
        nextN: c,
        offset: a,
        isZero: u,
        isNeg: d,
      } = Sn(r, o, i)
      if (((r = c), !u)) {
        const h = n[a]
        s = s.add(d ? h.negate() : h)
      }
    }
    return In(r), s
  }
  getPrecomputes(e, n, r) {
    let s = Rt.get(n)
    return (
      s ||
        ((s = this.precomputeWindow(n, e)),
        e !== 1 &&
          (typeof r == "function" && (s = r(s)),
          Rt.set(n, s))),
      s
    )
  }
  cached(e, n, r) {
    const s = Nt(e)
    return this.wNAF(s, this.getPrecomputes(s, e, r), n)
  }
  unsafe(e, n, r, s) {
    const i = Nt(e)
    return i === 1
      ? this._unsafeLadder(e, n, s)
      : this.wNAFUnsafe(
          i,
          this.getPrecomputes(i, e, r),
          n,
          s,
        )
  }
  createCache(e, n) {
    ar(n, this.bits), lr.set(e, n), Rt.delete(e)
  }
  hasCache(e) {
    return Nt(e) !== 1
  }
}
function si(t, e, n, r) {
  let s = e,
    i = t.ZERO,
    o = t.ZERO
  for (; n > De || r > De; )
    n & Ie && (i = i.add(s)),
      r & Ie && (o = o.add(s)),
      (s = s.double()),
      (n >>= Ie),
      (r >>= Ie)
  return { p1: i, p2: o }
}
function ii(t, e, n, r) {
  ti(n, t), ni(r, e)
  const s = n.length,
    i = r.length
  if (s !== i)
    throw new Error(
      "arrays of points and scalars must have equal length",
    )
  const o = t.ZERO,
    c = Yn(BigInt(s))
  let a = 1
  c > 12
    ? (a = c - 3)
    : c > 4
      ? (a = c - 2)
      : c > 0 && (a = 2)
  const u = We(a),
    d = new Array(Number(u) + 1).fill(o),
    h = Math.floor((e.BITS - 1) / a) * a
  let l = o
  for (let f = h; f >= 0; f -= a) {
    d.fill(o)
    for (let m = 0; m < i; m++) {
      const v = r[m],
        A = Number((v >> BigInt(f)) & u)
      d[A] = d[A].add(n[m])
    }
    let y = o
    for (let m = d.length - 1, v = o; m > 0; m--)
      (v = v.add(d[m])), (y = y.add(v))
    if (((l = l.add(y)), f !== 0))
      for (let m = 0; m < a; m++) l = l.double()
  }
  return l
}
function _n(t, e, n) {
  if (e) {
    if (e.ORDER !== t)
      throw new Error(
        "Field.ORDER must match order: Fp == p, Fn == n",
      )
    return Rs(e), e
  } else return Je(t, { isLE: n })
}
function oi(t, e, n = {}, r) {
  if (
    (r === void 0 && (r = t === "edwards"),
    !e || typeof e != "object")
  )
    throw new Error(`expected valid ${t} CURVE object`)
  for (const a of ["p", "n", "h"]) {
    const u = e[a]
    if (!(typeof u == "bigint" && u > De))
      throw new Error(`CURVE.${a} must be positive bigint`)
  }
  const s = _n(e.p, n.Fp, r),
    i = _n(e.n, n.Fn, r),
    c = ["Gx", "Gy", "a", "b"]
  for (const a of c)
    if (!s.isValid(e[a]))
      throw new Error(
        `CURVE.${a} must be valid field element of CURVE.Fp`,
      )
  return (
    (e = Object.freeze(Object.assign({}, e))),
    { CURVE: e, Fp: s, Fn: i }
  )
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const Un = (t, e) => (t + (t >= 0 ? e : -e) / ur) / e
function ci(t, e, n) {
  const [[r, s], [i, o]] = e,
    c = Un(o * t, n),
    a = Un(-s * t, n)
  let u = t - c * r - a * i,
    d = -c * s - a * o
  const h = u < pe,
    l = d < pe
  h && (u = -u), l && (d = -d)
  const f = We(Math.ceil(Yn(n) / 2)) + ze
  if (u < pe || u >= f || d < pe || d >= f)
    throw new Error(
      "splitScalar (endomorphism): failed, k=" + t,
    )
  return { k1neg: h, k1: u, k2neg: l, k2: d }
}
function Zt(t) {
  if (!["compact", "recovered", "der"].includes(t))
    throw new Error(
      'Signature format must be "compact", "recovered", or "der"',
    )
  return t
}
function qt(t, e) {
  const n = {}
  for (let r of Object.keys(e))
    n[r] = t[r] === void 0 ? e[r] : t[r]
  return (
    dt(n.lowS, "lowS"),
    dt(n.prehash, "prehash"),
    n.format !== void 0 && Zt(n.format),
    n
  )
}
class ai extends Error {
  constructor(e = "") {
    super(e)
  }
}
const de = {
    Err: ai,
    _tlv: {
      encode: (t, e) => {
        const { Err: n } = de
        if (t < 0 || t > 256)
          throw new n("tlv.encode: wrong tag")
        if (e.length & 1)
          throw new n("tlv.encode: unpadded data")
        const r = e.length / 2,
          s = rt(r)
        if ((s.length / 2) & 128)
          throw new n(
            "tlv.encode: long form length too big",
          )
        const i = r > 127 ? rt((s.length / 2) | 128) : ""
        return rt(t) + i + s + e
      },
      decode(t, e) {
        const { Err: n } = de
        let r = 0
        if (t < 0 || t > 256)
          throw new n("tlv.encode: wrong tag")
        if (e.length < 2 || e[r++] !== t)
          throw new n("tlv.decode: wrong tlv")
        const s = e[r++],
          i = !!(s & 128)
        let o = 0
        if (!i) o = s
        else {
          const a = s & 127
          if (!a)
            throw new n(
              "tlv.decode(long): indefinite length not supported",
            )
          if (a > 4)
            throw new n(
              "tlv.decode(long): byte length is too big",
            )
          const u = e.subarray(r, r + a)
          if (u.length !== a)
            throw new n(
              "tlv.decode: length bytes not complete",
            )
          if (u[0] === 0)
            throw new n(
              "tlv.decode(long): zero leftmost byte",
            )
          for (const d of u) o = (o << 8) | d
          if (((r += a), o < 128))
            throw new n(
              "tlv.decode(long): not minimal encoding",
            )
        }
        const c = e.subarray(r, r + o)
        if (c.length !== o)
          throw new n("tlv.decode: wrong value length")
        return { v: c, l: e.subarray(r + o) }
      },
    },
    _int: {
      encode(t) {
        const { Err: e } = de
        if (t < pe)
          throw new e(
            "integer: negative integers are not allowed",
          )
        let n = rt(t)
        if (
          (Number.parseInt(n[0], 16) & 8 && (n = "00" + n),
          n.length & 1)
        )
          throw new e(
            "unexpected DER parsing assertion: unpadded hex",
          )
        return n
      },
      decode(t) {
        const { Err: e } = de
        if (t[0] & 128)
          throw new e("invalid signature integer: negative")
        if (t[0] === 0 && !(t[1] & 128))
          throw new e(
            "invalid signature integer: unnecessary leading zero",
          )
        return At(t)
      },
    },
    toSig(t) {
      const { Err: e, _int: n, _tlv: r } = de,
        s = W("signature", t),
        { v: i, l: o } = r.decode(48, s)
      if (o.length)
        throw new e(
          "invalid signature: left bytes after parsing",
        )
      const { v: c, l: a } = r.decode(2, i),
        { v: u, l: d } = r.decode(2, a)
      if (d.length)
        throw new e(
          "invalid signature: left bytes after parsing",
        )
      return { r: n.decode(c), s: n.decode(u) }
    },
    hexFromSig(t) {
      const { _tlv: e, _int: n } = de,
        r = e.encode(2, n.encode(t.r)),
        s = e.encode(2, n.encode(t.s)),
        i = r + s
      return e.encode(48, i)
    },
  },
  pe = BigInt(0),
  ze = BigInt(1),
  ur = BigInt(2),
  ct = BigInt(3),
  li = BigInt(4)
function Te(t, e) {
  const { BYTES: n } = t
  let r
  if (typeof e == "bigint") r = e
  else {
    let s = W("private key", e)
    try {
      r = t.fromBytes(s)
    } catch {
      throw new Error(
        `invalid private key: expected ui8a of size ${n}, got ${typeof e}`,
      )
    }
  }
  if (!t.isValidNot0(r))
    throw new Error(
      "invalid private key: out of range [1..N-1]",
    )
  return r
}
function ui(t, e = {}) {
  const n = oi("weierstrass", t, e),
    { Fp: r, Fn: s } = n
  let i = n.CURVE
  const { h: o, n: c } = i
  on(
    e,
    {},
    {
      allowInfinityPoint: "boolean",
      clearCofactor: "function",
      isTorsionFree: "function",
      fromBytes: "function",
      toBytes: "function",
      endo: "object",
      wrapPrivateKey: "boolean",
    },
  )
  const { endo: a } = e
  if (
    a &&
    (!r.is0(i.a) ||
      typeof a.beta != "bigint" ||
      !Array.isArray(a.basises))
  )
    throw new Error(
      'invalid endo: expected "beta": bigint and "basises": array',
    )
  const u = dr(r, s)
  function d() {
    if (!r.isOdd)
      throw new Error(
        "compression is not supported: Field does not have .isOdd()",
      )
  }
  function h(O, g, b) {
    const { x: p, y: w } = g.toAffine(),
      k = r.toBytes(p)
    if ((dt(b, "isCompressed"), b)) {
      d()
      const I = !r.isOdd(w)
      return ne(fr(I), k)
    } else return ne(Uint8Array.of(4), k, r.toBytes(w))
  }
  function l(O) {
    Ae(O, void 0, "Point")
    const { publicKey: g, publicKeyUncompressed: b } = u,
      p = O.length,
      w = O[0],
      k = O.subarray(1)
    if (p === g && (w === 2 || w === 3)) {
      const I = r.fromBytes(k)
      if (!r.isValid(I))
        throw new Error(
          "bad point: is not on curve, wrong x",
        )
      const S = m(I)
      let B
      try {
        B = r.sqrt(S)
      } catch (T) {
        const q = T instanceof Error ? ": " + T.message : ""
        throw new Error(
          "bad point: is not on curve, sqrt error" + q,
        )
      }
      d()
      const _ = r.isOdd(B)
      return (
        ((w & 1) === 1) !== _ && (B = r.neg(B)),
        { x: I, y: B }
      )
    } else if (p === b && w === 4) {
      const I = r.BYTES,
        S = r.fromBytes(k.subarray(0, I)),
        B = r.fromBytes(k.subarray(I, I * 2))
      if (!v(S, B))
        throw new Error("bad point: is not on curve")
      return { x: S, y: B }
    } else
      throw new Error(
        `bad point: got length ${p}, expected compressed=${g} or uncompressed=${b}`,
      )
  }
  const f = e.toBytes || h,
    y = e.fromBytes || l
  function m(O) {
    const g = r.sqr(O),
      b = r.mul(g, O)
    return r.add(r.add(b, r.mul(O, i.a)), i.b)
  }
  function v(O, g) {
    const b = r.sqr(g),
      p = m(O)
    return r.eql(b, p)
  }
  if (!v(i.Gx, i.Gy))
    throw new Error("bad curve params: generator point")
  const A = r.mul(r.pow(i.a, ct), li),
    K = r.mul(r.sqr(i.b), BigInt(27))
  if (r.is0(r.add(A, K)))
    throw new Error("bad curve params: a or b")
  function x(O, g, b = !1) {
    if (!r.isValid(g) || (b && r.is0(g)))
      throw new Error(`bad point coordinate ${O}`)
    return g
  }
  function V(O) {
    if (!(O instanceof U))
      throw new Error("ProjectivePoint expected")
  }
  function N(O) {
    if (!a || !a.basises) throw new Error("no endo")
    return ci(O, a.basises, s.ORDER)
  }
  const G = vn((O, g) => {
      const { X: b, Y: p, Z: w } = O
      if (r.eql(w, r.ONE)) return { x: b, y: p }
      const k = O.is0()
      g == null && (g = k ? r.ONE : r.inv(w))
      const I = r.mul(b, g),
        S = r.mul(p, g),
        B = r.mul(w, g)
      if (k) return { x: r.ZERO, y: r.ZERO }
      if (!r.eql(B, r.ONE))
        throw new Error("invZ was invalid")
      return { x: I, y: S }
    }),
    ge = vn((O) => {
      if (O.is0()) {
        if (e.allowInfinityPoint && !r.is0(O.Y)) return
        throw new Error("bad point: ZERO")
      }
      const { x: g, y: b } = O.toAffine()
      if (!r.isValid(g) || !r.isValid(b))
        throw new Error(
          "bad point: x or y not field elements",
        )
      if (!v(g, b))
        throw new Error("bad point: equation left != right")
      if (!O.isTorsionFree())
        throw new Error(
          "bad point: not in prime-order subgroup",
        )
      return !0
    })
  function M(O, g, b, p, w) {
    return (
      (b = new U(r.mul(b.X, O), b.Y, b.Z)),
      (g = ht(p, g)),
      (b = ht(w, b)),
      g.add(b)
    )
  }
  class U {
    constructor(g, b, p) {
      ;(this.X = x("x", g)),
        (this.Y = x("y", b, !0)),
        (this.Z = x("z", p)),
        Object.freeze(this)
    }
    static CURVE() {
      return i
    }
    static fromAffine(g) {
      const { x: b, y: p } = g || {}
      if (!g || !r.isValid(b) || !r.isValid(p))
        throw new Error("invalid affine point")
      if (g instanceof U)
        throw new Error("projective point not allowed")
      return r.is0(b) && r.is0(p)
        ? U.ZERO
        : new U(b, p, r.ONE)
    }
    static fromBytes(g) {
      const b = U.fromAffine(y(Ae(g, void 0, "point")))
      return b.assertValidity(), b
    }
    static fromHex(g) {
      return U.fromBytes(W("pointHex", g))
    }
    get x() {
      return this.toAffine().x
    }
    get y() {
      return this.toAffine().y
    }
    precompute(g = 8, b = !0) {
      return (
        se.createCache(this, g),
        b || this.multiply(ct),
        this
      )
    }
    assertValidity() {
      ge(this)
    }
    hasEvenY() {
      const { y: g } = this.toAffine()
      if (!r.isOdd)
        throw new Error("Field doesn't support isOdd")
      return !r.isOdd(g)
    }
    equals(g) {
      V(g)
      const { X: b, Y: p, Z: w } = this,
        { X: k, Y: I, Z: S } = g,
        B = r.eql(r.mul(b, S), r.mul(k, w)),
        _ = r.eql(r.mul(p, S), r.mul(I, w))
      return B && _
    }
    negate() {
      return new U(this.X, r.neg(this.Y), this.Z)
    }
    double() {
      const { a: g, b } = i,
        p = r.mul(b, ct),
        { X: w, Y: k, Z: I } = this
      let S = r.ZERO,
        B = r.ZERO,
        _ = r.ZERO,
        H = r.mul(w, w),
        T = r.mul(k, k),
        q = r.mul(I, I),
        R = r.mul(w, k)
      return (
        (R = r.add(R, R)),
        (_ = r.mul(w, I)),
        (_ = r.add(_, _)),
        (S = r.mul(g, _)),
        (B = r.mul(p, q)),
        (B = r.add(S, B)),
        (S = r.sub(T, B)),
        (B = r.add(T, B)),
        (B = r.mul(S, B)),
        (S = r.mul(R, S)),
        (_ = r.mul(p, _)),
        (q = r.mul(g, q)),
        (R = r.sub(H, q)),
        (R = r.mul(g, R)),
        (R = r.add(R, _)),
        (_ = r.add(H, H)),
        (H = r.add(_, H)),
        (H = r.add(H, q)),
        (H = r.mul(H, R)),
        (B = r.add(B, H)),
        (q = r.mul(k, I)),
        (q = r.add(q, q)),
        (H = r.mul(q, R)),
        (S = r.sub(S, H)),
        (_ = r.mul(q, T)),
        (_ = r.add(_, _)),
        (_ = r.add(_, _)),
        new U(S, B, _)
      )
    }
    add(g) {
      V(g)
      const { X: b, Y: p, Z: w } = this,
        { X: k, Y: I, Z: S } = g
      let B = r.ZERO,
        _ = r.ZERO,
        H = r.ZERO
      const T = i.a,
        q = r.mul(i.b, ct)
      let R = r.mul(b, k),
        j = r.mul(p, I),
        $ = r.mul(w, S),
        X = r.add(b, p),
        L = r.add(k, I)
      ;(X = r.mul(X, L)),
        (L = r.add(R, j)),
        (X = r.sub(X, L)),
        (L = r.add(b, w))
      let F = r.add(k, S)
      return (
        (L = r.mul(L, F)),
        (F = r.add(R, $)),
        (L = r.sub(L, F)),
        (F = r.add(p, w)),
        (B = r.add(I, S)),
        (F = r.mul(F, B)),
        (B = r.add(j, $)),
        (F = r.sub(F, B)),
        (H = r.mul(T, L)),
        (B = r.mul(q, $)),
        (H = r.add(B, H)),
        (B = r.sub(j, H)),
        (H = r.add(j, H)),
        (_ = r.mul(B, H)),
        (j = r.add(R, R)),
        (j = r.add(j, R)),
        ($ = r.mul(T, $)),
        (L = r.mul(q, L)),
        (j = r.add(j, $)),
        ($ = r.sub(R, $)),
        ($ = r.mul(T, $)),
        (L = r.add(L, $)),
        (R = r.mul(j, L)),
        (_ = r.add(_, R)),
        (R = r.mul(F, L)),
        (B = r.mul(X, B)),
        (B = r.sub(B, R)),
        (R = r.mul(X, j)),
        (H = r.mul(F, H)),
        (H = r.add(H, R)),
        new U(B, _, H)
      )
    }
    subtract(g) {
      return this.add(g.negate())
    }
    is0() {
      return this.equals(U.ZERO)
    }
    multiply(g) {
      const { endo: b } = e
      if (!s.isValidNot0(g))
        throw new Error("invalid scalar: out of range")
      let p, w
      const k = (I) => se.cached(this, I, (S) => Ot(U, S))
      if (b) {
        const { k1neg: I, k1: S, k2neg: B, k2: _ } = N(g),
          { p: H, f: T } = k(S),
          { p: q, f: R } = k(_)
        ;(w = T.add(R)), (p = M(b.beta, H, q, I, B))
      } else {
        const { p: I, f: S } = k(g)
        ;(p = I), (w = S)
      }
      return Ot(U, [p, w])[0]
    }
    multiplyUnsafe(g) {
      const { endo: b } = e,
        p = this
      if (!s.isValid(g))
        throw new Error("invalid scalar: out of range")
      if (g === pe || p.is0()) return U.ZERO
      if (g === ze) return p
      if (se.hasCache(this)) return this.multiply(g)
      if (b) {
        const { k1neg: w, k1: k, k2neg: I, k2: S } = N(g),
          { p1: B, p2: _ } = si(U, p, k, S)
        return M(b.beta, B, _, w, I)
      } else return se.unsafe(p, g)
    }
    multiplyAndAddUnsafe(g, b, p) {
      const w = this.multiplyUnsafe(b).add(
        g.multiplyUnsafe(p),
      )
      return w.is0() ? void 0 : w
    }
    toAffine(g) {
      return G(this, g)
    }
    isTorsionFree() {
      const { isTorsionFree: g } = e
      return o === ze
        ? !0
        : g
          ? g(U, this)
          : se.unsafe(this, c).is0()
    }
    clearCofactor() {
      const { clearCofactor: g } = e
      return o === ze
        ? this
        : g
          ? g(U, this)
          : this.multiplyUnsafe(o)
    }
    isSmallOrder() {
      return this.multiplyUnsafe(o).is0()
    }
    toBytes(g = !0) {
      return (
        dt(g, "isCompressed"),
        this.assertValidity(),
        f(U, this, g)
      )
    }
    toHex(g = !0) {
      return Ue(this.toBytes(g))
    }
    toString() {
      return `<Point ${this.is0() ? "ZERO" : this.toHex()}>`
    }
    get px() {
      return this.X
    }
    get py() {
      return this.X
    }
    get pz() {
      return this.Z
    }
    toRawBytes(g = !0) {
      return this.toBytes(g)
    }
    _setWindowSize(g) {
      this.precompute(g)
    }
    static normalizeZ(g) {
      return Ot(U, g)
    }
    static msm(g, b) {
      return ii(U, s, g, b)
    }
    static fromPrivateKey(g) {
      return U.BASE.multiply(Te(s, g))
    }
  }
  ;(U.BASE = new U(i.Gx, i.Gy, r.ONE)),
    (U.ZERO = new U(r.ZERO, r.ONE, r.ZERO)),
    (U.Fp = r),
    (U.Fn = s)
  const ce = s.BITS,
    se = new ri(U, e.endo ? Math.ceil(ce / 2) : ce)
  return U.BASE.precompute(8), U
}
function fr(t) {
  return Uint8Array.of(t ? 2 : 3)
}
function dr(t, e) {
  return {
    secretKey: e.BYTES,
    publicKey: 1 + t.BYTES,
    publicKeyUncompressed: 1 + 2 * t.BYTES,
    publicKeyHasPrefix: !0,
    signature: 2 * e.BYTES,
  }
}
function fi(t, e = {}) {
  const { Fn: n } = t,
    r = e.randomBytes || Zn,
    s = Object.assign(dr(t.Fp, n), { seed: sr(n.ORDER) })
  function i(f) {
    try {
      return !!Te(n, f)
    } catch {
      return !1
    }
  }
  function o(f, y) {
    const { publicKey: m, publicKeyUncompressed: v } = s
    try {
      const A = f.length
      return (y === !0 && A !== m) || (y === !1 && A !== v)
        ? !1
        : !!t.fromBytes(f)
    } catch {
      return !1
    }
  }
  function c(f = r(s.seed)) {
    return qs(Ae(f, s.seed, "seed"), n.ORDER)
  }
  function a(f, y = !0) {
    return t.BASE.multiply(Te(n, f)).toBytes(y)
  }
  function u(f) {
    const y = c(f)
    return { secretKey: y, publicKey: a(y) }
  }
  function d(f) {
    if (typeof f == "bigint") return !1
    if (f instanceof t) return !0
    const {
      secretKey: y,
      publicKey: m,
      publicKeyUncompressed: v,
    } = s
    if (n.allowedLengths || y === m) return
    const A = W("key", f).length
    return A === m || A === v
  }
  function h(f, y, m = !0) {
    if (d(f) === !0)
      throw new Error("first arg must be private key")
    if (d(y) === !1)
      throw new Error("second arg must be public key")
    const v = Te(n, f)
    return t.fromHex(y).multiply(v).toBytes(m)
  }
  return Object.freeze({
    getPublicKey: a,
    getSharedSecret: h,
    keygen: u,
    Point: t,
    utils: {
      isValidSecretKey: i,
      isValidPublicKey: o,
      randomSecretKey: c,
      isValidPrivateKey: i,
      randomPrivateKey: c,
      normPrivateKeyToScalar: (f) => Te(n, f),
      precompute(f = 8, y = t.BASE) {
        return y.precompute(f, !1)
      },
    },
    lengths: s,
  })
}
function di(t, e, n = {}) {
  en(e),
    on(
      n,
      {},
      {
        hmac: "function",
        lowS: "boolean",
        randomBytes: "function",
        bits2int: "function",
        bits2int_modN: "function",
      },
    )
  const r = n.randomBytes || Zn,
    s = n.hmac || ((b, ...p) => Xe(e, b, ne(...p))),
    { Fp: i, Fn: o } = t,
    { ORDER: c, BITS: a } = o,
    {
      keygen: u,
      getPublicKey: d,
      getSharedSecret: h,
      utils: l,
      lengths: f,
    } = fi(t, n),
    y = {
      prehash: !1,
      lowS: typeof n.lowS == "boolean" ? n.lowS : !1,
      format: void 0,
      extraEntropy: !1,
    },
    m = "compact"
  function v(b) {
    const p = c >> ze
    return b > p
  }
  function A(b, p) {
    if (!o.isValidNot0(p))
      throw new Error(
        `invalid signature ${b}: out of range 1..Point.Fn.ORDER`,
      )
    return p
  }
  function K(b, p) {
    Zt(p)
    const w = f.signature,
      k =
        p === "compact"
          ? w
          : p === "recovered"
            ? w + 1
            : void 0
    return Ae(b, k, `${p} signature`)
  }
  class x {
    constructor(p, w, k) {
      ;(this.r = A("r", p)),
        (this.s = A("s", w)),
        k != null && (this.recovery = k),
        Object.freeze(this)
    }
    static fromBytes(p, w = m) {
      K(p, w)
      let k
      if (w === "der") {
        const { r: _, s: H } = de.toSig(Ae(p))
        return new x(_, H)
      }
      w === "recovered" &&
        ((k = p[0]), (w = "compact"), (p = p.subarray(1)))
      const I = o.BYTES,
        S = p.subarray(0, I),
        B = p.subarray(I, I * 2)
      return new x(o.fromBytes(S), o.fromBytes(B), k)
    }
    static fromHex(p, w) {
      return this.fromBytes(Ge(p), w)
    }
    addRecoveryBit(p) {
      return new x(this.r, this.s, p)
    }
    recoverPublicKey(p) {
      const w = i.ORDER,
        { r: k, s: I, recovery: S } = this
      if (S == null || ![0, 1, 2, 3].includes(S))
        throw new Error("recovery id invalid")
      if (c * ur < w && S > 1)
        throw new Error(
          "recovery id is ambiguous for h>1 curve",
        )
      const _ = S === 2 || S === 3 ? k + c : k
      if (!i.isValid(_))
        throw new Error("recovery id 2 or 3 invalid")
      const H = i.toBytes(_),
        T = t.fromBytes(ne(fr((S & 1) === 0), H)),
        q = o.inv(_),
        R = N(W("msgHash", p)),
        j = o.create(-R * q),
        $ = o.create(I * q),
        X = t.BASE.multiplyUnsafe(j).add(
          T.multiplyUnsafe($),
        )
      if (X.is0()) throw new Error("point at infinify")
      return X.assertValidity(), X
    }
    hasHighS() {
      return v(this.s)
    }
    toBytes(p = m) {
      if ((Zt(p), p === "der"))
        return Ge(de.hexFromSig(this))
      const w = o.toBytes(this.r),
        k = o.toBytes(this.s)
      if (p === "recovered") {
        if (this.recovery == null)
          throw new Error("recovery bit must be present")
        return ne(Uint8Array.of(this.recovery), w, k)
      }
      return ne(w, k)
    }
    toHex(p) {
      return Ue(this.toBytes(p))
    }
    assertValidity() {}
    static fromCompact(p) {
      return x.fromBytes(W("sig", p), "compact")
    }
    static fromDER(p) {
      return x.fromBytes(W("sig", p), "der")
    }
    normalizeS() {
      return this.hasHighS()
        ? new x(this.r, o.neg(this.s), this.recovery)
        : this
    }
    toDERRawBytes() {
      return this.toBytes("der")
    }
    toDERHex() {
      return Ue(this.toBytes("der"))
    }
    toCompactRawBytes() {
      return this.toBytes("compact")
    }
    toCompactHex() {
      return Ue(this.toBytes("compact"))
    }
  }
  const V =
      n.bits2int ||
      function (p) {
        if (p.length > 8192)
          throw new Error("input is too large")
        const w = At(p),
          k = p.length * 8 - a
        return k > 0 ? w >> BigInt(k) : w
      },
    N =
      n.bits2int_modN ||
      function (p) {
        return o.create(V(p))
      },
    G = We(a)
  function ge(b) {
    return As("num < 2^" + a, b, pe, G), o.toBytes(b)
  }
  function M(b, p) {
    return (
      Ae(b, void 0, "message"),
      p ? Ae(e(b), void 0, "prehashed message") : b
    )
  }
  function U(b, p, w) {
    if (["recovered", "canonical"].some((j) => j in w))
      throw new Error("sign() legacy options not supported")
    const {
      lowS: k,
      prehash: I,
      extraEntropy: S,
    } = qt(w, y)
    b = M(b, I)
    const B = N(b),
      _ = Te(o, p),
      H = [ge(_), ge(B)]
    if (S != null && S !== !1) {
      const j = S === !0 ? r(f.secretKey) : S
      H.push(W("extraEntropy", j))
    }
    const T = ne(...H),
      q = B
    function R(j) {
      const $ = V(j)
      if (!o.isValidNot0($)) return
      const X = o.inv($),
        L = t.BASE.multiply($).toAffine(),
        F = o.create(L.x)
      if (F === pe) return
      const tt = o.create(X * o.create(q + F * _))
      if (tt === pe) return
      let pn = (L.x === F ? 0 : 2) | Number(L.y & ze),
        yn = tt
      return (
        k && v(tt) && ((yn = o.neg(tt)), (pn ^= 1)),
        new x(F, yn, pn)
      )
    }
    return { seed: T, k2sig: R }
  }
  function ce(b, p, w = {}) {
    b = W("message", b)
    const { seed: k, k2sig: I } = U(b, p, w)
    return Ss(e.outputLen, o.BYTES, s)(k, I)
  }
  function se(b) {
    let p
    const w = typeof b == "string" || Et(b),
      k =
        !w &&
        b !== null &&
        typeof b == "object" &&
        typeof b.r == "bigint" &&
        typeof b.s == "bigint"
    if (!w && !k)
      throw new Error(
        "invalid signature, expected Uint8Array, hex string or Signature instance",
      )
    if (k) p = new x(b.r, b.s)
    else if (w) {
      try {
        p = x.fromBytes(W("sig", b), "der")
      } catch (I) {
        if (!(I instanceof de.Err)) throw I
      }
      if (!p)
        try {
          p = x.fromBytes(W("sig", b), "compact")
        } catch {
          return !1
        }
    }
    return p || !1
  }
  function O(b, p, w, k = {}) {
    const { lowS: I, prehash: S, format: B } = qt(k, y)
    if (
      ((w = W("publicKey", w)),
      (p = M(W("message", p), S)),
      "strict" in k)
    )
      throw new Error("options.strict was renamed to lowS")
    const _ =
      B === void 0 ? se(b) : x.fromBytes(W("sig", b), B)
    if (_ === !1) return !1
    try {
      const H = t.fromBytes(w)
      if (I && _.hasHighS()) return !1
      const { r: T, s: q } = _,
        R = N(p),
        j = o.inv(q),
        $ = o.create(R * j),
        X = o.create(T * j),
        L = t.BASE.multiplyUnsafe($).add(
          H.multiplyUnsafe(X),
        )
      return L.is0() ? !1 : o.create(L.x) === T
    } catch {
      return !1
    }
  }
  function g(b, p, w = {}) {
    const { prehash: k } = qt(w, y)
    return (
      (p = M(p, k)),
      x
        .fromBytes(b, "recovered")
        .recoverPublicKey(p)
        .toBytes()
    )
  }
  return Object.freeze({
    keygen: u,
    getPublicKey: d,
    getSharedSecret: h,
    utils: l,
    lengths: f,
    Point: t,
    sign: ce,
    verify: O,
    recoverPublicKey: g,
    Signature: x,
    hash: e,
  })
}
function hi(t) {
  const e = {
      a: t.a,
      b: t.b,
      p: t.Fp.ORDER,
      n: t.n,
      h: t.h,
      Gx: t.Gx,
      Gy: t.Gy,
    },
    n = t.Fp
  let r = t.allowedPrivateKeyLengths
    ? Array.from(
        new Set(
          t.allowedPrivateKeyLengths.map((o) =>
            Math.ceil(o / 2),
          ),
        ),
      )
    : void 0
  const s = Je(e.n, {
      BITS: t.nBitLength,
      allowedLengths: r,
      modFromBytes: t.wrapPrivateKey,
    }),
    i = {
      Fp: n,
      Fn: s,
      allowInfinityPoint: t.allowInfinityPoint,
      endo: t.endo,
      isTorsionFree: t.isTorsionFree,
      clearCofactor: t.clearCofactor,
      fromBytes: t.fromBytes,
      toBytes: t.toBytes,
    }
  return { CURVE: e, curveOpts: i }
}
function pi(t) {
  const { CURVE: e, curveOpts: n } = hi(t),
    r = {
      hmac: t.hmac,
      randomBytes: t.randomBytes,
      lowS: t.lowS,
      bits2int: t.bits2int,
      bits2int_modN: t.bits2int_modN,
    }
  return {
    CURVE: e,
    curveOpts: n,
    hash: t.hash,
    ecdsaOpts: r,
  }
}
function yi(t, e) {
  const n = e.Point
  return Object.assign({}, e, {
    ProjectivePoint: n,
    CURVE: Object.assign({}, t, nr(n.Fn.ORDER, n.Fn.BITS)),
  })
}
function bi(t) {
  const {
      CURVE: e,
      curveOpts: n,
      hash: r,
      ecdsaOpts: s,
    } = pi(t),
    i = ui(e, n),
    o = di(i, r, s)
  return yi(t, o)
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
function gi(t, e) {
  const n = (r) => bi({ ...t, hash: r })
  return { ...n(e), create: n }
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const ln = {
    p: BigInt(
      "0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f",
    ),
    n: BigInt(
      "0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141",
    ),
    h: BigInt(1),
    a: BigInt(0),
    b: BigInt(7),
    Gx: BigInt(
      "0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798",
    ),
    Gy: BigInt(
      "0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8",
    ),
  },
  mi = {
    beta: BigInt(
      "0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee",
    ),
    basises: [
      [
        BigInt("0x3086d221a7d46bcde86c90e49284eb15"),
        -BigInt("0xe4437ed6010e88286f547fa90abfe4c3"),
      ],
      [
        BigInt("0x114ca50f7a8e2f3f657c1108d9d44cfd8"),
        BigInt("0x3086d221a7d46bcde86c90e49284eb15"),
      ],
    ],
  },
  Hn = BigInt(2)
function wi(t) {
  const e = ln.p,
    n = BigInt(3),
    r = BigInt(6),
    s = BigInt(11),
    i = BigInt(22),
    o = BigInt(23),
    c = BigInt(44),
    a = BigInt(88),
    u = (t * t * t) % e,
    d = (u * u * t) % e,
    h = (ee(d, n, e) * d) % e,
    l = (ee(h, n, e) * d) % e,
    f = (ee(l, Hn, e) * u) % e,
    y = (ee(f, s, e) * f) % e,
    m = (ee(y, i, e) * y) % e,
    v = (ee(m, c, e) * m) % e,
    A = (ee(v, a, e) * v) % e,
    K = (ee(A, c, e) * m) % e,
    x = (ee(K, n, e) * d) % e,
    V = (ee(x, o, e) * y) % e,
    N = (ee(V, r, e) * u) % e,
    G = ee(N, Hn, e)
  if (!Dt.eql(Dt.sqr(G), t))
    throw new Error("Cannot find square root")
  return G
}
const Dt = Je(ln.p, { sqrt: wi }),
  fe = gi({ ...ln, Fp: Dt, lowS: !0, endo: mi }, St),
  vi = Uint8Array.from([
    7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8,
  ]),
  hr = Uint8Array.from(
    new Array(16).fill(0).map((t, e) => e),
  ),
  xi = hr.map((t) => (9 * t + 5) % 16),
  pr = (() => {
    const n = [[hr], [xi]]
    for (let r = 0; r < 4; r++)
      for (let s of n) s.push(s[r].map((i) => vi[i]))
    return n
  })(),
  yr = pr[0],
  br = pr[1],
  gr = [
    [
      11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9,
      8,
    ],
    [
      12, 13, 11, 15, 6, 9, 9, 7, 12, 15, 11, 13, 7, 8, 7,
      7,
    ],
    [
      13, 15, 14, 11, 7, 7, 6, 8, 13, 14, 13, 12, 5, 5, 6,
      9,
    ],
    [
      14, 11, 12, 14, 8, 6, 5, 5, 15, 12, 15, 14, 9, 9, 8,
      6,
    ],
    [
      15, 12, 13, 13, 9, 5, 8, 6, 14, 11, 12, 11, 8, 6, 5,
      5,
    ],
  ].map((t) => Uint8Array.from(t)),
  Ei = yr.map((t, e) => t.map((n) => gr[e][n])),
  ki = br.map((t, e) => t.map((n) => gr[e][n])),
  Bi = Uint32Array.from([
    0, 1518500249, 1859775393, 2400959708, 2840853838,
  ]),
  Ai = Uint32Array.from([
    1352829926, 1548603684, 1836072691, 2053994217, 0,
  ])
function On(t, e, n, r) {
  return t === 0
    ? e ^ n ^ r
    : t === 1
      ? (e & n) | (~e & r)
      : t === 2
        ? (e | ~n) ^ r
        : t === 3
          ? (e & r) | (n & ~r)
          : e ^ (n | ~r)
}
const at = new Uint32Array(16)
class Si extends an {
  constructor() {
    super(64, 20, 8, !0),
      (this.h0 = 1732584193),
      (this.h1 = -271733879),
      (this.h2 = -1732584194),
      (this.h3 = 271733878),
      (this.h4 = -1009589776)
  }
  get() {
    const { h0: e, h1: n, h2: r, h3: s, h4: i } = this
    return [e, n, r, s, i]
  }
  set(e, n, r, s, i) {
    ;(this.h0 = e | 0),
      (this.h1 = n | 0),
      (this.h2 = r | 0),
      (this.h3 = s | 0),
      (this.h4 = i | 0)
  }
  process(e, n) {
    for (let f = 0; f < 16; f++, n += 4)
      at[f] = e.getUint32(n, !0)
    let r = this.h0 | 0,
      s = r,
      i = this.h1 | 0,
      o = i,
      c = this.h2 | 0,
      a = c,
      u = this.h3 | 0,
      d = u,
      h = this.h4 | 0,
      l = h
    for (let f = 0; f < 5; f++) {
      const y = 4 - f,
        m = Bi[f],
        v = Ai[f],
        A = yr[f],
        K = br[f],
        x = Ei[f],
        V = ki[f]
      for (let N = 0; N < 16; N++) {
        const G =
          (nt(r + On(f, i, c, u) + at[A[N]] + m, x[N]) +
            h) |
          0
        ;(r = h),
          (h = u),
          (u = nt(c, 10) | 0),
          (c = i),
          (i = G)
      }
      for (let N = 0; N < 16; N++) {
        const G =
          (nt(s + On(y, o, a, d) + at[K[N]] + v, V[N]) +
            l) |
          0
        ;(s = l),
          (l = d),
          (d = nt(a, 10) | 0),
          (a = o),
          (o = G)
      }
    }
    this.set(
      (this.h1 + c + d) | 0,
      (this.h2 + u + l) | 0,
      (this.h3 + h + s) | 0,
      (this.h4 + r + o) | 0,
      (this.h0 + i + a) | 0,
    )
  }
  roundClean() {
    ie(at)
  }
  destroy() {
    ;(this.destroyed = !0),
      ie(this.buffer),
      this.set(0, 0, 0, 0, 0)
  }
}
const Ii = Bt(
  () => new Si(),
) /*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) */
function pt(t) {
  return (
    t instanceof Uint8Array ||
    (ArrayBuffer.isView(t) &&
      t.constructor.name === "Uint8Array")
  )
}
function mr(t, e) {
  return Array.isArray(e)
    ? e.length === 0
      ? !0
      : t
        ? e.every((n) => typeof n == "string")
        : e.every((n) => Number.isSafeInteger(n))
    : !1
}
function _i(t) {
  if (typeof t != "function")
    throw new Error("function expected")
  return !0
}
function yt(t, e) {
  if (typeof e != "string")
    throw new Error(`${t}: string expected`)
  return !0
}
function Fe(t) {
  if (!Number.isSafeInteger(t))
    throw new Error(`invalid integer: ${t}`)
}
function bt(t) {
  if (!Array.isArray(t)) throw new Error("array expected")
}
function gt(t, e) {
  if (!mr(!0, e))
    throw new Error(`${t}: array of strings expected`)
}
function wr(t, e) {
  if (!mr(!1, e))
    throw new Error(`${t}: array of numbers expected`)
}
function un(...t) {
  const e = (i) => i,
    n = (i, o) => (c) => i(o(c)),
    r = t.map((i) => i.encode).reduceRight(n, e),
    s = t.map((i) => i.decode).reduce(n, e)
  return { encode: r, decode: s }
}
function vr(t) {
  const e = typeof t == "string" ? t.split("") : t,
    n = e.length
  gt("alphabet", e)
  const r = new Map(e.map((s, i) => [s, i]))
  return {
    encode: (s) => (
      bt(s),
      s.map((i) => {
        if (!Number.isSafeInteger(i) || i < 0 || i >= n)
          throw new Error(
            `alphabet.encode: digit index outside alphabet "${i}". Allowed: ${t}`,
          )
        return e[i]
      })
    ),
    decode: (s) => (
      bt(s),
      s.map((i) => {
        yt("alphabet.decode", i)
        const o = r.get(i)
        if (o === void 0)
          throw new Error(
            `Unknown letter: "${i}". Allowed: ${t}`,
          )
        return o
      })
    ),
  }
}
function xr(t = "") {
  return (
    yt("join", t),
    {
      encode: (e) => (gt("join.decode", e), e.join(t)),
      decode: (e) => (yt("join.decode", e), e.split(t)),
    }
  )
}
function Ui(t, e = "=") {
  return (
    Fe(t),
    yt("padding", e),
    {
      encode(n) {
        for (gt("padding.encode", n); (n.length * t) % 8; )
          n.push(e)
        return n
      },
      decode(n) {
        gt("padding.decode", n)
        let r = n.length
        if ((r * t) % 8)
          throw new Error(
            "padding: invalid, string should have whole number of bytes",
          )
        for (; r > 0 && n[r - 1] === e; r--)
          if (((r - 1) * t) % 8 === 0)
            throw new Error(
              "padding: invalid, string has too much padding",
            )
        return n.slice(0, r)
      },
    }
  )
}
function Mt(t, e, n) {
  if (e < 2)
    throw new Error(
      `convertRadix: invalid from=${e}, base cannot be less than 2`,
    )
  if (n < 2)
    throw new Error(
      `convertRadix: invalid to=${n}, base cannot be less than 2`,
    )
  if ((bt(t), !t.length)) return []
  let r = 0
  const s = [],
    i = Array.from(t, (c) => {
      if ((Fe(c), c < 0 || c >= e))
        throw new Error(`invalid integer: ${c}`)
      return c
    }),
    o = i.length
  for (;;) {
    let c = 0,
      a = !0
    for (let u = r; u < o; u++) {
      const d = i[u],
        h = e * c,
        l = h + d
      if (
        !Number.isSafeInteger(l) ||
        h / e !== c ||
        l - d !== h
      )
        throw new Error("convertRadix: carry overflow")
      const f = l / n
      c = l % n
      const y = Math.floor(f)
      if (
        ((i[u] = y),
        !Number.isSafeInteger(y) || y * n + c !== l)
      )
        throw new Error("convertRadix: carry overflow")
      if (a) y ? (a = !1) : (r = u)
      else continue
    }
    if ((s.push(c), a)) break
  }
  for (let c = 0; c < t.length - 1 && t[c] === 0; c++)
    s.push(0)
  return s.reverse()
}
const Er = (t, e) => (e === 0 ? t : Er(e, t % e)),
  mt = (t, e) => t + (e - Er(t, e)),
  jt = (() => {
    let t = []
    for (let e = 0; e < 40; e++) t.push(2 ** e)
    return t
  })()
function Ft(t, e, n, r) {
  if ((bt(t), e <= 0 || e > 32))
    throw new Error(`convertRadix2: wrong from=${e}`)
  if (n <= 0 || n > 32)
    throw new Error(`convertRadix2: wrong to=${n}`)
  if (mt(e, n) > 32)
    throw new Error(
      `convertRadix2: carry overflow from=${e} to=${n} carryBits=${mt(e, n)}`,
    )
  let s = 0,
    i = 0
  const o = jt[e],
    c = jt[n] - 1,
    a = []
  for (const u of t) {
    if ((Fe(u), u >= o))
      throw new Error(
        `convertRadix2: invalid data word=${u} from=${e}`,
      )
    if (((s = (s << e) | u), i + e > 32))
      throw new Error(
        `convertRadix2: carry overflow pos=${i} from=${e}`,
      )
    for (i += e; i >= n; i -= n)
      a.push(((s >> (i - n)) & c) >>> 0)
    const d = jt[i]
    if (d === void 0) throw new Error("invalid carry")
    s &= d - 1
  }
  if (((s = (s << (n - i)) & c), !r && i >= e))
    throw new Error("Excess padding")
  if (!r && s > 0) throw new Error(`Non-zero padding: ${s}`)
  return r && i > 0 && a.push(s >>> 0), a
}
function kr(t) {
  Fe(t)
  const e = 2 ** 8
  return {
    encode: (n) => {
      if (!pt(n))
        throw new Error(
          "radix.encode input should be Uint8Array",
        )
      return Mt(Array.from(n), e, t)
    },
    decode: (n) => (
      wr("radix.decode", n), Uint8Array.from(Mt(n, t, e))
    ),
  }
}
function Hi(t, e = !1) {
  if ((Fe(t), t <= 0 || t > 32))
    throw new Error("radix2: bits should be in (0..32]")
  if (mt(8, t) > 32 || mt(t, 8) > 32)
    throw new Error("radix2: carry overflow")
  return {
    encode: (n) => {
      if (!pt(n))
        throw new Error(
          "radix2.encode input should be Uint8Array",
        )
      return Ft(Array.from(n), 8, t, !e)
    },
    decode: (n) => (
      wr("radix2.decode", n),
      Uint8Array.from(Ft(n, t, 8, e))
    ),
  }
}
function Br(t, e) {
  return (
    Fe(t),
    _i(e),
    {
      encode(n) {
        if (!pt(n))
          throw new Error(
            "checksum.encode: input should be Uint8Array",
          )
        const r = e(n).slice(0, t),
          s = new Uint8Array(n.length + t)
        return s.set(n), s.set(r, n.length), s
      },
      decode(n) {
        if (!pt(n))
          throw new Error(
            "checksum.decode: input should be Uint8Array",
          )
        const r = n.slice(0, -t),
          s = n.slice(-t),
          i = e(r).slice(0, t)
        for (let o = 0; o < t; o++)
          if (i[o] !== s[o])
            throw new Error("Invalid checksum")
        return r
      },
    }
  )
}
const lt = {
    alphabet: vr,
    chain: un,
    checksum: Br,
    convertRadix: Mt,
    convertRadix2: Ft,
    radix: kr,
    radix2: Hi,
    join: xr,
    padding: Ui,
  },
  Oi = (t) => un(kr(58), vr(t), xr("")),
  Ki = Oi(
    "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz",
  ),
  Ri = (t) =>
    un(
      Br(4, (e) => t(t(e))),
      Ki,
    ) /*! scure-bip32 - MIT License (c) 2022 Patricio Palladino, Paul Miller (paulmillr.com) */
const ut = fe.ProjectivePoint,
  Lt = Ri(St)
function Kn(t) {
  Z(t)
  const e = t.length === 0 ? "0" : Ue(t)
  return BigInt("0x" + e)
}
function Ni(t) {
  if (typeof t != "bigint")
    throw new Error("bigint expected")
  return Ge(t.toString(16).padStart(64, "0"))
}
const qi = tn("Bitcoin seed"),
  Ct = { private: 76066276, public: 76067358 },
  Tt = 2147483648,
  ji = (t) => Ii(St(t)),
  Li = (t) => _e(t).getUint32(0, !1),
  ft = (t) => {
    if (
      !Number.isSafeInteger(t) ||
      t < 0 ||
      t > 2 ** 32 - 1
    )
      throw new Error(
        "invalid number, should be from 0 to 2**32-1, got " +
          t,
      )
    const e = new Uint8Array(4)
    return _e(e).setUint32(0, t, !1), e
  }
class Ce {
  get fingerprint() {
    if (!this.pubHash) throw new Error("No publicKey set!")
    return Li(this.pubHash)
  }
  get identifier() {
    return this.pubHash
  }
  get pubKeyHash() {
    return this.pubHash
  }
  get privateKey() {
    return this.privKeyBytes || null
  }
  get publicKey() {
    return this.pubKey || null
  }
  get privateExtendedKey() {
    const e = this.privateKey
    if (!e) throw new Error("No private key")
    return Lt.encode(
      this.serialize(
        this.versions.private,
        ne(new Uint8Array([0]), e),
      ),
    )
  }
  get publicExtendedKey() {
    if (!this.pubKey) throw new Error("No public key")
    return Lt.encode(
      this.serialize(this.versions.public, this.pubKey),
    )
  }
  static fromMasterSeed(e, n = Ct) {
    if ((Z(e), 8 * e.length < 128 || 8 * e.length > 512))
      throw new Error(
        "HDKey: seed length must be between 128 and 512 bits; 256 bits is advised, got " +
          e.length,
      )
    const r = Xe(Vt, qi, e)
    return new Ce({
      versions: n,
      chainCode: r.slice(32),
      privateKey: r.slice(0, 32),
    })
  }
  static fromExtendedKey(e, n = Ct) {
    const r = Lt.decode(e),
      s = _e(r),
      i = s.getUint32(0, !1),
      o = {
        versions: n,
        depth: r[4],
        parentFingerprint: s.getUint32(5, !1),
        index: s.getUint32(9, !1),
        chainCode: r.slice(13, 45),
      },
      c = r.slice(45),
      a = c[0] === 0
    if (i !== n[a ? "private" : "public"])
      throw new Error("Version mismatch")
    return a
      ? new Ce({ ...o, privateKey: c.slice(1) })
      : new Ce({ ...o, publicKey: c })
  }
  static fromJSON(e) {
    return Ce.fromExtendedKey(e.xpriv)
  }
  constructor(e) {
    if (
      ((this.depth = 0),
      (this.index = 0),
      (this.chainCode = null),
      (this.parentFingerprint = 0),
      !e || typeof e != "object")
    )
      throw new Error(
        "HDKey.constructor must not be called directly",
      )
    if (
      ((this.versions = e.versions || Ct),
      (this.depth = e.depth || 0),
      (this.chainCode = e.chainCode || null),
      (this.index = e.index || 0),
      (this.parentFingerprint = e.parentFingerprint || 0),
      !this.depth && (this.parentFingerprint || this.index))
    )
      throw new Error(
        "HDKey: zero depth with non-zero index/parent fingerprint",
      )
    if (e.publicKey && e.privateKey)
      throw new Error(
        "HDKey: publicKey and privateKey at same time.",
      )
    if (e.privateKey) {
      if (!fe.utils.isValidPrivateKey(e.privateKey))
        throw new Error("Invalid private key")
      ;(this.privKey =
        typeof e.privateKey == "bigint"
          ? e.privateKey
          : Kn(e.privateKey)),
        (this.privKeyBytes = Ni(this.privKey)),
        (this.pubKey = fe.getPublicKey(e.privateKey, !0))
    } else if (e.publicKey)
      this.pubKey = ut.fromHex(e.publicKey).toRawBytes(!0)
    else
      throw new Error(
        "HDKey: no public or private key provided",
      )
    this.pubHash = ji(this.pubKey)
  }
  derive(e) {
    if (!/^[mM]'?/.test(e))
      throw new Error('Path must start with "m" or "M"')
    if (/^[mM]'?$/.test(e)) return this
    const n = e.replace(/^[mM]'?\//, "").split("/")
    let r = this
    for (const s of n) {
      const i = /^(\d+)('?)$/.exec(s),
        o = i && i[1]
      if (!i || i.length !== 3 || typeof o != "string")
        throw new Error("invalid child index: " + s)
      let c = +o
      if (!Number.isSafeInteger(c) || c >= Tt)
        throw new Error("Invalid index")
      i[2] === "'" && (c += Tt), (r = r.deriveChild(c))
    }
    return r
  }
  deriveChild(e) {
    if (!this.pubKey || !this.chainCode)
      throw new Error("No publicKey or chainCode set")
    let n = ft(e)
    if (e >= Tt) {
      const c = this.privateKey
      if (!c)
        throw new Error(
          "Could not derive hardened child key",
        )
      n = ne(new Uint8Array([0]), c, n)
    } else n = ne(this.pubKey, n)
    const r = Xe(Vt, this.chainCode, n),
      s = Kn(r.slice(0, 32)),
      i = r.slice(32)
    if (!fe.utils.isValidPrivateKey(s))
      throw new Error("Tweak bigger than curve order")
    const o = {
      versions: this.versions,
      chainCode: i,
      depth: this.depth + 1,
      parentFingerprint: this.fingerprint,
      index: e,
    }
    try {
      if (this.privateKey) {
        const c = te(this.privKey + s, fe.CURVE.n)
        if (!fe.utils.isValidPrivateKey(c))
          throw new Error(
            "The tweak was out of range or the resulted private key is invalid",
          )
        o.privateKey = c
      } else {
        const c = ut
          .fromHex(this.pubKey)
          .add(ut.fromPrivateKey(s))
        if (c.equals(ut.ZERO))
          throw new Error(
            "The tweak was equal to negative P, which made the result key invalid",
          )
        o.publicKey = c.toRawBytes(!0)
      }
      return new Ce(o)
    } catch {
      return this.deriveChild(e + 1)
    }
  }
  sign(e) {
    if (!this.privateKey)
      throw new Error("No privateKey set!")
    return (
      Z(e, 32), fe.sign(e, this.privKey).toCompactRawBytes()
    )
  }
  verify(e, n) {
    if ((Z(e, 32), Z(n, 64), !this.publicKey))
      throw new Error("No publicKey set!")
    let r
    try {
      r = fe.Signature.fromCompact(n)
    } catch {
      return !1
    }
    return fe.verify(r, e, this.publicKey)
  }
  wipePrivateData() {
    return (
      (this.privKey = void 0),
      this.privKeyBytes &&
        (this.privKeyBytes.fill(0),
        (this.privKeyBytes = void 0)),
      this
    )
  }
  toJSON() {
    return {
      xpriv: this.privateExtendedKey,
      xpub: this.publicExtendedKey,
    }
  }
  serialize(e, n) {
    if (!this.chainCode) throw new Error("No chainCode set")
    return (
      Z(n, 33),
      ne(
        ft(e),
        new Uint8Array([this.depth]),
        ft(this.parentFingerprint),
        ft(this.index),
        this.chainCode,
        n,
      )
    )
  }
}
const Ci = BigInt(0),
  Ye = BigInt(1),
  Ti = BigInt(2),
  $i = BigInt(7),
  zi = BigInt(256),
  Vi = BigInt(113),
  Ar = [],
  Sr = [],
  Ir = []
for (let t = 0, e = Ye, n = 1, r = 0; t < 24; t++) {
  ;([n, r] = [r, (2 * n + 3 * r) % 5]),
    Ar.push(2 * (5 * r + n)),
    Sr.push((((t + 1) * (t + 2)) / 2) % 64)
  let s = Ci
  for (let i = 0; i < 7; i++)
    (e = ((e << Ye) ^ ((e >> $i) * Vi)) % zi),
      e & Ti && (s ^= Ye << ((Ye << BigInt(i)) - Ye))
  Ir.push(s)
}
const _r = ir(Ir, !0),
  Zi = _r[0],
  Di = _r[1],
  Rn = (t, e, n) => (n > 32 ? Vs(t, e, n) : $s(t, e, n)),
  Nn = (t, e, n) => (n > 32 ? Zs(t, e, n) : zs(t, e, n))
function Mi(t, e = 24) {
  const n = new Uint32Array(10)
  for (let r = 24 - e; r < 24; r++) {
    for (let o = 0; o < 10; o++)
      n[o] =
        t[o] ^ t[o + 10] ^ t[o + 20] ^ t[o + 30] ^ t[o + 40]
    for (let o = 0; o < 10; o += 2) {
      const c = (o + 8) % 10,
        a = (o + 2) % 10,
        u = n[a],
        d = n[a + 1],
        h = Rn(u, d, 1) ^ n[c],
        l = Nn(u, d, 1) ^ n[c + 1]
      for (let f = 0; f < 50; f += 10)
        (t[o + f] ^= h), (t[o + f + 1] ^= l)
    }
    let s = t[2],
      i = t[3]
    for (let o = 0; o < 24; o++) {
      const c = Sr[o],
        a = Rn(s, i, c),
        u = Nn(s, i, c),
        d = Ar[o]
      ;(s = t[d]),
        (i = t[d + 1]),
        (t[d] = a),
        (t[d + 1] = u)
    }
    for (let o = 0; o < 50; o += 10) {
      for (let c = 0; c < 10; c++) n[c] = t[o + c]
      for (let c = 0; c < 10; c++)
        t[o + c] ^= ~n[(c + 2) % 10] & n[(c + 4) % 10]
    }
    ;(t[0] ^= Zi[r]), (t[1] ^= Di[r])
  }
  ie(n)
}
class fn extends nn {
  constructor(e, n, r, s = !1, i = 24) {
    if (
      (super(),
      (this.pos = 0),
      (this.posOut = 0),
      (this.finished = !1),
      (this.destroyed = !1),
      (this.enableXOF = !1),
      (this.blockLen = e),
      (this.suffix = n),
      (this.outputLen = r),
      (this.enableXOF = s),
      (this.rounds = i),
      Ee(r),
      !(0 < e && e < 200))
    )
      throw new Error(
        "only keccak-f1600 function is supported",
      )
    ;(this.state = new Uint8Array(200)),
      (this.state32 = ms(this.state))
  }
  clone() {
    return this._cloneInto()
  }
  keccak() {
    gn(this.state32),
      Mi(this.state32, this.rounds),
      gn(this.state32),
      (this.posOut = 0),
      (this.pos = 0)
  }
  update(e) {
    Ze(this), (e = kt(e)), Z(e)
    const { blockLen: n, state: r } = this,
      s = e.length
    for (let i = 0; i < s; ) {
      const o = Math.min(n - this.pos, s - i)
      for (let c = 0; c < o; c++) r[this.pos++] ^= e[i++]
      this.pos === n && this.keccak()
    }
    return this
  }
  finish() {
    if (this.finished) return
    this.finished = !0
    const {
      state: e,
      suffix: n,
      pos: r,
      blockLen: s,
    } = this
    ;(e[r] ^= n),
      (n & 128) !== 0 && r === s - 1 && this.keccak(),
      (e[s - 1] ^= 128),
      this.keccak()
  }
  writeInto(e) {
    Ze(this, !1), Z(e), this.finish()
    const n = this.state,
      { blockLen: r } = this
    for (let s = 0, i = e.length; s < i; ) {
      this.posOut >= r && this.keccak()
      const o = Math.min(r - this.posOut, i - s)
      e.set(n.subarray(this.posOut, this.posOut + o), s),
        (this.posOut += o),
        (s += o)
    }
    return e
  }
  xofInto(e) {
    if (!this.enableXOF)
      throw new Error(
        "XOF is not possible for this instance",
      )
    return this.writeInto(e)
  }
  xof(e) {
    return Ee(e), this.xofInto(new Uint8Array(e))
  }
  digestInto(e) {
    if ((zn(e, this), this.finished))
      throw new Error("digest() was already called")
    return this.writeInto(e), this.destroy(), e
  }
  digest() {
    return this.digestInto(new Uint8Array(this.outputLen))
  }
  destroy() {
    ;(this.destroyed = !0), ie(this.state)
  }
  _cloneInto(e) {
    const {
      blockLen: n,
      suffix: r,
      outputLen: s,
      rounds: i,
      enableXOF: o,
    } = this
    return (
      e || (e = new fn(n, r, s, o, i)),
      e.state32.set(this.state32),
      (e.pos = this.pos),
      (e.posOut = this.posOut),
      (e.finished = this.finished),
      (e.rounds = i),
      (e.suffix = r),
      (e.outputLen = s),
      (e.enableXOF = o),
      (e.destroyed = this.destroyed),
      e
    )
  }
}
const Fi = (t, e, n) => Bt(() => new fn(e, t, n)),
  Bo = Fi(
    1,
    136,
    256 / 8,
  ) /*! noble-secp256k1 - MIT License (c) 2019 Paul Miller (paulmillr.com) */
const Yi = {
    p: 0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2fn,
    n: 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n,
    b: 7n,
    Gx: 0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798n,
    Gy: 0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8n,
  },
  { p: He, n: be, Gx: Pi, Gy: Gi, b: Ur } = Yi,
  re = 32,
  Ve = 64,
  z = (t = "") => {
    throw new Error(t)
  },
  Hr = (t) => typeof t == "bigint",
  Or = (t) => typeof t == "string",
  Xi = (t) =>
    t instanceof Uint8Array ||
    (ArrayBuffer.isView(t) &&
      t.constructor.name === "Uint8Array"),
  Ke = (t, e) =>
    !Xi(t) ||
    (typeof e == "number" && e > 0 && t.length !== e)
      ? z("Uint8Array expected")
      : t,
  Oe = (t) => new Uint8Array(t),
  Wi = (t) => Uint8Array.from(t),
  Kr = (t, e) => t.toString(16).padStart(e, "0"),
  It = (t) =>
    Array.from(Ke(t))
      .map((e) => Kr(e, 2))
      .join(""),
  ue = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 },
  qn = (t) => {
    if (t >= ue._0 && t <= ue._9) return t - ue._0
    if (t >= ue.A && t <= ue.F) return t - (ue.A - 10)
    if (t >= ue.a && t <= ue.f) return t - (ue.a - 10)
  },
  dn = (t) => {
    const e = "hex invalid"
    if (!Or(t)) return z(e)
    const n = t.length,
      r = n / 2
    if (n % 2) return z(e)
    const s = Oe(r)
    for (let i = 0, o = 0; i < r; i++, o += 2) {
      const c = qn(t.charCodeAt(o)),
        a = qn(t.charCodeAt(o + 1))
      if (c === void 0 || a === void 0) return z(e)
      s[i] = c * 16 + a
    }
    return s
  },
  Re = (t, e) => Ke(Or(t) ? dn(t) : Wi(Ke(t)), e),
  Rr = () => globalThis?.crypto,
  Ji = () =>
    Rr()?.subtle ?? z("crypto.subtle must be defined"),
  Ne = (...t) => {
    const e = Oe(t.reduce((r, s) => r + Ke(s).length, 0))
    let n = 0
    return (
      t.forEach((r) => {
        e.set(r, n), (n += r.length)
      }),
      e
    )
  },
  Nr = (t = re) => Rr().getRandomValues(Oe(t)),
  Me = BigInt,
  Qe = (t, e, n, r = "bad number: out of range") =>
    Hr(t) && e <= t && t < n ? t : z(r),
  E = (t, e = He) => {
    const n = t % e
    return n >= 0n ? n : e + n
  },
  he = (t) => E(t, be),
  _t = (t, e) => {
    ;(t === 0n || e <= 0n) &&
      z("no inverse n=" + t + " mod=" + e)
    let n = E(t, e),
      r = e,
      s = 0n,
      i = 1n
    for (; n !== 0n; ) {
      const o = r / n,
        c = r % n,
        a = s - i * o
      ;(r = n), (n = c), (s = i), (i = a)
    }
    return r === 1n ? E(s, e) : z("no inverse")
  },
  Qi = (t) => {
    const e = ao[t]
    return (
      typeof e != "function" &&
        z("hashes." + t + " not set"),
      e
    )
  },
  jn = (t) => (t instanceof Q ? t : z("Point expected")),
  qr = (t) => E(E(t * t) * t + Ur),
  Ln = (t) => Qe(t, 0n, He),
  Pe = (t) => Qe(t, 1n, He),
  Yt = (t) => Qe(t, 1n, be),
  Pt = (t) => (t & 1n) === 0n,
  wt = (t) => Uint8Array.of(t),
  jr = (t) => wt(Pt(t) ? 2 : 3),
  eo = (t) => {
    const e = qr(Pe(t))
    let n = 1n
    for (let r = e, s = (He + 1n) / 4n; s > 0n; s >>= 1n)
      s & 1n && (n = (n * r) % He), (r = (r * r) % He)
    return E(n * n) === e ? n : z("sqrt invalid")
  }
class Q {
  static BASE
  static ZERO
  px
  py
  pz
  constructor(e, n, r) {
    ;(this.px = Ln(e)),
      (this.py = Pe(n)),
      (this.pz = Ln(r)),
      Object.freeze(this)
  }
  static fromBytes(e) {
    Ke(e)
    let n
    const r = e[0],
      s = e.subarray(1),
      i = vt(s, 0, re),
      o = e.length
    if (o === re + 1 && [2, 3].includes(r)) {
      let c = eo(i)
      const a = Pt(c)
      Pt(Me(r)) !== a && (c = E(-c)), (n = new Q(i, c, 1n))
    }
    return (
      o === Ve + 1 &&
        r === 4 &&
        (n = new Q(i, vt(s, re, Ve), 1n)),
      n ? n.assertValidity() : z("bad point: not on curve")
    )
  }
  equals(e) {
    const { px: n, py: r, pz: s } = this,
      { px: i, py: o, pz: c } = jn(e),
      a = E(n * c),
      u = E(i * s),
      d = E(r * c),
      h = E(o * s)
    return a === u && d === h
  }
  is0() {
    return this.equals(Be)
  }
  negate() {
    return new Q(this.px, E(-this.py), this.pz)
  }
  double() {
    return this.add(this)
  }
  add(e) {
    const { px: n, py: r, pz: s } = this,
      { px: i, py: o, pz: c } = jn(e),
      a = 0n,
      u = Ur
    let d = 0n,
      h = 0n,
      l = 0n
    const f = E(u * 3n)
    let y = E(n * i),
      m = E(r * o),
      v = E(s * c),
      A = E(n + r),
      K = E(i + o)
    ;(A = E(A * K)),
      (K = E(y + m)),
      (A = E(A - K)),
      (K = E(n + s))
    let x = E(i + c)
    return (
      (K = E(K * x)),
      (x = E(y + v)),
      (K = E(K - x)),
      (x = E(r + s)),
      (d = E(o + c)),
      (x = E(x * d)),
      (d = E(m + v)),
      (x = E(x - d)),
      (l = E(a * K)),
      (d = E(f * v)),
      (l = E(d + l)),
      (d = E(m - l)),
      (l = E(m + l)),
      (h = E(d * l)),
      (m = E(y + y)),
      (m = E(m + y)),
      (v = E(a * v)),
      (K = E(f * K)),
      (m = E(m + v)),
      (v = E(y - v)),
      (v = E(a * v)),
      (K = E(K + v)),
      (y = E(m * K)),
      (h = E(h + y)),
      (y = E(x * K)),
      (d = E(A * d)),
      (d = E(d - y)),
      (y = E(A * m)),
      (l = E(x * l)),
      (l = E(l + y)),
      new Q(d, h, l)
    )
  }
  multiply(e, n = !0) {
    if (!n && e === 0n) return Be
    if ((Yt(e), e === 1n)) return this
    if (this.equals(ye)) return fo(e).p
    let r = Be,
      s = ye
    for (let i = this; e > 0n; i = i.double(), e >>= 1n)
      e & 1n ? (r = r.add(i)) : n && (s = s.add(i))
    return r
  }
  toAffine() {
    const { px: e, py: n, pz: r } = this
    if (this.equals(Be)) return { x: 0n, y: 0n }
    if (r === 1n) return { x: e, y: n }
    const s = _t(r, He)
    return (
      E(r * s) !== 1n && z("inverse invalid"),
      { x: E(e * s), y: E(n * s) }
    )
  }
  assertValidity() {
    const { x: e, y: n } = this.toAffine()
    return (
      Pe(e),
      Pe(n),
      E(n * n) === qr(e)
        ? this
        : z("bad point: not on curve")
    )
  }
  toBytes(e = !0) {
    const { x: n, y: r } = this.assertValidity().toAffine(),
      s = ke(n)
    return e ? Ne(jr(r), s) : Ne(wt(4), s, ke(r))
  }
  static fromAffine(e) {
    const { x: n, y: r } = e
    return n === 0n && r === 0n ? Be : new Q(n, r, 1n)
  }
  toHex(e) {
    return It(this.toBytes(e))
  }
  static fromPrivateKey(e) {
    return ye.multiply(hn(e))
  }
  static fromHex(e) {
    return Q.fromBytes(Re(e))
  }
  get x() {
    return this.toAffine().x
  }
  get y() {
    return this.toAffine().y
  }
  toRawBytes(e) {
    return this.toBytes(e)
  }
}
const ye = new Q(Pi, Gi, 1n),
  Be = new Q(0n, 1n, 0n)
Q.BASE = ye
Q.ZERO = Be
const to = (t, e, n) =>
    ye
      .multiply(e, !1)
      .add(t.multiply(n, !1))
      .assertValidity(),
  et = (t) => Me("0x" + (It(t) || "0")),
  vt = (t, e, n) => et(t.subarray(e, n)),
  no = 2n ** 256n,
  ke = (t) => dn(Kr(Qe(t, 0n, no), Ve)),
  hn = (t) => {
    const e = Hr(t) ? t : et(Re(t, re))
    return Qe(e, 1n, be, "private key invalid 3")
  },
  Gt = (t) => t > be >> 1n,
  Ao = (t, e = !0) => ye.multiply(hn(t)).toBytes(e)
class $e {
  r
  s
  recovery
  constructor(e, n, r) {
    ;(this.r = Yt(e)),
      (this.s = Yt(n)),
      r != null && (this.recovery = r),
      Object.freeze(this)
  }
  static fromBytes(e) {
    Ke(e, Ve)
    const n = vt(e, 0, re),
      r = vt(e, re, Ve)
    return new $e(n, r)
  }
  toBytes() {
    const { r: e, s: n } = this
    return Ne(ke(e), ke(n))
  }
  addRecoveryBit(e) {
    return new $e(this.r, this.s, e)
  }
  hasHighS() {
    return Gt(this.s)
  }
  toCompactRawBytes() {
    return this.toBytes()
  }
  toCompactHex() {
    return It(this.toBytes())
  }
  recoverPublicKey(e) {
    return io(this, e)
  }
  static fromCompact(e) {
    return $e.fromBytes(Re(e, Ve))
  }
  assertValidity() {
    return this
  }
  normalizeS() {
    const { r: e, s: n, recovery: r } = this
    return Gt(n) ? new $e(e, he(-n), r) : this
  }
}
const Lr = (t) => {
    const e = t.length * 8 - 256
    e > 1024 && z("msg invalid")
    const n = et(t)
    return e > 0 ? n >> Me(e) : n
  },
  Cr = (t) => he(Lr(Ke(t))),
  Tr = { lowS: !0 },
  ro = (t, e, n = Tr) => {
    ;["der", "recovered", "canonical"].some(
      (l) => l in n,
    ) && z("option not supported")
    let { lowS: r, extraEntropy: s } = n
    r == null && (r = !0)
    const i = ke,
      o = Cr(Re(t)),
      c = i(o),
      a = hn(e),
      u = [i(a), c]
    s && u.push(s === !0 ? Nr(re) : Re(s))
    const d = o,
      h = (l) => {
        const f = Lr(l)
        if (!(1n <= f && f < be)) return
        const y = ye.multiply(f).toAffine(),
          m = he(y.x)
        if (m === 0n) return
        const v = _t(f, be),
          A = he(v * he(d + he(a * m)))
        if (A === 0n) return
        let K = A,
          x = (y.x === m ? 0 : 2) | Number(y.y & 1n)
        return (
          r && Gt(A) && ((K = he(-A)), (x ^= 1)),
          new $e(m, K, x)
        )
      }
    return { seed: Ne(...u), k2sig: h }
  },
  so = (t) => {
    let e = Oe(re),
      n = Oe(re),
      r = 0
    const s = Oe(0),
      i = () => {
        e.fill(1), n.fill(0), (r = 0)
      },
      o = 1e3,
      c = "drbg: tried 1000 values"
    {
      const a = (...h) => Qi("hmacSha256Sync")(n, e, ...h),
        u = (h = s) => {
          ;(n = a(wt(0), h)),
            (e = a()),
            h.length !== 0 && ((n = a(wt(1), h)), (e = a()))
        },
        d = () => (r++ >= o && z(c), (e = a()), e)
      return (h, l) => {
        i(), u(h)
        let f
        for (; !(f = l(d())); ) u()
        return i(), f
      }
    }
  },
  So = (t, e, n = Tr) => {
    const { seed: r, k2sig: s } = ro(t, e, n)
    return so()(r, s)
  },
  io = (t, e) => {
    const { r: n, s: r, recovery: s } = t
    ;[0, 1, 2, 3].includes(s) || z("recovery id invalid")
    const i = Cr(Re(e, re)),
      o = s === 2 || s === 3 ? n + be : n
    Pe(o)
    const c = jr(Me(s)),
      a = Ne(c, ke(o)),
      u = Q.fromBytes(a),
      d = _t(o, be),
      h = he(-i * d),
      l = he(r * d)
    return to(u, h, l)
  },
  oo = (t) => {
    ;(t = Re(t)),
      (t.length < re + 8 || t.length > 1024) &&
        z("expected 40-1024b")
    const e = E(et(t), be - 1n)
    return ke(e + 1n)
  },
  co = "SHA-256",
  ao = {
    hexToBytes: dn,
    bytesToHex: It,
    concatBytes: Ne,
    bytesToNumberBE: et,
    numberToBytesBE: ke,
    mod: E,
    invert: _t,
    hmacSha256Async: async (t, ...e) => {
      const n = Ji(),
        r = "HMAC",
        s = await n.importKey(
          "raw",
          t,
          { name: r, hash: { name: co } },
          !1,
          ["sign"],
        )
      return Oe(await n.sign(r, s, Ne(...e)))
    },
    hmacSha256Sync: void 0,
    hashToPrivateKey: oo,
    randomBytes: Nr,
  },
  xt = 8,
  lo = 256,
  $r = Math.ceil(lo / xt) + 1,
  Xt = 2 ** (xt - 1),
  uo = () => {
    const t = []
    let e = ye,
      n = e
    for (let r = 0; r < $r; r++) {
      ;(n = e), t.push(n)
      for (let s = 1; s < Xt; s++) (n = n.add(e)), t.push(n)
      e = n.double()
    }
    return t
  }
let Cn
const Tn = (t, e) => {
    const n = e.negate()
    return t ? n : e
  },
  fo = (t) => {
    const e = Cn || (Cn = uo())
    let n = Be,
      r = ye
    const s = 2 ** xt,
      i = s,
      o = Me(s - 1),
      c = Me(xt)
    for (let a = 0; a < $r; a++) {
      let u = Number(t & o)
      ;(t >>= c), u > Xt && ((u -= i), (t += 1n))
      const d = a * Xt,
        h = d,
        l = d + Math.abs(u) - 1,
        f = a % 2 !== 0,
        y = u < 0
      u === 0
        ? (r = r.add(Tn(f, e[h])))
        : (n = n.add(Tn(y, e[l])))
    }
    return { p: n, f: r }
  }
function ho(t, e, n, r) {
  en(t)
  const s = ks({ dkLen: 32, asyncTick: 10 }, r),
    { c: i, dkLen: o, asyncTick: c } = s
  if ((Ee(i), Ee(o), Ee(c), i < 1))
    throw new Error("iterations (c) should be >= 1")
  const a = wn(e),
    u = wn(n),
    d = new Uint8Array(o),
    h = Xe.create(t, a),
    l = h._cloneInto().update(u)
  return {
    c: i,
    dkLen: o,
    asyncTick: c,
    DK: d,
    PRF: h,
    PRFSalt: l,
  }
}
function po(t, e, n, r, s) {
  return (
    t.destroy(), e.destroy(), r && r.destroy(), ie(s), n
  )
}
function yo(t, e, n, r) {
  const {
    c: s,
    dkLen: i,
    DK: o,
    PRF: c,
    PRFSalt: a,
  } = ho(t, e, n, r)
  let u
  const d = new Uint8Array(4),
    h = _e(d),
    l = new Uint8Array(c.outputLen)
  for (let f = 1, y = 0; y < i; f++, y += c.outputLen) {
    const m = o.subarray(y, y + c.outputLen)
    h.setInt32(0, f, !1),
      (u = a._cloneInto(u)).update(d).digestInto(l),
      m.set(l.subarray(0, m.length))
    for (let v = 1; v < s; v++) {
      c._cloneInto(u).update(l).digestInto(l)
      for (let A = 0; A < m.length; A++) m[A] ^= l[A]
    }
  }
  return po(c, a, o, u, l)
} /*! scure-bip39 - MIT License (c) 2022 Patricio Palladino, Paul Miller (paulmillr.com) */
function zr(t) {
  if (typeof t != "string")
    throw new TypeError(
      "invalid mnemonic type: " + typeof t,
    )
  return t.normalize("NFKD")
}
function Vr(t) {
  const e = zr(t),
    n = e.split(" ")
  if (![12, 15, 18, 21, 24].includes(n.length))
    throw new Error("Invalid mnemonic")
  return { nfkd: e, words: n }
}
function bo(t) {
  Z(t, 16, 20, 24, 28, 32)
}
const go = (t) => {
  const e = 8 - t.length / 4
  return new Uint8Array([(St(t)[0] >> e) << e])
}
function mo(t) {
  if (
    !Array.isArray(t) ||
    t.length !== 2048 ||
    typeof t[0] != "string"
  )
    throw new Error(
      "Wordlist: expected array of 2048 strings",
    )
  return (
    t.forEach((e) => {
      if (typeof e != "string")
        throw new Error(
          "wordlist: non-string element: " + e,
        )
    }),
    lt.chain(
      lt.checksum(1, go),
      lt.radix2(11, !0),
      lt.alphabet(t),
    )
  )
}
function wo(t, e) {
  const { words: n } = Vr(t),
    r = mo(e).decode(n)
  return bo(r), r
}
function Io(t, e) {
  try {
    wo(t, e)
  } catch {
    return !1
  }
  return !0
}
const vo = (t) => zr("mnemonic" + t)
function _o(t, e = "") {
  return yo(Vt, Vr(t).nfkd, vo(e), { c: 2048, dkLen: 64 })
}
const Uo = `abandon
ability
able
about
above
absent
absorb
abstract
absurd
abuse
access
accident
account
accuse
achieve
acid
acoustic
acquire
across
act
action
actor
actress
actual
adapt
add
addict
address
adjust
admit
adult
advance
advice
aerobic
affair
afford
afraid
again
age
agent
agree
ahead
aim
air
airport
aisle
alarm
album
alcohol
alert
alien
all
alley
allow
almost
alone
alpha
already
also
alter
always
amateur
amazing
among
amount
amused
analyst
anchor
ancient
anger
angle
angry
animal
ankle
announce
annual
another
answer
antenna
antique
anxiety
any
apart
apology
appear
apple
approve
april
arch
arctic
area
arena
argue
arm
armed
armor
army
around
arrange
arrest
arrive
arrow
art
artefact
artist
artwork
ask
aspect
assault
asset
assist
assume
asthma
athlete
atom
attack
attend
attitude
attract
auction
audit
august
aunt
author
auto
autumn
average
avocado
avoid
awake
aware
away
awesome
awful
awkward
axis
baby
bachelor
bacon
badge
bag
balance
balcony
ball
bamboo
banana
banner
bar
barely
bargain
barrel
base
basic
basket
battle
beach
bean
beauty
because
become
beef
before
begin
behave
behind
believe
below
belt
bench
benefit
best
betray
better
between
beyond
bicycle
bid
bike
bind
biology
bird
birth
bitter
black
blade
blame
blanket
blast
bleak
bless
blind
blood
blossom
blouse
blue
blur
blush
board
boat
body
boil
bomb
bone
bonus
book
boost
border
boring
borrow
boss
bottom
bounce
box
boy
bracket
brain
brand
brass
brave
bread
breeze
brick
bridge
brief
bright
bring
brisk
broccoli
broken
bronze
broom
brother
brown
brush
bubble
buddy
budget
buffalo
build
bulb
bulk
bullet
bundle
bunker
burden
burger
burst
bus
business
busy
butter
buyer
buzz
cabbage
cabin
cable
cactus
cage
cake
call
calm
camera
camp
can
canal
cancel
candy
cannon
canoe
canvas
canyon
capable
capital
captain
car
carbon
card
cargo
carpet
carry
cart
case
cash
casino
castle
casual
cat
catalog
catch
category
cattle
caught
cause
caution
cave
ceiling
celery
cement
census
century
cereal
certain
chair
chalk
champion
change
chaos
chapter
charge
chase
chat
cheap
check
cheese
chef
cherry
chest
chicken
chief
child
chimney
choice
choose
chronic
chuckle
chunk
churn
cigar
cinnamon
circle
citizen
city
civil
claim
clap
clarify
claw
clay
clean
clerk
clever
click
client
cliff
climb
clinic
clip
clock
clog
close
cloth
cloud
clown
club
clump
cluster
clutch
coach
coast
coconut
code
coffee
coil
coin
collect
color
column
combine
come
comfort
comic
common
company
concert
conduct
confirm
congress
connect
consider
control
convince
cook
cool
copper
copy
coral
core
corn
correct
cost
cotton
couch
country
couple
course
cousin
cover
coyote
crack
cradle
craft
cram
crane
crash
crater
crawl
crazy
cream
credit
creek
crew
cricket
crime
crisp
critic
crop
cross
crouch
crowd
crucial
cruel
cruise
crumble
crunch
crush
cry
crystal
cube
culture
cup
cupboard
curious
current
curtain
curve
cushion
custom
cute
cycle
dad
damage
damp
dance
danger
daring
dash
daughter
dawn
day
deal
debate
debris
decade
december
decide
decline
decorate
decrease
deer
defense
define
defy
degree
delay
deliver
demand
demise
denial
dentist
deny
depart
depend
deposit
depth
deputy
derive
describe
desert
design
desk
despair
destroy
detail
detect
develop
device
devote
diagram
dial
diamond
diary
dice
diesel
diet
differ
digital
dignity
dilemma
dinner
dinosaur
direct
dirt
disagree
discover
disease
dish
dismiss
disorder
display
distance
divert
divide
divorce
dizzy
doctor
document
dog
doll
dolphin
domain
donate
donkey
donor
door
dose
double
dove
draft
dragon
drama
drastic
draw
dream
dress
drift
drill
drink
drip
drive
drop
drum
dry
duck
dumb
dune
during
dust
dutch
duty
dwarf
dynamic
eager
eagle
early
earn
earth
easily
east
easy
echo
ecology
economy
edge
edit
educate
effort
egg
eight
either
elbow
elder
electric
elegant
element
elephant
elevator
elite
else
embark
embody
embrace
emerge
emotion
employ
empower
empty
enable
enact
end
endless
endorse
enemy
energy
enforce
engage
engine
enhance
enjoy
enlist
enough
enrich
enroll
ensure
enter
entire
entry
envelope
episode
equal
equip
era
erase
erode
erosion
error
erupt
escape
essay
essence
estate
eternal
ethics
evidence
evil
evoke
evolve
exact
example
excess
exchange
excite
exclude
excuse
execute
exercise
exhaust
exhibit
exile
exist
exit
exotic
expand
expect
expire
explain
expose
express
extend
extra
eye
eyebrow
fabric
face
faculty
fade
faint
faith
fall
false
fame
family
famous
fan
fancy
fantasy
farm
fashion
fat
fatal
father
fatigue
fault
favorite
feature
february
federal
fee
feed
feel
female
fence
festival
fetch
fever
few
fiber
fiction
field
figure
file
film
filter
final
find
fine
finger
finish
fire
firm
first
fiscal
fish
fit
fitness
fix
flag
flame
flash
flat
flavor
flee
flight
flip
float
flock
floor
flower
fluid
flush
fly
foam
focus
fog
foil
fold
follow
food
foot
force
forest
forget
fork
fortune
forum
forward
fossil
foster
found
fox
fragile
frame
frequent
fresh
friend
fringe
frog
front
frost
frown
frozen
fruit
fuel
fun
funny
furnace
fury
future
gadget
gain
galaxy
gallery
game
gap
garage
garbage
garden
garlic
garment
gas
gasp
gate
gather
gauge
gaze
general
genius
genre
gentle
genuine
gesture
ghost
giant
gift
giggle
ginger
giraffe
girl
give
glad
glance
glare
glass
glide
glimpse
globe
gloom
glory
glove
glow
glue
goat
goddess
gold
good
goose
gorilla
gospel
gossip
govern
gown
grab
grace
grain
grant
grape
grass
gravity
great
green
grid
grief
grit
grocery
group
grow
grunt
guard
guess
guide
guilt
guitar
gun
gym
habit
hair
half
hammer
hamster
hand
happy
harbor
hard
harsh
harvest
hat
have
hawk
hazard
head
health
heart
heavy
hedgehog
height
hello
helmet
help
hen
hero
hidden
high
hill
hint
hip
hire
history
hobby
hockey
hold
hole
holiday
hollow
home
honey
hood
hope
horn
horror
horse
hospital
host
hotel
hour
hover
hub
huge
human
humble
humor
hundred
hungry
hunt
hurdle
hurry
hurt
husband
hybrid
ice
icon
idea
identify
idle
ignore
ill
illegal
illness
image
imitate
immense
immune
impact
impose
improve
impulse
inch
include
income
increase
index
indicate
indoor
industry
infant
inflict
inform
inhale
inherit
initial
inject
injury
inmate
inner
innocent
input
inquiry
insane
insect
inside
inspire
install
intact
interest
into
invest
invite
involve
iron
island
isolate
issue
item
ivory
jacket
jaguar
jar
jazz
jealous
jeans
jelly
jewel
job
join
joke
journey
joy
judge
juice
jump
jungle
junior
junk
just
kangaroo
keen
keep
ketchup
key
kick
kid
kidney
kind
kingdom
kiss
kit
kitchen
kite
kitten
kiwi
knee
knife
knock
know
lab
label
labor
ladder
lady
lake
lamp
language
laptop
large
later
latin
laugh
laundry
lava
law
lawn
lawsuit
layer
lazy
leader
leaf
learn
leave
lecture
left
leg
legal
legend
leisure
lemon
lend
length
lens
leopard
lesson
letter
level
liar
liberty
library
license
life
lift
light
like
limb
limit
link
lion
liquid
list
little
live
lizard
load
loan
lobster
local
lock
logic
lonely
long
loop
lottery
loud
lounge
love
loyal
lucky
luggage
lumber
lunar
lunch
luxury
lyrics
machine
mad
magic
magnet
maid
mail
main
major
make
mammal
man
manage
mandate
mango
mansion
manual
maple
marble
march
margin
marine
market
marriage
mask
mass
master
match
material
math
matrix
matter
maximum
maze
meadow
mean
measure
meat
mechanic
medal
media
melody
melt
member
memory
mention
menu
mercy
merge
merit
merry
mesh
message
metal
method
middle
midnight
milk
million
mimic
mind
minimum
minor
minute
miracle
mirror
misery
miss
mistake
mix
mixed
mixture
mobile
model
modify
mom
moment
monitor
monkey
monster
month
moon
moral
more
morning
mosquito
mother
motion
motor
mountain
mouse
move
movie
much
muffin
mule
multiply
muscle
museum
mushroom
music
must
mutual
myself
mystery
myth
naive
name
napkin
narrow
nasty
nation
nature
near
neck
need
negative
neglect
neither
nephew
nerve
nest
net
network
neutral
never
news
next
nice
night
noble
noise
nominee
noodle
normal
north
nose
notable
note
nothing
notice
novel
now
nuclear
number
nurse
nut
oak
obey
object
oblige
obscure
observe
obtain
obvious
occur
ocean
october
odor
off
offer
office
often
oil
okay
old
olive
olympic
omit
once
one
onion
online
only
open
opera
opinion
oppose
option
orange
orbit
orchard
order
ordinary
organ
orient
original
orphan
ostrich
other
outdoor
outer
output
outside
oval
oven
over
own
owner
oxygen
oyster
ozone
pact
paddle
page
pair
palace
palm
panda
panel
panic
panther
paper
parade
parent
park
parrot
party
pass
patch
path
patient
patrol
pattern
pause
pave
payment
peace
peanut
pear
peasant
pelican
pen
penalty
pencil
people
pepper
perfect
permit
person
pet
phone
photo
phrase
physical
piano
picnic
picture
piece
pig
pigeon
pill
pilot
pink
pioneer
pipe
pistol
pitch
pizza
place
planet
plastic
plate
play
please
pledge
pluck
plug
plunge
poem
poet
point
polar
pole
police
pond
pony
pool
popular
portion
position
possible
post
potato
pottery
poverty
powder
power
practice
praise
predict
prefer
prepare
present
pretty
prevent
price
pride
primary
print
priority
prison
private
prize
problem
process
produce
profit
program
project
promote
proof
property
prosper
protect
proud
provide
public
pudding
pull
pulp
pulse
pumpkin
punch
pupil
puppy
purchase
purity
purpose
purse
push
put
puzzle
pyramid
quality
quantum
quarter
question
quick
quit
quiz
quote
rabbit
raccoon
race
rack
radar
radio
rail
rain
raise
rally
ramp
ranch
random
range
rapid
rare
rate
rather
raven
raw
razor
ready
real
reason
rebel
rebuild
recall
receive
recipe
record
recycle
reduce
reflect
reform
refuse
region
regret
regular
reject
relax
release
relief
rely
remain
remember
remind
remove
render
renew
rent
reopen
repair
repeat
replace
report
require
rescue
resemble
resist
resource
response
result
retire
retreat
return
reunion
reveal
review
reward
rhythm
rib
ribbon
rice
rich
ride
ridge
rifle
right
rigid
ring
riot
ripple
risk
ritual
rival
river
road
roast
robot
robust
rocket
romance
roof
rookie
room
rose
rotate
rough
round
route
royal
rubber
rude
rug
rule
run
runway
rural
sad
saddle
sadness
safe
sail
salad
salmon
salon
salt
salute
same
sample
sand
satisfy
satoshi
sauce
sausage
save
say
scale
scan
scare
scatter
scene
scheme
school
science
scissors
scorpion
scout
scrap
screen
script
scrub
sea
search
season
seat
second
secret
section
security
seed
seek
segment
select
sell
seminar
senior
sense
sentence
series
service
session
settle
setup
seven
shadow
shaft
shallow
share
shed
shell
sheriff
shield
shift
shine
ship
shiver
shock
shoe
shoot
shop
short
shoulder
shove
shrimp
shrug
shuffle
shy
sibling
sick
side
siege
sight
sign
silent
silk
silly
silver
similar
simple
since
sing
siren
sister
situate
six
size
skate
sketch
ski
skill
skin
skirt
skull
slab
slam
sleep
slender
slice
slide
slight
slim
slogan
slot
slow
slush
small
smart
smile
smoke
smooth
snack
snake
snap
sniff
snow
soap
soccer
social
sock
soda
soft
solar
soldier
solid
solution
solve
someone
song
soon
sorry
sort
soul
sound
soup
source
south
space
spare
spatial
spawn
speak
special
speed
spell
spend
sphere
spice
spider
spike
spin
spirit
split
spoil
sponsor
spoon
sport
spot
spray
spread
spring
spy
square
squeeze
squirrel
stable
stadium
staff
stage
stairs
stamp
stand
start
state
stay
steak
steel
stem
step
stereo
stick
still
sting
stock
stomach
stone
stool
story
stove
strategy
street
strike
strong
struggle
student
stuff
stumble
style
subject
submit
subway
success
such
sudden
suffer
sugar
suggest
suit
summer
sun
sunny
sunset
super
supply
supreme
sure
surface
surge
surprise
surround
survey
suspect
sustain
swallow
swamp
swap
swarm
swear
sweet
swift
swim
swing
switch
sword
symbol
symptom
syrup
system
table
tackle
tag
tail
talent
talk
tank
tape
target
task
taste
tattoo
taxi
teach
team
tell
ten
tenant
tennis
tent
term
test
text
thank
that
theme
then
theory
there
they
thing
this
thought
three
thrive
throw
thumb
thunder
ticket
tide
tiger
tilt
timber
time
tiny
tip
tired
tissue
title
toast
tobacco
today
toddler
toe
together
toilet
token
tomato
tomorrow
tone
tongue
tonight
tool
tooth
top
topic
topple
torch
tornado
tortoise
toss
total
tourist
toward
tower
town
toy
track
trade
traffic
tragic
train
transfer
trap
trash
travel
tray
treat
tree
trend
trial
tribe
trick
trigger
trim
trip
trophy
trouble
truck
true
truly
trumpet
trust
truth
try
tube
tuition
tumble
tuna
tunnel
turkey
turn
turtle
twelve
twenty
twice
twin
twist
two
type
typical
ugly
umbrella
unable
unaware
uncle
uncover
under
undo
unfair
unfold
unhappy
uniform
unique
unit
universe
unknown
unlock
until
unusual
unveil
update
upgrade
uphold
upon
upper
upset
urban
urge
usage
use
used
useful
useless
usual
utility
vacant
vacuum
vague
valid
valley
valve
van
vanish
vapor
various
vast
vault
vehicle
velvet
vendor
venture
venue
verb
verify
version
very
vessel
veteran
viable
vibrant
vicious
victory
video
view
village
vintage
violin
virtual
virus
visa
visit
visual
vital
vivid
vocal
voice
void
volcano
volume
vote
voyage
wage
wagon
wait
walk
wall
walnut
want
warfare
warm
warrior
wash
wasp
waste
water
wave
way
wealth
weapon
wear
weasel
weather
web
wedding
weekend
weird
welcome
west
wet
whale
what
wheat
wheel
when
where
whip
whisper
wide
width
wife
wild
will
win
window
wine
wing
wink
winner
winter
wire
wisdom
wise
wish
witness
wolf
woman
wonder
wood
wool
word
work
world
worry
worth
wrap
wreck
wrestle
wrist
write
wrong
yard
year
yellow
you
young
youth
zebra
zero
zone
zoo`.split(`
`)
export {
  So as A,
  Xe as B,
  ao as C,
  St as D,
  Ce as H,
  fs as a,
  ns as b,
  bs as c,
  Eo as d,
  es as e,
  cs as f,
  Ao as g,
  Jr as h,
  ss as i,
  as as j,
  Bo as k,
  os as l,
  _o as m,
  ls as n,
  us as o,
  xo as p,
  gs as q,
  ds as r,
  hs as s,
  ps as t,
  ys as u,
  Io as v,
  Uo as w,
  is as x,
  rs as y,
  Qr as z,
}
