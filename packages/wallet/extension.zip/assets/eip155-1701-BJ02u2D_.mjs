const e = {
  name: "Anytype EVM Chain",
  shortName: "AnytypeChain",
  chain: "ETH",
  icon: "any",
  rpc: ["https://geth.anytype.io"],
  faucets: ["https://evm.anytype.io/faucet"],
  nativeCurrency: {
    name: "ANY",
    symbol: "ANY",
    decimals: 18
  },
  infoURL: "https://evm.anytype.io",
  chainId: 1701,
  networkId: 1701,
  explorers: [
    {
      name: "Anytype Explorer",
      url: "https://explorer.anytype.io",
      standard: "EIP3091"
    }
  ]
};
export {
  e as eip155_1701
};
