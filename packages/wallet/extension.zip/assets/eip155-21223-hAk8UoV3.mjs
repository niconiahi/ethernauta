const a = {
  name: "DCpay Mainnet",
  shortName: "DCPm",
  chain: "DCpay",
  icon: "dcpayIcon",
  rpc: ["https://rpc.dcpay.io"],
  faucets: [],
  nativeCurrency: {
    name: "DCP",
    symbol: "DCP",
    decimals: 18
  },
  infoURL: "https://dcpay.io",
  chainId: 21223,
  networkId: 21223,
  explorers: [
    {
      name: "DCpay Mainnet Explorer",
      url: "https://mainnet.dcpay.io",
      standard: "EIP3091"
    }
  ]
};
export {
  a as eip155_21223
};
