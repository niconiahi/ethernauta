import {
  y as B,
  d as R,
  u as a,
  k as ge,
  a as _e,
  E as Be,
} from "./preact-10.26.9-0icXUSiy.mjs"
import {
  p as u,
  o as h,
  a as d,
  n as be,
  u as v,
  b as F,
  c as U,
  r as xe,
  s as p,
  l as f,
  d as Me,
  e as W,
  f as De,
  t as j,
  g as I,
  v as je,
  m as He,
  H as te,
  h as Le,
  k as ne,
  w as qe,
  i as ce,
  j as we,
  q as Ke,
  x as Ge,
  y as We,
  z as ie,
  A as Ve,
  B as Je,
} from "./vendor-DQ8pdJLF.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const s of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(s)
  new MutationObserver((s) => {
    for (const o of s)
      if (o.type === "childList")
        for (const c of o.addedNodes)
          c.tagName === "LINK" &&
            c.rel === "modulepreload" &&
            r(c)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(s) {
    const o = {}
    return (
      s.integrity && (o.integrity = s.integrity),
      s.referrerPolicy &&
        (o.referrerPolicy = s.referrerPolicy),
      s.crossOrigin === "use-credentials"
        ? (o.credentials = "include")
        : s.crossOrigin === "anonymous"
          ? (o.credentials = "omit")
          : (o.credentials = "same-origin"),
      o
    )
  }
  function r(s) {
    if (s.ep) return
    s.ep = !0
    const o = n(s)
    fetch(s.href, o)
  }
})()
const de = { iterations: 1e5, hash: "SHA-256" },
  g = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function Y(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function z(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function ve(e, t, n) {
  const r = new TextEncoder().encode(e),
    s = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: de.iterations,
      hash: de.hash,
    },
    s,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function re() {
  return new Promise((e, t) => {
    const n = indexedDB.open(g.name, g.version)
    ;(n.onupgradeneeded = (r) => {
      const s = r.target.result
      s.objectStoreNames.contains(g.store_name) ||
        s.createObjectStore(g.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Ye(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    s = await ve(t, n, ["encrypt"]),
    o = new TextEncoder().encode(e),
    c = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      s,
      o,
    ),
    i = {
      salt: Y(n.buffer),
      iv: Y(r.buffer),
      cipher: Y(c),
    },
    l = await re()
  return new Promise((x, E) => {
    const T = l
      .transaction(g.store_name, "readwrite")
      .objectStore(g.store_name)
      .put(i, g.vault_key)
    ;(T.onsuccess = () => x()),
      (T.onerror = () =>
        E(
          new Error(
            `Failed to save vault: ${T.error?.message}`,
          ),
        ))
  })
}
async function Ae(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await re(),
    n = await new Promise((l, x) => {
      const y = t
        .transaction(g.store_name, "readonly")
        .objectStore(g.store_name)
        .get(g.vault_key)
      ;(y.onsuccess = () => {
        const T = y.result
        l(T)
      }),
        (y.onerror = () =>
          x(
            new Error(
              `Failed to load vault: ${y.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = z(n.salt),
    s = z(n.iv),
    o = z(n.cipher),
    c = await ve(e, r, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: s }, c, o)
      .catch((l) => {
        throw l instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unknown error")
      })
  return new TextDecoder().decode(i)
}
async function ze() {
  const e = await re()
  return new Promise((t) => {
    const s = e
      .transaction(g.store_name, "readonly")
      .objectStore(g.store_name)
      .get(g.vault_key)
    ;(s.onsuccess = () => t(!!s.result)),
      (s.onerror = () => t(!1))
  })
}
async function Qe(e) {
  try {
    return (await Ae(e)) !== void 0
  } catch {
    return !1
  }
}
function Xe(e) {
  const t = e.trim().split(/\s+/)
  return [12, 15, 18, 21, 24].includes(t.length)
}
const Ze = "password",
  k = B(Ze)
async function Se() {
  const e = Date.now()
  await chrome.storage.local.set({ timestamp: e })
}
async function et() {
  return u(
    h({ timestamp: d(be()) }),
    await chrome.storage.local.get("timestamp"),
  ).timestamp
}
async function tt() {
  const e = Date.now(),
    t = await et()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function nt() {
  ;(await ze())
    ? (k.value = "password")
    : (k.value = "mnemonics")
}
const rt = h({ signature: p(), names: F(p()) }),
  st = h({
    id: p(),
    type: f("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: p(),
    chainId: p(),
    to: d(p()),
    params: d(v([F(U()), xe(p(), U())])),
    _function: d(rt),
  }),
  at = st,
  X = W(
    p(),
    De(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  se = v([F(U()), xe(p(), U())]),
  ae = v([p(), be(), Me()]),
  ot = h({
    jsonrpc: f("2.0"),
    method: X,
    params: d(se),
    id: ae,
  }),
  ct = h({
    data: d(U()),
    message: p(),
    code: v([
      f(-32e3),
      f(-32300),
      f(-32400),
      f(-32500),
      f(-32600),
      f(-32601),
      f(-32602),
      f(-32603),
      f(-32700),
      f(-32701),
      f(-32702),
    ]),
  }),
  it = h({ id: ae, jsonrpc: f("2.0"), error: ct }),
  dt = h({ id: ae, jsonrpc: f("2.0"), result: U() }),
  ut = v([it, dt]),
  Ne = v([j([X, se]), j([X])])
function lt(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const mt = I(lt)
function ft(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const pt = I(ft)
function ht(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const Ee = I(ht),
  yt = ":"
function gt({ namespace: e, reference: t }) {
  const n = u(mt, e),
    r = u(pt, typeof t == "number" ? String(t) : t),
    s = n + yt + r
  return u(Ee, s)
}
function _t(e, t) {
  const n = e.find((r) => r.chainId === t)
  if (!n) throw new Error(`no chain configured for: ${t}`)
  return n.transports
}
function bt(e) {
  return async (t) => {
    const [n, r] = t,
      s = u(ot, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: xt(r),
      }),
      o = await fetch(e, {
        method: "POST",
        body: JSON.stringify(s),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return u(ut, o)
  }
}
function xt(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
const wt = h({ chain_id: Ee })
function vt(e) {
  return (t) => {
    const n = u(wt, t)
    return [_t(e, n.chain_id), n]
  }
}
const w = B({
    id: "some-id",
    method: "hello_world",
    params: [],
  }),
  M = B(null),
  ue = "0123456789abcdef"
function S(e) {
  let t = ""
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    ;(t += ue[r >> 4]), (t += ue[r & 15])
  }
  return `0x${t}`
}
function At(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
const le = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15,
}
function N(e) {
  const t = At(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    const s = le[t[r]],
      o = le[t[r + 1]]
    if (s === void 0 || o === void 0)
      throw new Error("Invalid hex character")
    n[r / 2] = (s << 4) | o
  }
  return n
}
function H(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function St(e) {
  if (!je(e, qe)) throw new Error("Invalid mnemonic")
  return He(e)
}
function Nt(e) {
  return te.fromMasterSeed(e)
}
function Et(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function Tt(e) {
  const t = Le(e, !1),
    n = ne(t.slice(1))
  return S(n.slice(-20))
}
function It(e) {
  const t = e.privateKey
  return H(t, "a private key should exist"), t
}
function K(e) {
  return BigInt(e)
}
const kt = h({ address: p(), private_key: p() }),
  $ = B({
    address: "",
    key: new te({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function Ft(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.local.set({ wallet: t })
}
async function Pt() {
  const t = u(
    h({ wallet: d(kt) }),
    await chrome.storage.local.get("wallet"),
  ).wallet
  t &&
    ($.value = {
      address: t.address,
      key: te.fromExtendedKey(t.private_key),
    })
}
async function Ot(e) {
  const t = await Ae(e)
  H(t, "vault should exist to sign in")
  const n = St(t),
    r = Nt(n),
    s = Et(r),
    o = Tt(s),
    c = r.derive("m/44'/60'/0'/0/0"),
    i = { address: o, key: c }
  ;($.value = i), Ft(i)
}
function C({
  children: e,
  class: t,
  variant: n = "primary",
  ...r
}) {
  const [s, o] = R(!1)
  return a("button", {
    type: "button",
    onPointerDown: () => o(!0),
    onPointerUp: () => o(!1),
    onPointerLeave: () => o(!1),
    onTouchCancel: () => o(!1),
    class: [
      "border-2 rounded-md p-2 cursor-pointer text-base transition-colors",
      n === "secondary"
        ? "bg-[color-mix(in_srgb,#FF5005_12%,#faf5f0)] hover:bg-[color-mix(in_srgb,#FF5005_25%,#faf5f0)] border-[#FF5005] text-[#FF5005]"
        : "bg-[#FF5005] hover:bg-[#cc4004] border-[#c73d00] text-white",
      s
        ? "outline outline-2 outline-offset-2 outline-gray-700"
        : "",
      t,
    ]
      .filter(Boolean)
      .join(" "),
    ...r,
    children: e,
  })
}
function Rt(e) {
  return `${e.slice(0, 6)}…${e.slice(-4)}`
}
function Ut() {
  const e = $.value.address
  return a("main", {
    className: "flex flex-col gap-4 p-4 w-80 text-base",
    children: [
      a("header", {
        className: "flex flex-col gap-1 text-center",
        children: [
          a("h1", {
            className: "text-xl font-bold leading-tight",
            children: "Connect to Ethernauta",
          }),
          a("p", {
            className: "text-sm text-gray-600",
            children:
              "A site is requesting access to your address.",
          }),
        ],
      }),
      a("section", {
        className:
          "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3",
        children: [
          a("p", {
            className:
              "text-xs uppercase tracking-wide text-gray-500",
            children: "Address",
          }),
          a("p", {
            className: "font-mono text-base font-semibold",
            title: e,
            children: Rt(e),
          }),
        ],
      }),
      a("div", {
        className: "flex flex-col gap-2",
        children: [
          a(C, {
            onClick: () => {
              const t = {
                id: M.value?.id ?? "",
                type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
                signed_transaction: JSON.stringify([e]),
              }
              chrome.runtime.sendMessage(t),
                (M.value = null),
                window.close()
            },
            children: "Connect",
          }),
          a(C, {
            variant: "secondary",
            onClick: () => {
              const t = {
                id: M.value?.id ?? "",
                type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
              }
              chrome.runtime.sendMessage(t),
                (M.value = null),
                window.close()
            },
            children: "Reject",
          }),
        ],
      }),
    ],
  })
}
const $t = W(p(), we(8)),
  Ct = W(p(), we(1))
function Bt() {
  const [e, t] = R(""),
    [n, r] = R(""),
    [s, o] = R("")
  return a("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      a("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (c) => {
          const i = c.currentTarget.value
          r(i), o("")
        },
      }),
      a("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (c) => {
          const i = c.currentTarget.value
          t(i), o("")
        },
      }),
      s
        ? a("p", {
            className: "text-red-500 text-sm",
            children: s,
          })
        : null,
      a(C, {
        onClick: async () => {
          const c = ce(Ct, n)
          if (!c.success) {
            o(c.issues[0].message)
            return
          }
          if (!Xe(c.output)) {
            o(
              "Invalid mnemonic: must be 12, 15, 18, 21, or 24 words",
            )
            return
          }
          const i = ce($t, e)
          if (!i.success) {
            o(i.issues[0].message)
            return
          }
          await Ye(c.output, i.output),
            await Se(),
            (k.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function Mt() {
  const [e, t] = R(""),
    [n, r] = R("")
  return a("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      a("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (s) => {
          const o = s.currentTarget.value
          t(o), r("")
        },
      }),
      n
        ? a("p", {
            className: "text-red-500 text-sm",
            children: n,
          })
        : null,
      a(C, {
        onClick: async () => {
          if (!(await Qe(e))) {
            r("Invalid password")
            return
          }
          await Se(), await Ot(e), (k.value = "wallet")
        },
        children: "Unlock",
      }),
    ],
  })
}
const Dt = new Set([
  "address",
  "bool",
  "bytes4",
  "bytes8",
  "bytes32",
  "bytes48",
  "bytes65",
  "bytes256",
  "uint",
  "uint8",
  "uint64",
  "uint256",
  "hash32",
])
function jt(e) {
  return Dt.has(e)
}
function V(e, t) {
  let n = 0n
  for (let r = 0; r < 32; r++)
    n = (n << 8n) | BigInt(e[t + r])
  return n
}
function Ht(e, t) {
  return S(e.slice(t, t + 32))
}
function Lt(e, t) {
  return S(e.slice(t + 12, t + 32))
}
function qt(e, t) {
  return V(e, t) === 1n
}
function P(e, t, n) {
  return S(e.slice(t, t + n))
}
function Kt(e, t) {
  const n = Number(V(e, t)),
    r = t + 32
  return new TextDecoder().decode(e.slice(r, r + n))
}
function Gt(e, t) {
  const n = Number(V(e, t)),
    r = t + 32
  return S(e.slice(r, r + n))
}
function Wt(e, t, n) {
  switch (e) {
    case "address":
    case "hash32":
      return Lt(t, n)
    case "bool":
      return qt(t, n)
    case "bytes4":
      return P(t, n, 4)
    case "bytes8":
      return P(t, n, 8)
    case "bytes32":
      return P(t, n, 32)
    case "bytes48":
      return P(t, n, 48)
    case "bytes65":
      return P(t, n, 65)
    case "bytes256":
      return P(t, n, 256)
    case "uint":
    case "uint8":
    case "uint64":
    case "uint256":
      return Ht(t, n)
    default:
      throw new Error(
        `decode_static called for dynamic type ${e}`,
      )
  }
}
function Vt(e, t, n) {
  switch (e) {
    case "string":
      return Kt(t, n)
    case "bytes":
      return Gt(t, n)
    default:
      throw new Error(
        `decode_dynamic called for static type ${e}`,
      )
  }
}
function Jt(e, t) {
  const n = N(t),
    r = []
  let s = 0
  for (const o of e)
    if (jt(o)) r.push(Wt(o, n, s)), (s += 32)
    else {
      const c = Number(V(n, s))
      r.push(Vt(o, n, c)), (s += 32)
    }
  return r
}
function Te(e, t) {
  const n = N(t)
  if (n.length < 4)
    throw new Error(`calldata too short: ${n.length} bytes`)
  const r = S(n.slice(0, 4)),
    s = S(n.slice(4)),
    o = Jt(e, s)
  return { selector: r, args: o }
}
function Ie(e) {
  return ne(new TextEncoder().encode(e)).slice(0, 4)
}
function Yt(e) {
  const t = new Uint8Array(32),
    n = e.slice(2)
  for (let r = 0; r < 20; r++)
    t[12 + r] = Number.parseInt(
      n.slice(r * 2, r * 2 + 2),
      16,
    )
  return t
}
function J(e) {
  const t = new Uint8Array(32)
  let n = e
  for (let r = 31; r >= 0; r--)
    (t[r] = Number(n & 0xffn)), (n >>= 8n)
  return t
}
function zt(e) {
  return J(e ? 1n : 0n)
}
function O(e, t) {
  const n = new Uint8Array(32),
    r = e.slice(2)
  if (r.length !== t * 2)
    throw new Error(
      `expected bytes${t} (${t * 2} hex chars), got ${r.length}`,
    )
  for (let s = 0; s < t; s++)
    n[s] = Number.parseInt(r.slice(s * 2, s * 2 + 2), 16)
  return n
}
function Qt(e) {
  const t = new TextEncoder().encode(e)
  return ke(t)
}
function ke(e) {
  const t = Math.ceil(e.length / 32) * 32,
    n = new Uint8Array(32 + t)
  return n.set(J(BigInt(e.length)), 0), n.set(e, 32), n
}
const Xt = new Set([
  "address",
  "bool",
  "bytes4",
  "bytes8",
  "bytes32",
  "bytes48",
  "bytes65",
  "bytes256",
  "uint",
  "uint8",
  "uint64",
  "uint256",
  "hash32",
])
function me(e) {
  return Xt.has(e)
}
function fe(e, t) {
  switch (e) {
    case "address":
    case "hash32":
      return Yt(t)
    case "bool":
      return zt(t)
    case "bytes4":
      return O(t, 4)
    case "bytes8":
      return O(t, 8)
    case "bytes32":
      return O(t, 32)
    case "bytes48":
      return O(t, 48)
    case "bytes65":
      return O(t, 65)
    case "bytes256":
      return O(t, 256)
    case "uint":
    case "uint8":
    case "uint64":
    case "uint256":
      return J(Zt(t))
    case "string":
      return Qt(t)
    case "bytes":
      return ke(typeof t == "string" ? en(t) : t)
  }
}
function Zt(e) {
  if (typeof e == "bigint") return e
  if (typeof e == "number") return BigInt(e)
  if (typeof e == "string")
    return e.startsWith("0x"), BigInt(e)
  throw new Error(
    `cannot coerce value to bigint: ${typeof e}`,
  )
}
function en(e) {
  const t = e.startsWith("0x") ? e.slice(2) : e,
    n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2)
    n[r / 2] = Number.parseInt(t.slice(r, r + 2), 16)
  return n
}
function tn(e, t, n) {
  if (t.length !== n.length)
    throw new Error(
      `param count mismatch: ${t.length} vs ${n.length}`,
    )
  const r = Ie(e),
    s = t.length * 32,
    o = [],
    c = []
  for (let m = 0; m < t.length; m++) {
    const y = t[m],
      T = n[m]
    me(y)
      ? (o.push(fe(y, T)), c.push(new Uint8Array(0)))
      : (o.push(new Uint8Array(32)), c.push(fe(y, T)))
  }
  let i = s
  for (let m = 0; m < t.length; m++) {
    const y = t[m]
    me(y) || ((o[m] = J(BigInt(i))), (i += c[m].length))
  }
  const l = 4 + s + c.reduce((m, y) => m + y.length, 0),
    x = new Uint8Array(l)
  x.set(r, 0)
  let E = 4
  for (const m of o) x.set(m, E), (E += 32)
  for (const m of c)
    m.length !== 0 && (x.set(m, E), (E += m.length))
  return x
}
function nn(e, t) {
  return tn(e, ["address", "string"], t)
}
const rn = {
    "0x00fdd58e": {
      name: "balanceOf",
      signature: "balanceOf(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "id"],
    },
    "0x01e1d114": {
      name: "totalAssets",
      signature: "totalAssets()",
      types: [],
      param_names: [],
    },
    "0x01ffc9a7": {
      name: "supportsInterface",
      signature: "supportsInterface(bytes4)",
      types: ["bytes4"],
      param_names: ["interfaceId"],
    },
    "0x06fdde03": {
      name: "name",
      signature: "name()",
      types: [],
      param_names: [],
    },
    "0x07a2d13a": {
      name: "convertToAssets",
      signature: "convertToAssets(uint256)",
      types: ["uint256"],
      param_names: ["shares"],
    },
    "0x081812fc": {
      name: "getApproved",
      signature: "getApproved(uint256)",
      types: ["uint256"],
      param_names: ["tokenId"],
    },
    "0x095ea7b3": {
      name: "approve",
      signature: "approve(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["spender", "value"],
    },
    "0x0a28a477": {
      name: "previewWithdraw",
      signature: "previewWithdraw(uint256)",
      types: ["uint256"],
      param_names: ["assets"],
    },
    "0x0e89341c": {
      name: "uri",
      signature: "uri(uint256)",
      types: ["uint256"],
      param_names: ["id"],
    },
    "0x141a468c": {
      name: "nonces",
      signature: "nonces(uint256)",
      types: ["uint256"],
      param_names: ["tokenId"],
    },
    "0x18160ddd": {
      name: "totalSupply",
      signature: "totalSupply()",
      types: [],
      param_names: [],
    },
    "0x205c2878": {
      name: "withdrawTo",
      signature: "withdrawTo(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "value"],
    },
    "0x23b872dd": {
      name: "transferFrom",
      signature: "transferFrom(address,address,uint256)",
      types: ["address", "address", "uint256"],
      param_names: ["from", "to", "value"],
    },
    "0x2a55205a": {
      name: "royaltyInfo",
      signature: "royaltyInfo(uint256,uint256)",
      types: ["uint256", "uint256"],
      param_names: ["tokenId", "salePrice"],
    },
    "0x2f4f21e2": {
      name: "depositFor",
      signature: "depositFor(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "value"],
    },
    "0x2f745c59": {
      name: "tokenOfOwnerByIndex",
      signature: "tokenOfOwnerByIndex(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["owner", "index"],
    },
    "0x313ce567": {
      name: "decimals",
      signature: "decimals()",
      types: [],
      param_names: [],
    },
    "0x355274ea": {
      name: "cap",
      signature: "cap()",
      types: [],
      param_names: [],
    },
    "0x3644e515": {
      name: "DOMAIN_SEPARATOR",
      signature: "DOMAIN_SEPARATOR()",
      types: [],
      param_names: [],
    },
    "0x38d52e0f": {
      name: "asset",
      signature: "asset()",
      types: [],
      param_names: [],
    },
    "0x3a46b1a8": {
      name: "getPastVotes",
      signature: "getPastVotes(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "timepoint"],
    },
    "0x3f4ba83a": {
      name: "unpause",
      signature: "unpause()",
      types: [],
      param_names: [],
    },
    "0x402d267d": {
      name: "maxDeposit",
      signature: "maxDeposit(address)",
      types: ["address"],
      param_names: ["receiver"],
    },
    "0x40c10f19": {
      name: "mint",
      signature: "mint(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["to", "value"],
    },
    "0x42842e0e": {
      name: "safeTransferFrom",
      signature:
        "safeTransferFrom(address,address,uint256)",
      types: ["address", "address", "uint256"],
      param_names: ["from", "to", "tokenId"],
    },
    "0x42966c68": {
      name: "burn",
      signature: "burn(uint256)",
      types: ["uint256"],
      param_names: ["value"],
    },
    "0x4cdad506": {
      name: "previewRedeem",
      signature: "previewRedeem(uint256)",
      types: ["uint256"],
      param_names: ["shares"],
    },
    "0x4f6ccce7": {
      name: "tokenByIndex",
      signature: "tokenByIndex(uint256)",
      types: ["uint256"],
      param_names: ["index"],
    },
    "0x587cde1e": {
      name: "delegates",
      signature: "delegates(address)",
      types: ["address"],
      param_names: ["account"],
    },
    "0x5c19a95c": {
      name: "delegate",
      signature: "delegate(address)",
      types: ["address"],
      param_names: ["delegatee"],
    },
    "0x5c975abb": {
      name: "paused",
      signature: "paused()",
      types: [],
      param_names: [],
    },
    "0x5cffe9de": {
      name: "flashLoan",
      signature: "flashLoan(address,address,uint256,bytes)",
      types: ["address", "address", "uint256", "bytes"],
      param_names: ["receiver", "token", "value", "data"],
    },
    "0x613255ab": {
      name: "maxFlashLoan",
      signature: "maxFlashLoan(address)",
      types: ["address"],
      param_names: ["token"],
    },
    "0x6352211e": {
      name: "ownerOf",
      signature: "ownerOf(uint256)",
      types: ["uint256"],
      param_names: ["tokenId"],
    },
    "0x6e553f65": {
      name: "deposit",
      signature: "deposit(uint256,address)",
      types: ["uint256", "address"],
      param_names: ["assets", "receiver"],
    },
    "0x6f307dc3": {
      name: "underlying",
      signature: "underlying()",
      types: [],
      param_names: [],
    },
    "0x70a08231": {
      name: "balanceOf",
      signature: "balanceOf(address)",
      types: ["address"],
      param_names: ["account"],
    },
    "0x745a41bc": {
      name: "permit",
      signature: "permit(address,uint256,uint256,bytes)",
      types: ["address", "uint256", "uint256", "bytes"],
      param_names: [
        "spender",
        "tokenId",
        "deadline",
        "signature",
      ],
    },
    "0x79cc6790": {
      name: "burnFrom",
      signature: "burnFrom(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["account", "value"],
    },
    "0x7ecebe00": {
      name: "nonces",
      signature: "nonces(address)",
      types: ["address"],
      param_names: ["owner"],
    },
    "0x8456cb59": {
      name: "pause",
      signature: "pause()",
      types: [],
      param_names: [],
    },
    "0x8e539e8c": {
      name: "getPastTotalSupply",
      signature: "getPastTotalSupply(uint256)",
      types: ["uint256"],
      param_names: ["timepoint"],
    },
    "0x94bf804d": {
      name: "mint",
      signature: "mint(uint256,address)",
      types: ["uint256", "address"],
      param_names: ["shares", "receiver"],
    },
    "0x95d89b41": {
      name: "symbol",
      signature: "symbol()",
      types: [],
      param_names: [],
    },
    "0x9ab24eb0": {
      name: "getVotes",
      signature: "getVotes(address)",
      types: ["address"],
      param_names: ["account"],
    },
    "0xa22cb465": {
      name: "setApprovalForAll",
      signature: "setApprovalForAll(address,bool)",
      types: ["address", "bool"],
      param_names: ["operator", "approved"],
    },
    "0xa9059cbb": {
      name: "transfer",
      signature: "transfer(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["to", "value"],
    },
    "0xb3d7f6b9": {
      name: "previewMint",
      signature: "previewMint(uint256)",
      types: ["uint256"],
      param_names: ["shares"],
    },
    "0xb460af94": {
      name: "withdraw",
      signature: "withdraw(uint256,address,address)",
      types: ["uint256", "address", "address"],
      param_names: ["assets", "receiver", "owner"],
    },
    "0xb88d4fde": {
      name: "safeTransferFrom",
      signature:
        "safeTransferFrom(address,address,uint256,bytes)",
      types: ["address", "address", "uint256", "bytes"],
      param_names: ["from", "to", "tokenId", "data"],
    },
    "0xba087652": {
      name: "redeem",
      signature: "redeem(uint256,address,address)",
      types: ["uint256", "address", "address"],
      param_names: ["shares", "receiver", "owner"],
    },
    "0xc3cda520": {
      name: "delegateBySig",
      signature:
        "delegateBySig(address,uint256,uint256,uint8,bytes32,bytes32)",
      types: [
        "address",
        "uint256",
        "uint256",
        "uint8",
        "bytes32",
        "bytes32",
      ],
      param_names: [
        "delegatee",
        "nonce",
        "expiry",
        "v",
        "r",
        "s",
      ],
    },
    "0xc63d75b6": {
      name: "maxMint",
      signature: "maxMint(address)",
      types: ["address"],
      param_names: ["receiver"],
    },
    "0xc6e6f592": {
      name: "convertToShares",
      signature: "convertToShares(uint256)",
      types: ["uint256"],
      param_names: ["assets"],
    },
    "0xc87b56dd": {
      name: "tokenURI",
      signature: "tokenURI(uint256)",
      types: ["uint256"],
      param_names: ["tokenId"],
    },
    "0xce96cb77": {
      name: "maxWithdraw",
      signature: "maxWithdraw(address)",
      types: ["address"],
      param_names: ["owner"],
    },
    "0xd505accf": {
      name: "permit",
      signature:
        "permit(address,address,uint256,uint256,uint8,bytes32,bytes32)",
      types: [
        "address",
        "address",
        "uint256",
        "uint256",
        "uint8",
        "bytes32",
        "bytes32",
      ],
      param_names: [
        "owner",
        "spender",
        "value",
        "deadline",
        "v",
        "r",
        "s",
      ],
    },
    "0xd905777e": {
      name: "maxRedeem",
      signature: "maxRedeem(address)",
      types: ["address"],
      param_names: ["owner"],
    },
    "0xd9d98ce4": {
      name: "flashFee",
      signature: "flashFee(address,uint256)",
      types: ["address", "uint256"],
      param_names: ["token", "value"],
    },
    "0xdd62ed3e": {
      name: "allowance",
      signature: "allowance(address,address)",
      types: ["address", "address"],
      param_names: ["owner", "spender"],
    },
    "0xe985e9c5": {
      name: "isApprovedForAll",
      signature: "isApprovedForAll(address,address)",
      types: ["address", "address"],
      param_names: ["account", "operator"],
    },
    "0xef8b30f7": {
      name: "previewDeposit",
      signature: "previewDeposit(uint256)",
      types: ["uint256"],
      param_names: ["assets"],
    },
    "0xf242432a": {
      name: "safeTransferFrom",
      signature:
        "safeTransferFrom(address,address,uint256,uint256,bytes)",
      types: [
        "address",
        "address",
        "uint256",
        "uint256",
        "bytes",
      ],
      param_names: ["from", "to", "id", "value", "data"],
    },
  },
  Z = { name: "Ethereum Sepolia", chainId: 11155111 },
  ee = [
    {
      id: Z.chainId,
      name: Z.name,
      rpc_url:
        "https://ethereum-sepolia-rpc.publicnode.com",
    },
  ],
  D = B(ee[0]),
  sn = "eip155"
function Fe(e) {
  return gt({ namespace: sn, reference: e.id })
}
function Pe(e) {
  const t = Fe(e)
  return {
    chain_id: t,
    reader: vt([
      { chainId: t, transports: [bt(e.rpc_url)] },
    ]),
  }
}
function an(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const _ = I(an)
function on(e) {
  return (
    typeof e == "string" &&
    /^0x([0-9,a-f,A-F]?){1,2}$/.test(e)
  )
}
const cn = I(on)
function dn(e) {
  return typeof e == "string" && /^0x[0-9a-f]*$/.test(e)
}
const pe = I(dn)
function un(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const oe = I(un)
function ln(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const b = I(ln),
  mn = h({ address: _, storageKeys: F(oe) }),
  fn = F(mn),
  pn = h({
    type: d(cn),
    nonce: d(b),
    to: d(Ke(_)),
    from: d(_),
    gas: d(b),
    value: d(b),
    input: d(pe),
    gasPrice: d(b),
    maxPriorityFeePerGas: d(b),
    maxFeePerGas: d(b),
    maxFeePerBlobGas: d(b),
    accessList: d(fn),
    blobVersionedHashes: d(F(oe)),
    blobs: d(F(pe)),
    chainId: d(b),
  }),
  hn = v([
    f("earliest"),
    f("finalized"),
    f("safe"),
    f("latest"),
    f("pending"),
  ]),
  G = v([b, hn, oe]),
  yn = v([
    j([_, G]),
    j([_]),
    h({ address: _, blockNumberOrTagOrHash: G }),
    h({ address: _ }),
  ])
function gn(e) {
  return async ([t, n]) => {
    const r = "eth_getBalance",
      s = u(yn, e),
      o = u(Ne, [r, s]),
      c = await Promise.any(t.map((l) => l(o)))
    if ("error" in c) throw new Error(c.error.message)
    return u(b, c.result)
  }
}
const _n = v([
  j([_, G]),
  h({ address: _, blockNumberOrTagOrHash: G }),
])
function bn(e) {
  return async ([t, n]) => {
    const r = "eth_getTransactionCount",
      s = u(_n, e),
      o = u(Ne, [r, s]),
      c = await Promise.race(t.map((l) => l(o)))
    if ("error" in c) throw new Error(c.error.message)
    return u(b, c.result)
  }
}
function Oe(e) {
  return Array.isArray(e) ? wn(e) : xn(e)
}
function xn(e) {
  const t = vn(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const o = new Uint8Array(1 + t.length)
    return (o[0] = 128 + t.length), o.set(t, 1), o
  }
  const r = Re(t.length),
    s = new Uint8Array(1 + r.length + t.length)
  return (
    (s[0] = 183 + r.length),
    s.set(r, 1),
    s.set(t, 1 + r.length),
    s
  )
}
function wn(e) {
  const t = e.map((c) => Oe(c)),
    n = t.reduce((c, i) => c + i.length, 0)
  if (n <= 55) {
    const c = new Uint8Array(1 + n)
    c[0] = 192 + n
    let i = 1
    for (const l of t) c.set(l, i), (i += l.length)
    return c
  }
  const r = Re(n),
    s = new Uint8Array(1 + r.length + n)
  ;(s[0] = 247 + r.length), s.set(r, 1)
  let o = 1 + r.length
  for (const c of t) s.set(c, o), (o += c.length)
  return s
}
function vn(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? N(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return An(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function An(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return N(n)
}
function Re(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function A(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return N(n)
}
function Sn(e, t) {
  return (
    (ie.hmacSha256Sync = (n, ...r) =>
      Ve(Je, n, ie.concatBytes(...r))),
    We(e, t)
  )
}
function Nn(e) {
  return BigInt(e)
}
async function En(e, t, n) {
  const s = await bn([e, "latest"])(t({ chain_id: n }))
  return K(s)
}
function Tn() {
  return BigInt(Z.chainId)
}
function In() {
  return 1000000n
}
function kn() {
  return 20000000000n
}
function Fn() {
  return 2000000000n
}
function Pn(e, t, n) {
  switch (e) {
    case "eth_signTransaction": {
      const r = Array.isArray(t) ? t[0] : t.transaction,
        s = u(pn, r),
        o = s.value ?? "0x0",
        c = s.input ?? "0x",
        i = c === "0x" ? new Uint8Array([]) : N(c)
      return { to: s.to, value: K(o), data: i }
    }
    case "transfer": {
      const r = u(_, t[0]),
        s = u(W(p(), Ge()), t[1])
      return {
        to: r,
        value: K(s),
        data: new Uint8Array([]),
      }
    }
    case "safeMint": {
      const r = u(_, n),
        s = u(_, t[0]),
        o = u(p(), t[1])
      return {
        to: r,
        value: 0n,
        data: nn("safeMint(address,string)", [s, o]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function On({
  key: e,
  nonce: t,
  method: n,
  params: r,
  to: s,
}) {
  const { to: o, value: c, data: i } = Pn(n, r, s),
    l = {
      to: o,
      data: i,
      value: c,
      nonce: t,
      chain_id: Tn(),
      gas_limit: In(),
      max_fee_per_gas: kn(),
      max_priority_fee_per_gas: Fn(),
    },
    x = It(e)
  return Un(l, x)
}
function Rn(e, t) {
  const n = Ue(e, t)
  return ne(n)
}
function Un(e, t) {
  const n = Bn(e),
    r = he(n),
    s = new Uint8Array([2]),
    o = Rn(s, r),
    c = Sn(o, t),
    i = Cn(n, c),
    l = he(i)
  return Ue(s, l)
}
function Ue(...e) {
  let t = 0
  for (const s of e) t += s.length
  const n = new Uint8Array(t)
  let r = 0
  for (const s of e) n.set(s, r), (r += s.length)
  return n
}
function $n(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    H(r, "access list item should exist")
    const s = new Array(r.storage_keys.length)
    for (let o = 0; o < r.storage_keys.length; o++) {
      const c = r.storage_keys[o]
      H(c, "storage key should exist"), (s[o] = N(c))
    }
    t[n] = [N(r.address), s]
  }
  return t
}
function Cn(e, t) {
  const n = new Array(12)
  H(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = Nn(t.recovery)
  return (
    (n[9] = A(r)), (n[10] = A(t.r)), (n[11] = A(t.s)), n
  )
}
function Bn(e) {
  const t = new Array(9)
  return (
    (t[0] = A(e.chain_id)),
    (t[1] = A(e.nonce)),
    (t[2] = A(e.max_priority_fee_per_gas)),
    (t[3] = A(e.max_fee_per_gas)),
    (t[4] = A(e.gas_limit)),
    (t[5] = N(e.to)),
    (t[6] = A(e.value)),
    (t[7] = e.data),
    (t[8] = $n([])),
    t
  )
}
function he(e) {
  return Oe(e)
}
function Mn(e) {
  return e == null
    ? ""
    : typeof e == "string"
      ? e
      : String(e)
}
function Dn(e) {
  return (
    typeof e == "object" && e !== null && !Array.isArray(e)
  )
}
function $e(e) {
  return (
    typeof e == "string" &&
    e.startsWith("0x") &&
    e.length >= 10 &&
    (e.length - 2) % 2 === 0
  )
}
function jn(e) {
  const n = rn[e]
  if (n) return { ...n, source: "bundled" }
}
function Hn(e) {
  const t = e.indexOf("("),
    n = e.lastIndexOf(")")
  if (t <= 0 || n <= t || n !== e.length - 1) return
  const r = e.slice(0, t),
    s = e.slice(t + 1, n)
  return s.length === 0
    ? { name: r, types: [] }
    : { name: r, types: s.split(",") }
}
function Ln(e, t) {
  const n = Ie(e)
  return S(n) === t.toLowerCase()
}
function qn(e, t) {
  if (!t || !Ln(t.signature, e)) return
  const n = Hn(t.signature)
  if (n)
    return {
      name: n.name,
      signature: t.signature,
      types: n.types,
      param_names: t.names,
      source: "sidecar",
    }
}
function Ce(e) {
  const t = e.slice(0, 10).toLowerCase(),
    n = w.value._function
  return qn(t, n) ?? jn(t)
}
function Kn({ hex: e, entry: t, args: n }) {
  const r = Math.max(t.types.length, t.param_names.length),
    s = Array.from(
      { length: r },
      (o, c) => t.param_names[c] || t.types[c] || String(c),
    )
  return a("div", {
    className: "flex flex-col gap-1 text-xs",
    children: [
      a("div", {
        className: "font-mono font-bold break-all",
        children: [
          t.name,
          "(",
          t.types
            .map((o, c) =>
              `${o} ${t.param_names[c] ?? ""}`.trim(),
            )
            .join(", "),
          ")",
        ],
      }),
      a("dl", {
        className:
          "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
        children: s.map((o, c) =>
          a(L, { label: o, value: n[c] }, `${o}-${c}`),
        ),
      }),
      a("details", {
        className: "text-[10px] opacity-70",
        children: [
          a("summary", {
            className: "cursor-pointer",
            children: "raw",
          }),
          a("div", {
            className: "font-mono break-all pt-1",
            children: e,
          }),
        ],
      }),
    ],
  })
}
function L({ label: e, value: t }) {
  if ($e(t)) {
    const n = Ce(t)
    if (n)
      try {
        const { args: r } = Te([...n.types], t)
        return a("div", {
          className: "flex flex-col gap-0.5 text-xs",
          children: [
            a("dt", {
              className: "font-bold",
              children: e,
            }),
            a("dd", {
              children: a(Kn, {
                hex: t,
                entry: n,
                args: r,
              }),
            }),
          ],
        })
      } catch {}
  }
  return Dn(t)
    ? a("div", {
        className: "flex flex-col gap-1 text-xs",
        children: [
          a("span", {
            className: "font-bold",
            children: e,
          }),
          a("dl", {
            className:
              "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
            children: Object.entries(t).map(([n, r]) =>
              a(L, { label: n, value: r }, n),
            ),
          }),
        ],
      })
    : Array.isArray(t)
      ? a("div", {
          className: "flex flex-col gap-1 text-xs",
          children: [
            a("span", {
              className: "font-bold",
              children: e,
            }),
            a("dl", {
              className:
                "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
              children: t.map((n, r) =>
                a(
                  L,
                  { label: String(r), value: n },
                  `${e}-${r}`,
                ),
              ),
            }),
          ],
        })
      : a("div", {
          className: "flex flex-col gap-0.5 text-xs",
          children: [
            a("dt", {
              className: "font-bold",
              children: e,
            }),
            a("dd", {
              className: "font-mono break-all",
              children: Mn(t),
            }),
          ],
        })
}
function Gn() {
  const e = u(se, w.value.params),
    t = Array.isArray(e)
      ? e.map((n, r) => [String(r), n])
      : Object.entries(e)
  return a("dl", {
    className: "flex flex-col gap-2",
    children: t.map(([n, r]) =>
      a(L, { label: n, value: r }, n),
    ),
  })
}
function Wn() {
  const e = w.value.params
  let t
  if (
    (Array.isArray(e)
      ? (t = e[0])
      : e && typeof e == "object" && (t = e.transaction),
    !t || typeof t != "object")
  )
    return null
  const n = t
  return {
    to: typeof n.to == "string" ? n.to : void 0,
    value: typeof n.value == "string" ? n.value : void 0,
    input: typeof n.input == "string" ? n.input : void 0,
  }
}
function Vn(e) {
  return !e || e === "0x" || e === "0x0"
    ? !0
    : /^0x0+$/.test(e)
}
function Jn(e) {
  if (!e || !$e(e)) return null
  const t = Ce(e)
  if (!t) return null
  try {
    const { args: n } = Te([...t.types], e)
    return { entry: t, args: n }
  } catch {
    return null
  }
}
function q({ children: e }) {
  return a("p", {
    className:
      "text-xs uppercase tracking-wide text-gray-500",
    children: e,
  })
}
function Q({ children: e }) {
  return a("p", {
    className: "font-mono text-sm font-semibold break-all",
    children: e,
  })
}
function Yn({
  to: e,
  value: t,
  input: n,
  entry: r,
  args: s,
}) {
  const o =
    r.param_names.length > 0
      ? r.param_names
      : r.types.map((c, i) => String(i))
  return a("section", {
    className:
      "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2",
    children: [
      e &&
        a("div", {
          className: "flex flex-col gap-0.5",
          children: [
            a(q, { children: "To" }),
            a(Q, { children: e }),
          ],
        }),
      !Vn(t) &&
        a("div", {
          className: "flex flex-col gap-0.5",
          children: [
            a(q, { children: "Value" }),
            a(Q, { children: t }),
          ],
        }),
      a("div", {
        className: "flex flex-col gap-0.5",
        children: [
          a(q, { children: "Method" }),
          a(Q, { children: r.name }),
        ],
      }),
      a("div", {
        className: "flex flex-col gap-1",
        children: [
          a(q, { children: "Params" }),
          a("dl", {
            className:
              "flex flex-col gap-1 pl-2 border-l-2 border-[#FF5005]/30",
            children: o.map((c, i) =>
              a(L, { label: c, value: s[i] }, `${c}-${i}`),
            ),
          }),
        ],
      }),
      a("details", {
        className: "text-[10px] opacity-70",
        children: [
          a("summary", {
            className: "cursor-pointer",
            children: "raw",
          }),
          a("div", {
            className: "font-mono break-all pt-1",
            children: n,
          }),
        ],
      }),
    ],
  })
}
function zn() {
  const e = Wn(),
    t = e ? Jn(e.input) : null
  return a("main", {
    className: "flex flex-col gap-3 p-4 w-80 text-base",
    children: [
      a("header", {
        className: "flex flex-col gap-1 text-center",
        children: a("h1", {
          className: "text-xl font-bold leading-tight",
          children: "You are about to sign",
        }),
      }),
      t && e?.input
        ? a(Yn, {
            to: e.to,
            value: e.value,
            input: e.input,
            entry: t.entry,
            args: t.args,
          })
        : a(ge, {
            children: [
              a("section", {
                className:
                  "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3",
                children: [
                  a("p", {
                    className:
                      "text-xs uppercase tracking-wide text-gray-500",
                    children: "Method",
                  }),
                  a("p", {
                    className:
                      "font-mono text-sm font-semibold break-all",
                    children: w.value.method,
                  }),
                ],
              }),
              a("section", {
                className:
                  "rounded-md border-2 border-[#FF5005] bg-[color-mix(in_srgb,#FF5005_8%,#faf5f0)] p-3 flex flex-col gap-2",
                children: [
                  a("p", {
                    className:
                      "text-xs uppercase tracking-wide text-gray-500",
                    children: "Params",
                  }),
                  a(Gn, {}),
                ],
              }),
            ],
          }),
      a("div", {
        className: "flex flex-col gap-2",
        children: [
          a(C, {
            onClick: async () => {
              const n = $.value.address,
                r = $.value.key,
                { chain_id: s, reader: o } = Pe(D.value),
                c = await En(n, o, s),
                i = await On({
                  key: r,
                  nonce: c,
                  method: w.value.method,
                  params: w.value.params,
                  to: w.value.to,
                }),
                l = {
                  id: w.value.id,
                  type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
                  signed_transaction: S(i),
                }
              chrome.runtime.sendMessage(l), window.close()
            },
            children: "Sign",
          }),
          a(C, {
            variant: "secondary",
            onClick: () => {
              const n = {
                id: w.value.id,
                type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
              }
              chrome.runtime.sendMessage(n), window.close()
            },
            children: "Reject",
          }),
        ],
      }),
    ],
  })
}
const ye = B(0n)
async function Qn(e) {
  const { chain_id: t, reader: n } = Pe(D.value),
    s = await gn([e, "latest"])(n({ chain_id: t }))
  return K(s)
}
function Xn(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    s = n.toString()
  if (r === 0n) return s
  const o = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${s}.${o}`
}
function Zn() {
  const e = $.value.address
  return (
    _e(() => {
      async function t() {
        const n = await Qn(e)
        ye.value = n
      }
      t()
    }, [D.value]),
    a("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        a("select", {
          className:
            "self-start bg-white p-2 border-2 rounded-md cursor-pointer text-base",
          value: D.value.id,
          onChange: (t) => {
            const n = Number(t.currentTarget.value),
              r = ee.find((s) => s.id === n)
            r && (D.value = r)
          },
          children: ee.map((t) =>
            a(
              "option",
              {
                value: t.id,
                children: [Fe(t), " — ", t.name],
              },
              t.id,
            ),
          ),
        }),
        a("p", {
          className: "flex gap-1 text-base",
          children: [
            a("span", { children: "Address:" }),
            a("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: e,
            }),
          ],
        }),
        a("p", {
          className: "flex gap-1 text-base",
          children: [
            a("span", { children: "Balance:" }),
            a("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: er(Xn(ye.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
      ],
    })
  )
}
function er(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function tr() {
  return (
    _e(() => {
      chrome.runtime.connect({ name: "popup" }),
        chrome.runtime.sendMessage({
          type: "ETHERNAUTA_POPUP_READY",
        }),
        chrome.runtime.onMessage.addListener(async (e) => {
          const t = u(at, e)
          if (
            t.type === "ETHERNAUTA_REQUEST_SIGN_TRANSACTION"
          ) {
            const n = await tt()
            if ((await nt(), !n)) return
            if (
              (await Pt(),
              t.method === "eth_requestAccounts")
            ) {
              ;(M.value = { id: t.id }),
                (k.value = "connect")
              return
            }
            ;(w.value = {
              id: t.id,
              method: t.method,
              params: t.params,
              to: t.to,
              _function: t._function,
            }),
              (k.value = "sign")
          }
        })
    }, []),
    a(ge, { children: nr(k.value) })
  )
}
function nr(e) {
  switch (e) {
    case "mnemonics":
      return a(Bt, {})
    case "password":
      return a(Mt, {})
    case "wallet":
      return a(Zn, {})
    case "connect":
      return a(Ut, {})
    case "sign":
      return a(zn, {})
    default:
      return a("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Be(a(tr, {}), document.querySelector("#app"))
