const e = {
  name: "NEAR Protocol",
  shortName: "near",
  chain: "NEAR",
  icon: "near",
  rpc: ["https://eth-rpc.mainnet.near.org"],
  faucets: [],
  nativeCurrency: {
    name: "NEAR",
    symbol: "NEAR",
    decimals: 18
  },
  infoURL: "https://near.org",
  chainId: 397,
  networkId: 397,
  explorers: [
    {
      name: "NEAR Explorer",
      url: "https://eth-explorer.near.org",
      standard: "EIP3091"
    }
  ]
};
export {
  e as eip155_397
};
