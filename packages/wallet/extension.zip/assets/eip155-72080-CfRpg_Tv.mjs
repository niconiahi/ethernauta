const e = {
  name: "Nexera Testnet",
  shortName: "nxra-testnet",
  chain: "Nexera",
  rpc: ["https://rpc.testnet.nexera.network"],
  faucets: ["https://faucet.nexera.network"],
  nativeCurrency: {
    name: "tNXRA",
    symbol: "tNXRA",
    decimals: 18
  },
  infoURL: "https://testnet.nexera.network",
  chainId: 72080,
  networkId: 72080,
  explorers: []
};
export {
  e as eip155_72080
};
