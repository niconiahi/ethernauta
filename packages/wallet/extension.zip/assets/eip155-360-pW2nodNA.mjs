const e = {
  name: "Shape",
  shortName: "shape",
  chain: "ETH",
  icon: "shape",
  rpc: [
    "https://mainnet.shape.network",
    "https://shape-mainnet.g.alchemy.com/public"
  ],
  faucets: [],
  nativeCurrency: {
    name: "Ether",
    symbol: "ETH",
    decimals: 18
  },
  infoURL: "https://shape.network",
  chainId: 360,
  networkId: 360,
  explorers: [
    {
      name: "shapescan",
      url: "https://shapescan.xyz",
      standard: "EIP3091"
    }
  ],
  status: "active"
};
export {
  e as eip155_360
};
