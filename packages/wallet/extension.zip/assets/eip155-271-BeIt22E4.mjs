const n = {
  name: "EgonCoin Mainnet",
  shortName: "EGONm",
  chain: "EGON",
  icon: "egonicon",
  rpc: ["https://rpc.egonscan.com"],
  faucets: [],
  nativeCurrency: {
    name: "EgonCoin",
    symbol: "EGON",
    decimals: 18
  },
  infoURL: "https://egonscan.com",
  chainId: 271,
  networkId: 271,
  explorers: [
    {
      name: "EgonCoin Mainnet",
      url: "https://egonscan.com",
      standard: "EIP3091"
    }
  ]
};
export {
  n as eip155_271
};
