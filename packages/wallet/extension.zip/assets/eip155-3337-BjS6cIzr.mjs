const t = {
  name: "EthStorage Devnet",
  shortName: "es-d",
  chain: "EthStorage",
  rpc: ["https://rpc.devnet.ethstorage.io:9540"],
  faucets: [],
  nativeCurrency: {
    name: "Ether",
    symbol: "ETH",
    decimals: 18
  },
  infoURL: "https://ethstorage.io/",
  chainId: 3337,
  networkId: 3337,
  slip44: 1,
  status: "incubating"
};
export {
  t as eip155_3337
};
