const e = {
  name: "MyRx Network",
  shortName: "mrt",
  chain: "MRT",
  rpc: [
    "https://rpc.myrxwallet.io",
    "wss://rpc.myrxwallet.io"
  ],
  faucets: [],
  nativeCurrency: {
    name: "MyRx Token",
    symbol: "MRT",
    decimals: 18
  },
  infoURL: "https://myrxwallet.io",
  chainId: 8472,
  networkId: 8472,
  explorers: [
    {
      name: "MyRx Explorer",
      url: "https://explorer.myrxwallet.io",
      standard: "EIP3091"
    }
  ]
};
export {
  e as eip155_8472
};
