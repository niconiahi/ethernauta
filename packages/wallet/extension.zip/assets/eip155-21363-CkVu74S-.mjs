const e = {
  name: "Lestnet",
  shortName: "leth",
  chain: "LETH",
  icon: "lestnet",
  rpc: ["https://service.lestnet.org"],
  faucets: [],
  nativeCurrency: {
    name: "Lestnet Ether",
    symbol: "LETH",
    decimals: 18
  },
  infoURL: "https://lestnet.org",
  chainId: 21363,
  networkId: 21363,
  explorers: [
    {
      name: "Lestnet Explorer",
      url: "https://explore.lestnet.org",
      standard: "EIP3091"
    }
  ]
};
export {
  e as eip155_21363
};
