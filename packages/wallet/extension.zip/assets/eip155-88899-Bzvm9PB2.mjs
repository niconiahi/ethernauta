const e = {
  name: "Unite",
  shortName: "unite",
  chain: "UNITE",
  icon: "unite",
  rpc: ["https://unite-mainnet.g.alchemy.com/public"],
  faucets: [],
  nativeCurrency: {
    name: "Unite",
    symbol: "UNITE",
    decimals: 18
  },
  infoURL: "https://unite.io",
  chainId: 88899,
  networkId: 88899,
  explorers: [
    {
      name: "Unite Explorer",
      url: "https://unite-mainnet.explorer.alchemy.com",
      standard: "EIP3091"
    }
  ],
  status: "active"
};
export {
  e as eip155_88899
};
