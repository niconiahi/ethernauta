const qe =
  typeof globalThis == "object" && "crypto" in globalThis
    ? globalThis.crypto
    : void 0 /*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
function Et(t) {
  return (
    t instanceof Uint8Array ||
    (ArrayBuffer.isView(t) &&
      t.constructor.name === "Uint8Array")
  )
}
function Ee(t) {
  if (!Number.isSafeInteger(t) || t < 0)
    throw new Error("positive integer expected, got " + t)
}
function Z(t, ...e) {
  if (!Et(t)) throw new Error("Uint8Array expected")
  if (e.length > 0 && !e.includes(t.length))
    throw new Error(
      "Uint8Array expected of length " +
        e +
        ", got length=" +
        t.length,
    )
}
function Xt(t) {
  if (
    typeof t != "function" ||
    typeof t.create != "function"
  )
    throw new Error(
      "Hash should be wrapped by utils.createHasher",
    )
  Ee(t.outputLen), Ee(t.blockLen)
}
function Ve(t, e = !0) {
  if (t.destroyed)
    throw new Error("Hash instance has been destroyed")
  if (e && t.finished)
    throw new Error("Hash#digest() has already been called")
}
function Ln(t, e) {
  Z(t)
  const n = e.outputLen
  if (t.length < n)
    throw new Error(
      "digestInto() expects output buffer of length at least " +
        n,
    )
}
function zr(t) {
  return new Uint32Array(
    t.buffer,
    t.byteOffset,
    Math.floor(t.byteLength / 4),
  )
}
function ie(...t) {
  for (let e = 0; e < t.length; e++) t[e].fill(0)
}
function _e(t) {
  return new DataView(t.buffer, t.byteOffset, t.byteLength)
}
function oe(t, e) {
  return (t << (32 - e)) | (t >>> e)
}
function nt(t, e) {
  return (t << e) | ((t >>> (32 - e)) >>> 0)
}
const Zr =
  new Uint8Array(new Uint32Array([287454020]).buffer)[0] ===
  68
function Vr(t) {
  return (
    ((t << 24) & 4278190080) |
    ((t << 8) & 16711680) |
    ((t >>> 8) & 65280) |
    ((t >>> 24) & 255)
  )
}
function Mr(t) {
  for (let e = 0; e < t.length; e++) t[e] = Vr(t[e])
  return t
}
const hn = Zr ? (t) => t : Mr,
  Cn =
    typeof Uint8Array.from([]).toHex == "function" &&
    typeof Uint8Array.fromHex == "function",
  Dr = Array.from({ length: 256 }, (t, e) =>
    e.toString(16).padStart(2, "0"),
  )
function Ue(t) {
  if ((Z(t), Cn)) return t.toHex()
  let e = ""
  for (let n = 0; n < t.length; n++) e += Dr[t[n]]
  return e
}
const ae = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 }
function pn(t) {
  if (t >= ae._0 && t <= ae._9) return t - ae._0
  if (t >= ae.A && t <= ae.F) return t - (ae.A - 10)
  if (t >= ae.a && t <= ae.f) return t - (ae.a - 10)
}
function Pe(t) {
  if (typeof t != "string")
    throw new Error("hex string expected, got " + typeof t)
  if (Cn) return Uint8Array.fromHex(t)
  const e = t.length,
    n = e / 2
  if (e % 2)
    throw new Error(
      "hex string expected, got unpadded hex of length " +
        e,
    )
  const r = new Uint8Array(n)
  for (let s = 0, i = 0; s < n; s++, i += 2) {
    const o = pn(t.charCodeAt(i)),
      c = pn(t.charCodeAt(i + 1))
    if (o === void 0 || c === void 0) {
      const a = t[i] + t[i + 1]
      throw new Error(
        'hex string expected, got non-hex character "' +
          a +
          '" at index ' +
          i,
      )
    }
    r[s] = o * 16 + c
  }
  return r
}
function Wt(t) {
  if (typeof t != "string")
    throw new Error("string expected")
  return new Uint8Array(new TextEncoder().encode(t))
}
function kt(t) {
  return typeof t == "string" && (t = Wt(t)), Z(t), t
}
function yn(t) {
  return typeof t == "string" && (t = Wt(t)), Z(t), t
}
function ne(...t) {
  let e = 0
  for (let r = 0; r < t.length; r++) {
    const s = t[r]
    Z(s), (e += s.length)
  }
  const n = new Uint8Array(e)
  for (let r = 0, s = 0; r < t.length; r++) {
    const i = t[r]
    n.set(i, s), (s += i.length)
  }
  return n
}
function Fr(t, e) {
  if (
    e !== void 0 &&
    {}.toString.call(e) !== "[object Object]"
  )
    throw new Error("options should be object or undefined")
  return Object.assign(t, e)
}
class Jt {}
function Bt(t) {
  const e = (r) => t().update(kt(r)).digest(),
    n = t()
  return (
    (e.outputLen = n.outputLen),
    (e.blockLen = n.blockLen),
    (e.create = () => t()),
    e
  )
}
function Tn(t = 32) {
  if (qe && typeof qe.getRandomValues == "function")
    return qe.getRandomValues(new Uint8Array(t))
  if (qe && typeof qe.randomBytes == "function")
    return Uint8Array.from(qe.randomBytes(t))
  throw new Error("crypto.getRandomValues must be defined")
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const Qt = BigInt(0),
  $t = BigInt(1)
function dt(t, e = "") {
  if (typeof t != "boolean") {
    const n = e && `"${e}"`
    throw new Error(
      n + "expected boolean, got type=" + typeof t,
    )
  }
  return t
}
function Ae(t, e, n = "") {
  const r = Et(t),
    s = t?.length,
    i = e !== void 0
  if (!r || (i && s !== e)) {
    const o = n && `"${n}" `,
      c = i ? ` of length ${e}` : "",
      a = r ? `length=${s}` : `type=${typeof t}`
    throw new Error(
      o + "expected Uint8Array" + c + ", got " + a,
    )
  }
  return t
}
function rt(t) {
  const e = t.toString(16)
  return e.length & 1 ? "0" + e : e
}
function $n(t) {
  if (typeof t != "string")
    throw new Error("hex string expected, got " + typeof t)
  return t === "" ? Qt : BigInt("0x" + t)
}
function At(t) {
  return $n(Ue(t))
}
function zn(t) {
  return Z(t), $n(Ue(Uint8Array.from(t).reverse()))
}
function en(t, e) {
  return Pe(t.toString(16).padStart(e * 2, "0"))
}
function Zn(t, e) {
  return en(t, e).reverse()
}
function X(t, e, n) {
  let r
  if (typeof e == "string")
    try {
      r = Pe(e)
    } catch (s) {
      throw new Error(
        t +
          " must be hex string or Uint8Array, cause: " +
          s,
      )
    }
  else if (Et(e)) r = Uint8Array.from(e)
  else
    throw new Error(t + " must be hex string or Uint8Array")
  return r.length, r
}
const Ut = (t) => typeof t == "bigint" && Qt <= t
function Yr(t, e, n) {
  return Ut(t) && Ut(e) && Ut(n) && e <= t && t < n
}
function Gr(t, e, n, r) {
  if (!Yr(e, n, r))
    throw new Error(
      "expected valid " +
        t +
        ": " +
        n +
        " <= n < " +
        r +
        ", got " +
        e,
    )
}
function Vn(t) {
  let e
  for (e = 0; t > Qt; t >>= $t, e += 1);
  return e
}
const We = (t) => ($t << BigInt(t)) - $t
function Pr(t, e, n) {
  if (typeof t != "number" || t < 2)
    throw new Error("hashLen must be a number")
  if (typeof e != "number" || e < 2)
    throw new Error("qByteLen must be a number")
  if (typeof n != "function")
    throw new Error("hmacFn must be a function")
  const r = (f) => new Uint8Array(f),
    s = (f) => Uint8Array.of(f)
  let i = r(t),
    o = r(t),
    c = 0
  const a = () => {
      i.fill(1), o.fill(0), (c = 0)
    },
    u = (...f) => n(o, i, ...f),
    d = (f = r(0)) => {
      ;(o = u(s(0), f)),
        (i = u()),
        f.length !== 0 && ((o = u(s(1), f)), (i = u()))
    },
    h = () => {
      if (c++ >= 1e3)
        throw new Error("drbg: tried 1000 values")
      let f = 0
      const b = []
      for (; f < e; ) {
        i = u()
        const m = i.slice()
        b.push(m), (f += i.length)
      }
      return ne(...b)
    }
  return (f, b) => {
    a(), d(f)
    let m
    for (; !(m = b(h())); ) d()
    return a(), m
  }
}
function tn(t, e, n = {}) {
  if (!t || typeof t != "object")
    throw new Error("expected valid options object")
  function r(s, i, o) {
    const c = t[s]
    if (o && c === void 0) return
    const a = typeof c
    if (a !== i || c === null)
      throw new Error(
        `param "${s}" is invalid: expected ${i}, got ${a}`,
      )
  }
  Object.entries(e).forEach(([s, i]) => r(s, i, !1)),
    Object.entries(n).forEach(([s, i]) => r(s, i, !0))
}
function bn(t) {
  const e = new WeakMap()
  return (n, ...r) => {
    const s = e.get(n)
    if (s !== void 0) return s
    const i = t(n, ...r)
    return e.set(n, i), i
  }
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const W = BigInt(0),
  Y = BigInt(1),
  Se = BigInt(2),
  Mn = BigInt(3),
  Dn = BigInt(4),
  Fn = BigInt(5),
  Xr = BigInt(7),
  Yn = BigInt(8),
  Wr = BigInt(9),
  Gn = BigInt(16)
function te(t, e) {
  const n = t % e
  return n >= W ? n : e + n
}
function ee(t, e, n) {
  let r = t
  for (; e-- > W; ) (r *= r), (r %= n)
  return r
}
function gn(t, e) {
  if (t === W)
    throw new Error("invert: expected non-zero number")
  if (e <= W)
    throw new Error(
      "invert: expected positive modulus, got " + e,
    )
  let n = te(t, e),
    r = e,
    s = W,
    i = Y
  for (; n !== W; ) {
    const c = r / n,
      a = r % n,
      u = s - i * c
    ;(r = n), (n = a), (s = i), (i = u)
  }
  if (r !== Y) throw new Error("invert: does not exist")
  return te(s, e)
}
function nn(t, e, n) {
  if (!t.eql(t.sqr(e), n))
    throw new Error("Cannot find square root")
}
function Pn(t, e) {
  const n = (t.ORDER + Y) / Dn,
    r = t.pow(e, n)
  return nn(t, r, e), r
}
function Jr(t, e) {
  const n = (t.ORDER - Fn) / Yn,
    r = t.mul(e, Se),
    s = t.pow(r, n),
    i = t.mul(e, s),
    o = t.mul(t.mul(i, Se), s),
    c = t.mul(i, t.sub(o, t.ONE))
  return nn(t, c, e), c
}
function Qr(t) {
  const e = Je(t),
    n = Xn(t),
    r = n(e, e.neg(e.ONE)),
    s = n(e, r),
    i = n(e, e.neg(r)),
    o = (t + Xr) / Gn
  return (c, a) => {
    let u = c.pow(a, o),
      d = c.mul(u, r)
    const h = c.mul(u, s),
      l = c.mul(u, i),
      f = c.eql(c.sqr(d), a),
      b = c.eql(c.sqr(h), a)
    ;(u = c.cmov(u, d, f)), (d = c.cmov(l, h, b))
    const m = c.eql(c.sqr(d), a),
      E = c.cmov(u, d, m)
    return nn(c, E, a), E
  }
}
function Xn(t) {
  if (t < Mn)
    throw new Error("sqrt is not defined for small field")
  let e = t - Y,
    n = 0
  for (; e % Se === W; ) (e /= Se), n++
  let r = Se
  const s = Je(t)
  for (; mn(s, r) === 1; )
    if (r++ > 1e3)
      throw new Error(
        "Cannot find square root: probably non-prime P",
      )
  if (n === 1) return Pn
  const i = s.pow(r, e)
  const o = (e + Y) / Se
  return (a, u) => {
    if (a.is0(u)) return u
    if (mn(a, u) !== 1)
      throw new Error("Cannot find square root")
    let d = n,
      h = a.mul(a.ONE, i),
      l = a.pow(u, e),
      f = a.pow(u, o)
    for (; !a.eql(l, a.ONE); ) {
      if (a.is0(l)) return a.ZERO
      let b = 1,
        m = a.sqr(l)
      for (; !a.eql(m, a.ONE); )
        if ((b++, (m = a.sqr(m)), b === d))
          throw new Error("Cannot find square root")
      const E = Y << BigInt(d - b - 1),
        I = a.pow(h, E)
      ;(d = b),
        (h = a.sqr(I)),
        (l = a.mul(l, h)),
        (f = a.mul(f, I))
    }
    return f
  }
}
function es(t) {
  return t % Dn === Mn
    ? Pn
    : t % Yn === Fn
      ? Jr
      : t % Gn === Wr
        ? Qr(t)
        : Xn(t)
}
const ts = [
  "create",
  "isValid",
  "is0",
  "neg",
  "inv",
  "sqrt",
  "sqr",
  "eql",
  "add",
  "sub",
  "mul",
  "pow",
  "div",
  "addN",
  "subN",
  "mulN",
  "sqrN",
]
function ns(t) {
  const e = {
      ORDER: "bigint",
      MASK: "bigint",
      BYTES: "number",
      BITS: "number",
    },
    n = ts.reduce((r, s) => ((r[s] = "function"), r), e)
  return tn(t, n), t
}
function rs(t, e, n) {
  if (n < W)
    throw new Error(
      "invalid exponent, negatives unsupported",
    )
  if (n === W) return t.ONE
  if (n === Y) return e
  let r = t.ONE,
    s = e
  for (; n > W; )
    n & Y && (r = t.mul(r, s)), (s = t.sqr(s)), (n >>= Y)
  return r
}
function Wn(t, e, n = !1) {
  const r = new Array(e.length).fill(n ? t.ZERO : void 0),
    s = e.reduce(
      (o, c, a) =>
        t.is0(c) ? o : ((r[a] = o), t.mul(o, c)),
      t.ONE,
    ),
    i = t.inv(s)
  return (
    e.reduceRight(
      (o, c, a) =>
        t.is0(c)
          ? o
          : ((r[a] = t.mul(o, r[a])), t.mul(o, c)),
      i,
    ),
    r
  )
}
function mn(t, e) {
  const n = (t.ORDER - Y) / Se,
    r = t.pow(e, n),
    s = t.eql(r, t.ONE),
    i = t.eql(r, t.ZERO),
    o = t.eql(r, t.neg(t.ONE))
  if (!s && !i && !o)
    throw new Error("invalid Legendre symbol result")
  return s ? 1 : i ? 0 : -1
}
function Jn(t, e) {
  e !== void 0 && Ee(e)
  const n = e !== void 0 ? e : t.toString(2).length,
    r = Math.ceil(n / 8)
  return { nBitLength: n, nByteLength: r }
}
function Je(t, e, n = !1, r = {}) {
  if (t <= W)
    throw new Error(
      "invalid field: expected ORDER > 0, got " + t,
    )
  let s,
    i,
    o = !1,
    c
  if (typeof e == "object" && e != null) {
    if (r.sqrt || n)
      throw new Error(
        "cannot specify opts in two arguments",
      )
    const l = e
    l.BITS && (s = l.BITS),
      l.sqrt && (i = l.sqrt),
      typeof l.isLE == "boolean" && (n = l.isLE),
      typeof l.modFromBytes == "boolean" &&
        (o = l.modFromBytes),
      (c = l.allowedLengths)
  } else
    typeof e == "number" && (s = e), r.sqrt && (i = r.sqrt)
  const { nBitLength: a, nByteLength: u } = Jn(t, s)
  if (u > 2048)
    throw new Error(
      "invalid field: expected ORDER of <= 2048 bytes",
    )
  let d
  const h = Object.freeze({
    ORDER: t,
    isLE: n,
    BITS: a,
    BYTES: u,
    MASK: We(a),
    ZERO: W,
    ONE: Y,
    allowedLengths: c,
    create: (l) => te(l, t),
    isValid: (l) => {
      if (typeof l != "bigint")
        throw new Error(
          "invalid field element: expected bigint, got " +
            typeof l,
        )
      return W <= l && l < t
    },
    is0: (l) => l === W,
    isValidNot0: (l) => !h.is0(l) && h.isValid(l),
    isOdd: (l) => (l & Y) === Y,
    neg: (l) => te(-l, t),
    eql: (l, f) => l === f,
    sqr: (l) => te(l * l, t),
    add: (l, f) => te(l + f, t),
    sub: (l, f) => te(l - f, t),
    mul: (l, f) => te(l * f, t),
    pow: (l, f) => rs(h, l, f),
    div: (l, f) => te(l * gn(f, t), t),
    sqrN: (l) => l * l,
    addN: (l, f) => l + f,
    subN: (l, f) => l - f,
    mulN: (l, f) => l * f,
    inv: (l) => gn(l, t),
    sqrt: i || ((l) => (d || (d = es(t)), d(h, l))),
    toBytes: (l) => (n ? Zn(l, u) : en(l, u)),
    fromBytes: (l, f = !0) => {
      if (c) {
        if (!c.includes(l.length) || l.length > u)
          throw new Error(
            "Field.fromBytes: expected " +
              c +
              " bytes, got " +
              l.length,
          )
        const m = new Uint8Array(u)
        m.set(l, n ? 0 : m.length - l.length), (l = m)
      }
      if (l.length !== u)
        throw new Error(
          "Field.fromBytes: expected " +
            u +
            " bytes, got " +
            l.length,
        )
      let b = n ? zn(l) : At(l)
      if ((o && (b = te(b, t)), !f && !h.isValid(b)))
        throw new Error(
          "invalid field element: outside of range 0..ORDER",
        )
      return b
    },
    invertBatch: (l) => Wn(h, l),
    cmov: (l, f, b) => (b ? f : l),
  })
  return Object.freeze(h)
}
function Qn(t) {
  if (typeof t != "bigint")
    throw new Error("field order must be bigint")
  const e = t.toString(2).length
  return Math.ceil(e / 8)
}
function er(t) {
  const e = Qn(t)
  return e + Math.ceil(e / 2)
}
function ss(t, e, n = !1) {
  const r = t.length,
    s = Qn(e),
    i = er(e)
  if (r < 16 || r < i || r > 1024)
    throw new Error(
      "expected " + i + "-1024 bytes of input, got " + r,
    )
  const o = n ? zn(t) : At(t),
    c = te(o, e - Y) + Y
  return n ? Zn(c, s) : en(c, s)
}
function is(t, e, n, r) {
  if (typeof t.setBigUint64 == "function")
    return t.setBigUint64(e, n, r)
  const s = BigInt(32),
    i = BigInt(4294967295),
    o = Number((n >> s) & i),
    c = Number(n & i),
    a = r ? 4 : 0,
    u = r ? 0 : 4
  t.setUint32(e + a, o, r), t.setUint32(e + u, c, r)
}
function os(t, e, n) {
  return (t & e) ^ (~t & n)
}
function cs(t, e, n) {
  return (t & e) ^ (t & n) ^ (e & n)
}
class rn extends Jt {
  constructor(e, n, r, s) {
    super(),
      (this.finished = !1),
      (this.length = 0),
      (this.pos = 0),
      (this.destroyed = !1),
      (this.blockLen = e),
      (this.outputLen = n),
      (this.padOffset = r),
      (this.isLE = s),
      (this.buffer = new Uint8Array(e)),
      (this.view = _e(this.buffer))
  }
  update(e) {
    Ve(this), (e = kt(e)), Z(e)
    const { view: n, buffer: r, blockLen: s } = this,
      i = e.length
    for (let o = 0; o < i; ) {
      const c = Math.min(s - this.pos, i - o)
      if (c === s) {
        const a = _e(e)
        for (; s <= i - o; o += s) this.process(a, o)
        continue
      }
      r.set(e.subarray(o, o + c), this.pos),
        (this.pos += c),
        (o += c),
        this.pos === s &&
          (this.process(n, 0), (this.pos = 0))
    }
    return (
      (this.length += e.length), this.roundClean(), this
    )
  }
  digestInto(e) {
    Ve(this), Ln(e, this), (this.finished = !0)
    const {
      buffer: n,
      view: r,
      blockLen: s,
      isLE: i,
    } = this
    let { pos: o } = this
    ;(n[o++] = 128),
      ie(this.buffer.subarray(o)),
      this.padOffset > s - o &&
        (this.process(r, 0), (o = 0))
    for (let h = o; h < s; h++) n[h] = 0
    is(r, s - 8, BigInt(this.length * 8), i),
      this.process(r, 0)
    const c = _e(e),
      a = this.outputLen
    if (a % 4)
      throw new Error(
        "_sha2: outputLen should be aligned to 32bit",
      )
    const u = a / 4,
      d = this.get()
    if (u > d.length)
      throw new Error("_sha2: outputLen bigger than state")
    for (let h = 0; h < u; h++) c.setUint32(4 * h, d[h], i)
  }
  digest() {
    const { buffer: e, outputLen: n } = this
    this.digestInto(e)
    const r = e.slice(0, n)
    return this.destroy(), r
  }
  _cloneInto(e) {
    e || (e = new this.constructor()), e.set(...this.get())
    const {
      blockLen: n,
      buffer: r,
      length: s,
      finished: i,
      destroyed: o,
      pos: c,
    } = this
    return (
      (e.destroyed = o),
      (e.finished = i),
      (e.length = s),
      (e.pos = c),
      s % n && e.buffer.set(r),
      e
    )
  }
  clone() {
    return this._cloneInto()
  }
}
const me = Uint32Array.from([
    1779033703, 3144134277, 1013904242, 2773480762,
    1359893119, 2600822924, 528734635, 1541459225,
  ]),
  D = Uint32Array.from([
    1779033703, 4089235720, 3144134277, 2227873595,
    1013904242, 4271175723, 2773480762, 1595750129,
    1359893119, 2917565137, 2600822924, 725511199,
    528734635, 4215389547, 1541459225, 327033209,
  ]),
  st = BigInt(2 ** 32 - 1),
  wn = BigInt(32)
function as(t, e = !1) {
  return e
    ? { h: Number(t & st), l: Number((t >> wn) & st) }
    : {
        h: Number((t >> wn) & st) | 0,
        l: Number(t & st) | 0,
      }
}
function tr(t, e = !1) {
  const n = t.length
  const r = new Uint32Array(n),
    s = new Uint32Array(n)
  for (let i = 0; i < n; i++) {
    const { h: o, l: c } = as(t[i], e)
    ;[r[i], s[i]] = [o, c]
  }
  return [r, s]
}
const vn = (t, e, n) => t >>> n,
  xn = (t, e, n) => (t << (32 - n)) | (e >>> n),
  je = (t, e, n) => (t >>> n) | (e << (32 - n)),
  Le = (t, e, n) => (t << (32 - n)) | (e >>> n),
  it = (t, e, n) => (t << (64 - n)) | (e >>> (n - 32)),
  ot = (t, e, n) => (t >>> (n - 32)) | (e << (64 - n)),
  ls = (t, e, n) => (t << n) | (e >>> (32 - n)),
  us = (t, e, n) => (e << n) | (t >>> (32 - n)),
  fs = (t, e, n) => (e << (n - 32)) | (t >>> (64 - n)),
  ds = (t, e, n) => (t << (n - 32)) | (e >>> (64 - n))
function le(t, e, n, r) {
  const s = (e >>> 0) + (r >>> 0)
  return { h: (t + n + ((s / 2 ** 32) | 0)) | 0, l: s | 0 }
}
const hs = (t, e, n) => (t >>> 0) + (e >>> 0) + (n >>> 0),
  ps = (t, e, n, r) =>
    (e + n + r + ((t / 2 ** 32) | 0)) | 0,
  ys = (t, e, n, r) =>
    (t >>> 0) + (e >>> 0) + (n >>> 0) + (r >>> 0),
  bs = (t, e, n, r, s) =>
    (e + n + r + s + ((t / 2 ** 32) | 0)) | 0,
  gs = (t, e, n, r, s) =>
    (t >>> 0) +
    (e >>> 0) +
    (n >>> 0) +
    (r >>> 0) +
    (s >>> 0),
  ms = (t, e, n, r, s, i) =>
    (e + n + r + s + i + ((t / 2 ** 32) | 0)) | 0,
  ws = Uint32Array.from([
    1116352408, 1899447441, 3049323471, 3921009573,
    961987163, 1508970993, 2453635748, 2870763221,
    3624381080, 310598401, 607225278, 1426881987,
    1925078388, 2162078206, 2614888103, 3248222580,
    3835390401, 4022224774, 264347078, 604807628, 770255983,
    1249150122, 1555081692, 1996064986, 2554220882,
    2821834349, 2952996808, 3210313671, 3336571891,
    3584528711, 113926993, 338241895, 666307205, 773529912,
    1294757372, 1396182291, 1695183700, 1986661051,
    2177026350, 2456956037, 2730485921, 2820302411,
    3259730800, 3345764771, 3516065817, 3600352804,
    4094571909, 275423344, 430227734, 506948616, 659060556,
    883997877, 958139571, 1322822218, 1537002063,
    1747873779, 1955562222, 2024104815, 2227730452,
    2361852424, 2428436474, 2756734187, 3204031479,
    3329325298,
  ]),
  we = new Uint32Array(64)
class vs extends rn {
  constructor(e = 32) {
    super(64, e, 8, !1),
      (this.A = me[0] | 0),
      (this.B = me[1] | 0),
      (this.C = me[2] | 0),
      (this.D = me[3] | 0),
      (this.E = me[4] | 0),
      (this.F = me[5] | 0),
      (this.G = me[6] | 0),
      (this.H = me[7] | 0)
  }
  get() {
    const {
      A: e,
      B: n,
      C: r,
      D: s,
      E: i,
      F: o,
      G: c,
      H: a,
    } = this
    return [e, n, r, s, i, o, c, a]
  }
  set(e, n, r, s, i, o, c, a) {
    ;(this.A = e | 0),
      (this.B = n | 0),
      (this.C = r | 0),
      (this.D = s | 0),
      (this.E = i | 0),
      (this.F = o | 0),
      (this.G = c | 0),
      (this.H = a | 0)
  }
  process(e, n) {
    for (let h = 0; h < 16; h++, n += 4)
      we[h] = e.getUint32(n, !1)
    for (let h = 16; h < 64; h++) {
      const l = we[h - 15],
        f = we[h - 2],
        b = oe(l, 7) ^ oe(l, 18) ^ (l >>> 3),
        m = oe(f, 17) ^ oe(f, 19) ^ (f >>> 10)
      we[h] = (m + we[h - 7] + b + we[h - 16]) | 0
    }
    let {
      A: r,
      B: s,
      C: i,
      D: o,
      E: c,
      F: a,
      G: u,
      H: d,
    } = this
    for (let h = 0; h < 64; h++) {
      const l = oe(c, 6) ^ oe(c, 11) ^ oe(c, 25),
        f = (d + l + os(c, a, u) + ws[h] + we[h]) | 0,
        m =
          ((oe(r, 2) ^ oe(r, 13) ^ oe(r, 22)) +
            cs(r, s, i)) |
          0
      ;(d = u),
        (u = a),
        (a = c),
        (c = (o + f) | 0),
        (o = i),
        (i = s),
        (s = r),
        (r = (f + m) | 0)
    }
    ;(r = (r + this.A) | 0),
      (s = (s + this.B) | 0),
      (i = (i + this.C) | 0),
      (o = (o + this.D) | 0),
      (c = (c + this.E) | 0),
      (a = (a + this.F) | 0),
      (u = (u + this.G) | 0),
      (d = (d + this.H) | 0),
      this.set(r, s, i, o, c, a, u, d)
  }
  roundClean() {
    ie(we)
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0), ie(this.buffer)
  }
}
const nr = tr(
    [
      "0x428a2f98d728ae22",
      "0x7137449123ef65cd",
      "0xb5c0fbcfec4d3b2f",
      "0xe9b5dba58189dbbc",
      "0x3956c25bf348b538",
      "0x59f111f1b605d019",
      "0x923f82a4af194f9b",
      "0xab1c5ed5da6d8118",
      "0xd807aa98a3030242",
      "0x12835b0145706fbe",
      "0x243185be4ee4b28c",
      "0x550c7dc3d5ffb4e2",
      "0x72be5d74f27b896f",
      "0x80deb1fe3b1696b1",
      "0x9bdc06a725c71235",
      "0xc19bf174cf692694",
      "0xe49b69c19ef14ad2",
      "0xefbe4786384f25e3",
      "0x0fc19dc68b8cd5b5",
      "0x240ca1cc77ac9c65",
      "0x2de92c6f592b0275",
      "0x4a7484aa6ea6e483",
      "0x5cb0a9dcbd41fbd4",
      "0x76f988da831153b5",
      "0x983e5152ee66dfab",
      "0xa831c66d2db43210",
      "0xb00327c898fb213f",
      "0xbf597fc7beef0ee4",
      "0xc6e00bf33da88fc2",
      "0xd5a79147930aa725",
      "0x06ca6351e003826f",
      "0x142929670a0e6e70",
      "0x27b70a8546d22ffc",
      "0x2e1b21385c26c926",
      "0x4d2c6dfc5ac42aed",
      "0x53380d139d95b3df",
      "0x650a73548baf63de",
      "0x766a0abb3c77b2a8",
      "0x81c2c92e47edaee6",
      "0x92722c851482353b",
      "0xa2bfe8a14cf10364",
      "0xa81a664bbc423001",
      "0xc24b8b70d0f89791",
      "0xc76c51a30654be30",
      "0xd192e819d6ef5218",
      "0xd69906245565a910",
      "0xf40e35855771202a",
      "0x106aa07032bbd1b8",
      "0x19a4c116b8d2d0c8",
      "0x1e376c085141ab53",
      "0x2748774cdf8eeb99",
      "0x34b0bcb5e19b48a8",
      "0x391c0cb3c5c95a63",
      "0x4ed8aa4ae3418acb",
      "0x5b9cca4f7763e373",
      "0x682e6ff3d6b2b8a3",
      "0x748f82ee5defb2fc",
      "0x78a5636f43172f60",
      "0x84c87814a1f0ab72",
      "0x8cc702081a6439ec",
      "0x90befffa23631e28",
      "0xa4506cebde82bde9",
      "0xbef9a3f7b2c67915",
      "0xc67178f2e372532b",
      "0xca273eceea26619c",
      "0xd186b8c721c0c207",
      "0xeada7dd6cde0eb1e",
      "0xf57d4f7fee6ed178",
      "0x06f067aa72176fba",
      "0x0a637dc5a2c898a6",
      "0x113f9804bef90dae",
      "0x1b710b35131c471b",
      "0x28db77f523047d84",
      "0x32caab7b40c72493",
      "0x3c9ebe0a15c9bebc",
      "0x431d67c49c100d4c",
      "0x4cc5d4becb3e42b6",
      "0x597f299cfc657e2a",
      "0x5fcb6fab3ad6faec",
      "0x6c44198c4a475817",
    ].map((t) => BigInt(t)),
  ),
  xs = nr[0],
  Es = nr[1],
  ve = new Uint32Array(80),
  xe = new Uint32Array(80)
class ks extends rn {
  constructor(e = 64) {
    super(128, e, 16, !1),
      (this.Ah = D[0] | 0),
      (this.Al = D[1] | 0),
      (this.Bh = D[2] | 0),
      (this.Bl = D[3] | 0),
      (this.Ch = D[4] | 0),
      (this.Cl = D[5] | 0),
      (this.Dh = D[6] | 0),
      (this.Dl = D[7] | 0),
      (this.Eh = D[8] | 0),
      (this.El = D[9] | 0),
      (this.Fh = D[10] | 0),
      (this.Fl = D[11] | 0),
      (this.Gh = D[12] | 0),
      (this.Gl = D[13] | 0),
      (this.Hh = D[14] | 0),
      (this.Hl = D[15] | 0)
  }
  get() {
    const {
      Ah: e,
      Al: n,
      Bh: r,
      Bl: s,
      Ch: i,
      Cl: o,
      Dh: c,
      Dl: a,
      Eh: u,
      El: d,
      Fh: h,
      Fl: l,
      Gh: f,
      Gl: b,
      Hh: m,
      Hl: E,
    } = this
    return [e, n, r, s, i, o, c, a, u, d, h, l, f, b, m, E]
  }
  set(e, n, r, s, i, o, c, a, u, d, h, l, f, b, m, E) {
    ;(this.Ah = e | 0),
      (this.Al = n | 0),
      (this.Bh = r | 0),
      (this.Bl = s | 0),
      (this.Ch = i | 0),
      (this.Cl = o | 0),
      (this.Dh = c | 0),
      (this.Dl = a | 0),
      (this.Eh = u | 0),
      (this.El = d | 0),
      (this.Fh = h | 0),
      (this.Fl = l | 0),
      (this.Gh = f | 0),
      (this.Gl = b | 0),
      (this.Hh = m | 0),
      (this.Hl = E | 0)
  }
  process(e, n) {
    for (let v = 0; v < 16; v++, n += 4)
      (ve[v] = e.getUint32(n)),
        (xe[v] = e.getUint32((n += 4)))
    for (let v = 16; v < 80; v++) {
      const z = ve[v - 15] | 0,
        O = xe[v - 15] | 0,
        G = je(z, O, 1) ^ je(z, O, 8) ^ vn(z, O, 7),
        ge = Le(z, O, 1) ^ Le(z, O, 8) ^ xn(z, O, 7),
        V = ve[v - 2] | 0,
        U = xe[v - 2] | 0,
        ce = je(V, U, 19) ^ it(V, U, 61) ^ vn(V, U, 6),
        se = Le(V, U, 19) ^ ot(V, U, 61) ^ xn(V, U, 6),
        R = ys(ge, se, xe[v - 7], xe[v - 16]),
        g = bs(R, G, ce, ve[v - 7], ve[v - 16])
      ;(ve[v] = g | 0), (xe[v] = R | 0)
    }
    let {
      Ah: r,
      Al: s,
      Bh: i,
      Bl: o,
      Ch: c,
      Cl: a,
      Dh: u,
      Dl: d,
      Eh: h,
      El: l,
      Fh: f,
      Fl: b,
      Gh: m,
      Gl: E,
      Hh: I,
      Hl: K,
    } = this
    for (let v = 0; v < 80; v++) {
      const z = je(h, l, 14) ^ je(h, l, 18) ^ it(h, l, 41),
        O = Le(h, l, 14) ^ Le(h, l, 18) ^ ot(h, l, 41),
        G = (h & f) ^ (~h & m),
        ge = (l & b) ^ (~l & E),
        V = gs(K, O, ge, Es[v], xe[v]),
        U = ms(V, I, z, G, xs[v], ve[v]),
        ce = V | 0,
        se = je(r, s, 28) ^ it(r, s, 34) ^ it(r, s, 39),
        R = Le(r, s, 28) ^ ot(r, s, 34) ^ ot(r, s, 39),
        g = (r & i) ^ (r & c) ^ (i & c),
        y = (s & o) ^ (s & a) ^ (o & a)
      ;(I = m | 0),
        (K = E | 0),
        (m = f | 0),
        (E = b | 0),
        (f = h | 0),
        (b = l | 0),
        ({ h, l } = le(u | 0, d | 0, U | 0, ce | 0)),
        (u = c | 0),
        (d = a | 0),
        (c = i | 0),
        (a = o | 0),
        (i = r | 0),
        (o = s | 0)
      const p = hs(ce, R, y)
      ;(r = ps(p, U, se, g)), (s = p | 0)
    }
    ;({ h: r, l: s } = le(
      this.Ah | 0,
      this.Al | 0,
      r | 0,
      s | 0,
    )),
      ({ h: i, l: o } = le(
        this.Bh | 0,
        this.Bl | 0,
        i | 0,
        o | 0,
      )),
      ({ h: c, l: a } = le(
        this.Ch | 0,
        this.Cl | 0,
        c | 0,
        a | 0,
      )),
      ({ h: u, l: d } = le(
        this.Dh | 0,
        this.Dl | 0,
        u | 0,
        d | 0,
      )),
      ({ h, l } = le(
        this.Eh | 0,
        this.El | 0,
        h | 0,
        l | 0,
      )),
      ({ h: f, l: b } = le(
        this.Fh | 0,
        this.Fl | 0,
        f | 0,
        b | 0,
      )),
      ({ h: m, l: E } = le(
        this.Gh | 0,
        this.Gl | 0,
        m | 0,
        E | 0,
      )),
      ({ h: I, l: K } = le(
        this.Hh | 0,
        this.Hl | 0,
        I | 0,
        K | 0,
      )),
      this.set(
        r,
        s,
        i,
        o,
        c,
        a,
        u,
        d,
        h,
        l,
        f,
        b,
        m,
        E,
        I,
        K,
      )
  }
  roundClean() {
    ie(ve, xe)
  }
  destroy() {
    ie(this.buffer),
      this.set(
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
      )
  }
}
const St = Bt(() => new vs()),
  zt = Bt(() => new ks())
class rr extends Jt {
  constructor(e, n) {
    super(),
      (this.finished = !1),
      (this.destroyed = !1),
      Xt(e)
    const r = kt(n)
    if (
      ((this.iHash = e.create()),
      typeof this.iHash.update != "function")
    )
      throw new Error(
        "Expected instance of class which extends utils.Hash",
      )
    ;(this.blockLen = this.iHash.blockLen),
      (this.outputLen = this.iHash.outputLen)
    const s = this.blockLen,
      i = new Uint8Array(s)
    i.set(r.length > s ? e.create().update(r).digest() : r)
    for (let o = 0; o < i.length; o++) i[o] ^= 54
    this.iHash.update(i), (this.oHash = e.create())
    for (let o = 0; o < i.length; o++) i[o] ^= 106
    this.oHash.update(i), ie(i)
  }
  update(e) {
    return Ve(this), this.iHash.update(e), this
  }
  digestInto(e) {
    Ve(this),
      Z(e, this.outputLen),
      (this.finished = !0),
      this.iHash.digestInto(e),
      this.oHash.update(e),
      this.oHash.digestInto(e),
      this.destroy()
  }
  digest() {
    const e = new Uint8Array(this.oHash.outputLen)
    return this.digestInto(e), e
  }
  _cloneInto(e) {
    e ||
      (e = Object.create(Object.getPrototypeOf(this), {}))
    const {
      oHash: n,
      iHash: r,
      finished: s,
      destroyed: i,
      blockLen: o,
      outputLen: c,
    } = this
    return (
      (e = e),
      (e.finished = s),
      (e.destroyed = i),
      (e.blockLen = o),
      (e.outputLen = c),
      (e.oHash = n._cloneInto(e.oHash)),
      (e.iHash = r._cloneInto(e.iHash)),
      e
    )
  }
  clone() {
    return this._cloneInto()
  }
  destroy() {
    ;(this.destroyed = !0),
      this.oHash.destroy(),
      this.iHash.destroy()
  }
}
const Xe = (t, e, n) => new rr(t, e).update(n).digest()
Xe.create = (t, e) =>
  new rr(
    t,
    e,
  ) /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const Me = BigInt(0),
  Ie = BigInt(1)
function ht(t, e) {
  const n = e.negate()
  return t ? n : e
}
function Ht(t, e) {
  const n = Wn(
    t.Fp,
    e.map((r) => r.Z),
  )
  return e.map((r, s) => t.fromAffine(r.toAffine(n[s])))
}
function sr(t, e) {
  if (!Number.isSafeInteger(t) || t <= 0 || t > e)
    throw new Error(
      "invalid window size, expected [1.." +
        e +
        "], got W=" +
        t,
    )
}
function Rt(t, e) {
  sr(t, e)
  const n = Math.ceil(e / t) + 1,
    r = 2 ** (t - 1),
    s = 2 ** t,
    i = We(t),
    o = BigInt(t)
  return {
    windows: n,
    windowSize: r,
    mask: i,
    maxNumber: s,
    shiftBy: o,
  }
}
function En(t, e, n) {
  const {
    windowSize: r,
    mask: s,
    maxNumber: i,
    shiftBy: o,
  } = n
  let c = Number(t & s),
    a = t >> o
  c > r && ((c -= i), (a += Ie))
  const u = e * r,
    d = u + Math.abs(c) - 1,
    h = c === 0,
    l = c < 0,
    f = e % 2 !== 0
  return {
    nextN: a,
    offset: d,
    isZero: h,
    isNeg: l,
    isNegF: f,
    offsetF: u,
  }
}
function Bs(t, e) {
  if (!Array.isArray(t)) throw new Error("array expected")
  t.forEach((n, r) => {
    if (!(n instanceof e))
      throw new Error("invalid point at index " + r)
  })
}
function As(t, e) {
  if (!Array.isArray(t))
    throw new Error("array of scalars expected")
  t.forEach((n, r) => {
    if (!e.isValid(n))
      throw new Error("invalid scalar at index " + r)
  })
}
const Kt = new WeakMap(),
  ir = new WeakMap()
function Nt(t) {
  return ir.get(t) || 1
}
function kn(t) {
  if (t !== Me) throw new Error("invalid wNAF")
}
const Ss = class {
  constructor(e, n) {
    ;(this.BASE = e.BASE),
      (this.ZERO = e.ZERO),
      (this.Fn = e.Fn),
      (this.bits = n)
  }
  _unsafeLadder(e, n, r = this.ZERO) {
    let s = e
    for (; n > Me; )
      n & Ie && (r = r.add(s)), (s = s.double()), (n >>= Ie)
    return r
  }
  precomputeWindow(e, n) {
    const { windows: r, windowSize: s } = Rt(n, this.bits),
      i = []
    let o = e,
      c = o
    for (let a = 0; a < r; a++) {
      ;(c = o), i.push(c)
      for (let u = 1; u < s; u++) (c = c.add(o)), i.push(c)
      o = c.double()
    }
    return i
  }
  wNAF(e, n, r) {
    if (!this.Fn.isValid(r))
      throw new Error("invalid scalar")
    let s = this.ZERO,
      i = this.BASE
    const o = Rt(e, this.bits)
    for (let c = 0; c < o.windows; c++) {
      const {
        nextN: a,
        offset: u,
        isZero: d,
        isNeg: h,
        isNegF: l,
        offsetF: f,
      } = En(r, c, o)
      ;(r = a),
        d
          ? (i = i.add(ht(l, n[f])))
          : (s = s.add(ht(h, n[u])))
    }
    return kn(r), { p: s, f: i }
  }
  wNAFUnsafe(e, n, r, s = this.ZERO) {
    const i = Rt(e, this.bits)
    for (let o = 0; o < i.windows && r !== Me; o++) {
      const {
        nextN: c,
        offset: a,
        isZero: u,
        isNeg: d,
      } = En(r, o, i)
      if (((r = c), !u)) {
        const h = n[a]
        s = s.add(d ? h.negate() : h)
      }
    }
    return kn(r), s
  }
  getPrecomputes(e, n, r) {
    let s = Kt.get(n)
    return (
      s ||
        ((s = this.precomputeWindow(n, e)),
        e !== 1 &&
          (typeof r == "function" && (s = r(s)),
          Kt.set(n, s))),
      s
    )
  }
  cached(e, n, r) {
    const s = Nt(e)
    return this.wNAF(s, this.getPrecomputes(s, e, r), n)
  }
  unsafe(e, n, r, s) {
    const i = Nt(e)
    return i === 1
      ? this._unsafeLadder(e, n, s)
      : this.wNAFUnsafe(
          i,
          this.getPrecomputes(i, e, r),
          n,
          s,
        )
  }
  createCache(e, n) {
    sr(n, this.bits), ir.set(e, n), Kt.delete(e)
  }
  hasCache(e) {
    return Nt(e) !== 1
  }
}
function Is(t, e, n, r) {
  let s = e,
    i = t.ZERO,
    o = t.ZERO
  for (; n > Me || r > Me; )
    n & Ie && (i = i.add(s)),
      r & Ie && (o = o.add(s)),
      (s = s.double()),
      (n >>= Ie),
      (r >>= Ie)
  return { p1: i, p2: o }
}
function _s(t, e, n, r) {
  Bs(n, t), As(r, e)
  const s = n.length,
    i = r.length
  if (s !== i)
    throw new Error(
      "arrays of points and scalars must have equal length",
    )
  const o = t.ZERO,
    c = Vn(BigInt(s))
  let a = 1
  c > 12
    ? (a = c - 3)
    : c > 4
      ? (a = c - 2)
      : c > 0 && (a = 2)
  const u = We(a),
    d = new Array(Number(u) + 1).fill(o),
    h = Math.floor((e.BITS - 1) / a) * a
  let l = o
  for (let f = h; f >= 0; f -= a) {
    d.fill(o)
    for (let m = 0; m < i; m++) {
      const E = r[m],
        I = Number((E >> BigInt(f)) & u)
      d[I] = d[I].add(n[m])
    }
    let b = o
    for (let m = d.length - 1, E = o; m > 0; m--)
      (E = E.add(d[m])), (b = b.add(E))
    if (((l = l.add(b)), f !== 0))
      for (let m = 0; m < a; m++) l = l.double()
  }
  return l
}
function Bn(t, e, n) {
  if (e) {
    if (e.ORDER !== t)
      throw new Error(
        "Field.ORDER must match order: Fp == p, Fn == n",
      )
    return ns(e), e
  }
  return Je(t, { isLE: n })
}
function Us(t, e, n = {}, r) {
  if (
    (r === void 0 && (r = t === "edwards"),
    !e || typeof e != "object")
  )
    throw new Error(`expected valid ${t} CURVE object`)
  for (const a of ["p", "n", "h"]) {
    const u = e[a]
    if (!(typeof u == "bigint" && u > Me))
      throw new Error(`CURVE.${a} must be positive bigint`)
  }
  const s = Bn(e.p, n.Fp, r),
    i = Bn(e.n, n.Fn, r),
    c = ["Gx", "Gy", "a", "b"]
  for (const a of c)
    if (!s.isValid(e[a]))
      throw new Error(
        `CURVE.${a} must be valid field element of CURVE.Fp`,
      )
  return (
    (e = Object.freeze(Object.assign({}, e))),
    { CURVE: e, Fp: s, Fn: i }
  )
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const An = (t, e) => (t + (t >= 0 ? e : -e) / or) / e
function Hs(t, e, n) {
  const [[r, s], [i, o]] = e,
    c = An(o * t, n),
    a = An(-s * t, n)
  let u = t - c * r - a * i,
    d = -c * s - a * o
  const h = u < pe,
    l = d < pe
  h && (u = -u), l && (d = -d)
  const f = We(Math.ceil(Vn(n) / 2)) + ze
  if (u < pe || u >= f || d < pe || d >= f)
    throw new Error(
      "splitScalar (endomorphism): failed, k=" + t,
    )
  return { k1neg: h, k1: u, k2neg: l, k2: d }
}
function Zt(t) {
  if (!["compact", "recovered", "der"].includes(t))
    throw new Error(
      'Signature format must be "compact", "recovered", or "der"',
    )
  return t
}
function Ot(t, e) {
  const n = {}
  for (const r of Object.keys(e))
    n[r] = t[r] === void 0 ? e[r] : t[r]
  return (
    dt(n.lowS, "lowS"),
    dt(n.prehash, "prehash"),
    n.format !== void 0 && Zt(n.format),
    n
  )
}
class Rs extends Error {
  constructor(e = "") {
    super(e)
  }
}
const de = {
    Err: Rs,
    _tlv: {
      encode: (t, e) => {
        const { Err: n } = de
        if (t < 0 || t > 256)
          throw new n("tlv.encode: wrong tag")
        if (e.length & 1)
          throw new n("tlv.encode: unpadded data")
        const r = e.length / 2,
          s = rt(r)
        if ((s.length / 2) & 128)
          throw new n(
            "tlv.encode: long form length too big",
          )
        const i = r > 127 ? rt((s.length / 2) | 128) : ""
        return rt(t) + i + s + e
      },
      decode(t, e) {
        const { Err: n } = de
        let r = 0
        if (t < 0 || t > 256)
          throw new n("tlv.encode: wrong tag")
        if (e.length < 2 || e[r++] !== t)
          throw new n("tlv.decode: wrong tlv")
        const s = e[r++],
          i = !!(s & 128)
        let o = 0
        if (!i) o = s
        else {
          const a = s & 127
          if (!a)
            throw new n(
              "tlv.decode(long): indefinite length not supported",
            )
          if (a > 4)
            throw new n(
              "tlv.decode(long): byte length is too big",
            )
          const u = e.subarray(r, r + a)
          if (u.length !== a)
            throw new n(
              "tlv.decode: length bytes not complete",
            )
          if (u[0] === 0)
            throw new n(
              "tlv.decode(long): zero leftmost byte",
            )
          for (const d of u) o = (o << 8) | d
          if (((r += a), o < 128))
            throw new n(
              "tlv.decode(long): not minimal encoding",
            )
        }
        const c = e.subarray(r, r + o)
        if (c.length !== o)
          throw new n("tlv.decode: wrong value length")
        return { v: c, l: e.subarray(r + o) }
      },
    },
    _int: {
      encode(t) {
        const { Err: e } = de
        if (t < pe)
          throw new e(
            "integer: negative integers are not allowed",
          )
        let n = rt(t)
        if (
          (Number.parseInt(n[0], 16) & 8 && (n = "00" + n),
          n.length & 1)
        )
          throw new e(
            "unexpected DER parsing assertion: unpadded hex",
          )
        return n
      },
      decode(t) {
        const { Err: e } = de
        if (t[0] & 128)
          throw new e("invalid signature integer: negative")
        if (t[0] === 0 && !(t[1] & 128))
          throw new e(
            "invalid signature integer: unnecessary leading zero",
          )
        return At(t)
      },
    },
    toSig(t) {
      const { Err: e, _int: n, _tlv: r } = de,
        s = X("signature", t),
        { v: i, l: o } = r.decode(48, s)
      if (o.length)
        throw new e(
          "invalid signature: left bytes after parsing",
        )
      const { v: c, l: a } = r.decode(2, i),
        { v: u, l: d } = r.decode(2, a)
      if (d.length)
        throw new e(
          "invalid signature: left bytes after parsing",
        )
      return { r: n.decode(c), s: n.decode(u) }
    },
    hexFromSig(t) {
      const { _tlv: e, _int: n } = de,
        r = e.encode(2, n.encode(t.r)),
        s = e.encode(2, n.encode(t.s)),
        i = r + s
      return e.encode(48, i)
    },
  },
  pe = BigInt(0),
  ze = BigInt(1),
  or = BigInt(2),
  ct = BigInt(3),
  Ks = BigInt(4)
function Te(t, e) {
  const { BYTES: n } = t
  let r
  if (typeof e == "bigint") r = e
  else {
    const s = X("private key", e)
    try {
      r = t.fromBytes(s)
    } catch {
      throw new Error(
        `invalid private key: expected ui8a of size ${n}, got ${typeof e}`,
      )
    }
  }
  if (!t.isValidNot0(r))
    throw new Error(
      "invalid private key: out of range [1..N-1]",
    )
  return r
}
function Ns(t, e = {}) {
  const n = Us("weierstrass", t, e),
    { Fp: r, Fn: s } = n
  const i = n.CURVE
  const { h: o, n: c } = i
  tn(
    e,
    {},
    {
      allowInfinityPoint: "boolean",
      clearCofactor: "function",
      isTorsionFree: "function",
      fromBytes: "function",
      toBytes: "function",
      endo: "object",
      wrapPrivateKey: "boolean",
    },
  )
  const { endo: a } = e
  if (
    a &&
    (!r.is0(i.a) ||
      typeof a.beta != "bigint" ||
      !Array.isArray(a.basises))
  )
    throw new Error(
      'invalid endo: expected "beta": bigint and "basises": array',
    )
  const u = ar(r, s)
  function d() {
    if (!r.isOdd)
      throw new Error(
        "compression is not supported: Field does not have .isOdd()",
      )
  }
  function h(R, g, y) {
    const { x: p, y: w } = g.toAffine(),
      k = r.toBytes(p)
    if ((dt(y, "isCompressed"), y)) {
      d()
      const S = !r.isOdd(w)
      return ne(cr(S), k)
    }
    return ne(Uint8Array.of(4), k, r.toBytes(w))
  }
  function l(R) {
    Ae(R, void 0, "Point")
    const { publicKey: g, publicKeyUncompressed: y } = u,
      p = R.length,
      w = R[0],
      k = R.subarray(1)
    if (p === g && (w === 2 || w === 3)) {
      const S = r.fromBytes(k)
      if (!r.isValid(S))
        throw new Error(
          "bad point: is not on curve, wrong x",
        )
      const A = m(S)
      let B
      try {
        B = r.sqrt(A)
      } catch (C) {
        const q = C instanceof Error ? ": " + C.message : ""
        throw new Error(
          "bad point: is not on curve, sqrt error" + q,
        )
      }
      d()
      const _ = r.isOdd(B)
      return (
        ((w & 1) === 1) !== _ && (B = r.neg(B)),
        { x: S, y: B }
      )
    }
    if (p === y && w === 4) {
      const S = r.BYTES,
        A = r.fromBytes(k.subarray(0, S)),
        B = r.fromBytes(k.subarray(S, S * 2))
      if (!E(A, B))
        throw new Error("bad point: is not on curve")
      return { x: A, y: B }
    }
    throw new Error(
      `bad point: got length ${p}, expected compressed=${g} or uncompressed=${y}`,
    )
  }
  const f = e.toBytes || h,
    b = e.fromBytes || l
  function m(R) {
    const g = r.sqr(R),
      y = r.mul(g, R)
    return r.add(r.add(y, r.mul(R, i.a)), i.b)
  }
  function E(R, g) {
    const y = r.sqr(g),
      p = m(R)
    return r.eql(y, p)
  }
  if (!E(i.Gx, i.Gy))
    throw new Error("bad curve params: generator point")
  const I = r.mul(r.pow(i.a, ct), Ks),
    K = r.mul(r.sqr(i.b), BigInt(27))
  if (r.is0(r.add(I, K)))
    throw new Error("bad curve params: a or b")
  function v(R, g, y = !1) {
    if (!r.isValid(g) || (y && r.is0(g)))
      throw new Error(`bad point coordinate ${R}`)
    return g
  }
  function z(R) {
    if (!(R instanceof U))
      throw new Error("ProjectivePoint expected")
  }
  function O(R) {
    if (!a || !a.basises) throw new Error("no endo")
    return Hs(R, a.basises, s.ORDER)
  }
  const G = bn((R, g) => {
      const { X: y, Y: p, Z: w } = R
      if (r.eql(w, r.ONE)) return { x: y, y: p }
      const k = R.is0()
      g == null && (g = k ? r.ONE : r.inv(w))
      const S = r.mul(y, g),
        A = r.mul(p, g),
        B = r.mul(w, g)
      if (k) return { x: r.ZERO, y: r.ZERO }
      if (!r.eql(B, r.ONE))
        throw new Error("invZ was invalid")
      return { x: S, y: A }
    }),
    ge = bn((R) => {
      if (R.is0()) {
        if (e.allowInfinityPoint && !r.is0(R.Y)) return
        throw new Error("bad point: ZERO")
      }
      const { x: g, y } = R.toAffine()
      if (!r.isValid(g) || !r.isValid(y))
        throw new Error(
          "bad point: x or y not field elements",
        )
      if (!E(g, y))
        throw new Error("bad point: equation left != right")
      if (!R.isTorsionFree())
        throw new Error(
          "bad point: not in prime-order subgroup",
        )
      return !0
    })
  function V(R, g, y, p, w) {
    return (
      (y = new U(r.mul(y.X, R), y.Y, y.Z)),
      (g = ht(p, g)),
      (y = ht(w, y)),
      g.add(y)
    )
  }
  class U {
    constructor(g, y, p) {
      ;(this.X = v("x", g)),
        (this.Y = v("y", y, !0)),
        (this.Z = v("z", p)),
        Object.freeze(this)
    }
    static CURVE() {
      return i
    }
    static fromAffine(g) {
      const { x: y, y: p } = g || {}
      if (!g || !r.isValid(y) || !r.isValid(p))
        throw new Error("invalid affine point")
      if (g instanceof U)
        throw new Error("projective point not allowed")
      return r.is0(y) && r.is0(p)
        ? U.ZERO
        : new U(y, p, r.ONE)
    }
    static fromBytes(g) {
      const y = U.fromAffine(b(Ae(g, void 0, "point")))
      return y.assertValidity(), y
    }
    static fromHex(g) {
      return U.fromBytes(X("pointHex", g))
    }
    get x() {
      return this.toAffine().x
    }
    get y() {
      return this.toAffine().y
    }
    precompute(g = 8, y = !0) {
      return (
        se.createCache(this, g),
        y || this.multiply(ct),
        this
      )
    }
    assertValidity() {
      ge(this)
    }
    hasEvenY() {
      const { y: g } = this.toAffine()
      if (!r.isOdd)
        throw new Error("Field doesn't support isOdd")
      return !r.isOdd(g)
    }
    equals(g) {
      z(g)
      const { X: y, Y: p, Z: w } = this,
        { X: k, Y: S, Z: A } = g,
        B = r.eql(r.mul(y, A), r.mul(k, w)),
        _ = r.eql(r.mul(p, A), r.mul(S, w))
      return B && _
    }
    negate() {
      return new U(this.X, r.neg(this.Y), this.Z)
    }
    double() {
      const { a: g, b: y } = i,
        p = r.mul(y, ct),
        { X: w, Y: k, Z: S } = this
      let A = r.ZERO,
        B = r.ZERO,
        _ = r.ZERO,
        H = r.mul(w, w),
        C = r.mul(k, k),
        q = r.mul(S, S),
        N = r.mul(w, k)
      return (
        (N = r.add(N, N)),
        (_ = r.mul(w, S)),
        (_ = r.add(_, _)),
        (A = r.mul(g, _)),
        (B = r.mul(p, q)),
        (B = r.add(A, B)),
        (A = r.sub(C, B)),
        (B = r.add(C, B)),
        (B = r.mul(A, B)),
        (A = r.mul(N, A)),
        (_ = r.mul(p, _)),
        (q = r.mul(g, q)),
        (N = r.sub(H, q)),
        (N = r.mul(g, N)),
        (N = r.add(N, _)),
        (_ = r.add(H, H)),
        (H = r.add(_, H)),
        (H = r.add(H, q)),
        (H = r.mul(H, N)),
        (B = r.add(B, H)),
        (q = r.mul(k, S)),
        (q = r.add(q, q)),
        (H = r.mul(q, N)),
        (A = r.sub(A, H)),
        (_ = r.mul(q, C)),
        (_ = r.add(_, _)),
        (_ = r.add(_, _)),
        new U(A, B, _)
      )
    }
    add(g) {
      z(g)
      const { X: y, Y: p, Z: w } = this,
        { X: k, Y: S, Z: A } = g
      let B = r.ZERO,
        _ = r.ZERO,
        H = r.ZERO
      const C = i.a,
        q = r.mul(i.b, ct)
      let N = r.mul(y, k),
        j = r.mul(p, S),
        T = r.mul(w, A),
        P = r.add(y, p),
        L = r.add(k, S)
      ;(P = r.mul(P, L)),
        (L = r.add(N, j)),
        (P = r.sub(P, L)),
        (L = r.add(y, w))
      let M = r.add(k, A)
      return (
        (L = r.mul(L, M)),
        (M = r.add(N, T)),
        (L = r.sub(L, M)),
        (M = r.add(p, w)),
        (B = r.add(S, A)),
        (M = r.mul(M, B)),
        (B = r.add(j, T)),
        (M = r.sub(M, B)),
        (H = r.mul(C, L)),
        (B = r.mul(q, T)),
        (H = r.add(B, H)),
        (B = r.sub(j, H)),
        (H = r.add(j, H)),
        (_ = r.mul(B, H)),
        (j = r.add(N, N)),
        (j = r.add(j, N)),
        (T = r.mul(C, T)),
        (L = r.mul(q, L)),
        (j = r.add(j, T)),
        (T = r.sub(N, T)),
        (T = r.mul(C, T)),
        (L = r.add(L, T)),
        (N = r.mul(j, L)),
        (_ = r.add(_, N)),
        (N = r.mul(M, L)),
        (B = r.mul(P, B)),
        (B = r.sub(B, N)),
        (N = r.mul(P, j)),
        (H = r.mul(M, H)),
        (H = r.add(H, N)),
        new U(B, _, H)
      )
    }
    subtract(g) {
      return this.add(g.negate())
    }
    is0() {
      return this.equals(U.ZERO)
    }
    multiply(g) {
      const { endo: y } = e
      if (!s.isValidNot0(g))
        throw new Error("invalid scalar: out of range")
      let p, w
      const k = (S) => se.cached(this, S, (A) => Ht(U, A))
      if (y) {
        const { k1neg: S, k1: A, k2neg: B, k2: _ } = O(g),
          { p: H, f: C } = k(A),
          { p: q, f: N } = k(_)
        ;(w = C.add(N)), (p = V(y.beta, H, q, S, B))
      } else {
        const { p: S, f: A } = k(g)
        ;(p = S), (w = A)
      }
      return Ht(U, [p, w])[0]
    }
    multiplyUnsafe(g) {
      const { endo: y } = e
      if (!s.isValid(g))
        throw new Error("invalid scalar: out of range")
      if (g === pe || this.is0()) return U.ZERO
      if (g === ze) return this
      if (se.hasCache(this)) return this.multiply(g)
      if (y) {
        const { k1neg: w, k1: k, k2neg: S, k2: A } = O(g),
          { p1: B, p2: _ } = Is(U, this, k, A)
        return V(y.beta, B, _, w, S)
      }
      return se.unsafe(this, g)
    }
    multiplyAndAddUnsafe(g, y, p) {
      const w = this.multiplyUnsafe(y).add(
        g.multiplyUnsafe(p),
      )
      return w.is0() ? void 0 : w
    }
    toAffine(g) {
      return G(this, g)
    }
    isTorsionFree() {
      const { isTorsionFree: g } = e
      return o === ze
        ? !0
        : g
          ? g(U, this)
          : se.unsafe(this, c).is0()
    }
    clearCofactor() {
      const { clearCofactor: g } = e
      return o === ze
        ? this
        : g
          ? g(U, this)
          : this.multiplyUnsafe(o)
    }
    isSmallOrder() {
      return this.multiplyUnsafe(o).is0()
    }
    toBytes(g = !0) {
      return (
        dt(g, "isCompressed"),
        this.assertValidity(),
        f(U, this, g)
      )
    }
    toHex(g = !0) {
      return Ue(this.toBytes(g))
    }
    toString() {
      return `<Point ${this.is0() ? "ZERO" : this.toHex()}>`
    }
    get px() {
      return this.X
    }
    get py() {
      return this.X
    }
    get pz() {
      return this.Z
    }
    toRawBytes(g = !0) {
      return this.toBytes(g)
    }
    _setWindowSize(g) {
      this.precompute(g)
    }
    static normalizeZ(g) {
      return Ht(U, g)
    }
    static msm(g, y) {
      return _s(U, s, g, y)
    }
    static fromPrivateKey(g) {
      return U.BASE.multiply(Te(s, g))
    }
  }
  ;(U.BASE = new U(i.Gx, i.Gy, r.ONE)),
    (U.ZERO = new U(r.ZERO, r.ONE, r.ZERO)),
    (U.Fp = r),
    (U.Fn = s)
  const ce = s.BITS,
    se = new Ss(U, e.endo ? Math.ceil(ce / 2) : ce)
  return U.BASE.precompute(8), U
}
function cr(t) {
  return Uint8Array.of(t ? 2 : 3)
}
function ar(t, e) {
  return {
    secretKey: e.BYTES,
    publicKey: 1 + t.BYTES,
    publicKeyUncompressed: 1 + 2 * t.BYTES,
    publicKeyHasPrefix: !0,
    signature: 2 * e.BYTES,
  }
}
function Os(t, e = {}) {
  const { Fn: n } = t,
    r = e.randomBytes || Tn,
    s = Object.assign(ar(t.Fp, n), { seed: er(n.ORDER) })
  function i(f) {
    try {
      return !!Te(n, f)
    } catch {
      return !1
    }
  }
  function o(f, b) {
    const { publicKey: m, publicKeyUncompressed: E } = s
    try {
      const I = f.length
      return (b === !0 && I !== m) || (b === !1 && I !== E)
        ? !1
        : !!t.fromBytes(f)
    } catch {
      return !1
    }
  }
  function c(f = r(s.seed)) {
    return ss(Ae(f, s.seed, "seed"), n.ORDER)
  }
  function a(f, b = !0) {
    return t.BASE.multiply(Te(n, f)).toBytes(b)
  }
  function u(f) {
    const b = c(f)
    return { secretKey: b, publicKey: a(b) }
  }
  function d(f) {
    if (typeof f == "bigint") return !1
    if (f instanceof t) return !0
    const {
      secretKey: b,
      publicKey: m,
      publicKeyUncompressed: E,
    } = s
    if (n.allowedLengths || b === m) return
    const I = X("key", f).length
    return I === m || I === E
  }
  function h(f, b, m = !0) {
    if (d(f) === !0)
      throw new Error("first arg must be private key")
    if (d(b) === !1)
      throw new Error("second arg must be public key")
    const E = Te(n, f)
    return t.fromHex(b).multiply(E).toBytes(m)
  }
  return Object.freeze({
    getPublicKey: a,
    getSharedSecret: h,
    keygen: u,
    Point: t,
    utils: {
      isValidSecretKey: i,
      isValidPublicKey: o,
      randomSecretKey: c,
      isValidPrivateKey: i,
      randomPrivateKey: c,
      normPrivateKeyToScalar: (f) => Te(n, f),
      precompute(f = 8, b = t.BASE) {
        return b.precompute(f, !1)
      },
    },
    lengths: s,
  })
}
function qs(t, e, n = {}) {
  Xt(e),
    tn(
      n,
      {},
      {
        hmac: "function",
        lowS: "boolean",
        randomBytes: "function",
        bits2int: "function",
        bits2int_modN: "function",
      },
    )
  const r = n.randomBytes || Tn,
    s = n.hmac || ((y, ...p) => Xe(e, y, ne(...p))),
    { Fp: i, Fn: o } = t,
    { ORDER: c, BITS: a } = o,
    {
      keygen: u,
      getPublicKey: d,
      getSharedSecret: h,
      utils: l,
      lengths: f,
    } = Os(t, n),
    b = {
      prehash: !1,
      lowS: typeof n.lowS == "boolean" ? n.lowS : !1,
      format: void 0,
      extraEntropy: !1,
    },
    m = "compact"
  function E(y) {
    const p = c >> ze
    return y > p
  }
  function I(y, p) {
    if (!o.isValidNot0(p))
      throw new Error(
        `invalid signature ${y}: out of range 1..Point.Fn.ORDER`,
      )
    return p
  }
  function K(y, p) {
    Zt(p)
    const w = f.signature,
      k =
        p === "compact"
          ? w
          : p === "recovered"
            ? w + 1
            : void 0
    return Ae(y, k, `${p} signature`)
  }
  class v {
    constructor(p, w, k) {
      ;(this.r = I("r", p)),
        (this.s = I("s", w)),
        k != null && (this.recovery = k),
        Object.freeze(this)
    }
    static fromBytes(p, w = m) {
      K(p, w)
      let k
      if (w === "der") {
        const { r: _, s: H } = de.toSig(Ae(p))
        return new v(_, H)
      }
      w === "recovered" &&
        ((k = p[0]), (w = "compact"), (p = p.subarray(1)))
      const S = o.BYTES,
        A = p.subarray(0, S),
        B = p.subarray(S, S * 2)
      return new v(o.fromBytes(A), o.fromBytes(B), k)
    }
    static fromHex(p, w) {
      return v.fromBytes(Pe(p), w)
    }
    addRecoveryBit(p) {
      return new v(this.r, this.s, p)
    }
    recoverPublicKey(p) {
      const w = i.ORDER,
        { r: k, s: S, recovery: A } = this
      if (A == null || ![0, 1, 2, 3].includes(A))
        throw new Error("recovery id invalid")
      if (c * or < w && A > 1)
        throw new Error(
          "recovery id is ambiguous for h>1 curve",
        )
      const _ = A === 2 || A === 3 ? k + c : k
      if (!i.isValid(_))
        throw new Error("recovery id 2 or 3 invalid")
      const H = i.toBytes(_),
        C = t.fromBytes(ne(cr((A & 1) === 0), H)),
        q = o.inv(_),
        N = O(X("msgHash", p)),
        j = o.create(-N * q),
        T = o.create(S * q),
        P = t.BASE.multiplyUnsafe(j).add(
          C.multiplyUnsafe(T),
        )
      if (P.is0()) throw new Error("point at infinify")
      return P.assertValidity(), P
    }
    hasHighS() {
      return E(this.s)
    }
    toBytes(p = m) {
      if ((Zt(p), p === "der"))
        return Pe(de.hexFromSig(this))
      const w = o.toBytes(this.r),
        k = o.toBytes(this.s)
      if (p === "recovered") {
        if (this.recovery == null)
          throw new Error("recovery bit must be present")
        return ne(Uint8Array.of(this.recovery), w, k)
      }
      return ne(w, k)
    }
    toHex(p) {
      return Ue(this.toBytes(p))
    }
    assertValidity() {}
    static fromCompact(p) {
      return v.fromBytes(X("sig", p), "compact")
    }
    static fromDER(p) {
      return v.fromBytes(X("sig", p), "der")
    }
    normalizeS() {
      return this.hasHighS()
        ? new v(this.r, o.neg(this.s), this.recovery)
        : this
    }
    toDERRawBytes() {
      return this.toBytes("der")
    }
    toDERHex() {
      return Ue(this.toBytes("der"))
    }
    toCompactRawBytes() {
      return this.toBytes("compact")
    }
    toCompactHex() {
      return Ue(this.toBytes("compact"))
    }
  }
  const z =
      n.bits2int ||
      ((p) => {
        if (p.length > 8192)
          throw new Error("input is too large")
        const w = At(p),
          k = p.length * 8 - a
        return k > 0 ? w >> BigInt(k) : w
      }),
    O = n.bits2int_modN || ((p) => o.create(z(p))),
    G = We(a)
  function ge(y) {
    return Gr("num < 2^" + a, y, pe, G), o.toBytes(y)
  }
  function V(y, p) {
    return (
      Ae(y, void 0, "message"),
      p ? Ae(e(y), void 0, "prehashed message") : y
    )
  }
  function U(y, p, w) {
    if (["recovered", "canonical"].some((j) => j in w))
      throw new Error("sign() legacy options not supported")
    const {
      lowS: k,
      prehash: S,
      extraEntropy: A,
    } = Ot(w, b)
    y = V(y, S)
    const B = O(y),
      _ = Te(o, p),
      H = [ge(_), ge(B)]
    if (A != null && A !== !1) {
      const j = A === !0 ? r(f.secretKey) : A
      H.push(X("extraEntropy", j))
    }
    const C = ne(...H),
      q = B
    function N(j) {
      const T = z(j)
      if (!o.isValidNot0(T)) return
      const P = o.inv(T),
        L = t.BASE.multiply(T).toAffine(),
        M = o.create(L.x)
      if (M === pe) return
      const tt = o.create(P * o.create(q + M * _))
      if (tt === pe) return
      let fn = (L.x === M ? 0 : 2) | Number(L.y & ze),
        dn = tt
      return (
        k && E(tt) && ((dn = o.neg(tt)), (fn ^= 1)),
        new v(M, dn, fn)
      )
    }
    return { seed: C, k2sig: N }
  }
  function ce(y, p, w = {}) {
    y = X("message", y)
    const { seed: k, k2sig: S } = U(y, p, w)
    return Pr(e.outputLen, o.BYTES, s)(k, S)
  }
  function se(y) {
    let p
    const w = typeof y == "string" || Et(y),
      k =
        !w &&
        y !== null &&
        typeof y == "object" &&
        typeof y.r == "bigint" &&
        typeof y.s == "bigint"
    if (!w && !k)
      throw new Error(
        "invalid signature, expected Uint8Array, hex string or Signature instance",
      )
    if (k) p = new v(y.r, y.s)
    else if (w) {
      try {
        p = v.fromBytes(X("sig", y), "der")
      } catch (S) {
        if (!(S instanceof de.Err)) throw S
      }
      if (!p)
        try {
          p = v.fromBytes(X("sig", y), "compact")
        } catch {
          return !1
        }
    }
    return p || !1
  }
  function R(y, p, w, k = {}) {
    const { lowS: S, prehash: A, format: B } = Ot(k, b)
    if (
      ((w = X("publicKey", w)),
      (p = V(X("message", p), A)),
      "strict" in k)
    )
      throw new Error("options.strict was renamed to lowS")
    const _ =
      B === void 0 ? se(y) : v.fromBytes(X("sig", y), B)
    if (_ === !1) return !1
    try {
      const H = t.fromBytes(w)
      if (S && _.hasHighS()) return !1
      const { r: C, s: q } = _,
        N = O(p),
        j = o.inv(q),
        T = o.create(N * j),
        P = o.create(C * j),
        L = t.BASE.multiplyUnsafe(T).add(
          H.multiplyUnsafe(P),
        )
      return L.is0() ? !1 : o.create(L.x) === C
    } catch {
      return !1
    }
  }
  function g(y, p, w = {}) {
    const { prehash: k } = Ot(w, b)
    return (
      (p = V(p, k)),
      v
        .fromBytes(y, "recovered")
        .recoverPublicKey(p)
        .toBytes()
    )
  }
  return Object.freeze({
    keygen: u,
    getPublicKey: d,
    getSharedSecret: h,
    utils: l,
    lengths: f,
    Point: t,
    sign: ce,
    verify: R,
    recoverPublicKey: g,
    Signature: v,
    hash: e,
  })
}
function js(t) {
  const e = {
      a: t.a,
      b: t.b,
      p: t.Fp.ORDER,
      n: t.n,
      h: t.h,
      Gx: t.Gx,
      Gy: t.Gy,
    },
    n = t.Fp
  const r = t.allowedPrivateKeyLengths
    ? Array.from(
        new Set(
          t.allowedPrivateKeyLengths.map((o) =>
            Math.ceil(o / 2),
          ),
        ),
      )
    : void 0
  const s = Je(e.n, {
      BITS: t.nBitLength,
      allowedLengths: r,
      modFromBytes: t.wrapPrivateKey,
    }),
    i = {
      Fp: n,
      Fn: s,
      allowInfinityPoint: t.allowInfinityPoint,
      endo: t.endo,
      isTorsionFree: t.isTorsionFree,
      clearCofactor: t.clearCofactor,
      fromBytes: t.fromBytes,
      toBytes: t.toBytes,
    }
  return { CURVE: e, curveOpts: i }
}
function Ls(t) {
  const { CURVE: e, curveOpts: n } = js(t),
    r = {
      hmac: t.hmac,
      randomBytes: t.randomBytes,
      lowS: t.lowS,
      bits2int: t.bits2int,
      bits2int_modN: t.bits2int_modN,
    }
  return {
    CURVE: e,
    curveOpts: n,
    hash: t.hash,
    ecdsaOpts: r,
  }
}
function Cs(t, e) {
  const n = e.Point
  return Object.assign({}, e, {
    ProjectivePoint: n,
    CURVE: Object.assign({}, t, Jn(n.Fn.ORDER, n.Fn.BITS)),
  })
}
function Ts(t) {
  const {
      CURVE: e,
      curveOpts: n,
      hash: r,
      ecdsaOpts: s,
    } = Ls(t),
    i = Ns(e, n),
    o = qs(i, r, s)
  return Cs(t, o)
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
function $s(t, e) {
  const n = (r) => Ts({ ...t, hash: r })
  return { ...n(e), create: n }
} /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const sn = {
    p: BigInt(
      "0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f",
    ),
    n: BigInt(
      "0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141",
    ),
    h: BigInt(1),
    a: BigInt(0),
    b: BigInt(7),
    Gx: BigInt(
      "0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798",
    ),
    Gy: BigInt(
      "0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8",
    ),
  },
  zs = {
    beta: BigInt(
      "0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee",
    ),
    basises: [
      [
        BigInt("0x3086d221a7d46bcde86c90e49284eb15"),
        -BigInt("0xe4437ed6010e88286f547fa90abfe4c3"),
      ],
      [
        BigInt("0x114ca50f7a8e2f3f657c1108d9d44cfd8"),
        BigInt("0x3086d221a7d46bcde86c90e49284eb15"),
      ],
    ],
  },
  Sn = BigInt(2)
function Zs(t) {
  const e = sn.p,
    n = BigInt(3),
    r = BigInt(6),
    s = BigInt(11),
    i = BigInt(22),
    o = BigInt(23),
    c = BigInt(44),
    a = BigInt(88),
    u = (t * t * t) % e,
    d = (u * u * t) % e,
    h = (ee(d, n, e) * d) % e,
    l = (ee(h, n, e) * d) % e,
    f = (ee(l, Sn, e) * u) % e,
    b = (ee(f, s, e) * f) % e,
    m = (ee(b, i, e) * b) % e,
    E = (ee(m, c, e) * m) % e,
    I = (ee(E, a, e) * E) % e,
    K = (ee(I, c, e) * m) % e,
    v = (ee(K, n, e) * d) % e,
    z = (ee(v, o, e) * b) % e,
    O = (ee(z, r, e) * u) % e,
    G = ee(O, Sn, e)
  if (!Vt.eql(Vt.sqr(G), t))
    throw new Error("Cannot find square root")
  return G
}
const Vt = Je(sn.p, { sqrt: Zs }),
  fe = $s({ ...sn, Fp: Vt, lowS: !0, endo: zs }, St),
  Vs = Uint8Array.from([
    7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8,
  ]),
  lr = Uint8Array.from(
    new Array(16).fill(0).map((t, e) => e),
  ),
  Ms = lr.map((t) => (9 * t + 5) % 16),
  ur = (() => {
    const n = [[lr], [Ms]]
    for (let r = 0; r < 4; r++)
      for (const s of n) s.push(s[r].map((i) => Vs[i]))
    return n
  })(),
  fr = ur[0],
  dr = ur[1],
  hr = [
    [
      11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9,
      8,
    ],
    [
      12, 13, 11, 15, 6, 9, 9, 7, 12, 15, 11, 13, 7, 8, 7,
      7,
    ],
    [
      13, 15, 14, 11, 7, 7, 6, 8, 13, 14, 13, 12, 5, 5, 6,
      9,
    ],
    [
      14, 11, 12, 14, 8, 6, 5, 5, 15, 12, 15, 14, 9, 9, 8,
      6,
    ],
    [
      15, 12, 13, 13, 9, 5, 8, 6, 14, 11, 12, 11, 8, 6, 5,
      5,
    ],
  ].map((t) => Uint8Array.from(t)),
  Ds = fr.map((t, e) => t.map((n) => hr[e][n])),
  Fs = dr.map((t, e) => t.map((n) => hr[e][n])),
  Ys = Uint32Array.from([
    0, 1518500249, 1859775393, 2400959708, 2840853838,
  ]),
  Gs = Uint32Array.from([
    1352829926, 1548603684, 1836072691, 2053994217, 0,
  ])
function In(t, e, n, r) {
  return t === 0
    ? e ^ n ^ r
    : t === 1
      ? (e & n) | (~e & r)
      : t === 2
        ? (e | ~n) ^ r
        : t === 3
          ? (e & r) | (n & ~r)
          : e ^ (n | ~r)
}
const at = new Uint32Array(16)
class Ps extends rn {
  constructor() {
    super(64, 20, 8, !0),
      (this.h0 = 1732584193),
      (this.h1 = -271733879),
      (this.h2 = -1732584194),
      (this.h3 = 271733878),
      (this.h4 = -1009589776)
  }
  get() {
    const { h0: e, h1: n, h2: r, h3: s, h4: i } = this
    return [e, n, r, s, i]
  }
  set(e, n, r, s, i) {
    ;(this.h0 = e | 0),
      (this.h1 = n | 0),
      (this.h2 = r | 0),
      (this.h3 = s | 0),
      (this.h4 = i | 0)
  }
  process(e, n) {
    for (let f = 0; f < 16; f++, n += 4)
      at[f] = e.getUint32(n, !0)
    let r = this.h0 | 0,
      s = r,
      i = this.h1 | 0,
      o = i,
      c = this.h2 | 0,
      a = c,
      u = this.h3 | 0,
      d = u,
      h = this.h4 | 0,
      l = h
    for (let f = 0; f < 5; f++) {
      const b = 4 - f,
        m = Ys[f],
        E = Gs[f],
        I = fr[f],
        K = dr[f],
        v = Ds[f],
        z = Fs[f]
      for (let O = 0; O < 16; O++) {
        const G =
          (nt(r + In(f, i, c, u) + at[I[O]] + m, v[O]) +
            h) |
          0
        ;(r = h),
          (h = u),
          (u = nt(c, 10) | 0),
          (c = i),
          (i = G)
      }
      for (let O = 0; O < 16; O++) {
        const G =
          (nt(s + In(b, o, a, d) + at[K[O]] + E, z[O]) +
            l) |
          0
        ;(s = l),
          (l = d),
          (d = nt(a, 10) | 0),
          (a = o),
          (o = G)
      }
    }
    this.set(
      (this.h1 + c + d) | 0,
      (this.h2 + u + l) | 0,
      (this.h3 + h + s) | 0,
      (this.h4 + r + o) | 0,
      (this.h0 + i + a) | 0,
    )
  }
  roundClean() {
    ie(at)
  }
  destroy() {
    ;(this.destroyed = !0),
      ie(this.buffer),
      this.set(0, 0, 0, 0, 0)
  }
}
const Xs = Bt(
  () => new Ps(),
) /*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) */
function pt(t) {
  return (
    t instanceof Uint8Array ||
    (ArrayBuffer.isView(t) &&
      t.constructor.name === "Uint8Array")
  )
}
function pr(t, e) {
  return Array.isArray(e)
    ? e.length === 0
      ? !0
      : t
        ? e.every((n) => typeof n == "string")
        : e.every((n) => Number.isSafeInteger(n))
    : !1
}
function Ws(t) {
  if (typeof t != "function")
    throw new Error("function expected")
  return !0
}
function yt(t, e) {
  if (typeof e != "string")
    throw new Error(`${t}: string expected`)
  return !0
}
function Fe(t) {
  if (!Number.isSafeInteger(t))
    throw new Error(`invalid integer: ${t}`)
}
function bt(t) {
  if (!Array.isArray(t)) throw new Error("array expected")
}
function gt(t, e) {
  if (!pr(!0, e))
    throw new Error(`${t}: array of strings expected`)
}
function yr(t, e) {
  if (!pr(!1, e))
    throw new Error(`${t}: array of numbers expected`)
}
function on(...t) {
  const e = (i) => i,
    n = (i, o) => (c) => i(o(c)),
    r = t.map((i) => i.encode).reduceRight(n, e),
    s = t.map((i) => i.decode).reduce(n, e)
  return { encode: r, decode: s }
}
function br(t) {
  const e = typeof t == "string" ? t.split("") : t,
    n = e.length
  gt("alphabet", e)
  const r = new Map(e.map((s, i) => [s, i]))
  return {
    encode: (s) => (
      bt(s),
      s.map((i) => {
        if (!Number.isSafeInteger(i) || i < 0 || i >= n)
          throw new Error(
            `alphabet.encode: digit index outside alphabet "${i}". Allowed: ${t}`,
          )
        return e[i]
      })
    ),
    decode: (s) => (
      bt(s),
      s.map((i) => {
        yt("alphabet.decode", i)
        const o = r.get(i)
        if (o === void 0)
          throw new Error(
            `Unknown letter: "${i}". Allowed: ${t}`,
          )
        return o
      })
    ),
  }
}
function gr(t = "") {
  return (
    yt("join", t),
    {
      encode: (e) => (gt("join.decode", e), e.join(t)),
      decode: (e) => (yt("join.decode", e), e.split(t)),
    }
  )
}
function Js(t, e = "=") {
  return (
    Fe(t),
    yt("padding", e),
    {
      encode(n) {
        for (gt("padding.encode", n); (n.length * t) % 8; )
          n.push(e)
        return n
      },
      decode(n) {
        gt("padding.decode", n)
        let r = n.length
        if ((r * t) % 8)
          throw new Error(
            "padding: invalid, string should have whole number of bytes",
          )
        for (; r > 0 && n[r - 1] === e; r--)
          if (((r - 1) * t) % 8 === 0)
            throw new Error(
              "padding: invalid, string has too much padding",
            )
        return n.slice(0, r)
      },
    }
  )
}
function Mt(t, e, n) {
  if (e < 2)
    throw new Error(
      `convertRadix: invalid from=${e}, base cannot be less than 2`,
    )
  if (n < 2)
    throw new Error(
      `convertRadix: invalid to=${n}, base cannot be less than 2`,
    )
  if ((bt(t), !t.length)) return []
  let r = 0
  const s = [],
    i = Array.from(t, (c) => {
      if ((Fe(c), c < 0 || c >= e))
        throw new Error(`invalid integer: ${c}`)
      return c
    }),
    o = i.length
  for (;;) {
    let c = 0,
      a = !0
    for (let u = r; u < o; u++) {
      const d = i[u],
        h = e * c,
        l = h + d
      if (
        !Number.isSafeInteger(l) ||
        h / e !== c ||
        l - d !== h
      )
        throw new Error("convertRadix: carry overflow")
      const f = l / n
      c = l % n
      const b = Math.floor(f)
      if (
        ((i[u] = b),
        !Number.isSafeInteger(b) || b * n + c !== l)
      )
        throw new Error("convertRadix: carry overflow")
      if (a) b ? (a = !1) : (r = u)
      else continue
    }
    if ((s.push(c), a)) break
  }
  for (let c = 0; c < t.length - 1 && t[c] === 0; c++)
    s.push(0)
  return s.reverse()
}
const mr = (t, e) => (e === 0 ? t : mr(e, t % e)),
  mt = (t, e) => t + (e - mr(t, e)),
  qt = (() => {
    const t = []
    for (let e = 0; e < 40; e++) t.push(2 ** e)
    return t
  })()
function Dt(t, e, n, r) {
  if ((bt(t), e <= 0 || e > 32))
    throw new Error(`convertRadix2: wrong from=${e}`)
  if (n <= 0 || n > 32)
    throw new Error(`convertRadix2: wrong to=${n}`)
  if (mt(e, n) > 32)
    throw new Error(
      `convertRadix2: carry overflow from=${e} to=${n} carryBits=${mt(e, n)}`,
    )
  let s = 0,
    i = 0
  const o = qt[e],
    c = qt[n] - 1,
    a = []
  for (const u of t) {
    if ((Fe(u), u >= o))
      throw new Error(
        `convertRadix2: invalid data word=${u} from=${e}`,
      )
    if (((s = (s << e) | u), i + e > 32))
      throw new Error(
        `convertRadix2: carry overflow pos=${i} from=${e}`,
      )
    for (i += e; i >= n; i -= n)
      a.push(((s >> (i - n)) & c) >>> 0)
    const d = qt[i]
    if (d === void 0) throw new Error("invalid carry")
    s &= d - 1
  }
  if (((s = (s << (n - i)) & c), !r && i >= e))
    throw new Error("Excess padding")
  if (!r && s > 0) throw new Error(`Non-zero padding: ${s}`)
  return r && i > 0 && a.push(s >>> 0), a
}
function wr(t) {
  Fe(t)
  const e = 2 ** 8
  return {
    encode: (n) => {
      if (!pt(n))
        throw new Error(
          "radix.encode input should be Uint8Array",
        )
      return Mt(Array.from(n), e, t)
    },
    decode: (n) => (
      yr("radix.decode", n), Uint8Array.from(Mt(n, t, e))
    ),
  }
}
function Qs(t, e = !1) {
  if ((Fe(t), t <= 0 || t > 32))
    throw new Error("radix2: bits should be in (0..32]")
  if (mt(8, t) > 32 || mt(t, 8) > 32)
    throw new Error("radix2: carry overflow")
  return {
    encode: (n) => {
      if (!pt(n))
        throw new Error(
          "radix2.encode input should be Uint8Array",
        )
      return Dt(Array.from(n), 8, t, !e)
    },
    decode: (n) => (
      yr("radix2.decode", n),
      Uint8Array.from(Dt(n, t, 8, e))
    ),
  }
}
function vr(t, e) {
  return (
    Fe(t),
    Ws(e),
    {
      encode(n) {
        if (!pt(n))
          throw new Error(
            "checksum.encode: input should be Uint8Array",
          )
        const r = e(n).slice(0, t),
          s = new Uint8Array(n.length + t)
        return s.set(n), s.set(r, n.length), s
      },
      decode(n) {
        if (!pt(n))
          throw new Error(
            "checksum.decode: input should be Uint8Array",
          )
        const r = n.slice(0, -t),
          s = n.slice(-t),
          i = e(r).slice(0, t)
        for (let o = 0; o < t; o++)
          if (i[o] !== s[o])
            throw new Error("Invalid checksum")
        return r
      },
    }
  )
}
const lt = {
    alphabet: br,
    chain: on,
    checksum: vr,
    convertRadix: Mt,
    convertRadix2: Dt,
    radix: wr,
    radix2: Qs,
    join: gr,
    padding: Js,
  },
  ei = (t) => on(wr(58), br(t), gr("")),
  ti = ei(
    "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz",
  ),
  ni = (t) =>
    on(
      vr(4, (e) => t(t(e))),
      ti,
    ) /*! scure-bip32 - MIT License (c) 2022 Patricio Palladino, Paul Miller (paulmillr.com) */
const ut = fe.ProjectivePoint,
  jt = ni(St)
function _n(t) {
  Z(t)
  const e = t.length === 0 ? "0" : Ue(t)
  return BigInt("0x" + e)
}
function ri(t) {
  if (typeof t != "bigint")
    throw new Error("bigint expected")
  return Pe(t.toString(16).padStart(64, "0"))
}
const si = Wt("Bitcoin seed"),
  Lt = { private: 76066276, public: 76067358 },
  Ct = 2147483648,
  ii = (t) => Xs(St(t)),
  oi = (t) => _e(t).getUint32(0, !1),
  ft = (t) => {
    if (
      !Number.isSafeInteger(t) ||
      t < 0 ||
      t > 2 ** 32 - 1
    )
      throw new Error(
        "invalid number, should be from 0 to 2**32-1, got " +
          t,
      )
    const e = new Uint8Array(4)
    return _e(e).setUint32(0, t, !1), e
  }
class Ce {
  get fingerprint() {
    if (!this.pubHash) throw new Error("No publicKey set!")
    return oi(this.pubHash)
  }
  get identifier() {
    return this.pubHash
  }
  get pubKeyHash() {
    return this.pubHash
  }
  get privateKey() {
    return this.privKeyBytes || null
  }
  get publicKey() {
    return this.pubKey || null
  }
  get privateExtendedKey() {
    const e = this.privateKey
    if (!e) throw new Error("No private key")
    return jt.encode(
      this.serialize(
        this.versions.private,
        ne(new Uint8Array([0]), e),
      ),
    )
  }
  get publicExtendedKey() {
    if (!this.pubKey) throw new Error("No public key")
    return jt.encode(
      this.serialize(this.versions.public, this.pubKey),
    )
  }
  static fromMasterSeed(e, n = Lt) {
    if ((Z(e), 8 * e.length < 128 || 8 * e.length > 512))
      throw new Error(
        "HDKey: seed length must be between 128 and 512 bits; 256 bits is advised, got " +
          e.length,
      )
    const r = Xe(zt, si, e)
    return new Ce({
      versions: n,
      chainCode: r.slice(32),
      privateKey: r.slice(0, 32),
    })
  }
  static fromExtendedKey(e, n = Lt) {
    const r = jt.decode(e),
      s = _e(r),
      i = s.getUint32(0, !1),
      o = {
        versions: n,
        depth: r[4],
        parentFingerprint: s.getUint32(5, !1),
        index: s.getUint32(9, !1),
        chainCode: r.slice(13, 45),
      },
      c = r.slice(45),
      a = c[0] === 0
    if (i !== n[a ? "private" : "public"])
      throw new Error("Version mismatch")
    return a
      ? new Ce({ ...o, privateKey: c.slice(1) })
      : new Ce({ ...o, publicKey: c })
  }
  static fromJSON(e) {
    return Ce.fromExtendedKey(e.xpriv)
  }
  constructor(e) {
    if (
      ((this.depth = 0),
      (this.index = 0),
      (this.chainCode = null),
      (this.parentFingerprint = 0),
      !e || typeof e != "object")
    )
      throw new Error(
        "HDKey.constructor must not be called directly",
      )
    if (
      ((this.versions = e.versions || Lt),
      (this.depth = e.depth || 0),
      (this.chainCode = e.chainCode || null),
      (this.index = e.index || 0),
      (this.parentFingerprint = e.parentFingerprint || 0),
      !this.depth && (this.parentFingerprint || this.index))
    )
      throw new Error(
        "HDKey: zero depth with non-zero index/parent fingerprint",
      )
    if (e.publicKey && e.privateKey)
      throw new Error(
        "HDKey: publicKey and privateKey at same time.",
      )
    if (e.privateKey) {
      if (!fe.utils.isValidPrivateKey(e.privateKey))
        throw new Error("Invalid private key")
      ;(this.privKey =
        typeof e.privateKey == "bigint"
          ? e.privateKey
          : _n(e.privateKey)),
        (this.privKeyBytes = ri(this.privKey)),
        (this.pubKey = fe.getPublicKey(e.privateKey, !0))
    } else if (e.publicKey)
      this.pubKey = ut.fromHex(e.publicKey).toRawBytes(!0)
    else
      throw new Error(
        "HDKey: no public or private key provided",
      )
    this.pubHash = ii(this.pubKey)
  }
  derive(e) {
    if (!/^[mM]'?/.test(e))
      throw new Error('Path must start with "m" or "M"')
    if (/^[mM]'?$/.test(e)) return this
    const n = e.replace(/^[mM]'?\//, "").split("/")
    let r = this
    for (const s of n) {
      const i = /^(\d+)('?)$/.exec(s),
        o = i && i[1]
      if (!i || i.length !== 3 || typeof o != "string")
        throw new Error("invalid child index: " + s)
      let c = +o
      if (!Number.isSafeInteger(c) || c >= Ct)
        throw new Error("Invalid index")
      i[2] === "'" && (c += Ct), (r = r.deriveChild(c))
    }
    return r
  }
  deriveChild(e) {
    if (!this.pubKey || !this.chainCode)
      throw new Error("No publicKey or chainCode set")
    let n = ft(e)
    if (e >= Ct) {
      const c = this.privateKey
      if (!c)
        throw new Error(
          "Could not derive hardened child key",
        )
      n = ne(new Uint8Array([0]), c, n)
    } else n = ne(this.pubKey, n)
    const r = Xe(zt, this.chainCode, n),
      s = _n(r.slice(0, 32)),
      i = r.slice(32)
    if (!fe.utils.isValidPrivateKey(s))
      throw new Error("Tweak bigger than curve order")
    const o = {
      versions: this.versions,
      chainCode: i,
      depth: this.depth + 1,
      parentFingerprint: this.fingerprint,
      index: e,
    }
    try {
      if (this.privateKey) {
        const c = te(this.privKey + s, fe.CURVE.n)
        if (!fe.utils.isValidPrivateKey(c))
          throw new Error(
            "The tweak was out of range or the resulted private key is invalid",
          )
        o.privateKey = c
      } else {
        const c = ut
          .fromHex(this.pubKey)
          .add(ut.fromPrivateKey(s))
        if (c.equals(ut.ZERO))
          throw new Error(
            "The tweak was equal to negative P, which made the result key invalid",
          )
        o.publicKey = c.toRawBytes(!0)
      }
      return new Ce(o)
    } catch {
      return this.deriveChild(e + 1)
    }
  }
  sign(e) {
    if (!this.privateKey)
      throw new Error("No privateKey set!")
    return (
      Z(e, 32), fe.sign(e, this.privKey).toCompactRawBytes()
    )
  }
  verify(e, n) {
    if ((Z(e, 32), Z(n, 64), !this.publicKey))
      throw new Error("No publicKey set!")
    let r
    try {
      r = fe.Signature.fromCompact(n)
    } catch {
      return !1
    }
    return fe.verify(r, e, this.publicKey)
  }
  wipePrivateData() {
    return (
      (this.privKey = void 0),
      this.privKeyBytes &&
        (this.privKeyBytes.fill(0),
        (this.privKeyBytes = void 0)),
      this
    )
  }
  toJSON() {
    return {
      xpriv: this.privateExtendedKey,
      xpub: this.publicExtendedKey,
    }
  }
  serialize(e, n) {
    if (!this.chainCode) throw new Error("No chainCode set")
    return (
      Z(n, 33),
      ne(
        ft(e),
        new Uint8Array([this.depth]),
        ft(this.parentFingerprint),
        ft(this.index),
        this.chainCode,
        n,
      )
    )
  }
}
function ci(t, e, n, r) {
  Xt(t)
  const s = Fr({ dkLen: 32, asyncTick: 10 }, r),
    { c: i, dkLen: o, asyncTick: c } = s
  if ((Ee(i), Ee(o), Ee(c), i < 1))
    throw new Error("iterations (c) should be >= 1")
  const a = yn(e),
    u = yn(n),
    d = new Uint8Array(o),
    h = Xe.create(t, a),
    l = h._cloneInto().update(u)
  return {
    c: i,
    dkLen: o,
    asyncTick: c,
    DK: d,
    PRF: h,
    PRFSalt: l,
  }
}
function ai(t, e, n, r, s) {
  return (
    t.destroy(), e.destroy(), r && r.destroy(), ie(s), n
  )
}
function li(t, e, n, r) {
  const {
    c: s,
    dkLen: i,
    DK: o,
    PRF: c,
    PRFSalt: a,
  } = ci(t, e, n, r)
  let u
  const d = new Uint8Array(4),
    h = _e(d),
    l = new Uint8Array(c.outputLen)
  for (let f = 1, b = 0; b < i; f++, b += c.outputLen) {
    const m = o.subarray(b, b + c.outputLen)
    h.setInt32(0, f, !1),
      (u = a._cloneInto(u)).update(d).digestInto(l),
      m.set(l.subarray(0, m.length))
    for (let E = 1; E < s; E++) {
      c._cloneInto(u).update(l).digestInto(l)
      for (let I = 0; I < m.length; I++) m[I] ^= l[I]
    }
  }
  return ai(c, a, o, u, l)
} /*! scure-bip39 - MIT License (c) 2022 Patricio Palladino, Paul Miller (paulmillr.com) */
function xr(t) {
  if (typeof t != "string")
    throw new TypeError(
      "invalid mnemonic type: " + typeof t,
    )
  return t.normalize("NFKD")
}
function Er(t) {
  const e = xr(t),
    n = e.split(" ")
  if (![12, 15, 18, 21, 24].includes(n.length))
    throw new Error("Invalid mnemonic")
  return { nfkd: e, words: n }
}
function ui(t) {
  Z(t, 16, 20, 24, 28, 32)
}
const fi = (t) => {
  const e = 8 - t.length / 4
  return new Uint8Array([(St(t)[0] >> e) << e])
}
function di(t) {
  if (
    !Array.isArray(t) ||
    t.length !== 2048 ||
    typeof t[0] != "string"
  )
    throw new Error(
      "Wordlist: expected array of 2048 strings",
    )
  return (
    t.forEach((e) => {
      if (typeof e != "string")
        throw new Error(
          "wordlist: non-string element: " + e,
        )
    }),
    lt.chain(
      lt.checksum(1, fi),
      lt.radix2(11, !0),
      lt.alphabet(t),
    )
  )
}
function hi(t, e) {
  const { words: n } = Er(t),
    r = di(e).decode(n)
  return ui(r), r
}
function mo(t, e) {
  try {
    hi(t, e)
  } catch {
    return !1
  }
  return !0
}
const pi = (t) => xr("mnemonic" + t)
function wo(t, e = "") {
  return li(zt, Er(t).nfkd, pi(e), { c: 2048, dkLen: 64 })
}
const vo = `abandon
ability
able
about
above
absent
absorb
abstract
absurd
abuse
access
accident
account
accuse
achieve
acid
acoustic
acquire
across
act
action
actor
actress
actual
adapt
add
addict
address
adjust
admit
adult
advance
advice
aerobic
affair
afford
afraid
again
age
agent
agree
ahead
aim
air
airport
aisle
alarm
album
alcohol
alert
alien
all
alley
allow
almost
alone
alpha
already
also
alter
always
amateur
amazing
among
amount
amused
analyst
anchor
ancient
anger
angle
angry
animal
ankle
announce
annual
another
answer
antenna
antique
anxiety
any
apart
apology
appear
apple
approve
april
arch
arctic
area
arena
argue
arm
armed
armor
army
around
arrange
arrest
arrive
arrow
art
artefact
artist
artwork
ask
aspect
assault
asset
assist
assume
asthma
athlete
atom
attack
attend
attitude
attract
auction
audit
august
aunt
author
auto
autumn
average
avocado
avoid
awake
aware
away
awesome
awful
awkward
axis
baby
bachelor
bacon
badge
bag
balance
balcony
ball
bamboo
banana
banner
bar
barely
bargain
barrel
base
basic
basket
battle
beach
bean
beauty
because
become
beef
before
begin
behave
behind
believe
below
belt
bench
benefit
best
betray
better
between
beyond
bicycle
bid
bike
bind
biology
bird
birth
bitter
black
blade
blame
blanket
blast
bleak
bless
blind
blood
blossom
blouse
blue
blur
blush
board
boat
body
boil
bomb
bone
bonus
book
boost
border
boring
borrow
boss
bottom
bounce
box
boy
bracket
brain
brand
brass
brave
bread
breeze
brick
bridge
brief
bright
bring
brisk
broccoli
broken
bronze
broom
brother
brown
brush
bubble
buddy
budget
buffalo
build
bulb
bulk
bullet
bundle
bunker
burden
burger
burst
bus
business
busy
butter
buyer
buzz
cabbage
cabin
cable
cactus
cage
cake
call
calm
camera
camp
can
canal
cancel
candy
cannon
canoe
canvas
canyon
capable
capital
captain
car
carbon
card
cargo
carpet
carry
cart
case
cash
casino
castle
casual
cat
catalog
catch
category
cattle
caught
cause
caution
cave
ceiling
celery
cement
census
century
cereal
certain
chair
chalk
champion
change
chaos
chapter
charge
chase
chat
cheap
check
cheese
chef
cherry
chest
chicken
chief
child
chimney
choice
choose
chronic
chuckle
chunk
churn
cigar
cinnamon
circle
citizen
city
civil
claim
clap
clarify
claw
clay
clean
clerk
clever
click
client
cliff
climb
clinic
clip
clock
clog
close
cloth
cloud
clown
club
clump
cluster
clutch
coach
coast
coconut
code
coffee
coil
coin
collect
color
column
combine
come
comfort
comic
common
company
concert
conduct
confirm
congress
connect
consider
control
convince
cook
cool
copper
copy
coral
core
corn
correct
cost
cotton
couch
country
couple
course
cousin
cover
coyote
crack
cradle
craft
cram
crane
crash
crater
crawl
crazy
cream
credit
creek
crew
cricket
crime
crisp
critic
crop
cross
crouch
crowd
crucial
cruel
cruise
crumble
crunch
crush
cry
crystal
cube
culture
cup
cupboard
curious
current
curtain
curve
cushion
custom
cute
cycle
dad
damage
damp
dance
danger
daring
dash
daughter
dawn
day
deal
debate
debris
decade
december
decide
decline
decorate
decrease
deer
defense
define
defy
degree
delay
deliver
demand
demise
denial
dentist
deny
depart
depend
deposit
depth
deputy
derive
describe
desert
design
desk
despair
destroy
detail
detect
develop
device
devote
diagram
dial
diamond
diary
dice
diesel
diet
differ
digital
dignity
dilemma
dinner
dinosaur
direct
dirt
disagree
discover
disease
dish
dismiss
disorder
display
distance
divert
divide
divorce
dizzy
doctor
document
dog
doll
dolphin
domain
donate
donkey
donor
door
dose
double
dove
draft
dragon
drama
drastic
draw
dream
dress
drift
drill
drink
drip
drive
drop
drum
dry
duck
dumb
dune
during
dust
dutch
duty
dwarf
dynamic
eager
eagle
early
earn
earth
easily
east
easy
echo
ecology
economy
edge
edit
educate
effort
egg
eight
either
elbow
elder
electric
elegant
element
elephant
elevator
elite
else
embark
embody
embrace
emerge
emotion
employ
empower
empty
enable
enact
end
endless
endorse
enemy
energy
enforce
engage
engine
enhance
enjoy
enlist
enough
enrich
enroll
ensure
enter
entire
entry
envelope
episode
equal
equip
era
erase
erode
erosion
error
erupt
escape
essay
essence
estate
eternal
ethics
evidence
evil
evoke
evolve
exact
example
excess
exchange
excite
exclude
excuse
execute
exercise
exhaust
exhibit
exile
exist
exit
exotic
expand
expect
expire
explain
expose
express
extend
extra
eye
eyebrow
fabric
face
faculty
fade
faint
faith
fall
false
fame
family
famous
fan
fancy
fantasy
farm
fashion
fat
fatal
father
fatigue
fault
favorite
feature
february
federal
fee
feed
feel
female
fence
festival
fetch
fever
few
fiber
fiction
field
figure
file
film
filter
final
find
fine
finger
finish
fire
firm
first
fiscal
fish
fit
fitness
fix
flag
flame
flash
flat
flavor
flee
flight
flip
float
flock
floor
flower
fluid
flush
fly
foam
focus
fog
foil
fold
follow
food
foot
force
forest
forget
fork
fortune
forum
forward
fossil
foster
found
fox
fragile
frame
frequent
fresh
friend
fringe
frog
front
frost
frown
frozen
fruit
fuel
fun
funny
furnace
fury
future
gadget
gain
galaxy
gallery
game
gap
garage
garbage
garden
garlic
garment
gas
gasp
gate
gather
gauge
gaze
general
genius
genre
gentle
genuine
gesture
ghost
giant
gift
giggle
ginger
giraffe
girl
give
glad
glance
glare
glass
glide
glimpse
globe
gloom
glory
glove
glow
glue
goat
goddess
gold
good
goose
gorilla
gospel
gossip
govern
gown
grab
grace
grain
grant
grape
grass
gravity
great
green
grid
grief
grit
grocery
group
grow
grunt
guard
guess
guide
guilt
guitar
gun
gym
habit
hair
half
hammer
hamster
hand
happy
harbor
hard
harsh
harvest
hat
have
hawk
hazard
head
health
heart
heavy
hedgehog
height
hello
helmet
help
hen
hero
hidden
high
hill
hint
hip
hire
history
hobby
hockey
hold
hole
holiday
hollow
home
honey
hood
hope
horn
horror
horse
hospital
host
hotel
hour
hover
hub
huge
human
humble
humor
hundred
hungry
hunt
hurdle
hurry
hurt
husband
hybrid
ice
icon
idea
identify
idle
ignore
ill
illegal
illness
image
imitate
immense
immune
impact
impose
improve
impulse
inch
include
income
increase
index
indicate
indoor
industry
infant
inflict
inform
inhale
inherit
initial
inject
injury
inmate
inner
innocent
input
inquiry
insane
insect
inside
inspire
install
intact
interest
into
invest
invite
involve
iron
island
isolate
issue
item
ivory
jacket
jaguar
jar
jazz
jealous
jeans
jelly
jewel
job
join
joke
journey
joy
judge
juice
jump
jungle
junior
junk
just
kangaroo
keen
keep
ketchup
key
kick
kid
kidney
kind
kingdom
kiss
kit
kitchen
kite
kitten
kiwi
knee
knife
knock
know
lab
label
labor
ladder
lady
lake
lamp
language
laptop
large
later
latin
laugh
laundry
lava
law
lawn
lawsuit
layer
lazy
leader
leaf
learn
leave
lecture
left
leg
legal
legend
leisure
lemon
lend
length
lens
leopard
lesson
letter
level
liar
liberty
library
license
life
lift
light
like
limb
limit
link
lion
liquid
list
little
live
lizard
load
loan
lobster
local
lock
logic
lonely
long
loop
lottery
loud
lounge
love
loyal
lucky
luggage
lumber
lunar
lunch
luxury
lyrics
machine
mad
magic
magnet
maid
mail
main
major
make
mammal
man
manage
mandate
mango
mansion
manual
maple
marble
march
margin
marine
market
marriage
mask
mass
master
match
material
math
matrix
matter
maximum
maze
meadow
mean
measure
meat
mechanic
medal
media
melody
melt
member
memory
mention
menu
mercy
merge
merit
merry
mesh
message
metal
method
middle
midnight
milk
million
mimic
mind
minimum
minor
minute
miracle
mirror
misery
miss
mistake
mix
mixed
mixture
mobile
model
modify
mom
moment
monitor
monkey
monster
month
moon
moral
more
morning
mosquito
mother
motion
motor
mountain
mouse
move
movie
much
muffin
mule
multiply
muscle
museum
mushroom
music
must
mutual
myself
mystery
myth
naive
name
napkin
narrow
nasty
nation
nature
near
neck
need
negative
neglect
neither
nephew
nerve
nest
net
network
neutral
never
news
next
nice
night
noble
noise
nominee
noodle
normal
north
nose
notable
note
nothing
notice
novel
now
nuclear
number
nurse
nut
oak
obey
object
oblige
obscure
observe
obtain
obvious
occur
ocean
october
odor
off
offer
office
often
oil
okay
old
olive
olympic
omit
once
one
onion
online
only
open
opera
opinion
oppose
option
orange
orbit
orchard
order
ordinary
organ
orient
original
orphan
ostrich
other
outdoor
outer
output
outside
oval
oven
over
own
owner
oxygen
oyster
ozone
pact
paddle
page
pair
palace
palm
panda
panel
panic
panther
paper
parade
parent
park
parrot
party
pass
patch
path
patient
patrol
pattern
pause
pave
payment
peace
peanut
pear
peasant
pelican
pen
penalty
pencil
people
pepper
perfect
permit
person
pet
phone
photo
phrase
physical
piano
picnic
picture
piece
pig
pigeon
pill
pilot
pink
pioneer
pipe
pistol
pitch
pizza
place
planet
plastic
plate
play
please
pledge
pluck
plug
plunge
poem
poet
point
polar
pole
police
pond
pony
pool
popular
portion
position
possible
post
potato
pottery
poverty
powder
power
practice
praise
predict
prefer
prepare
present
pretty
prevent
price
pride
primary
print
priority
prison
private
prize
problem
process
produce
profit
program
project
promote
proof
property
prosper
protect
proud
provide
public
pudding
pull
pulp
pulse
pumpkin
punch
pupil
puppy
purchase
purity
purpose
purse
push
put
puzzle
pyramid
quality
quantum
quarter
question
quick
quit
quiz
quote
rabbit
raccoon
race
rack
radar
radio
rail
rain
raise
rally
ramp
ranch
random
range
rapid
rare
rate
rather
raven
raw
razor
ready
real
reason
rebel
rebuild
recall
receive
recipe
record
recycle
reduce
reflect
reform
refuse
region
regret
regular
reject
relax
release
relief
rely
remain
remember
remind
remove
render
renew
rent
reopen
repair
repeat
replace
report
require
rescue
resemble
resist
resource
response
result
retire
retreat
return
reunion
reveal
review
reward
rhythm
rib
ribbon
rice
rich
ride
ridge
rifle
right
rigid
ring
riot
ripple
risk
ritual
rival
river
road
roast
robot
robust
rocket
romance
roof
rookie
room
rose
rotate
rough
round
route
royal
rubber
rude
rug
rule
run
runway
rural
sad
saddle
sadness
safe
sail
salad
salmon
salon
salt
salute
same
sample
sand
satisfy
satoshi
sauce
sausage
save
say
scale
scan
scare
scatter
scene
scheme
school
science
scissors
scorpion
scout
scrap
screen
script
scrub
sea
search
season
seat
second
secret
section
security
seed
seek
segment
select
sell
seminar
senior
sense
sentence
series
service
session
settle
setup
seven
shadow
shaft
shallow
share
shed
shell
sheriff
shield
shift
shine
ship
shiver
shock
shoe
shoot
shop
short
shoulder
shove
shrimp
shrug
shuffle
shy
sibling
sick
side
siege
sight
sign
silent
silk
silly
silver
similar
simple
since
sing
siren
sister
situate
six
size
skate
sketch
ski
skill
skin
skirt
skull
slab
slam
sleep
slender
slice
slide
slight
slim
slogan
slot
slow
slush
small
smart
smile
smoke
smooth
snack
snake
snap
sniff
snow
soap
soccer
social
sock
soda
soft
solar
soldier
solid
solution
solve
someone
song
soon
sorry
sort
soul
sound
soup
source
south
space
spare
spatial
spawn
speak
special
speed
spell
spend
sphere
spice
spider
spike
spin
spirit
split
spoil
sponsor
spoon
sport
spot
spray
spread
spring
spy
square
squeeze
squirrel
stable
stadium
staff
stage
stairs
stamp
stand
start
state
stay
steak
steel
stem
step
stereo
stick
still
sting
stock
stomach
stone
stool
story
stove
strategy
street
strike
strong
struggle
student
stuff
stumble
style
subject
submit
subway
success
such
sudden
suffer
sugar
suggest
suit
summer
sun
sunny
sunset
super
supply
supreme
sure
surface
surge
surprise
surround
survey
suspect
sustain
swallow
swamp
swap
swarm
swear
sweet
swift
swim
swing
switch
sword
symbol
symptom
syrup
system
table
tackle
tag
tail
talent
talk
tank
tape
target
task
taste
tattoo
taxi
teach
team
tell
ten
tenant
tennis
tent
term
test
text
thank
that
theme
then
theory
there
they
thing
this
thought
three
thrive
throw
thumb
thunder
ticket
tide
tiger
tilt
timber
time
tiny
tip
tired
tissue
title
toast
tobacco
today
toddler
toe
together
toilet
token
tomato
tomorrow
tone
tongue
tonight
tool
tooth
top
topic
topple
torch
tornado
tortoise
toss
total
tourist
toward
tower
town
toy
track
trade
traffic
tragic
train
transfer
trap
trash
travel
tray
treat
tree
trend
trial
tribe
trick
trigger
trim
trip
trophy
trouble
truck
true
truly
trumpet
trust
truth
try
tube
tuition
tumble
tuna
tunnel
turkey
turn
turtle
twelve
twenty
twice
twin
twist
two
type
typical
ugly
umbrella
unable
unaware
uncle
uncover
under
undo
unfair
unfold
unhappy
uniform
unique
unit
universe
unknown
unlock
until
unusual
unveil
update
upgrade
uphold
upon
upper
upset
urban
urge
usage
use
used
useful
useless
usual
utility
vacant
vacuum
vague
valid
valley
valve
van
vanish
vapor
various
vast
vault
vehicle
velvet
vendor
venture
venue
verb
verify
version
very
vessel
veteran
viable
vibrant
vicious
victory
video
view
village
vintage
violin
virtual
virus
visa
visit
visual
vital
vivid
vocal
voice
void
volcano
volume
vote
voyage
wage
wagon
wait
walk
wall
walnut
want
warfare
warm
warrior
wash
wasp
waste
water
wave
way
wealth
weapon
wear
weasel
weather
web
wedding
weekend
weird
welcome
west
wet
whale
what
wheat
wheel
when
where
whip
whisper
wide
width
wife
wild
will
win
window
wine
wing
wink
winner
winter
wire
wisdom
wise
wish
witness
wolf
woman
wonder
wood
wool
word
work
world
worry
worth
wrap
wreck
wrestle
wrist
write
wrong
yard
year
yellow
you
young
youth
zebra
zero
zone
zoo`.split(`
`),
  yi = BigInt(0),
  Ye = BigInt(1),
  bi = BigInt(2),
  gi = BigInt(7),
  mi = BigInt(256),
  wi = BigInt(113),
  kr = [],
  Br = [],
  Ar = []
for (let t = 0, e = Ye, n = 1, r = 0; t < 24; t++) {
  ;([n, r] = [r, (2 * n + 3 * r) % 5]),
    kr.push(2 * (5 * r + n)),
    Br.push((((t + 1) * (t + 2)) / 2) % 64)
  let s = yi
  for (let i = 0; i < 7; i++)
    (e = ((e << Ye) ^ ((e >> gi) * wi)) % mi),
      e & bi && (s ^= Ye << ((Ye << BigInt(i)) - Ye))
  Ar.push(s)
}
const Sr = tr(Ar, !0),
  vi = Sr[0],
  xi = Sr[1],
  Un = (t, e, n) => (n > 32 ? fs(t, e, n) : ls(t, e, n)),
  Hn = (t, e, n) => (n > 32 ? ds(t, e, n) : us(t, e, n))
function Ei(t, e = 24) {
  const n = new Uint32Array(10)
  for (let r = 24 - e; r < 24; r++) {
    for (let o = 0; o < 10; o++)
      n[o] =
        t[o] ^ t[o + 10] ^ t[o + 20] ^ t[o + 30] ^ t[o + 40]
    for (let o = 0; o < 10; o += 2) {
      const c = (o + 8) % 10,
        a = (o + 2) % 10,
        u = n[a],
        d = n[a + 1],
        h = Un(u, d, 1) ^ n[c],
        l = Hn(u, d, 1) ^ n[c + 1]
      for (let f = 0; f < 50; f += 10)
        (t[o + f] ^= h), (t[o + f + 1] ^= l)
    }
    let s = t[2],
      i = t[3]
    for (let o = 0; o < 24; o++) {
      const c = Br[o],
        a = Un(s, i, c),
        u = Hn(s, i, c),
        d = kr[o]
      ;(s = t[d]),
        (i = t[d + 1]),
        (t[d] = a),
        (t[d + 1] = u)
    }
    for (let o = 0; o < 50; o += 10) {
      for (let c = 0; c < 10; c++) n[c] = t[o + c]
      for (let c = 0; c < 10; c++)
        t[o + c] ^= ~n[(c + 2) % 10] & n[(c + 4) % 10]
    }
    ;(t[0] ^= vi[r]), (t[1] ^= xi[r])
  }
  ie(n)
}
class cn extends Jt {
  constructor(e, n, r, s = !1, i = 24) {
    if (
      (super(),
      (this.pos = 0),
      (this.posOut = 0),
      (this.finished = !1),
      (this.destroyed = !1),
      (this.enableXOF = !1),
      (this.blockLen = e),
      (this.suffix = n),
      (this.outputLen = r),
      (this.enableXOF = s),
      (this.rounds = i),
      Ee(r),
      !(0 < e && e < 200))
    )
      throw new Error(
        "only keccak-f1600 function is supported",
      )
    ;(this.state = new Uint8Array(200)),
      (this.state32 = zr(this.state))
  }
  clone() {
    return this._cloneInto()
  }
  keccak() {
    hn(this.state32),
      Ei(this.state32, this.rounds),
      hn(this.state32),
      (this.posOut = 0),
      (this.pos = 0)
  }
  update(e) {
    Ve(this), (e = kt(e)), Z(e)
    const { blockLen: n, state: r } = this,
      s = e.length
    for (let i = 0; i < s; ) {
      const o = Math.min(n - this.pos, s - i)
      for (let c = 0; c < o; c++) r[this.pos++] ^= e[i++]
      this.pos === n && this.keccak()
    }
    return this
  }
  finish() {
    if (this.finished) return
    this.finished = !0
    const {
      state: e,
      suffix: n,
      pos: r,
      blockLen: s,
    } = this
    ;(e[r] ^= n),
      (n & 128) !== 0 && r === s - 1 && this.keccak(),
      (e[s - 1] ^= 128),
      this.keccak()
  }
  writeInto(e) {
    Ve(this, !1), Z(e), this.finish()
    const n = this.state,
      { blockLen: r } = this
    for (let s = 0, i = e.length; s < i; ) {
      this.posOut >= r && this.keccak()
      const o = Math.min(r - this.posOut, i - s)
      e.set(n.subarray(this.posOut, this.posOut + o), s),
        (this.posOut += o),
        (s += o)
    }
    return e
  }
  xofInto(e) {
    if (!this.enableXOF)
      throw new Error(
        "XOF is not possible for this instance",
      )
    return this.writeInto(e)
  }
  xof(e) {
    return Ee(e), this.xofInto(new Uint8Array(e))
  }
  digestInto(e) {
    if ((Ln(e, this), this.finished))
      throw new Error("digest() was already called")
    return this.writeInto(e), this.destroy(), e
  }
  digest() {
    return this.digestInto(new Uint8Array(this.outputLen))
  }
  destroy() {
    ;(this.destroyed = !0), ie(this.state)
  }
  _cloneInto(e) {
    const {
      blockLen: n,
      suffix: r,
      outputLen: s,
      rounds: i,
      enableXOF: o,
    } = this
    return (
      e || (e = new cn(n, r, s, o, i)),
      e.state32.set(this.state32),
      (e.pos = this.pos),
      (e.posOut = this.posOut),
      (e.finished = this.finished),
      (e.rounds = i),
      (e.suffix = r),
      (e.outputLen = s),
      (e.enableXOF = o),
      (e.destroyed = this.destroyed),
      e
    )
  }
}
const ki = (t, e, n) => Bt(() => new cn(e, t, n)),
  xo = ki(
    1,
    136,
    256 / 8,
  ) /*! noble-secp256k1 - MIT License (c) 2019 Paul Miller (paulmillr.com) */
const Bi = {
    p: 0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2fn,
    n: 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n,
    b: 7n,
    Gx: 0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798n,
    Gy: 0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8n,
  },
  { p: He, n: be, Gx: Ai, Gy: Si, b: Ir } = Bi,
  re = 32,
  Ze = 64,
  $ = (t = "") => {
    throw new Error(t)
  },
  _r = (t) => typeof t == "bigint",
  Ur = (t) => typeof t == "string",
  Ii = (t) =>
    t instanceof Uint8Array ||
    (ArrayBuffer.isView(t) &&
      t.constructor.name === "Uint8Array"),
  Ke = (t, e) =>
    !Ii(t) ||
    (typeof e == "number" && e > 0 && t.length !== e)
      ? $("Uint8Array expected")
      : t,
  Re = (t) => new Uint8Array(t),
  _i = (t) => Uint8Array.from(t),
  Hr = (t, e) => t.toString(16).padStart(e, "0"),
  It = (t) =>
    Array.from(Ke(t))
      .map((e) => Hr(e, 2))
      .join(""),
  ue = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 },
  Rn = (t) => {
    if (t >= ue._0 && t <= ue._9) return t - ue._0
    if (t >= ue.A && t <= ue.F) return t - (ue.A - 10)
    if (t >= ue.a && t <= ue.f) return t - (ue.a - 10)
  },
  an = (t) => {
    const e = "hex invalid"
    if (!Ur(t)) return $(e)
    const n = t.length,
      r = n / 2
    if (n % 2) return $(e)
    const s = Re(r)
    for (let i = 0, o = 0; i < r; i++, o += 2) {
      const c = Rn(t.charCodeAt(o)),
        a = Rn(t.charCodeAt(o + 1))
      if (c === void 0 || a === void 0) return $(e)
      s[i] = c * 16 + a
    }
    return s
  },
  Ne = (t, e) => Ke(Ur(t) ? an(t) : _i(Ke(t)), e),
  Rr = () => globalThis?.crypto,
  Ui = () =>
    Rr()?.subtle ?? $("crypto.subtle must be defined"),
  Oe = (...t) => {
    const e = Re(t.reduce((r, s) => r + Ke(s).length, 0))
    let n = 0
    return (
      t.forEach((r) => {
        e.set(r, n), (n += r.length)
      }),
      e
    )
  },
  Kr = (t = re) => Rr().getRandomValues(Re(t)),
  De = BigInt,
  Qe = (t, e, n, r = "bad number: out of range") =>
    _r(t) && e <= t && t < n ? t : $(r),
  x = (t, e = He) => {
    const n = t % e
    return n >= 0n ? n : e + n
  },
  he = (t) => x(t, be),
  _t = (t, e) => {
    ;(t === 0n || e <= 0n) &&
      $("no inverse n=" + t + " mod=" + e)
    let n = x(t, e),
      r = e,
      s = 0n,
      i = 1n
    for (; n !== 0n; ) {
      const o = r / n,
        c = r % n,
        a = s - i * o
      ;(r = n), (n = c), (s = i), (i = a)
    }
    return r === 1n ? x(s, e) : $("no inverse")
  },
  Hi = (t) => {
    const e = Ti[t]
    return (
      typeof e != "function" &&
        $("hashes." + t + " not set"),
      e
    )
  },
  Kn = (t) => (t instanceof Q ? t : $("Point expected")),
  Nr = (t) => x(x(t * t) * t + Ir),
  Nn = (t) => Qe(t, 0n, He),
  Ge = (t) => Qe(t, 1n, He),
  Ft = (t) => Qe(t, 1n, be),
  Yt = (t) => (t & 1n) === 0n,
  wt = (t) => Uint8Array.of(t),
  Or = (t) => wt(Yt(t) ? 2 : 3),
  Ri = (t) => {
    const e = Nr(Ge(t))
    let n = 1n
    for (let r = e, s = (He + 1n) / 4n; s > 0n; s >>= 1n)
      s & 1n && (n = (n * r) % He), (r = (r * r) % He)
    return x(n * n) === e ? n : $("sqrt invalid")
  }
class Q {
  static BASE
  static ZERO
  px
  py
  pz
  constructor(e, n, r) {
    ;(this.px = Nn(e)),
      (this.py = Ge(n)),
      (this.pz = Nn(r)),
      Object.freeze(this)
  }
  static fromBytes(e) {
    Ke(e)
    let n
    const r = e[0],
      s = e.subarray(1),
      i = vt(s, 0, re),
      o = e.length
    if (o === re + 1 && [2, 3].includes(r)) {
      let c = Ri(i)
      const a = Yt(c)
      Yt(De(r)) !== a && (c = x(-c)), (n = new Q(i, c, 1n))
    }
    return (
      o === Ze + 1 &&
        r === 4 &&
        (n = new Q(i, vt(s, re, Ze), 1n)),
      n ? n.assertValidity() : $("bad point: not on curve")
    )
  }
  equals(e) {
    const { px: n, py: r, pz: s } = this,
      { px: i, py: o, pz: c } = Kn(e),
      a = x(n * c),
      u = x(i * s),
      d = x(r * c),
      h = x(o * s)
    return a === u && d === h
  }
  is0() {
    return this.equals(Be)
  }
  negate() {
    return new Q(this.px, x(-this.py), this.pz)
  }
  double() {
    return this.add(this)
  }
  add(e) {
    const { px: n, py: r, pz: s } = this,
      { px: i, py: o, pz: c } = Kn(e),
      a = 0n,
      u = Ir
    let d = 0n,
      h = 0n,
      l = 0n
    const f = x(u * 3n)
    let b = x(n * i),
      m = x(r * o),
      E = x(s * c),
      I = x(n + r),
      K = x(i + o)
    ;(I = x(I * K)),
      (K = x(b + m)),
      (I = x(I - K)),
      (K = x(n + s))
    let v = x(i + c)
    return (
      (K = x(K * v)),
      (v = x(b + E)),
      (K = x(K - v)),
      (v = x(r + s)),
      (d = x(o + c)),
      (v = x(v * d)),
      (d = x(m + E)),
      (v = x(v - d)),
      (l = x(a * K)),
      (d = x(f * E)),
      (l = x(d + l)),
      (d = x(m - l)),
      (l = x(m + l)),
      (h = x(d * l)),
      (m = x(b + b)),
      (m = x(m + b)),
      (E = x(a * E)),
      (K = x(f * K)),
      (m = x(m + E)),
      (E = x(b - E)),
      (E = x(a * E)),
      (K = x(K + E)),
      (b = x(m * K)),
      (h = x(h + b)),
      (b = x(v * K)),
      (d = x(I * d)),
      (d = x(d - b)),
      (b = x(I * m)),
      (l = x(v * l)),
      (l = x(l + b)),
      new Q(d, h, l)
    )
  }
  multiply(e, n = !0) {
    if (!n && e === 0n) return Be
    if ((Ft(e), e === 1n)) return this
    if (this.equals(ye)) return Zi(e).p
    let r = Be,
      s = ye
    for (let i = this; e > 0n; i = i.double(), e >>= 1n)
      e & 1n ? (r = r.add(i)) : n && (s = s.add(i))
    return r
  }
  toAffine() {
    const { px: e, py: n, pz: r } = this
    if (this.equals(Be)) return { x: 0n, y: 0n }
    if (r === 1n) return { x: e, y: n }
    const s = _t(r, He)
    return (
      x(r * s) !== 1n && $("inverse invalid"),
      { x: x(e * s), y: x(n * s) }
    )
  }
  assertValidity() {
    const { x: e, y: n } = this.toAffine()
    return (
      Ge(e),
      Ge(n),
      x(n * n) === Nr(e)
        ? this
        : $("bad point: not on curve")
    )
  }
  toBytes(e = !0) {
    const { x: n, y: r } = this.assertValidity().toAffine(),
      s = ke(n)
    return e ? Oe(Or(r), s) : Oe(wt(4), s, ke(r))
  }
  static fromAffine(e) {
    const { x: n, y: r } = e
    return n === 0n && r === 0n ? Be : new Q(n, r, 1n)
  }
  toHex(e) {
    return It(this.toBytes(e))
  }
  static fromPrivateKey(e) {
    return ye.multiply(ln(e))
  }
  static fromHex(e) {
    return Q.fromBytes(Ne(e))
  }
  get x() {
    return this.toAffine().x
  }
  get y() {
    return this.toAffine().y
  }
  toRawBytes(e) {
    return this.toBytes(e)
  }
}
const ye = new Q(Ai, Si, 1n),
  Be = new Q(0n, 1n, 0n)
Q.BASE = ye
Q.ZERO = Be
const Ki = (t, e, n) =>
    ye
      .multiply(e, !1)
      .add(t.multiply(n, !1))
      .assertValidity(),
  et = (t) => De("0x" + (It(t) || "0")),
  vt = (t, e, n) => et(t.subarray(e, n)),
  Ni = 2n ** 256n,
  ke = (t) => an(Hr(Qe(t, 0n, Ni), Ze)),
  ln = (t) => {
    const e = _r(t) ? t : et(Ne(t, re))
    return Qe(e, 1n, be, "private key invalid 3")
  },
  Gt = (t) => t > be >> 1n,
  Eo = (t, e = !0) => ye.multiply(ln(t)).toBytes(e)
class $e {
  r
  s
  recovery
  constructor(e, n, r) {
    ;(this.r = Ft(e)),
      (this.s = Ft(n)),
      r != null && (this.recovery = r),
      Object.freeze(this)
  }
  static fromBytes(e) {
    Ke(e, Ze)
    const n = vt(e, 0, re),
      r = vt(e, re, Ze)
    return new $e(n, r)
  }
  toBytes() {
    const { r: e, s: n } = this
    return Oe(ke(e), ke(n))
  }
  addRecoveryBit(e) {
    return new $e(this.r, this.s, e)
  }
  hasHighS() {
    return Gt(this.s)
  }
  toCompactRawBytes() {
    return this.toBytes()
  }
  toCompactHex() {
    return It(this.toBytes())
  }
  recoverPublicKey(e) {
    return ji(this, e)
  }
  static fromCompact(e) {
    return $e.fromBytes(Ne(e, Ze))
  }
  assertValidity() {
    return this
  }
  normalizeS() {
    const { r: e, s: n, recovery: r } = this
    return Gt(n) ? new $e(e, he(-n), r) : this
  }
}
const qr = (t) => {
    const e = t.length * 8 - 256
    e > 1024 && $("msg invalid")
    const n = et(t)
    return e > 0 ? n >> De(e) : n
  },
  jr = (t) => he(qr(Ke(t))),
  Lr = { lowS: !0 },
  Oi = (t, e, n = Lr) => {
    ;["der", "recovered", "canonical"].some(
      (l) => l in n,
    ) && $("option not supported")
    let { lowS: r, extraEntropy: s } = n
    r == null && (r = !0)
    const i = ke,
      o = jr(Ne(t)),
      c = i(o),
      a = ln(e),
      u = [i(a), c]
    s && u.push(s === !0 ? Kr(re) : Ne(s))
    const d = o,
      h = (l) => {
        const f = qr(l)
        if (!(1n <= f && f < be)) return
        const b = ye.multiply(f).toAffine(),
          m = he(b.x)
        if (m === 0n) return
        const E = _t(f, be),
          I = he(E * he(d + he(a * m)))
        if (I === 0n) return
        let K = I,
          v = (b.x === m ? 0 : 2) | Number(b.y & 1n)
        return (
          r && Gt(I) && ((K = he(-I)), (v ^= 1)),
          new $e(m, K, v)
        )
      }
    return { seed: Oe(...u), k2sig: h }
  },
  qi = (t) => {
    let e = Re(re),
      n = Re(re),
      r = 0
    const s = Re(0),
      i = () => {
        e.fill(1), n.fill(0), (r = 0)
      },
      o = 1e3,
      c = "drbg: tried 1000 values"
    {
      const a = (...h) => Hi("hmacSha256Sync")(n, e, ...h),
        u = (h = s) => {
          ;(n = a(wt(0), h)),
            (e = a()),
            h.length !== 0 && ((n = a(wt(1), h)), (e = a()))
        },
        d = () => (r++ >= o && $(c), (e = a()), e)
      return (h, l) => {
        i(), u(h)
        let f
        for (; !(f = l(d())); ) u()
        return i(), f
      }
    }
  },
  ko = (t, e, n = Lr) => {
    const { seed: r, k2sig: s } = Oi(t, e, n)
    return qi()(r, s)
  },
  ji = (t, e) => {
    const { r: n, s: r, recovery: s } = t
    ;[0, 1, 2, 3].includes(s) || $("recovery id invalid")
    const i = jr(Ne(e, re)),
      o = s === 2 || s === 3 ? n + be : n
    Ge(o)
    const c = Or(De(s)),
      a = Oe(c, ke(o)),
      u = Q.fromBytes(a),
      d = _t(o, be),
      h = he(-i * d),
      l = he(r * d)
    return Ki(u, h, l)
  },
  Li = (t) => {
    ;(t = Ne(t)),
      (t.length < re + 8 || t.length > 1024) &&
        $("expected 40-1024b")
    const e = x(et(t), be - 1n)
    return ke(e + 1n)
  },
  Ci = "SHA-256",
  Ti = {
    hexToBytes: an,
    bytesToHex: It,
    concatBytes: Oe,
    bytesToNumberBE: et,
    numberToBytesBE: ke,
    mod: x,
    invert: _t,
    hmacSha256Async: async (t, ...e) => {
      const n = Ui(),
        r = "HMAC",
        s = await n.importKey(
          "raw",
          t,
          { name: r, hash: { name: Ci } },
          !1,
          ["sign"],
        )
      return Re(await n.sign(r, s, Oe(...e)))
    },
    hmacSha256Sync: void 0,
    hashToPrivateKey: Li,
    randomBytes: Kr,
  },
  xt = 8,
  $i = 256,
  Cr = Math.ceil($i / xt) + 1,
  Pt = 2 ** (xt - 1),
  zi = () => {
    const t = []
    let e = ye,
      n = e
    for (let r = 0; r < Cr; r++) {
      ;(n = e), t.push(n)
      for (let s = 1; s < Pt; s++) (n = n.add(e)), t.push(n)
      e = n.double()
    }
    return t
  }
let On
const qn = (t, e) => {
    const n = e.negate()
    return t ? n : e
  },
  Zi = (t) => {
    const e = On || (On = zi())
    let n = Be,
      r = ye
    const s = 2 ** xt,
      i = s,
      o = De(s - 1),
      c = De(xt)
    for (let a = 0; a < Cr; a++) {
      let u = Number(t & o)
      ;(t >>= c), u > Pt && ((u -= i), (t += 1n))
      const d = a * Pt,
        h = d,
        l = d + Math.abs(u) - 1,
        f = a % 2 !== 0,
        b = u < 0
      u === 0
        ? (r = r.add(qn(f, e[h])))
        : (n = n.add(qn(b, e[l])))
    }
    return { p: n, f: r }
  }
var Tt
function Tr(t) {
  return {
    lang: t?.lang ?? Tt?.lang,
    message: t?.message,
    abortEarly: t?.abortEarly ?? Tt?.abortEarly,
    abortPipeEarly: t?.abortPipeEarly ?? Tt?.abortPipeEarly,
  }
}
var Vi
function Mi(t) {
  return Vi?.get(t)
}
var Di
function Fi(t) {
  return Di?.get(t)
}
var Yi
function Gi(t, e) {
  return Yi?.get(t)?.get(e)
}
function un(t) {
  const e = typeof t
  return e === "string"
    ? `"${t}"`
    : e === "number" || e === "bigint" || e === "boolean"
      ? `${t}`
      : e === "object" || e === "function"
        ? ((t &&
            Object.getPrototypeOf(t)?.constructor?.name) ??
          "null")
        : e
}
function F(t, e, n, r, s) {
  const i = s && "input" in s ? s.input : n.value,
    o = s?.expected ?? t.expects ?? null,
    c = s?.received ?? un(i),
    a = {
      kind: t.kind,
      type: t.type,
      input: i,
      expected: o,
      received: c,
      message: `Invalid ${e}: ${o ? `Expected ${o} but r` : "R"}eceived ${c}`,
      requirement: t.requirement,
      path: s?.path,
      issues: s?.issues,
      lang: r.lang,
      abortEarly: r.abortEarly,
      abortPipeEarly: r.abortPipeEarly,
    },
    u = t.kind === "schema",
    d =
      s?.message ??
      t.message ??
      Gi(t.reference, a.lang) ??
      (u ? Fi(a.lang) : null) ??
      r.message ??
      Mi(a.lang)
  d !== void 0 &&
    (a.message = typeof d == "function" ? d(a) : d),
    u && (n.typed = !1),
    n.issues ? n.issues.push(a) : (n.issues = [a])
}
function J(t) {
  return {
    version: 1,
    vendor: "valibot",
    validate(e) {
      return t["~run"]({ value: e }, Tr())
    },
  }
}
function Pi(t, e) {
  return (
    Object.hasOwn(t, e) &&
    e !== "__proto__" &&
    e !== "prototype" &&
    e !== "constructor"
  )
}
function Xi(t, e) {
  const n = [...new Set(t)]
  return n.length > 1
    ? `(${n.join(` ${e} `)})`
    : (n[0] ?? "never")
}
var Wi = class extends Error {
    constructor(t) {
      super(t[0].message),
        (this.name = "ValiError"),
        (this.issues = t)
    }
  },
  Ji = /^(?:0[hx])?[\da-fA-F]+$/u
function Qi(t, e) {
  const n = un(t)
  return {
    kind: "validation",
    type: "excludes",
    reference: Qi,
    async: !1,
    expects: `!${n}`,
    requirement: t,
    message: e,
    "~run"(r, s) {
      return (
        r.typed &&
          r.value.includes(this.requirement) &&
          F(this, "content", r, s, { received: n }),
        r
      )
    },
  }
}
function eo(t) {
  return {
    kind: "validation",
    type: "hexadecimal",
    reference: eo,
    async: !1,
    expects: null,
    requirement: Ji,
    message: t,
    "~run"(e, n) {
      return (
        e.typed &&
          !this.requirement.test(e.value) &&
          F(this, "hexadecimal", e, n),
        e
      )
    },
  }
}
function to(t, e) {
  return {
    kind: "validation",
    type: "min_length",
    reference: to,
    async: !1,
    expects: `>=${t}`,
    requirement: t,
    message: e,
    "~run"(n, r) {
      return (
        n.typed &&
          n.value.length < this.requirement &&
          F(this, "length", n, r, {
            received: `${n.value.length}`,
          }),
        n
      )
    },
  }
}
function no(t, e, n) {
  return typeof t.fallback == "function"
    ? t.fallback(e, n)
    : t.fallback
}
function $r(t, e, n) {
  return typeof t.default == "function"
    ? t.default(e, n)
    : t.default
}
function ro(t, e) {
  return {
    kind: "schema",
    type: "array",
    reference: ro,
    expects: "Array",
    async: !1,
    item: t,
    message: e,
    get "~standard"() {
      return J(this)
    },
    "~run"(n, r) {
      const s = n.value
      if (Array.isArray(s)) {
        ;(n.typed = !0), (n.value = [])
        for (let i = 0; i < s.length; i++) {
          const o = s[i],
            c = this.item["~run"]({ value: o }, r)
          if (c.issues) {
            const a = {
              type: "array",
              origin: "value",
              input: s,
              key: i,
              value: o,
            }
            for (const u of c.issues)
              u.path ? u.path.unshift(a) : (u.path = [a]),
                n.issues?.push(u)
            if (
              (n.issues || (n.issues = c.issues),
              r.abortEarly)
            ) {
              n.typed = !1
              break
            }
          }
          c.typed || (n.typed = !1), n.value.push(c.value)
        }
      } else F(this, "type", n, r)
      return n
    },
  }
}
function so(t) {
  return {
    kind: "schema",
    type: "boolean",
    reference: so,
    expects: "boolean",
    async: !1,
    message: t,
    get "~standard"() {
      return J(this)
    },
    "~run"(e, n) {
      return (
        typeof e.value == "boolean"
          ? (e.typed = !0)
          : F(this, "type", e, n),
        e
      )
    },
  }
}
function io(t, e) {
  return {
    kind: "schema",
    type: "custom",
    reference: io,
    expects: "unknown",
    async: !1,
    check: t,
    message: e,
    get "~standard"() {
      return J(this)
    },
    "~run"(n, r) {
      return (
        this.check(n.value)
          ? (n.typed = !0)
          : F(this, "type", n, r),
        n
      )
    },
  }
}
function oo(t, e) {
  return {
    kind: "schema",
    type: "literal",
    reference: oo,
    expects: un(t),
    async: !1,
    literal: t,
    message: e,
    get "~standard"() {
      return J(this)
    },
    "~run"(n, r) {
      return (
        n.value === this.literal
          ? (n.typed = !0)
          : F(this, "type", n, r),
        n
      )
    },
  }
}
function co(t) {
  return {
    kind: "schema",
    type: "null",
    reference: co,
    expects: "null",
    async: !1,
    message: t,
    get "~standard"() {
      return J(this)
    },
    "~run"(e, n) {
      return (
        e.value === null
          ? (e.typed = !0)
          : F(this, "type", e, n),
        e
      )
    },
  }
}
function ao(t) {
  return {
    kind: "schema",
    type: "number",
    reference: ao,
    expects: "number",
    async: !1,
    message: t,
    get "~standard"() {
      return J(this)
    },
    "~run"(e, n) {
      return (
        typeof e.value == "number" && !isNaN(e.value)
          ? (e.typed = !0)
          : F(this, "type", e, n),
        e
      )
    },
  }
}
function lo(t, e) {
  return {
    kind: "schema",
    type: "object",
    reference: lo,
    expects: "Object",
    async: !1,
    entries: t,
    message: e,
    get "~standard"() {
      return J(this)
    },
    "~run"(n, r) {
      const s = n.value
      if (s && typeof s == "object") {
        ;(n.typed = !0), (n.value = {})
        for (const i in this.entries) {
          const o = this.entries[i]
          if (
            i in s ||
            ((o.type === "exact_optional" ||
              o.type === "optional" ||
              o.type === "nullish") &&
              o.default !== void 0)
          ) {
            const c = i in s ? s[i] : $r(o),
              a = o["~run"]({ value: c }, r)
            if (a.issues) {
              const u = {
                type: "object",
                origin: "value",
                input: s,
                key: i,
                value: c,
              }
              for (const d of a.issues)
                d.path ? d.path.unshift(u) : (d.path = [u]),
                  n.issues?.push(d)
              if (
                (n.issues || (n.issues = a.issues),
                r.abortEarly)
              ) {
                n.typed = !1
                break
              }
            }
            a.typed || (n.typed = !1),
              (n.value[i] = a.value)
          } else if (o.fallback !== void 0)
            n.value[i] = no(o)
          else if (
            o.type !== "exact_optional" &&
            o.type !== "optional" &&
            o.type !== "nullish" &&
            (F(this, "key", n, r, {
              input: void 0,
              expected: `"${i}"`,
              path: [
                {
                  type: "object",
                  origin: "key",
                  input: s,
                  key: i,
                  value: s[i],
                },
              ],
            }),
            r.abortEarly)
          )
            break
        }
      } else F(this, "type", n, r)
      return n
    },
  }
}
function uo(t, e) {
  return {
    kind: "schema",
    type: "optional",
    reference: uo,
    expects: `(${t.expects} | undefined)`,
    async: !1,
    wrapped: t,
    default: e,
    get "~standard"() {
      return J(this)
    },
    "~run"(n, r) {
      return n.value === void 0 &&
        (this.default !== void 0 &&
          (n.value = $r(this, n, r)),
        n.value === void 0)
        ? ((n.typed = !0), n)
        : this.wrapped["~run"](n, r)
    },
  }
}
function fo(t, e, n) {
  return {
    kind: "schema",
    type: "record",
    reference: fo,
    expects: "Object",
    async: !1,
    key: t,
    value: e,
    message: n,
    get "~standard"() {
      return J(this)
    },
    "~run"(r, s) {
      const i = r.value
      if (i && typeof i == "object") {
        ;(r.typed = !0), (r.value = {})
        for (const o in i)
          if (Pi(i, o)) {
            const c = i[o],
              a = this.key["~run"]({ value: o }, s)
            if (a.issues) {
              const d = {
                type: "object",
                origin: "key",
                input: i,
                key: o,
                value: c,
              }
              for (const h of a.issues)
                (h.path = [d]), r.issues?.push(h)
              if (
                (r.issues || (r.issues = a.issues),
                s.abortEarly)
              ) {
                r.typed = !1
                break
              }
            }
            const u = this.value["~run"]({ value: c }, s)
            if (u.issues) {
              const d = {
                type: "object",
                origin: "value",
                input: i,
                key: o,
                value: c,
              }
              for (const h of u.issues)
                h.path ? h.path.unshift(d) : (h.path = [d]),
                  r.issues?.push(h)
              if (
                (r.issues || (r.issues = u.issues),
                s.abortEarly)
              ) {
                r.typed = !1
                break
              }
            }
            ;(!a.typed || !u.typed) && (r.typed = !1),
              a.typed && (r.value[a.value] = u.value)
          }
      } else F(this, "type", r, s)
      return r
    },
  }
}
function ho(t) {
  return {
    kind: "schema",
    type: "string",
    reference: ho,
    expects: "string",
    async: !1,
    message: t,
    get "~standard"() {
      return J(this)
    },
    "~run"(e, n) {
      return (
        typeof e.value == "string"
          ? (e.typed = !0)
          : F(this, "type", e, n),
        e
      )
    },
  }
}
function po(t, e) {
  return {
    kind: "schema",
    type: "tuple",
    reference: po,
    expects: "Array",
    async: !1,
    items: t,
    message: e,
    get "~standard"() {
      return J(this)
    },
    "~run"(n, r) {
      const s = n.value
      if (Array.isArray(s)) {
        ;(n.typed = !0), (n.value = [])
        for (let i = 0; i < this.items.length; i++) {
          const o = s[i],
            c = this.items[i]["~run"]({ value: o }, r)
          if (c.issues) {
            const a = {
              type: "array",
              origin: "value",
              input: s,
              key: i,
              value: o,
            }
            for (const u of c.issues)
              u.path ? u.path.unshift(a) : (u.path = [a]),
                n.issues?.push(u)
            if (
              (n.issues || (n.issues = c.issues),
              r.abortEarly)
            ) {
              n.typed = !1
              break
            }
          }
          c.typed || (n.typed = !1), n.value.push(c.value)
        }
      } else F(this, "type", n, r)
      return n
    },
  }
}
function jn(t) {
  let e
  if (t)
    for (const n of t)
      e ? e.push(...n.issues) : (e = n.issues)
  return e
}
function yo(t, e) {
  return {
    kind: "schema",
    type: "union",
    reference: yo,
    expects: Xi(
      t.map((n) => n.expects),
      "|",
    ),
    async: !1,
    options: t,
    message: e,
    get "~standard"() {
      return J(this)
    },
    "~run"(n, r) {
      let s, i, o
      for (const c of this.options) {
        const a = c["~run"]({ value: n.value }, r)
        if (a.typed)
          if (a.issues) i ? i.push(a) : (i = [a])
          else {
            s = a
            break
          }
        else o ? o.push(a) : (o = [a])
      }
      if (s) return s
      if (i) {
        if (i.length === 1) return i[0]
        F(this, "type", n, r, { issues: jn(i) }),
          (n.typed = !0)
      } else {
        if (o?.length === 1) return o[0]
        F(this, "type", n, r, { issues: jn(o) })
      }
      return n
    },
  }
}
function bo() {
  return {
    kind: "schema",
    type: "unknown",
    reference: bo,
    expects: "unknown",
    async: !1,
    get "~standard"() {
      return J(this)
    },
    "~run"(t) {
      return (t.typed = !0), t
    },
  }
}
function Bo(t, e, n) {
  const r = t["~run"]({ value: e }, Tr(n))
  if (r.issues) throw new Wi(r.issues)
  return r.value
}
function Ao(...t) {
  return {
    ...t[0],
    pipe: t,
    get "~standard"() {
      return J(this)
    },
    "~run"(e, n) {
      for (const r of t)
        if (r.kind !== "metadata") {
          if (
            e.issues &&
            (r.kind === "schema" ||
              r.kind === "transformation")
          ) {
            e.typed = !1
            break
          }
          ;(!e.issues ||
            (!n.abortEarly && !n.abortPipeEarly)) &&
            (e = r["~run"](e, n))
        }
      return e
    },
  }
}
export {
  St as A,
  Ce as H,
  uo as a,
  ro as b,
  so as c,
  io as d,
  Ao as e,
  co as f,
  Eo as g,
  Qi as h,
  bo as i,
  to as j,
  xo as k,
  oo as l,
  wo as m,
  ao as n,
  lo as o,
  Bo as p,
  eo as q,
  fo as r,
  ho as s,
  po as t,
  yo as u,
  mo as v,
  vo as w,
  ko as x,
  Xe as y,
  Ti as z,
}
