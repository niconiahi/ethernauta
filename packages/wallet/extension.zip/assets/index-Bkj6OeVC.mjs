import {
  d as R,
  a as U,
  u as o,
  y as ee,
  k as Ee,
  E as Se,
} from "./preact-10.26.9-DO5-VWXm.mjs"
import {
  p as u,
  o as h,
  a as C,
  n as te,
  u as p,
  s as d,
  l,
  b as ne,
  r as re,
  c as v,
  v as Ae,
  m as xe,
  H as F,
  g as Te,
  k as ae,
  w as Ne,
  d as O,
  e as se,
  f as ke,
  h as Ie,
  t as x,
  i as E,
  j as Ue,
  q as Pe,
  x as Re,
  y as W,
  z as Ce,
} from "./vendor-6cAV8jNg.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const a of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(a)
  new MutationObserver((a) => {
    for (const s of a)
      if (s.type === "childList")
        for (const c of s.addedNodes)
          c.tagName === "LINK" &&
            c.rel === "modulepreload" &&
            r(c)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(a) {
    const s = {}
    return (
      a.integrity && (s.integrity = a.integrity),
      a.referrerPolicy &&
        (s.referrerPolicy = a.referrerPolicy),
      a.crossOrigin === "use-credentials"
        ? (s.credentials = "include")
        : a.crossOrigin === "anonymous"
          ? (s.credentials = "omit")
          : (s.credentials = "same-origin"),
      s
    )
  }
  function r(a) {
    if (a.ep) return
    a.ep = !0
    const s = n(a)
    fetch(a.href, s)
  }
})()
const z = { iterations: 1e5, hash: "SHA-256" },
  f = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function M(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function $(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function oe(e, t, n) {
  const r = new TextEncoder().encode(e),
    a = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: z.iterations,
      hash: z.hash,
    },
    a,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function B() {
  return new Promise((e, t) => {
    const n = indexedDB.open(f.name, f.version)
    ;(n.onupgradeneeded = (r) => {
      const a = r.target.result
      a.objectStoreNames.contains(f.store_name) ||
        a.createObjectStore(f.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Oe(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    a = await oe(t, n, ["encrypt"]),
    s = new TextEncoder().encode(e),
    c = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      a,
      s,
    ),
    i = {
      salt: M(n.buffer),
      iv: M(r.buffer),
      cipher: M(c),
    },
    m = await B()
  return new Promise((k, G) => {
    const A = m
      .transaction(f.store_name, "readwrite")
      .objectStore(f.store_name)
      .put(i, f.vault_key)
    ;(A.onsuccess = () => k()),
      (A.onerror = () =>
        G(
          new Error(
            `Failed to save vault: ${A.error?.message}`,
          ),
        ))
  })
}
async function ce(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await B(),
    n = await new Promise((m, k) => {
      const S = t
        .transaction(f.store_name, "readonly")
        .objectStore(f.store_name)
        .get(f.vault_key)
      ;(S.onsuccess = () => {
        const A = S.result
        m(A)
      }),
        (S.onerror = () =>
          k(
            new Error(
              `Failed to load vault: ${S.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = $(n.salt),
    a = $(n.iv),
    s = $(n.cipher),
    c = await oe(e, r, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: a }, c, s)
      .catch((m) => {
        throw m instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unkwown error")
      })
  return new TextDecoder().decode(i)
}
async function Me() {
  const e = await B()
  return new Promise((t) => {
    const a = e
      .transaction(f.store_name, "readonly")
      .objectStore(f.store_name)
      .get(f.vault_key)
    ;(a.onsuccess = () => t(!!a.result)),
      (a.onerror = () => t(!1))
  })
}
async function $e(e) {
  try {
    return (await ce(e)) !== void 0
  } catch {
    return !1
  }
}
const He = "password",
  w = R(He)
async function ie() {
  const e = Date.now()
  await chrome.storage.local.set({ timestamp: e })
}
async function Fe() {
  return u(
    h({ timestamp: C(te()) }),
    await chrome.storage.local.get("timestamp"),
  ).timestamp
}
async function Q() {
  const e = Date.now(),
    t = await Fe()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function V() {
  ;(await Me())
    ? (w.value = "password")
    : (w.value = "mnemonics")
}
const Be = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: d(),
    params: p([ne(v()), re(d(), v())]),
  }),
  je = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  qe = p([Be, je]),
  g = R({
    id: "some-id",
    method: "hello_world",
    params: [],
  })
function T(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function le(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += J[e[n] >> 4]), (t += J[e[n] & 15])
  return `0x${t}`
}
function De(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function b(e) {
  const t = De(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in I)) throw new Error("Invalid character")
    if (!(t[r + 1] in I))
      throw new Error("Invalid character")
    ;(n[r / 2] |= I[t[r]] << 4), (n[r / 2] |= I[t[r + 1]])
  }
  return n
}
const J = "0123456789abcdef",
  I = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function Ke(e) {
  if (!Ae(e, Ne)) throw new Error("Invalid mnemonic")
  return xe(e)
}
function Le(e) {
  return F.fromMasterSeed(e)
}
function Ge(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function We(e) {
  const t = Te(e, !1),
    n = ae(t.slice(1))
  return le(n.slice(-20))
}
function ze(e) {
  const t = e.privateKey
  return T(t, "a private key should exist"), t
}
function j(e) {
  return BigInt(e)
}
const Qe = h({ address: d(), private_key: d() }),
  N = R({
    address: "",
    key: new F({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function Ve(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.local.set({ wallet: t })
}
async function Y() {
  const t = u(
    h({ wallet: C(Qe) }),
    await chrome.storage.local.get("wallet"),
  ).wallet
  t &&
    (N.value = {
      address: t.address,
      key: F.fromExtendedKey(t.private_key),
    })
}
async function Je(e) {
  const t = await ce(e)
  T(t, "vault should exist to sign in")
  const n = Ke(t),
    r = Le(n),
    a = Ge(r),
    s = We(a),
    c = r.derive("m/44'/60'/0'/0/0"),
    i = { address: s, key: c }
  ;(N.value = i), Ve(i)
}
function q({ children: e, class: t, ...n }) {
  const [r, a] = U(!1)
  return o("button", {
    type: "button",
    onPointerDown: () => a(!0),
    onPointerUp: () => a(!1),
    onPointerLeave: () => a(!1),
    onTouchCancel: () => a(!1),
    class: [
      "bg-[#FF5005] border-2 rounded-md p-2 cursor-pointer text-base hover:bg-[#cc4004] transition-colors",
      r
        ? "outline outline-2 outline-offset-2 outline-gray-700"
        : "",
      t,
    ]
      .filter(Boolean)
      .join(" "),
    ...n,
    children: e,
  })
}
const Ye =
    "smile price bomb movie minimum treat hurdle adult wing come space cross",
  Ze = O(d(), se(8)),
  Xe = O(d(), se(1))
function et() {
  const [e, t] = U(""),
    [n, r] = U("")
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          r(s)
        },
      }),
      o("button", {
        type: "button",
        class: "text-xs text-left text-[#FF5005] underline",
        onClick: () => r(Ye),
        children: "Use test wallet",
      }),
      o("input", {
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          t(s)
        },
      }),
      o(q, {
        onClick: async () => {
          const a = u(Xe, n),
            s = u(Ze, e)
          Oe(a, s), await ie(), (w.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function tt() {
  const [e, t] = U("")
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (n) => {
          const r = n.currentTarget.value
          t(r)
        },
      }),
      o(q, {
        onClick: async () => {
          ;(await $e(e)) &&
            (await ie(), await Je(e), (w.value = "wallet"))
        },
        children: "Unlock",
      }),
    ],
  })
}
const D = { chainId: 11155111 },
  H = O(
    d(),
    Ie(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  ue = p([ne(v()), re(d(), v())]),
  K = p([d(), te(), ke()]),
  nt = h({
    jsonrpc: l("2.0"),
    method: H,
    params: C(ue),
    id: K,
  }),
  rt = h({
    data: C(v()),
    message: d(),
    code: p([
      l(-32e3),
      l(-32300),
      l(-32400),
      l(-32500),
      l(-32600),
      l(-32601),
      l(-32602),
      l(-32603),
      l(-32700),
      l(-32701),
      l(-32702),
    ]),
  }),
  at = h({ id: K, jsonrpc: l("2.0"), error: rt }),
  st = h({ id: K, jsonrpc: l("2.0"), result: v() }),
  ot = p([at, st]),
  de = p([x([H, ue]), x([H])])
function ct(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const it = E(ct)
function lt(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const ut = E(lt)
function dt(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const fe = E(dt),
  ft = ":"
function me({ namespace: e, reference: t }) {
  const n = u(it, e),
    r = u(ut, String(t)),
    a = n + ft + r
  return u(fe, a)
}
function he(e) {
  return async (t) => {
    const [n, r] = t,
      a = u(nt, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: mt(r),
      }),
      s = await fetch(e, {
        method: "POST",
        body: JSON.stringify(a),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return u(ot, s)
  }
}
function mt(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function pe(e) {
  return (t) => {
    const n = u(fe, t),
      r = e.find(({ chainId: a }) => a === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
function ht(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const y = E(ht)
function pt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const _t = E(pt)
function yt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const L = E(yt),
  wt = p([
    l("earliest"),
    l("finalized"),
    l("safe"),
    l("latest"),
    l("pending"),
  ]),
  P = p([L, wt, _t]),
  gt = p([
    x([y, P]),
    x([y]),
    h({ address: y, blockNumberOrTagOrHash: P }),
    h({ address: y }),
  ])
function vt(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = u(gt, e),
      a = u(de, [n, r]),
      s = await Promise.any(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return u(L, s.result)
  }
}
const bt = p([
  x([y, P]),
  h({ address: y, blockNumberOrTagOrHash: P }),
])
function Et(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = u(bt, e),
      a = u(de, [n, r]),
      s = await Promise.race(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return u(L, s.result)
  }
}
function _e(e) {
  return Array.isArray(e) ? At(e) : St(e)
}
function St(e) {
  const t = xt(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const s = new Uint8Array(1 + t.length)
    return (s[0] = 128 + t.length), s.set(t, 1), s
  }
  const r = ye(t.length),
    a = new Uint8Array(1 + r.length + t.length)
  return (
    (a[0] = 183 + r.length),
    a.set(r, 1),
    a.set(t, 1 + r.length),
    a
  )
}
function At(e) {
  const t = e.map((c) => _e(c)),
    n = t.reduce((c, i) => c + i.length, 0)
  if (n <= 55) {
    const c = new Uint8Array(1 + n)
    c[0] = 192 + n
    let i = 1
    for (const m of t) c.set(m, i), (i += m.length)
    return c
  }
  const r = ye(n),
    a = new Uint8Array(1 + r.length + n)
  ;(a[0] = 247 + r.length), a.set(r, 1)
  let s = 1 + r.length
  for (const c of t) a.set(c, s), (s += c.length)
  return a
}
function xt(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? b(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return Tt(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function Tt(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return b(n)
}
function ye(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function _(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return b(n)
}
function Nt(e, t) {
  return (
    (W.hmacSha256Sync = (n, ...r) =>
      Re(Ce, n, W.concatBytes(...r))),
    Pe(e, t)
  )
}
function kt(e) {
  return BigInt(e)
}
async function It(e, t, n) {
  const a = await Et([e, "latest"])(t(n))
  return j(a)
}
function Ut() {
  return BigInt(D.chainId)
}
function Pt() {
  return 21000n
}
function Rt() {
  return 20000000000n
}
function Ct() {
  return 2000000000n
}
function Ot(e, t) {
  switch (e) {
    case "transfer": {
      const n = u(y, t[0]),
        r = u(O(d(), Ue()), t[1])
      return {
        to: n,
        value: j(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function Mt({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: a, value: s, data: c } = Ot(n, r),
    i = {
      to: a,
      data: c,
      value: s,
      nonce: t,
      chain_id: Ut(),
      gas_limit: Pt(),
      max_fee_per_gas: Rt(),
      max_priority_fee_per_gas: Ct(),
    },
    m = ze(e)
  return Ht(i, m)
}
function $t(e, t) {
  const n = we(e, t)
  return ae(n)
}
function Ht(e, t) {
  const n = jt(e),
    r = Z(n),
    a = new Uint8Array([2]),
    s = $t(a, r),
    c = Nt(s, t),
    i = Bt(n, c),
    m = Z(i)
  return we(a, m)
}
function we(...e) {
  let t = 0
  for (const a of e) t += a.length
  const n = new Uint8Array(t)
  let r = 0
  for (const a of e) n.set(a, r), (r += a.length)
  return n
}
function Ft(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    T(r, "access list item should exist")
    const a = new Array(r.storage_keys.length)
    for (let s = 0; s < r.storage_keys.length; s++) {
      const c = r.storage_keys[s]
      T(c, "storage key should exist"), (a[s] = b(c))
    }
    t[n] = [b(r.address), a]
  }
  return t
}
function Bt(e, t) {
  const n = new Array(12)
  T(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = kt(t.recovery)
  return (
    (n[9] = _(r)), (n[10] = _(t.r)), (n[11] = _(t.s)), n
  )
}
function jt(e) {
  const t = new Array(9)
  return (
    (t[0] = _(e.chain_id)),
    (t[1] = _(e.nonce)),
    (t[2] = _(e.max_priority_fee_per_gas)),
    (t[3] = _(e.max_fee_per_gas)),
    (t[4] = _(e.gas_limit)),
    (t[5] = b(e.to)),
    (t[6] = _(e.value)),
    (t[7] = e.data),
    (t[8] = Ft([])),
    t
  )
}
function Z(e) {
  return _e(e)
}
const qt = { ETHEREUM: "eip155" },
  Dt = "https://ethereum-sepolia-rpc.publicnode.com",
  ge = me({ namespace: qt.ETHEREUM, reference: D.chainId }),
  Kt = pe([{ chainId: ge, transports: [he(Dt)] }])
function Lt() {
  return o("main", {
    className: "flex flex-col gap-2 p-2 text-base",
    children: [
      o("h1", {
        className: "text-center",
        children: "You are about to sign",
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Method" }),
          o("p", {
            className: "font-bold",
            children: g.value.method,
          }),
        ],
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Params" }),
          o("ul", {
            children: g.value.params.map((e, t) => {
              const n = u(d(), e),
                r = `param-${n}`
              return o(
                "li",
                {
                  className: "flex gap-2",
                  children: [
                    o("span", {
                      className: "w-2 text-center",
                      children: t,
                    }),
                    o("span", {
                      className: "font-bold",
                      children: n,
                    }),
                  ],
                },
                r,
              )
            }),
          }),
        ],
      }),
      o(q, {
        onClick: async () => {
          const e = N.value.address,
            t = N.value.key,
            n = await It(e, Kt, ge),
            r = await Mt({
              key: t,
              nonce: n,
              method: g.value.method,
              params: g.value.params,
            }),
            a = {
              id: g.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: le(r),
            }
          chrome.runtime.sendMessage(a)
        },
        children: "Sign",
      }),
    ],
  })
}
const Gt = { ETHEREUM: "eip155" },
  Wt = "https://ethereum-sepolia-rpc.publicnode.com",
  ve = me({ namespace: Gt.ETHEREUM, reference: D.chainId }),
  zt = pe([{ chainId: ve, transports: [he(Wt)] }]),
  X = R(0n)
async function Qt(e) {
  const n = await vt([e, "latest"])(zt(ve))
  return j(n)
}
function Vt(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    a = n.toString()
  if (r === 0n) return a
  const s = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${a}.${s}`
}
function Jt() {
  const e = N.value.address
  return (
    ee(() => {
      async function t() {
        const n = await Qt(e)
        X.value = n
      }
      t()
    }, []),
    o("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Address:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: e,
            }),
          ],
        }),
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Balance:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: Yt(Vt(X.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
      ],
    })
  )
}
function Yt(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function Zt() {
  return (
    ee(() => {
      chrome.runtime.sendMessage({
        type: "ETHERNAUTA_POPUP_READY",
      }),
        chrome.runtime.onMessage.addListener(async (e) => {
          const t = u(qe, e)
          switch (t.type) {
            case "ETHERNAUTA_REQUEST_CONNECT": {
              const n = await Q()
              if ((await V(), n)) {
                await Y(), (w.value = "wallet")
                return
              }
              break
            }
            case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
              {
                const n = await Q()
                if ((await V(), n)) {
                  await Y(),
                    (g.value = {
                      id: t.id,
                      method: t.method,
                      params: t.params,
                    }),
                    (w.value = "sign")
                  return
                }
              }
              break
          }
        })
    }, []),
    o(Ee, { children: Xt(w.value) })
  )
}
function Xt(e) {
  switch (e) {
    case "mnemonics":
      return o(et, {})
    case "password":
      return o(tt, {})
    case "wallet":
      return o(Jt, {})
    case "sign":
      return o(Lt, {})
    default:
      return o("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Se(o(Zt, {}), document.querySelector("#app"))
