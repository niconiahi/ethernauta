import {
  d as U,
  a as v,
  u as c,
  y as re,
  k as be,
  E as Ee,
} from "./preact-10.26.9-DO5-VWXm.mjs"
import {
  p as d,
  o as h,
  a as F,
  n as ae,
  u as p,
  s as f,
  l,
  b as se,
  r as oe,
  c as b,
  v as Se,
  m as xe,
  H as q,
  g as Ae,
  k as ce,
  w as Ne,
  d as $,
  V as z,
  e as ie,
  f as Te,
  h as ke,
  t as T,
  i as S,
  j as Ie,
  q as Ue,
  x as Pe,
  y as Q,
  z as Ce,
} from "./vendor-6yDqY-0P.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const a of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(a)
  new MutationObserver((a) => {
    for (const s of a)
      if (s.type === "childList")
        for (const o of s.addedNodes)
          o.tagName === "LINK" &&
            o.rel === "modulepreload" &&
            r(o)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(a) {
    const s = {}
    return (
      a.integrity && (s.integrity = a.integrity),
      a.referrerPolicy &&
        (s.referrerPolicy = a.referrerPolicy),
      a.crossOrigin === "use-credentials"
        ? (s.credentials = "include")
        : a.crossOrigin === "anonymous"
          ? (s.credentials = "omit")
          : (s.credentials = "same-origin"),
      s
    )
  }
  function r(a) {
    if (a.ep) return
    a.ep = !0
    const s = n(a)
    fetch(a.href, s)
  }
})()
const J = { iterations: 1e5, hash: "SHA-256" },
  m = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function H(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function M(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function le(e, t, n) {
  const r = new TextEncoder().encode(e),
    a = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: J.iterations,
      hash: J.hash,
    },
    a,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function K() {
  return new Promise((e, t) => {
    const n = indexedDB.open(m.name, m.version)
    ;(n.onupgradeneeded = (r) => {
      const a = r.target.result
      a.objectStoreNames.contains(m.store_name) ||
        a.createObjectStore(m.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Re(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    a = await le(t, n, ["encrypt"]),
    s = new TextEncoder().encode(e),
    o = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      a,
      s,
    ),
    i = {
      salt: H(n.buffer),
      iv: H(r.buffer),
      cipher: H(o),
    },
    u = await K()
  return new Promise((P, W) => {
    const A = u
      .transaction(m.store_name, "readwrite")
      .objectStore(m.store_name)
      .put(i, m.vault_key)
    ;(A.onsuccess = () => P()),
      (A.onerror = () =>
        W(
          new Error(
            `Failed to save vault: ${A.error?.message}`,
          ),
        ))
  })
}
async function ue(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await K(),
    n = await new Promise((u, P) => {
      const x = t
        .transaction(m.store_name, "readonly")
        .objectStore(m.store_name)
        .get(m.vault_key)
      ;(x.onsuccess = () => {
        const A = x.result
        u(A)
      }),
        (x.onerror = () =>
          P(
            new Error(
              `Failed to load vault: ${x.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = M(n.salt),
    a = M(n.iv),
    s = M(n.cipher),
    o = await le(e, r, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: a }, o, s)
      .catch((u) => {
        throw u instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unknown error")
      })
  return new TextDecoder().decode(i)
}
async function Oe() {
  const e = await K()
  return new Promise((t) => {
    const a = e
      .transaction(m.store_name, "readonly")
      .objectStore(m.store_name)
      .get(m.vault_key)
    ;(a.onsuccess = () => t(!!a.result)),
      (a.onerror = () => t(!1))
  })
}
async function Fe(e) {
  try {
    return (await ue(e)) !== void 0
  } catch {
    return !1
  }
}
function $e(e) {
  const t = e.trim().split(/\s+/)
  return [12, 15, 18, 21, 24].includes(t.length)
}
const He = "password",
  g = U(He)
async function de() {
  const e = Date.now()
  await chrome.storage.local.set({ timestamp: e })
}
async function Me() {
  return d(
    h({ timestamp: F(ae()) }),
    await chrome.storage.local.get("timestamp"),
  ).timestamp
}
async function Y() {
  const e = Date.now(),
    t = await Me()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function Z() {
  ;(await Oe())
    ? (g.value = "password")
    : (g.value = "mnemonics")
}
const je = h({
    id: f(),
    type: l("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: f(),
    params: p([se(b()), oe(f(), b())]),
  }),
  Be = h({
    id: f(),
    type: l("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  De = p([je, Be]),
  y = U({
    id: "some-id",
    method: "hello_world",
    params: [],
  })
function k(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function fe(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += X[e[n] >> 4]), (t += X[e[n] & 15])
  return `0x${t}`
}
function qe(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function E(e) {
  const t = qe(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in C)) throw new Error("Invalid character")
    if (!(t[r + 1] in C))
      throw new Error("Invalid character")
    ;(n[r / 2] |= C[t[r]] << 4), (n[r / 2] |= C[t[r + 1]])
  }
  return n
}
const X = "0123456789abcdef",
  C = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function Ke(e) {
  if (!Se(e, Ne)) throw new Error("Invalid mnemonic")
  return xe(e)
}
function Le(e) {
  return q.fromMasterSeed(e)
}
function Ge(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function Ve(e) {
  const t = Ae(e, !1),
    n = ce(t.slice(1))
  return fe(n.slice(-20))
}
function We(e) {
  const t = e.privateKey
  return k(t, "a private key should exist"), t
}
function L(e) {
  return BigInt(e)
}
const ze = h({ address: f(), private_key: f() }),
  I = U({
    address: "",
    key: new q({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function Qe(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.local.set({ wallet: t })
}
async function ee() {
  const t = d(
    h({ wallet: F(ze) }),
    await chrome.storage.local.get("wallet"),
  ).wallet
  t &&
    (I.value = {
      address: t.address,
      key: q.fromExtendedKey(t.private_key),
    })
}
async function Je(e) {
  const t = await ue(e)
  k(t, "vault should exist to sign in")
  const n = Ke(t),
    r = Le(n),
    a = Ge(r),
    s = Ve(a),
    o = r.derive("m/44'/60'/0'/0/0"),
    i = { address: s, key: o }
  ;(I.value = i), Qe(i)
}
function R({
  children: e,
  class: t,
  variant: n = "primary",
  ...r
}) {
  const [a, s] = v(!1)
  return c("button", {
    type: "button",
    onPointerDown: () => s(!0),
    onPointerUp: () => s(!1),
    onPointerLeave: () => s(!1),
    onTouchCancel: () => s(!1),
    class: [
      "border-2 rounded-md p-2 cursor-pointer text-base transition-colors",
      n === "secondary"
        ? "bg-[color-mix(in_srgb,#FF5005_12%,#faf5f0)] hover:bg-[color-mix(in_srgb,#FF5005_25%,#faf5f0)] border-[#FF5005] text-[#FF5005]"
        : "bg-[#FF5005] hover:bg-[#cc4004] border-[#c73d00] text-white",
      a
        ? "outline outline-2 outline-offset-2 outline-gray-700"
        : "",
      t,
    ]
      .filter(Boolean)
      .join(" "),
    ...r,
    children: e,
  })
}
const Ye = $(f(), ie(8)),
  Ze = $(f(), ie(1))
function Xe() {
  const [e, t] = v(""),
    [n, r] = v(""),
    [a, s] = v("")
  return c("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      c("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (o) => {
          const i = o.currentTarget.value
          r(i), s("")
        },
      }),
      c("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (o) => {
          const i = o.currentTarget.value
          t(i), s("")
        },
      }),
      a
        ? c("p", {
            className: "text-red-500 text-sm",
            children: a,
          })
        : null,
      c(R, {
        onClick: async () => {
          let o
          try {
            o = d(Ze, n)
          } catch (u) {
            if (u instanceof z) {
              s(u.message)
              return
            }
            throw u
          }
          if (!$e(o)) {
            s(
              "Invalid mnemonic: must be 12, 15, 18, 21, or 24 words",
            )
            return
          }
          let i
          try {
            i = d(Ye, e)
          } catch (u) {
            if (u instanceof z) {
              s(u.message)
              return
            }
            throw u
          }
          await Re(o, i), await de(), (g.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function et() {
  const [e, t] = v(""),
    [n, r] = v("")
  return c("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      c("input", {
        type: "password",
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          t(s), r("")
        },
      }),
      n
        ? c("p", {
            className: "text-red-500 text-sm",
            children: n,
          })
        : null,
      c(R, {
        onClick: async () => {
          if (!(await Fe(e))) {
            r("Invalid password")
            return
          }
          await de(), await Je(e), (g.value = "wallet")
        },
        children: "Unlock",
      }),
    ],
  })
}
const j = { name: "Ethereum Sepolia", chainId: 11155111 },
  B = $(
    f(),
    ke(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  me = p([se(b()), oe(f(), b())]),
  G = p([f(), ae(), Te()]),
  tt = h({
    jsonrpc: l("2.0"),
    method: B,
    params: F(me),
    id: G,
  }),
  nt = h({
    data: F(b()),
    message: f(),
    code: p([
      l(-32e3),
      l(-32300),
      l(-32400),
      l(-32500),
      l(-32600),
      l(-32601),
      l(-32602),
      l(-32603),
      l(-32700),
      l(-32701),
      l(-32702),
    ]),
  }),
  rt = h({ id: G, jsonrpc: l("2.0"), error: nt }),
  at = h({ id: G, jsonrpc: l("2.0"), result: b() }),
  st = p([rt, at]),
  he = p([T([B, me]), T([B])])
function ot(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const ct = S(ot)
function it(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const lt = S(it)
function ut(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const pe = S(ut),
  dt = ":"
function ft({ namespace: e, reference: t }) {
  const n = d(ct, e),
    r = d(lt, typeof t == "number" ? String(t) : t),
    a = n + dt + r
  return d(pe, a)
}
function mt(e) {
  return async (t) => {
    const [n, r] = t,
      a = d(tt, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: ht(r),
      }),
      s = await fetch(e, {
        method: "POST",
        body: JSON.stringify(a),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return d(st, s)
  }
}
function ht(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function pt(e) {
  return (t) => {
    const n = d(pe, t),
      r = e.find(({ chainId: a }) => a === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
const D = [
    {
      id: j.chainId,
      name: j.name,
      rpc_url:
        "https://ethereum-sepolia-rpc.publicnode.com",
    },
  ],
  N = U(D[0]),
  _t = "eip155"
function yt(e) {
  return ft({ namespace: _t, reference: e.id })
}
function _e(e) {
  const t = yt(e)
  return {
    chain_id: t,
    reader: pt([
      { chainId: t, transports: [mt(e.rpc_url)] },
    ]),
  }
}
function wt(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const w = S(wt)
function gt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const vt = S(gt)
function bt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const V = S(bt),
  Et = p([
    l("earliest"),
    l("finalized"),
    l("safe"),
    l("latest"),
    l("pending"),
  ]),
  O = p([V, Et, vt]),
  St = p([
    T([w, O]),
    T([w]),
    h({ address: w, blockNumberOrTagOrHash: O }),
    h({ address: w }),
  ])
function xt(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = d(St, e),
      a = d(he, [n, r]),
      s = await Promise.any(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return d(V, s.result)
  }
}
const At = p([
  T([w, O]),
  h({ address: w, blockNumberOrTagOrHash: O }),
])
function Nt(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = d(At, e),
      a = d(he, [n, r]),
      s = await Promise.race(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return d(V, s.result)
  }
}
function ye(e) {
  return Array.isArray(e) ? kt(e) : Tt(e)
}
function Tt(e) {
  const t = It(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const s = new Uint8Array(1 + t.length)
    return (s[0] = 128 + t.length), s.set(t, 1), s
  }
  const r = we(t.length),
    a = new Uint8Array(1 + r.length + t.length)
  return (
    (a[0] = 183 + r.length),
    a.set(r, 1),
    a.set(t, 1 + r.length),
    a
  )
}
function kt(e) {
  const t = e.map((o) => ye(o)),
    n = t.reduce((o, i) => o + i.length, 0)
  if (n <= 55) {
    const o = new Uint8Array(1 + n)
    o[0] = 192 + n
    let i = 1
    for (const u of t) o.set(u, i), (i += u.length)
    return o
  }
  const r = we(n),
    a = new Uint8Array(1 + r.length + n)
  ;(a[0] = 247 + r.length), a.set(r, 1)
  let s = 1 + r.length
  for (const o of t) a.set(o, s), (s += o.length)
  return a
}
function It(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? E(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return Ut(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function Ut(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return E(n)
}
function we(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function _(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return E(n)
}
function Pt(e, t) {
  return (
    (Q.hmacSha256Sync = (n, ...r) =>
      Pe(Ce, n, Q.concatBytes(...r))),
    Ue(e, t)
  )
}
function Ct(e) {
  return BigInt(e)
}
async function Rt(e, t, n) {
  const a = await Nt([e, "latest"])(t(n))
  return L(a)
}
function Ot() {
  return BigInt(j.chainId)
}
function Ft() {
  return 21000n
}
function $t() {
  return 20000000000n
}
function Ht() {
  return 2000000000n
}
function Mt(e, t) {
  switch (e) {
    case "transfer": {
      const n = d(w, t[0]),
        r = d($(f(), Ie()), t[1])
      return {
        to: n,
        value: L(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function jt({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: a, value: s, data: o } = Mt(n, r),
    i = {
      to: a,
      data: o,
      value: s,
      nonce: t,
      chain_id: Ot(),
      gas_limit: Ft(),
      max_fee_per_gas: $t(),
      max_priority_fee_per_gas: Ht(),
    },
    u = We(e)
  return Dt(i, u)
}
function Bt(e, t) {
  const n = ge(e, t)
  return ce(n)
}
function Dt(e, t) {
  const n = Lt(e),
    r = te(n),
    a = new Uint8Array([2]),
    s = Bt(a, r),
    o = Pt(s, t),
    i = Kt(n, o),
    u = te(i)
  return ge(a, u)
}
function ge(...e) {
  let t = 0
  for (const a of e) t += a.length
  const n = new Uint8Array(t)
  let r = 0
  for (const a of e) n.set(a, r), (r += a.length)
  return n
}
function qt(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    k(r, "access list item should exist")
    const a = new Array(r.storage_keys.length)
    for (let s = 0; s < r.storage_keys.length; s++) {
      const o = r.storage_keys[s]
      k(o, "storage key should exist"), (a[s] = E(o))
    }
    t[n] = [E(r.address), a]
  }
  return t
}
function Kt(e, t) {
  const n = new Array(12)
  k(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = Ct(t.recovery)
  return (
    (n[9] = _(r)), (n[10] = _(t.r)), (n[11] = _(t.s)), n
  )
}
function Lt(e) {
  const t = new Array(9)
  return (
    (t[0] = _(e.chain_id)),
    (t[1] = _(e.nonce)),
    (t[2] = _(e.max_priority_fee_per_gas)),
    (t[3] = _(e.max_fee_per_gas)),
    (t[4] = _(e.gas_limit)),
    (t[5] = E(e.to)),
    (t[6] = _(e.value)),
    (t[7] = e.data),
    (t[8] = qt([])),
    t
  )
}
function te(e) {
  return ye(e)
}
function Gt() {
  return c("main", {
    className: "flex flex-col gap-2 p-2 text-base",
    children: [
      c("h1", {
        className: "text-center",
        children: "You are about to sign",
      }),
      c("fieldset", {
        children: [
          c("legend", { children: "Method" }),
          c("p", {
            className: "font-bold",
            children: y.value.method,
          }),
        ],
      }),
      c("fieldset", {
        children: [
          c("legend", { children: "Params" }),
          c("ul", {
            children: y.value.params.map((e, t) => {
              const n = d(f(), e),
                r = `param-${n}`
              return c(
                "li",
                {
                  className: "flex gap-2",
                  children: [
                    c("span", {
                      className: "w-2 text-center",
                      children: t,
                    }),
                    c("span", {
                      className: "font-bold",
                      children: n,
                    }),
                  ],
                },
                r,
              )
            }),
          }),
        ],
      }),
      c(R, {
        onClick: async () => {
          const e = I.value.address,
            t = I.value.key,
            { chain_id: n, reader: r } = _e(N.value),
            a = await Rt(e, r, n),
            s = await jt({
              key: t,
              nonce: a,
              method: y.value.method,
              params: y.value.params,
            }),
            o = {
              id: y.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: fe(s),
            }
          chrome.runtime.sendMessage(o), window.close()
        },
        children: "Sign",
      }),
      c(R, {
        onClick: () => {
          const e = {
            id: y.value.id,
            type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
          }
          chrome.runtime.sendMessage(e), window.close()
        },
        children: "Reject",
      }),
    ],
  })
}
const ne = U(0n)
async function Vt(e) {
  const { chain_id: t, reader: n } = _e(N.value),
    a = await xt([e, "latest"])(n(t))
  return L(a)
}
function Wt(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    a = n.toString()
  if (r === 0n) return a
  const s = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${a}.${s}`
}
function zt() {
  const e = I.value.address
  return (
    re(() => {
      async function t() {
        const n = await Vt(e)
        ne.value = n
      }
      t()
    }, [N.value]),
    c("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        c("select", {
          className:
            "p-2 border-2 rounded-md cursor-pointer text-base",
          value: N.value.id,
          onChange: (t) => {
            const n = Number(t.currentTarget.value),
              r = D.find((a) => a.id === n)
            r && (N.value = r)
          },
          children: D.map((t) =>
            c(
              "option",
              { value: t.id, children: t.name },
              t.id,
            ),
          ),
        }),
        c("p", {
          className: "flex gap-1 text-base",
          children: [
            c("span", { children: "Address:" }),
            c("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: e,
            }),
          ],
        }),
        c("p", {
          className: "flex gap-1 text-base",
          children: [
            c("span", { children: "Balance:" }),
            c("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: Qt(Wt(ne.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
      ],
    })
  )
}
function Qt(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function Jt() {
  return (
    re(() => {
      chrome.runtime.connect({ name: "popup" }),
        chrome.runtime.sendMessage({
          type: "ETHERNAUTA_POPUP_READY",
        }),
        chrome.runtime.onMessage.addListener(async (e) => {
          const t = d(De, e)
          switch (t.type) {
            case "ETHERNAUTA_REQUEST_CONNECT": {
              const n = await Y()
              if ((await Z(), n)) {
                await ee(), (g.value = "wallet")
                return
              }
              break
            }
            case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
              {
                const n = await Y()
                if ((await Z(), n)) {
                  await ee(),
                    (y.value = {
                      id: t.id,
                      method: t.method,
                      params: t.params,
                    }),
                    (g.value = "sign")
                  return
                }
              }
              break
          }
        })
    }, []),
    c(be, { children: Yt(g.value) })
  )
}
function Yt(e) {
  switch (e) {
    case "mnemonics":
      return c(Xe, {})
    case "password":
      return c(et, {})
    case "wallet":
      return c(zt, {})
    case "sign":
      return c(Gt, {})
    default:
      return c("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Ee(c(Jt, {}), document.querySelector("#app"))
