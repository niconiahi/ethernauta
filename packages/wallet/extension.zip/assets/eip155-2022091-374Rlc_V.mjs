const e = {
  name: "Alterscope Testnet",
  shortName: "AlterscopeTest",
  chain: "AlterscopeTest",
  rpc: [],
  faucets: [],
  nativeCurrency: {
    name: "RISK Test Token",
    symbol: "RISKT",
    decimals: 18
  },
  infoURL: "https://alterscope.org",
  chainId: 2022091,
  networkId: 2022091,
  status: "incubating"
};
export {
  e as eip155_2022091
};
