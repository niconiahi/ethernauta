const a = {
  name: "Cybria Testnet",
  shortName: "tcyba",
  chain: "CYBA",
  icon: "cybria",
  rpc: ["https://l2-rpc.cybascan.io"],
  faucets: ["https://faucet.cybascan.io"],
  features: [
    {
      name: "EIP155"
    },
    {
      name: "EIP1559"
    }
  ],
  nativeCurrency: {
    name: "Cybria",
    symbol: "CYBA",
    decimals: 18
  },
  infoURL: "https://cybria.io",
  chainId: 6666,
  networkId: 6666,
  explorers: [
    {
      name: "Cybria Explorer",
      url: "https://explorer.cybascan.io",
      standard: "EIP3091"
    }
  ],
  parent: {
    type: "L2",
    chain: "eip155-11155420",
    bridges: [
      {
        url: "https://app.optimism.io/bridge"
      }
    ]
  }
};
export {
  a as eip155_6666
};
