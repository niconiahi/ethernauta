const i = {
  name: "Shibarium",
  shortName: "shibariumecosystem",
  chain: "Shibarium",
  icon: "shibarium",
  rpc: [
    "https://www.shibrpc.com",
    "https://rpc.shibrpc.com",
    "https://shib.nownodes.io"
  ],
  faucets: [],
  nativeCurrency: {
    name: "BONE Shibarium",
    symbol: "BONE",
    decimals: 18
  },
  infoURL: "https://shibariumecosystem.com",
  chainId: 109,
  networkId: 109,
  explorers: [
    {
      name: "shibariumscan",
      url: "https://www.shibariumscan.io",
      standard: "none"
    }
  ]
};
export {
  i as eip155_109
};
