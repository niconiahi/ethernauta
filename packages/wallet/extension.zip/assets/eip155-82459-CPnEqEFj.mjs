const e = {
  name: "Smart Layer Network Testnet",
  shortName: "tSLN",
  chain: "SLN",
  rpc: ["https://rpc.test.smartlayer.network"],
  faucets: [],
  nativeCurrency: {
    name: "Service Unit Token",
    symbol: "SU",
    decimals: 18
  },
  infoURL: "https://www.smartlayer.network/",
  chainId: 82459,
  networkId: 82459,
  explorers: [
    {
      name: "SLN Testnet Explorer",
      url: "https://explorer.test.smartlayer.network",
      standard: "EIP3091"
    }
  ]
};
export {
  e as eip155_82459
};
