const e = {
  name: "Fair Testnet",
  shortName: "fairt",
  chain: "FAIR",
  rpc: [
    "https://rpc-testnet.xfair.ai",
    "wss://rpc-testnet.xfair.ai"
  ],
  faucets: [],
  features: [
    {
      name: "EIP155"
    }
  ],
  nativeCurrency: {
    name: "FAIR",
    symbol: "FAIR",
    decimals: 18
  },
  infoURL: "https://xfair.ai",
  chainId: 171e3,
  networkId: 171e3
};
export {
  e as eip155_171000
};
