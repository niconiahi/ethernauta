var X;
// @__NO_SIDE_EFFECTS__
function se(t) {
  return {
    lang: t?.lang ?? X?.lang,
    message: t?.message,
    abortEarly: t?.abortEarly ?? X?.abortEarly,
    abortPipeEarly: t?.abortPipeEarly ?? X?.abortPipeEarly
  };
}
var et;
// @__NO_SIDE_EFFECTS__
function tt(t) {
  return et?.get(t);
}
var nt;
// @__NO_SIDE_EFFECTS__
function rt(t) {
  return nt?.get(t);
}
var it;
// @__NO_SIDE_EFFECTS__
function st(t, e) {
  return it?.get(t)?.get(e);
}
// @__NO_SIDE_EFFECTS__
function W(t) {
  const e = typeof t;
  return e === "string" ? `"${t}"` : e === "number" || e === "bigint" || e === "boolean" ? `${t}` : e === "object" || e === "function" ? (t && Object.getPrototypeOf(t)?.constructor?.name) ?? "null" : e;
}
function d(t, e, n, r, i) {
  const s = i && "input" in i ? i.input : n.value, o = i?.expected ?? t.expects ?? null, a = i?.received ?? /* @__PURE__ */ W(s), u = {
    kind: t.kind,
    type: t.type,
    input: s,
    expected: o,
    received: a,
    message: `Invalid ${e}: ${o ? `Expected ${o} but r` : "R"}eceived ${a}`,
    requirement: t.requirement,
    path: i?.path,
    issues: i?.issues,
    lang: r.lang,
    abortEarly: r.abortEarly,
    abortPipeEarly: r.abortPipeEarly
  }, c = t.kind === "schema", f = i?.message ?? t.message ?? /* @__PURE__ */ st(t.reference, u.lang) ?? (c ? /* @__PURE__ */ rt(u.lang) : null) ?? r.message ?? /* @__PURE__ */ tt(u.lang);
  f !== void 0 && (u.message = typeof f == "function" ? (
    // @ts-expect-error
    f(u)
  ) : f), c && (n.typed = !1), n.issues ? n.issues.push(u) : n.issues = [u];
}
// @__NO_SIDE_EFFECTS__
function y(t) {
  return {
    version: 1,
    vendor: "valibot",
    validate(e) {
      return t["~run"]({ value: e }, /* @__PURE__ */ se());
    }
  };
}
// @__NO_SIDE_EFFECTS__
function ot(t, e) {
  return Object.hasOwn(t, e) && e !== "__proto__" && e !== "prototype" && e !== "constructor";
}
// @__NO_SIDE_EFFECTS__
function xe(t, e) {
  const n = [...new Set(t)];
  return n.length > 1 ? `(${n.join(` ${e} `)})` : n[0] ?? "never";
}
var ut = class extends Error {
  /**
   * Creates a Valibot error with useful information.
   *
   * @param issues The error issues.
   */
  constructor(t) {
    super(t[0].message), this.name = "ValiError", this.issues = t;
  }
};
// @__NO_SIDE_EFFECTS__
function $(t) {
  return {
    kind: "transformation",
    type: "brand",
    reference: $,
    async: !1,
    name: t,
    "~run"(e) {
      return e;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function Ie(t, e) {
  const n = /* @__PURE__ */ W(t);
  return {
    kind: "validation",
    type: "excludes",
    reference: Ie,
    async: !1,
    expects: `!${n}`,
    requirement: t,
    message: e,
    "~run"(r, i) {
      return r.typed && r.value.includes(this.requirement) && d(this, "content", r, i, { received: n }), r;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function at(t) {
  return {
    kind: "validation",
    type: "url",
    reference: at,
    async: !1,
    expects: null,
    requirement(e) {
      try {
        return new URL(e), !0;
      } catch {
        return !1;
      }
    },
    message: t,
    "~run"(e, n) {
      return e.typed && !this.requirement(e.value) && d(this, "URL", e, n), e;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function ct(t, e, n) {
  return typeof t.fallback == "function" ? (
    // @ts-expect-error
    t.fallback(e, n)
  ) : (
    // @ts-expect-error
    t.fallback
  );
}
// @__NO_SIDE_EFFECTS__
function oe(t, e, n) {
  return typeof t.default == "function" ? (
    // @ts-expect-error
    t.default(e, n)
  ) : (
    // @ts-expect-error
    t.default
  );
}
// @__NO_SIDE_EFFECTS__
function U(t, e) {
  return {
    kind: "schema",
    type: "array",
    reference: U,
    expects: "Array",
    async: !1,
    item: t,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(n, r) {
      const i = n.value;
      if (Array.isArray(i)) {
        n.typed = !0, n.value = [];
        for (let s = 0; s < i.length; s++) {
          const o = i[s], a = this.item["~run"]({ value: o }, r);
          if (a.issues) {
            const u = {
              type: "array",
              origin: "value",
              input: i,
              key: s,
              value: o
            };
            for (const c of a.issues)
              c.path ? c.path.unshift(u) : c.path = [u], n.issues?.push(c);
            if (n.issues || (n.issues = a.issues), r.abortEarly) {
              n.typed = !1;
              break;
            }
          }
          a.typed || (n.typed = !1), n.value.push(a.value);
        }
      } else
        d(this, "type", n, r);
      return n;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function ue(t) {
  return {
    kind: "schema",
    type: "boolean",
    reference: ue,
    expects: "boolean",
    async: !1,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(e, n) {
      return typeof e.value == "boolean" ? e.typed = !0 : d(this, "type", e, n), e;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function k(t, e) {
  return {
    kind: "schema",
    type: "custom",
    reference: k,
    expects: "unknown",
    async: !1,
    check: t,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(n, r) {
      return this.check(n.value) ? n.typed = !0 : d(this, "type", n, r), n;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function S(t, e) {
  return {
    kind: "schema",
    type: "literal",
    reference: S,
    expects: /* @__PURE__ */ W(t),
    async: !1,
    literal: t,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(n, r) {
      return n.value === this.literal ? n.typed = !0 : d(this, "type", n, r), n;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function ae(t) {
  return {
    kind: "schema",
    type: "null",
    reference: ae,
    expects: "null",
    async: !1,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(e, n) {
      return e.value === null ? e.typed = !0 : d(this, "type", e, n), e;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function ee(t, e) {
  return {
    kind: "schema",
    type: "nullable",
    reference: ee,
    expects: `(${t.expects} | null)`,
    async: !1,
    wrapped: t,
    default: e,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(n, r) {
      return n.value === null && (this.default !== void 0 && (n.value = /* @__PURE__ */ oe(this, n, r)), n.value === null) ? (n.typed = !0, n) : this.wrapped["~run"](n, r);
    }
  };
}
// @__NO_SIDE_EFFECTS__
function J(t) {
  return {
    kind: "schema",
    type: "number",
    reference: J,
    expects: "number",
    async: !1,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(e, n) {
      return typeof e.value == "number" && !isNaN(e.value) ? e.typed = !0 : d(this, "type", e, n), e;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function p(t, e) {
  return {
    kind: "schema",
    type: "object",
    reference: p,
    expects: "Object",
    async: !1,
    entries: t,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(n, r) {
      const i = n.value;
      if (i && typeof i == "object") {
        n.typed = !0, n.value = {};
        for (const s in this.entries) {
          const o = this.entries[s];
          if (s in i || (o.type === "exact_optional" || o.type === "optional" || o.type === "nullish") && // @ts-expect-error
          o.default !== void 0) {
            const a = s in i ? (
              // @ts-expect-error
              i[s]
            ) : /* @__PURE__ */ oe(o), u = o["~run"]({ value: a }, r);
            if (u.issues) {
              const c = {
                type: "object",
                origin: "value",
                input: i,
                key: s,
                value: a
              };
              for (const f of u.issues)
                f.path ? f.path.unshift(c) : f.path = [c], n.issues?.push(f);
              if (n.issues || (n.issues = u.issues), r.abortEarly) {
                n.typed = !1;
                break;
              }
            }
            u.typed || (n.typed = !1), n.value[s] = u.value;
          } else if (o.fallback !== void 0)
            n.value[s] = /* @__PURE__ */ ct(o);
          else if (o.type !== "exact_optional" && o.type !== "optional" && o.type !== "nullish" && (d(this, "key", n, r, {
            input: void 0,
            expected: `"${s}"`,
            path: [
              {
                type: "object",
                origin: "key",
                input: i,
                key: s,
                // @ts-expect-error
                value: i[s]
              }
            ]
          }), r.abortEarly))
            break;
        }
      } else
        d(this, "type", n, r);
      return n;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function N(t, e) {
  return {
    kind: "schema",
    type: "optional",
    reference: N,
    expects: `(${t.expects} | undefined)`,
    async: !1,
    wrapped: t,
    default: e,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(n, r) {
      return n.value === void 0 && (this.default !== void 0 && (n.value = /* @__PURE__ */ oe(this, n, r)), n.value === void 0) ? (n.typed = !0, n) : this.wrapped["~run"](n, r);
    }
  };
}
// @__NO_SIDE_EFFECTS__
function Pe(t, e) {
  return {
    kind: "schema",
    type: "picklist",
    reference: Pe,
    expects: /* @__PURE__ */ xe(t.map(W), "|"),
    async: !1,
    options: t,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(n, r) {
      return this.options.includes(n.value) ? n.typed = !0 : d(this, "type", n, r), n;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function ce(t, e, n) {
  return {
    kind: "schema",
    type: "record",
    reference: ce,
    expects: "Object",
    async: !1,
    key: t,
    value: e,
    message: n,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(r, i) {
      const s = r.value;
      if (s && typeof s == "object") {
        r.typed = !0, r.value = {};
        for (const o in s)
          if (/* @__PURE__ */ ot(s, o)) {
            const a = s[o], u = this.key["~run"]({ value: o }, i);
            if (u.issues) {
              const f = {
                type: "object",
                origin: "key",
                input: s,
                key: o,
                value: a
              };
              for (const _ of u.issues)
                _.path = [f], r.issues?.push(_);
              if (r.issues || (r.issues = u.issues), i.abortEarly) {
                r.typed = !1;
                break;
              }
            }
            const c = this.value["~run"](
              { value: a },
              i
            );
            if (c.issues) {
              const f = {
                type: "object",
                origin: "value",
                input: s,
                key: o,
                value: a
              };
              for (const _ of c.issues)
                _.path ? _.path.unshift(f) : _.path = [f], r.issues?.push(_);
              if (r.issues || (r.issues = c.issues), i.abortEarly) {
                r.typed = !1;
                break;
              }
            }
            (!u.typed || !c.typed) && (r.typed = !1), u.typed && (r.value[u.value] = c.value);
          }
      } else
        d(this, "type", r, i);
      return r;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function h(t) {
  return {
    kind: "schema",
    type: "string",
    reference: h,
    expects: "string",
    async: !1,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(e, n) {
      return typeof e.value == "string" ? e.typed = !0 : d(this, "type", e, n), e;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function M(t, e) {
  return {
    kind: "schema",
    type: "tuple",
    reference: M,
    expects: "Array",
    async: !1,
    items: t,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(n, r) {
      const i = n.value;
      if (Array.isArray(i)) {
        n.typed = !0, n.value = [];
        for (let s = 0; s < this.items.length; s++) {
          const o = i[s], a = this.items[s]["~run"]({ value: o }, r);
          if (a.issues) {
            const u = {
              type: "array",
              origin: "value",
              input: i,
              key: s,
              value: o
            };
            for (const c of a.issues)
              c.path ? c.path.unshift(u) : c.path = [u], n.issues?.push(c);
            if (n.issues || (n.issues = a.issues), r.abortEarly) {
              n.typed = !1;
              break;
            }
          }
          a.typed || (n.typed = !1), n.value.push(a.value);
        }
      } else
        d(this, "type", n, r);
      return n;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function Ue(t, e, n) {
  return {
    kind: "schema",
    type: "tuple_with_rest",
    reference: Ue,
    expects: "Array",
    async: !1,
    items: t,
    rest: e,
    message: n,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(r, i) {
      const s = r.value;
      if (Array.isArray(s)) {
        r.typed = !0, r.value = [];
        for (let o = 0; o < this.items.length; o++) {
          const a = s[o], u = this.items[o]["~run"]({ value: a }, i);
          if (u.issues) {
            const c = {
              type: "array",
              origin: "value",
              input: s,
              key: o,
              value: a
            };
            for (const f of u.issues)
              f.path ? f.path.unshift(c) : f.path = [c], r.issues?.push(f);
            if (r.issues || (r.issues = u.issues), i.abortEarly) {
              r.typed = !1;
              break;
            }
          }
          u.typed || (r.typed = !1), r.value.push(u.value);
        }
        if (!r.issues || !i.abortEarly)
          for (let o = this.items.length; o < s.length; o++) {
            const a = s[o], u = this.rest["~run"]({ value: a }, i);
            if (u.issues) {
              const c = {
                type: "array",
                origin: "value",
                input: s,
                key: o,
                value: a
              };
              for (const f of u.issues)
                f.path ? f.path.unshift(c) : f.path = [c], r.issues?.push(f);
              if (r.issues || (r.issues = u.issues), i.abortEarly) {
                r.typed = !1;
                break;
              }
            }
            u.typed || (r.typed = !1), r.value.push(u.value);
          }
      } else
        d(this, "type", r, i);
      return r;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function de(t) {
  let e;
  if (t)
    for (const n of t)
      e ? e.push(...n.issues) : e = n.issues;
  return e;
}
// @__NO_SIDE_EFFECTS__
function w(t, e) {
  return {
    kind: "schema",
    type: "union",
    reference: w,
    expects: /* @__PURE__ */ xe(
      t.map((n) => n.expects),
      "|"
    ),
    async: !1,
    options: t,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(n, r) {
      let i, s, o;
      for (const a of this.options) {
        const u = a["~run"]({ value: n.value }, r);
        if (u.typed)
          if (u.issues)
            s ? s.push(u) : s = [u];
          else {
            i = u;
            break;
          }
        else
          o ? o.push(u) : o = [u];
      }
      if (i)
        return i;
      if (s) {
        if (s.length === 1)
          return s[0];
        d(this, "type", n, r, {
          issues: /* @__PURE__ */ de(s)
        }), n.typed = !0;
      } else {
        if (o?.length === 1)
          return o[0];
        d(this, "type", n, r, {
          issues: /* @__PURE__ */ de(o)
        });
      }
      return n;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function P() {
  return {
    kind: "schema",
    type: "unknown",
    reference: P,
    expects: "unknown",
    async: !1,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(t) {
      return t.typed = !0, t;
    }
  };
}
function b(t, e, n) {
  const r = t["~run"]({ value: e }, /* @__PURE__ */ se(n));
  if (r.issues)
    throw new ut(r.issues);
  return r.value;
}
// @__NO_SIDE_EFFECTS__
function x(...t) {
  return {
    ...t[0],
    pipe: t,
    get "~standard"() {
      return /* @__PURE__ */ y(this);
    },
    "~run"(e, n) {
      for (const r of t)
        if (r.kind !== "metadata") {
          if (e.issues && (r.kind === "schema" || r.kind === "transformation")) {
            e.typed = !1;
            break;
          }
          (!e.issues || !n.abortEarly && !n.abortPipeEarly) && (e = r["~run"](e, n));
        }
      return e;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function Hn(t, e, n) {
  const r = t["~run"]({ value: e }, /* @__PURE__ */ se(n));
  return {
    typed: r.typed,
    success: !r.issues,
    output: r.value,
    issues: r.issues
  };
}
function ft(t) {
  return typeof t == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(t);
}
const V = /* @__PURE__ */ x(
  /* @__PURE__ */ k(ft),
  /* @__PURE__ */ $("Address")
);
function lt(t) {
  return typeof t == "string" && /^0x([0-9,a-f,A-F]?){1,2}$/.test(t);
}
const ht = /* @__PURE__ */ x(
  /* @__PURE__ */ k(lt),
  /* @__PURE__ */ $("Byte")
);
function pt(t) {
  return typeof t == "string" && /^0x[0-9a-f]*$/.test(t);
}
const _t = /* @__PURE__ */ x(
  /* @__PURE__ */ k(pt),
  /* @__PURE__ */ $("Bytes")
);
function vt(t) {
  return typeof t == "string" && /^0x[0-9a-f]{64}$/.test(t);
}
const dt = /* @__PURE__ */ x(
  /* @__PURE__ */ k(vt),
  /* @__PURE__ */ $("Bytes32")
);
function yt(t) {
  return typeof t == "string" && /^0x[0-9a-f]{512}$/.test(t);
}
const mt = /* @__PURE__ */ x(
  /* @__PURE__ */ k(yt),
  /* @__PURE__ */ $("Bytes256")
);
function bt(t) {
  return typeof t == "string" && /^0x[0-9a-f]{64}$/.test(t);
}
const I = /* @__PURE__ */ x(
  /* @__PURE__ */ k(bt),
  /* @__PURE__ */ $("Hash32")
), Et = /* @__PURE__ */ ae();
function St(t) {
  return typeof t == "string" && /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(t);
}
const E = /* @__PURE__ */ x(
  /* @__PURE__ */ k(St, "uint"),
  /* @__PURE__ */ $("Uint")
), te = /* @__PURE__ */ x(
  /* @__PURE__ */ h(),
  /* @__PURE__ */ Ie(
    "rpc.",
    'method names that begin with "rpc." are reserved for system extensions'
  )
), De = /* @__PURE__ */ w([
  /* @__PURE__ */ U(/* @__PURE__ */ P()),
  /* @__PURE__ */ ce(/* @__PURE__ */ h(), /* @__PURE__ */ P())
]), fe = /* @__PURE__ */ w([/* @__PURE__ */ h(), /* @__PURE__ */ J(), /* @__PURE__ */ ae()]), Ce = /* @__PURE__ */ p({
  jsonrpc: /* @__PURE__ */ S("2.0"),
  method: te,
  params: /* @__PURE__ */ N(De),
  id: fe
}), gt = /* @__PURE__ */ p({
  data: /* @__PURE__ */ N(/* @__PURE__ */ P()),
  message: /* @__PURE__ */ h(),
  code: /* @__PURE__ */ J()
}), At = /* @__PURE__ */ p({
  id: fe,
  jsonrpc: /* @__PURE__ */ S("2.0"),
  error: gt
}), kt = /* @__PURE__ */ p({
  id: fe,
  jsonrpc: /* @__PURE__ */ S("2.0"),
  result: /* @__PURE__ */ P()
}), Oe = /* @__PURE__ */ w([
  At,
  kt
]), wt = /* @__PURE__ */ w([
  /* @__PURE__ */ M([te, De]),
  /* @__PURE__ */ M([te])
]);
function Tt(t) {
  return typeof t == "string" && /^[-a-z0-9]{3,8}$/.test(t);
}
const Nt = /* @__PURE__ */ k(Tt);
function Rt(t) {
  return typeof t == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(t);
}
const $t = /* @__PURE__ */ k(Rt);
function xt(t) {
  return typeof t == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(t);
}
const He = /* @__PURE__ */ k(xt), It = ":";
function Pt({
  namespace: t,
  reference: e
}) {
  const n = b(Nt, t), r = b(
    $t,
    typeof e == "number" ? String(e) : e
  ), i = n + It + r;
  return b(He, i);
}
function Ut(t, e = {}) {
  return e.batch ? Ct(t, e) : Dt(t, e);
}
function Dt(t, e) {
  return async (n) => {
    const [r, i] = n, s = b(Ce, {
      jsonrpc: "2.0",
      id: crypto.randomUUID(),
      method: r,
      params: Fe(i)
    }), o = await qe(
      () => Ot(t, s, e),
      e.retry
    );
    return b(Oe, o);
  };
}
function Ct(t, e) {
  const n = typeof e.batch == "object" ? e.batch : {}, r = n.window_ms ?? 0, i = n.max_size ?? 100;
  let s = [], o = null;
  function a() {
    const u = s;
    if (s = [], o && (clearTimeout(o), o = null), u.length === 0) return;
    const c = u.map((f) => f.request);
    qe(
      () => Ht(t, c, e),
      e.retry
    ).then((f) => {
      const _ = /* @__PURE__ */ new Map();
      for (const T of f) {
        const g = b(Oe, T);
        _.set(g.id, g);
      }
      for (const T of u) {
        const g = _.get(T.request.id);
        if (!g) {
          T.reject(
            new Error(
              `batch response missing id: ${String(T.request.id)}`
            )
          );
          continue;
        }
        T.resolve(g);
      }
    }).catch((f) => {
      for (const _ of u) _.reject(f);
    });
  }
  return async (u) => {
    const [c, f] = u, _ = b(Ce, {
      jsonrpc: "2.0",
      id: crypto.randomUUID(),
      method: c,
      params: Fe(f)
    });
    return new Promise((T, g) => {
      if (s.push({ request: _, resolve: T, reject: g }), s.length >= i) {
        a();
        return;
      }
      o || (o = setTimeout(a, r));
    });
  };
}
async function Ot(t, e, n) {
  return (await je(t, e, n)).json();
}
async function Ht(t, e, n) {
  const i = await (await je(t, e, n)).json();
  if (!Array.isArray(i))
    throw new Error("batch response was not an array");
  return i;
}
async function je(t, e, n) {
  const r = n.timeout_ms ? AbortSignal.timeout(n.timeout_ms) : void 0, i = await fetch(t, {
    method: "POST",
    body: JSON.stringify(e),
    headers: {
      "Content-Type": "application/json",
      ...n.headers
    },
    signal: r
  });
  if (!i.ok)
    throw new Error(
      `http ${i.status}: ${i.statusText}`
    );
  return i;
}
async function qe(t, e) {
  if (!e || e.attempts <= 1) return t();
  const n = e.base_delay_ms ?? 250, r = e.max_delay_ms ?? 3e4;
  let i;
  for (let s = 0; s < e.attempts; s += 1)
    try {
      return await t();
    } catch (o) {
      if (i = o, s === e.attempts - 1) break;
      const a = Math.min(r, n * 2 ** s);
      await jt(a);
    }
  throw i;
}
function jt(t) {
  return new Promise((e) => setTimeout(e, t));
}
function Fe(t) {
  if (t)
    return Array.isArray(t) ? t : Object.values(t);
}
function qt(t) {
  return `0x${t.toString(16)}`;
}
function Ft(t, e) {
  const n = t.find((r) => r.chainId === e);
  if (!n)
    throw new Error(`no chain configured for: ${e}`);
  return n.transports;
}
const Lt = /* @__PURE__ */ p({
  chain_id: He
});
function Vt(t) {
  return (e) => {
    const n = b(Lt, e);
    return [Ft(
      t,
      n.chain_id
    ), n];
  };
}
const F = {
  PENDING: 100,
  CONFIRMED: 200,
  REVERTED: 500,
  PARTIALLY_REVERTED: 600
}, Gt = /* @__PURE__ */ p({
  removed: /* @__PURE__ */ ue(),
  logIndex: E,
  transactionIndex: E,
  transactionHash: I,
  blockHash: I,
  blockNumber: E,
  address: V,
  data: _t,
  topics: /* @__PURE__ */ U(dt)
}), Le = /* @__PURE__ */ p({
  blockHash: I,
  blockNumber: E,
  from: V,
  cumulativeGasUsed: E,
  gasUsed: E,
  logs: /* @__PURE__ */ U(Gt),
  logsBloom: mt,
  transactionHash: I,
  transactionIndex: E,
  effectiveGasPrice: E,
  type: /* @__PURE__ */ N(ht),
  // might not be present in all receipts
  to: /* @__PURE__ */ ee(V),
  blobGasUsed: /* @__PURE__ */ N(E),
  // only for blob transactions
  root: /* @__PURE__ */ N(I),
  // only for pre-Byzantium transactions
  status: /* @__PURE__ */ N(E),
  // only for post-Byzantium transactions
  blobGasPrice: /* @__PURE__ */ N(E),
  // only for blob transactions
  contractAddress: /* @__PURE__ */ ee(V)
}), le = {
  REVERTED: "0x0",
  SUCCESS: "0x1"
}, Mt = /* @__PURE__ */ x(
  /* @__PURE__ */ Pe(Object.values(le)),
  /* @__PURE__ */ $("Uint")
);
({
  ...Le.entries
});
const Bt = /* @__PURE__ */ w([
  /* @__PURE__ */ M([I]),
  /* @__PURE__ */ p({ transactionHash: I })
]);
function zt(t) {
  return async ([
    e,
    n
  ]) => {
    const r = "eth_getTransactionReceipt", i = b(Bt, t), s = b(wt, [r, i]), o = await Promise.any(
      e.map((u) => u(s))
    );
    if ("error" in o)
      throw new Error(o.error.message);
    return b(
      /* @__PURE__ */ w([Le, Et]),
      o.result
    );
  };
}
const Yt = "calls_", Zt = /* @__PURE__ */ p({
  id: /* @__PURE__ */ h(),
  chainId: E,
  atomic: /* @__PURE__ */ ue(),
  transaction_hashes: /* @__PURE__ */ U(I)
});
function Wt(t) {
  return `${Yt}${t}`;
}
async function Jt(t) {
  const e = Wt(t), r = (await chrome.storage.session.get(e))[e];
  return r === void 0 ? void 0 : b(Zt, r);
}
const ye = {
  name: "Ethereum Mainnet",
  chainId: 1
}, me = {
  name: "Ethereum Sepolia",
  chainId: 11155111
};
var j, Ve;
function Kt(t) {
  return t.children;
}
j = { __e: function(t, e, n, r) {
  for (var i, s, o; e = e.__; ) if ((i = e.__c) && !i.__) try {
    if ((s = i.constructor) && s.getDerivedStateFromError != null && (i.setState(s.getDerivedStateFromError(t)), o = i.__d), i.componentDidCatch != null && (i.componentDidCatch(t, r || {}), o = i.__d), o) return i.__E = i;
  } catch (a) {
    t = a;
  }
  throw t;
} }, Ve = function(t) {
  return t != null && t.constructor == null;
}, typeof Promise == "function" && Promise.prototype.then.bind(Promise.resolve());
var ne, A, Q, be, Ee = 0, Ge = [], v = j, Se = v.__b, ge = v.__r, Ae = v.diffed, ke = v.__c, we = v.unmount, Te = v.__;
function Xt(t, e) {
  v.__h && v.__h(A, t, Ee || e), Ee = 0;
  var n = A.__H || (A.__H = { __: [], __h: [] });
  return t >= n.__.length && n.__.push({}), n.__[t];
}
function Me(t, e) {
  var n = Xt(ne++, 7);
  return tn(n.__H, e) && (n.__ = t(), n.__H = e, n.__h = t), n.__;
}
function Qt() {
  for (var t; t = Ge.shift(); ) if (t.__P && t.__H) try {
    t.__H.__h.forEach(G), t.__H.__h.forEach(re), t.__H.__h = [];
  } catch (e) {
    t.__H.__h = [], v.__e(e, t.__v);
  }
}
v.__b = function(t) {
  A = null, Se && Se(t);
}, v.__ = function(t, e) {
  t && e.__k && e.__k.__m && (t.__m = e.__k.__m), Te && Te(t, e);
}, v.__r = function(t) {
  ge && ge(t), ne = 0;
  var e = (A = t.__c).__H;
  e && (Q === A ? (e.__h = [], A.__h = [], e.__.forEach(function(n) {
    n.__N && (n.__ = n.__N), n.u = n.__N = void 0;
  })) : (e.__h.forEach(G), e.__h.forEach(re), e.__h = [], ne = 0)), Q = A;
}, v.diffed = function(t) {
  Ae && Ae(t);
  var e = t.__c;
  e && e.__H && (e.__H.__h.length && (Ge.push(e) !== 1 && be === v.requestAnimationFrame || ((be = v.requestAnimationFrame) || en)(Qt)), e.__H.__.forEach(function(n) {
    n.u && (n.__H = n.u), n.u = void 0;
  })), Q = A = null;
}, v.__c = function(t, e) {
  e.some(function(n) {
    try {
      n.__h.forEach(G), n.__h = n.__h.filter(function(r) {
        return !r.__ || re(r);
      });
    } catch (r) {
      e.some(function(i) {
        i.__h && (i.__h = []);
      }), e = [], v.__e(r, n.__v);
    }
  }), ke && ke(t, e);
}, v.unmount = function(t) {
  we && we(t);
  var e, n = t.__c;
  n && n.__H && (n.__H.__.forEach(function(r) {
    try {
      G(r);
    } catch (i) {
      e = i;
    }
  }), n.__H = void 0, e && v.__e(e, n.__v));
};
var Ne = typeof requestAnimationFrame == "function";
function en(t) {
  var e, n = function() {
    clearTimeout(r), Ne && cancelAnimationFrame(e), setTimeout(t);
  }, r = setTimeout(n, 35);
  Ne && (e = requestAnimationFrame(n));
}
function G(t) {
  var e = A, n = t.__c;
  typeof n == "function" && (t.__c = void 0, n()), A = e;
}
function re(t) {
  var e = A;
  t.__c = t.__(), A = e;
}
function tn(t, e) {
  return !t || t.length !== e.length || e.some(function(n, r) {
    return n !== t[r];
  });
}
var nn = Symbol.for("preact-signals");
function K() {
  if (R > 1)
    R--;
  else {
    var t, e = !1;
    for ((function() {
      var i = z;
      for (z = void 0; i !== void 0; )
        i.S.v === i.v && (i.S.i = i.i), i = i.o;
    })(); H !== void 0; ) {
      var n = H;
      for (H = void 0, B++; n !== void 0; ) {
        var r = n.u;
        if (n.u = void 0, n.f &= -3, !(8 & n.f) && ze(n)) try {
          n.c();
        } catch (i) {
          e || (t = i, e = !0);
        }
        n = r;
      }
    }
    if (B = 0, R--, e) throw t;
  }
}
function rn(t) {
  if (R > 0) return t();
  ie = ++sn, R++;
  try {
    return t();
  } finally {
    K();
  }
}
var l = void 0;
function he(t) {
  var e = l;
  l = void 0;
  try {
    return t();
  } finally {
    l = e;
  }
}
var H = void 0, R = 0, B = 0, sn = 0, ie = 0, z = void 0, Y = 0;
function Be(t) {
  if (l !== void 0) {
    var e = t.n;
    if (e === void 0 || e.t !== l)
      return e = { i: 0, S: t, p: l.s, n: void 0, t: l, e: void 0, x: void 0, r: e }, l.s !== void 0 && (l.s.n = e), l.s = e, t.n = e, 32 & l.f && t.S(e), e;
    if (e.i === -1)
      return e.i = 0, e.n !== void 0 && (e.n.p = e.p, e.p !== void 0 && (e.p.n = e.n), e.p = l.s, e.n = void 0, l.s.n = e, l.s = e), e;
  }
}
function m(t, e) {
  this.v = t, this.i = 0, this.n = void 0, this.t = void 0, this.l = 0, this.W = e?.watched, this.Z = e?.unwatched, this.name = e?.name;
}
m.prototype.brand = nn;
m.prototype.h = function() {
  return !0;
};
m.prototype.S = function(t) {
  var e = this, n = this.t;
  n !== t && t.e === void 0 && (t.x = n, this.t = t, n !== void 0 ? n.e = t : he(function() {
    var r;
    (r = e.W) == null || r.call(e);
  }));
};
m.prototype.U = function(t) {
  var e = this;
  if (this.t !== void 0) {
    var n = t.e, r = t.x;
    n !== void 0 && (n.x = r, t.e = void 0), r !== void 0 && (r.e = n, t.x = void 0), t === this.t && (this.t = r, r === void 0 && he(function() {
      var i;
      (i = e.Z) == null || i.call(e);
    }));
  }
};
m.prototype.subscribe = function(t) {
  var e = this;
  return q(function() {
    var n = e.value, r = l;
    l = void 0;
    try {
      t(n);
    } finally {
      l = r;
    }
  }, { name: "sub" });
};
m.prototype.valueOf = function() {
  return this.value;
};
m.prototype.toString = function() {
  return this.value + "";
};
m.prototype.toJSON = function() {
  return this.value;
};
m.prototype.peek = function() {
  var t = this;
  return he(function() {
    return t.value;
  });
};
Object.defineProperty(m.prototype, "value", { get: function() {
  var t = Be(this);
  return t !== void 0 && (t.i = this.i), this.v;
}, set: function(t) {
  if (t !== this.v) {
    if (B > 100) throw new Error("Cycle detected");
    (function(n) {
      R !== 0 && B === 0 && n.l !== ie && (n.l = ie, z = { S: n, v: n.v, i: n.i, o: z });
    })(this), this.v = t, this.i++, Y++, R++;
    try {
      for (var e = this.t; e !== void 0; e = e.x) e.t.N();
    } finally {
      K();
    }
  }
} });
function pe(t, e) {
  return new m(t, e);
}
function ze(t) {
  for (var e = t.s; e !== void 0; e = e.n) if (e.S.i !== e.i || !e.S.h() || e.S.i !== e.i) return !0;
  return !1;
}
function Ye(t) {
  for (var e = t.s; e !== void 0; e = e.n) {
    var n = e.S.n;
    if (n !== void 0 && (e.r = n), e.S.n = e, e.i = -1, e.n === void 0) {
      t.s = e;
      break;
    }
  }
}
function Ze(t) {
  for (var e = t.s, n = void 0; e !== void 0; ) {
    var r = e.p;
    e.i === -1 ? (e.S.U(e), r !== void 0 && (r.n = e.n), e.n !== void 0 && (e.n.p = r)) : n = e, e.S.n = e.r, e.r !== void 0 && (e.r = void 0), e = r;
  }
  t.s = n;
}
function D(t, e) {
  m.call(this, void 0), this.x = t, this.s = void 0, this.g = Y - 1, this.f = 4, this.W = e?.watched, this.Z = e?.unwatched, this.name = e?.name;
}
D.prototype = new m();
D.prototype.h = function() {
  if (this.f &= -3, 1 & this.f) return !1;
  if ((36 & this.f) == 32 || (this.f &= -5, this.g === Y)) return !0;
  if (this.g = Y, this.f |= 1, this.i > 0 && !ze(this))
    return this.f &= -2, !0;
  var t = l;
  try {
    Ye(this), l = this;
    var e = this.x();
    (16 & this.f || this.v !== e || this.i === 0) && (this.v = e, this.f &= -17, this.i++);
  } catch (n) {
    this.v = n, this.f |= 16, this.i++;
  }
  return l = t, Ze(this), this.f &= -2, !0;
};
D.prototype.S = function(t) {
  if (this.t === void 0) {
    this.f |= 36;
    for (var e = this.s; e !== void 0; e = e.n) e.S.S(e);
  }
  m.prototype.S.call(this, t);
};
D.prototype.U = function(t) {
  if (this.t !== void 0 && (m.prototype.U.call(this, t), this.t === void 0)) {
    this.f &= -33;
    for (var e = this.s; e !== void 0; e = e.n) e.S.U(e);
  }
};
D.prototype.N = function() {
  if (!(2 & this.f)) {
    this.f |= 6;
    for (var t = this.t; t !== void 0; t = t.x) t.t.N();
  }
};
Object.defineProperty(D.prototype, "value", { get: function() {
  if (1 & this.f) throw new Error("Cycle detected");
  var t = Be(this);
  if (this.h(), t !== void 0 && (t.i = this.i), 16 & this.f) throw this.v;
  return this.v;
} });
function Re(t, e) {
  return new D(t, e);
}
function We(t) {
  var e = t.m;
  if (t.m = void 0, typeof e == "function") {
    R++;
    var n = l;
    l = void 0;
    try {
      e();
    } catch (r) {
      throw t.f &= -2, t.f |= 8, _e(t), r;
    } finally {
      l = n, K();
    }
  }
}
function _e(t) {
  for (var e = t.s; e !== void 0; e = e.n) e.S.U(e);
  t.x = void 0, t.s = void 0, We(t);
}
function on(t) {
  if (l !== this) throw new Error("Out-of-order effect");
  Ze(this), l = t, this.f &= -2, 8 & this.f && _e(this), K();
}
function C(t, e) {
  this.x = t, this.m = void 0, this.s = void 0, this.u = void 0, this.f = 32, this.name = e?.name;
}
C.prototype.c = function() {
  var t = this.S();
  try {
    if (8 & this.f || this.x === void 0) return;
    var e = this.x();
    typeof e == "function" && (this.m = e);
  } finally {
    t();
  }
};
C.prototype.S = function() {
  if (1 & this.f) throw new Error("Cycle detected");
  this.f |= 1, this.f &= -9, We(this), Ye(this), R++;
  var t = l;
  return l = this, on.bind(this, t);
};
C.prototype.N = function() {
  2 & this.f || (this.f |= 2, this.u = H, H = this);
};
C.prototype.d = function() {
  this.f |= 8, 1 & this.f || _e(this);
};
C.prototype.dispose = function() {
  this.d();
};
function q(t, e) {
  var n = new C(t, e);
  try {
    n.c();
  } catch (i) {
    throw n.d(), i;
  }
  var r = n.d.bind(n);
  return r[Symbol.dispose] = r, r;
}
var Je, L, un = typeof window < "u" && !!window.__PREACT_SIGNALS_DEVTOOLS__, Ke = [];
q(function() {
  Je = this.N;
})();
function O(t, e) {
  j[t] = e.bind(null, j[t] || function() {
  });
}
function Z(t) {
  if (L) {
    var e = L;
    L = void 0, e();
  }
  L = t && t.S();
}
function Xe(t) {
  var e = this, n = t.data, r = cn(n);
  r.value = n;
  var i = Me(function() {
    for (var a = e, u = e.__v; u = u.__; ) if (u.__c) {
      u.__c.__$f |= 4;
      break;
    }
    var c = Re(function() {
      var g = r.value.value;
      return g === 0 ? 0 : g === !0 ? "" : g || "";
    }), f = Re(function() {
      return !Array.isArray(c.value) && !Ve(c.value);
    }), _ = q(function() {
      if (this.N = Qe, f.value) {
        var g = c.value;
        a.__v && a.__v.__e && a.__v.__e.nodeType === 3 && (a.__v.__e.data = g);
      }
    }), T = e.__$u.d;
    return e.__$u.d = function() {
      _(), T.call(this);
    }, [f, c];
  }, []), s = i[0], o = i[1];
  return s.value ? o.peek() : o.value;
}
Xe.displayName = "ReactiveTextNode";
Object.defineProperties(m.prototype, { constructor: { configurable: !0, value: void 0 }, type: { configurable: !0, value: Xe }, props: { configurable: !0, get: function() {
  var t = this;
  return { data: { get value() {
    return t.value;
  } } };
} }, __b: { configurable: !0, value: 1 } });
O("__b", function(t, e) {
  if (typeof e.type == "string") {
    var n, r = e.props;
    for (var i in r) if (i !== "children") {
      var s = r[i];
      s instanceof m && (n || (e.__np = n = {}), n[i] = s, r[i] = s.peek());
    }
  }
  t(e);
});
O("__r", function(t, e) {
  if (t(e), e.type !== Kt) {
    Z();
    var n, r = e.__c;
    r && (r.__$f &= -2, (n = r.__$u) === void 0 && (r.__$u = n = (function(i, s) {
      var o;
      return q(function() {
        o = this;
      }, { name: s }), o.c = i, o;
    })(function() {
      var i;
      un && ((i = n.y) == null || i.call(n)), r.__$f |= 1, r.setState({});
    }, typeof e.type == "function" ? e.type.displayName || e.type.name : ""))), Z(n);
  }
});
O("__e", function(t, e, n, r) {
  Z(), t(e, n, r);
});
O("diffed", function(t, e) {
  Z();
  var n;
  if (typeof e.type == "string" && (n = e.__e)) {
    var r = e.__np, i = e.props;
    if (r) {
      var s = n.U;
      if (s) for (var o in s) {
        var a = s[o];
        a !== void 0 && !(o in r) && (a.d(), s[o] = void 0);
      }
      else
        s = {}, n.U = s;
      for (var u in r) {
        var c = s[u], f = r[u];
        c === void 0 ? (c = an(n, u, f), s[u] = c) : c.o(f, i);
      }
      for (var _ in r) i[_] = r[_];
    }
  }
  t(e);
});
function an(t, e, n, r) {
  var i = e in t && t.ownerSVGElement === void 0, s = pe(n), o = n.peek();
  return { o: function(a, u) {
    s.value = a, o = a.peek();
  }, d: q(function() {
    this.N = Qe;
    var a = s.value.value;
    o !== a ? (o = void 0, i ? t[e] = a : a != null && (a !== !1 || e[4] === "-") ? t.setAttribute(e, a) : t.removeAttribute(e)) : o = void 0;
  }) };
}
O("unmount", function(t, e) {
  if (typeof e.type == "string") {
    var n = e.__e;
    if (n) {
      var r = n.U;
      if (r) {
        n.U = void 0;
        for (var i in r) {
          var s = r[i];
          s && s.d();
        }
      }
    }
    e.__np = void 0;
  } else {
    var o = e.__c;
    if (o) {
      var a = o.__$u;
      a && (o.__$u = void 0, a.d());
    }
  }
  t(e);
});
O("__h", function(t, e, n, r) {
  (r < 3 || r === 9) && (e.__$f |= 2), t(e, n, r);
});
function cn(t, e) {
  return Me(function() {
    return pe(t, e);
  }, []);
}
var fn = function(t) {
  queueMicrotask(function() {
    queueMicrotask(t);
  });
};
function ln() {
  rn(function() {
    for (var t; t = Ke.shift(); ) Je.call(t);
  });
}
function Qe() {
  Ke.push(this) === 1 && (j.requestAnimationFrame || fn)(ln);
}
const $e = /* @__PURE__ */ p({
  id: /* @__PURE__ */ J(),
  name: /* @__PURE__ */ h(),
  rpc_url: /* @__PURE__ */ h()
}), hn = /* @__PURE__ */ Ue(
  [$e],
  $e
), ve = b(hn, [
  {
    id: me.chainId,
    name: me.name,
    rpc_url: "https://ethereum-sepolia-rpc.publicnode.com"
  },
  {
    id: ye.chainId,
    name: ye.name,
    rpc_url: "https://ethereum-rpc.publicnode.com"
  }
]);
pe(ve[0]);
const pn = "eip155";
function _n(t) {
  return Pt({
    namespace: pn,
    reference: t.id
  });
}
function vn(t) {
  const e = _n(t);
  return {
    chain_id: e,
    reader: Vt([
      {
        chainId: e,
        transports: [Ut(t.rpc_url)]
      }
    ])
  };
}
function jn(t) {
  return `0x${t.id.toString(16)}`;
}
function dn(t) {
  return ve.find((e) => e.id === t);
}
const yn = "2.0.0", mn = b(
  E,
  le.SUCCESS
), bn = b(
  E,
  le.REVERTED
);
function En(t) {
  return Number.parseInt(t.slice(2), 16);
}
function qn() {
  const t = {};
  for (const e of ve) {
    const n = b(E, qt(e.id));
    t[n] = {
      atomic: { status: "unsupported" }
    };
  }
  return t;
}
async function Fn(t) {
  const e = await Jt(t);
  if (!e)
    throw new Error(`unknown batch id: ${t}`);
  const n = dn(En(e.chainId));
  if (!n)
    throw new Error(
      `unknown chain for batch: ${e.chainId}`
    );
  const { chain_id: r, reader: i } = vn(n), s = await Promise.all(
    e.transaction_hashes.map(
      async (o) => {
        const a = await zt([
          o
        ])(i({ chain_id: r }));
        return { transaction_hash: o, receipt: a };
      }
    )
  );
  return Sn(e, s);
}
function Sn(t, e) {
  const n = e.filter((o) => o.receipt !== null), r = n.length === e.length, i = gn(e), s = n.map((o) => An(o.receipt)).filter((o) => o !== null);
  return {
    version: yn,
    id: t.id,
    chainId: t.chainId,
    status: i,
    atomic: t.atomic,
    receipts: r ? s : void 0
  };
}
function gn(t) {
  let e = 0, n = 0, r = 0;
  for (const { receipt: i } of t)
    i !== null && (e += 1, i.status === mn ? n += 1 : r += 1);
  return e < t.length ? F.PENDING : r === 0 ? F.CONFIRMED : n === 0 ? F.REVERTED : F.PARTIALLY_REVERTED;
}
function An(t) {
  return t === null ? null : {
    logs: t.logs.map((e) => ({
      address: e.address,
      topics: e.topics,
      data: e.data
    })),
    status: t.status ?? bn,
    blockHash: t.blockHash,
    blockNumber: t.blockNumber,
    gasUsed: t.gasUsed,
    transactionHash: t.transactionHash
  };
}
const kn = /* @__PURE__ */ p({
  id: /* @__PURE__ */ h(),
  type: /* @__PURE__ */ S("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
  method: /* @__PURE__ */ h(),
  chainId: /* @__PURE__ */ h(),
  to: /* @__PURE__ */ N(/* @__PURE__ */ h()),
  params: /* @__PURE__ */ N(
    /* @__PURE__ */ w([/* @__PURE__ */ U(/* @__PURE__ */ P()), /* @__PURE__ */ ce(/* @__PURE__ */ h(), /* @__PURE__ */ P())])
  )
}), wn = /* @__PURE__ */ p({
  id: /* @__PURE__ */ h(),
  type: /* @__PURE__ */ S("ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION"),
  signed_transaction: /* @__PURE__ */ h()
}), Tn = /* @__PURE__ */ p({
  id: /* @__PURE__ */ h(),
  type: /* @__PURE__ */ S("ETHERNAUTA_RESPONSE_SIGNED_TYPED_DATA"),
  signature: /* @__PURE__ */ h()
}), Nn = /* @__PURE__ */ p({
  id: /* @__PURE__ */ h(),
  type: /* @__PURE__ */ S("ETHERNAUTA_RESPONSE_PERSONAL_SIGNED"),
  signature: /* @__PURE__ */ h()
}), Rn = /* @__PURE__ */ p({
  id: /* @__PURE__ */ h(),
  type: /* @__PURE__ */ S("ETHERNAUTA_RESPONSE_ADD_CHAIN_APPROVED")
}), $n = kn, xn = /* @__PURE__ */ p({
  id: /* @__PURE__ */ h(),
  type: /* @__PURE__ */ S("ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED")
}), In = /* @__PURE__ */ p({
  id: /* @__PURE__ */ h(),
  type: /* @__PURE__ */ S(
    "ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE"
  )
}), Pn = /* @__PURE__ */ w([
  wn,
  Tn,
  Nn,
  Rn,
  xn,
  In
]), Un = /* @__PURE__ */ p({
  type: /* @__PURE__ */ S("ETHERNAUTA_NOTIFICATION_POPUP_READY")
}), Dn = /* @__PURE__ */ p({
  type: /* @__PURE__ */ S("ETHERNAUTA_NOTIFICATION_CHAIN_SELECTED"),
  chainId: /* @__PURE__ */ h()
}), Cn = /* @__PURE__ */ p({
  type: /* @__PURE__ */ S("ETHERNAUTA_NOTIFICATION_ACCOUNTS_CHANGED"),
  accounts: /* @__PURE__ */ U(/* @__PURE__ */ h())
}), On = /* @__PURE__ */ w([
  Un,
  Dn,
  Cn
]), Ln = /* @__PURE__ */ w([
  $n,
  Pn,
  On
]);
export {
  ve as C,
  On as E,
  kn as S,
  U as a,
  V as b,
  N as c,
  at as d,
  Hn as e,
  jn as f,
  Fn as g,
  qn as h,
  Ut as i,
  b as j,
  wt as k,
  Pn as l,
  Ln as m,
  J as n,
  p as o,
  x as p,
  $n as q,
  h as s,
  M as t,
  E as u
};
