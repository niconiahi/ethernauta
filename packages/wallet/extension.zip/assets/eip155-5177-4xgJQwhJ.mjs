const n = {
  name: "TLChain Network Mainnet",
  shortName: "tlc",
  chain: "TLC",
  icon: "tlc",
  rpc: ["https://mainnet-rpc.tlxscan.com/"],
  faucets: [],
  nativeCurrency: {
    name: "TLChain Network",
    symbol: "TLC",
    decimals: 18
  },
  infoURL: "https://tlchain.network/",
  chainId: 5177,
  networkId: 5177,
  explorers: [
    {
      name: "TLChain Explorer",
      url: "https://explorer.tlchain.network",
      standard: "none"
    }
  ]
};
export {
  n as eip155_5177
};
