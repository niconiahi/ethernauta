const a = {
  name: "Dodao",
  shortName: "dodao",
  chain: "EVMCC",
  icon: "dodao",
  rpc: [
    "https://fraa-flashbox-4643-rpc.a.stagenet.tanssi.network",
    "wss://fraa-flashbox-4643-rpc.a.stagenet.tanssi.network"
  ],
  faucets: [],
  nativeCurrency: {
    name: "Dodao",
    symbol: "DODAO",
    decimals: 18
  },
  infoURL: "https://dodao.dev/",
  chainId: 855456,
  networkId: 855456,
  explorers: [
    {
      name: "Dodao EVM Explorer",
      url: "https://evmexplorer.tanssi-chains.network/?rpcUrl=https://fraa-flashbox-4643-rpc.a.stagenet.tanssi.network",
      standard: "none"
    },
    {
      name: "Dodao Polkadot Explorer",
      url: "https://polkadot.js.org/apps/?rpc=wss://fraa-flashbox-4643-rpc.a.stagenet.tanssi.network#/explorer",
      standard: "none"
    }
  ]
};
export {
  a as eip155_855456
};
