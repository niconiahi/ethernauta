const a = {
  name: "Flag Mainnet",
  shortName: "FLAG",
  chain: "Flag",
  icon: "flag",
  rpc: ["https://mainnet-rpc.flagscan.xyz"],
  faucets: [],
  nativeCurrency: {
    name: "Flag",
    symbol: "FLAG",
    decimals: 18
  },
  infoURL: "https://flagscan.xyz",
  chainId: 147,
  networkId: 147,
  explorers: [
    {
      name: "Flag Mainnet Explorer",
      url: "https://flagscan.xyz",
      standard: "EIP3091"
    }
  ]
};
export {
  a as eip155_147
};
