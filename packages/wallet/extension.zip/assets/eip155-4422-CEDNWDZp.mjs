const e = {
  name: "Testnet Pika",
  shortName: "PikaMinter",
  chain: "tPKA",
  icon: "testnetpsc",
  rpc: ["https://testnet-rpc1.pikascan.com"],
  faucets: [],
  features: [
    {
      name: "EIP155"
    },
    {
      name: "EIP1559"
    }
  ],
  nativeCurrency: {
    name: "Testnet Pika",
    symbol: "tPKA",
    decimals: 18
  },
  infoURL: "https://pikaminter.com",
  chainId: 4422,
  networkId: 4422,
  explorers: []
};
export {
  e as eip155_4422
};
