const n = {
  name: "Plinga Mainnet",
  shortName: "plgchain",
  chain: "Plinga",
  icon: "plinga",
  rpc: [
    "https://rpcurl.mainnet.plgchain.com",
    "https://rpcurl.plgchain.blockchain.evmnode.online",
    "https://rpcurl.mainnet.plgchain.plinga.technology"
  ],
  faucets: [],
  nativeCurrency: {
    name: "Plinga",
    symbol: "PLINGA",
    decimals: 18
  },
  infoURL: "https://www.plinga.technology/",
  chainId: 242,
  networkId: 242,
  explorers: [
    {
      name: "plgscan",
      url: "https://www.plgscan.com",
      standard: "EIP3091"
    }
  ]
};
export {
  n as eip155_242
};
