import {
  d as R,
  a as $,
  u as o,
  y as X,
  k as ve,
  E as Ee,
} from "./preact-10.26.9-DO5-VWXm.mjs"
import {
  p as u,
  o as h,
  a as P,
  n as ee,
  u as p,
  s as d,
  l,
  b as te,
  r as ne,
  c as b,
  v as Se,
  m as Ae,
  H,
  g as xe,
  k as re,
  w as Ne,
  d as C,
  e as ae,
  f as Te,
  h as ke,
  t as x,
  i as E,
  j as Ie,
  q as Ue,
  x as Re,
  y as G,
  z as Pe,
} from "./vendor-6cAV8jNg.mjs"
;(function () {
  const t = document.createElement("link").relList
  if (t && t.supports && t.supports("modulepreload")) return
  for (const a of document.querySelectorAll(
    'link[rel="modulepreload"]',
  ))
    r(a)
  new MutationObserver((a) => {
    for (const s of a)
      if (s.type === "childList")
        for (const c of s.addedNodes)
          c.tagName === "LINK" &&
            c.rel === "modulepreload" &&
            r(c)
  }).observe(document, { childList: !0, subtree: !0 })
  function n(a) {
    const s = {}
    return (
      a.integrity && (s.integrity = a.integrity),
      a.referrerPolicy &&
        (s.referrerPolicy = a.referrerPolicy),
      a.crossOrigin === "use-credentials"
        ? (s.credentials = "include")
        : a.crossOrigin === "anonymous"
          ? (s.credentials = "omit")
          : (s.credentials = "same-origin"),
      s
    )
  }
  function r(a) {
    if (a.ep) return
    a.ep = !0
    const s = n(a)
    fetch(a.href, s)
  }
})()
const W = { iterations: 1e5, hash: "SHA-256" },
  f = {
    name: "ethernauta/signer",
    version: 1,
    store_name: "vault",
    vault_key: "credentials",
  }
function O(e) {
  return btoa(String.fromCharCode(...new Uint8Array(e)))
}
function M(e) {
  return Uint8Array.from(atob(e), (t) => t.charCodeAt(0))
}
async function se(e, t, n) {
  const r = new TextEncoder().encode(e),
    a = await crypto.subtle.importKey(
      "raw",
      r,
      "PBKDF2",
      !1,
      ["deriveKey"],
    )
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: t,
      iterations: W.iterations,
      hash: W.hash,
    },
    a,
    { name: "AES-GCM", length: 256 },
    !1,
    n,
  )
}
function j() {
  return new Promise((e, t) => {
    const n = indexedDB.open(f.name, f.version)
    ;(n.onupgradeneeded = (r) => {
      const a = r.target.result
      a.objectStoreNames.contains(f.store_name) ||
        a.createObjectStore(f.store_name)
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () =>
        t(
          new Error(
            `Failed to open database: ${n.error?.message}`,
          ),
        ))
  })
}
async function Ce(e, t) {
  if (!e.trim()) throw new Error("Mnemonic cannot be empty")
  if (!t.trim()) throw new Error("Password cannot be empty")
  const n = crypto.getRandomValues(new Uint8Array(16)),
    r = crypto.getRandomValues(new Uint8Array(12)),
    a = await se(t, n, ["encrypt"]),
    s = new TextEncoder().encode(e),
    c = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: r },
      a,
      s,
    ),
    i = {
      salt: O(n.buffer),
      iv: O(r.buffer),
      cipher: O(c),
    },
    m = await j()
  return new Promise((k, D) => {
    const A = m
      .transaction(f.store_name, "readwrite")
      .objectStore(f.store_name)
      .put(i, f.vault_key)
    ;(A.onsuccess = () => k()),
      (A.onerror = () =>
        D(
          new Error(
            `Failed to save vault: ${A.error?.message}`,
          ),
        ))
  })
}
async function oe(e) {
  if (!e.trim()) throw new Error("Password cannot be empty")
  const t = await j(),
    n = await new Promise((m, k) => {
      const S = t
        .transaction(f.store_name, "readonly")
        .objectStore(f.store_name)
        .get(f.vault_key)
      ;(S.onsuccess = () => {
        const A = S.result
        m(A)
      }),
        (S.onerror = () =>
          k(
            new Error(
              `Failed to load vault: ${S.error?.message}`,
            ),
          ))
    })
  if (!n) return
  const r = M(n.salt),
    a = M(n.iv),
    s = M(n.cipher),
    c = await se(e, r, ["decrypt"]),
    i = await crypto.subtle
      .decrypt({ name: "AES-GCM", iv: a }, c, s)
      .catch((m) => {
        throw m instanceof Error
          ? new Error("Invalid password or corrupted vault")
          : new Error("invalid unkwown error")
      })
  return new TextDecoder().decode(i)
}
async function Oe() {
  const e = await j()
  return new Promise((t) => {
    const a = e
      .transaction(f.store_name, "readonly")
      .objectStore(f.store_name)
      .get(f.vault_key)
    ;(a.onsuccess = () => t(!!a.result)),
      (a.onerror = () => t(!1))
  })
}
async function Me(e) {
  try {
    return (await oe(e)) !== void 0
  } catch {
    return !1
  }
}
const $e = "password",
  g = R($e)
async function ce() {
  const e = Date.now()
  await chrome.storage.sync.set({ timestamp: e })
}
async function Fe() {
  return u(
    h({ timestamp: P(ee()) }),
    await chrome.storage.sync.get("timestamp"),
  ).timestamp
}
async function z() {
  const e = Date.now(),
    t = await Fe()
  if (!t) return !1
  const n = e - t,
    r = 300 * 1e3
  return n < r
}
async function Q() {
  ;(await Oe())
    ? (g.value = "password")
    : (g.value = "mnemonics")
}
const He = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: d(),
    params: p([te(b()), ne(d(), b())]),
  }),
  je = h({
    id: d(),
    type: l("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  qe = p([He, je]),
  w = R({
    id: "some-id",
    method: "hello_world",
    params: [],
  })
function N(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
function ie(e) {
  let t = ""
  for (let n = 0; n < e.length; n++)
    (t += V[e[n] >> 4]), (t += V[e[n] & 15])
  return `0x${t}`
}
function Be(e) {
  return e.startsWith("0x") ? e.substring(2) : e
}
function v(e) {
  const t = Be(e)
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string")
  const n = new Uint8Array(t.length / 2)
  for (let r = 0; r < t.length; r += 2) {
    if (!(t[r] in I)) throw new Error("Invalid character")
    if (!(t[r + 1] in I))
      throw new Error("Invalid character")
    ;(n[r / 2] |= I[t[r]] << 4), (n[r / 2] |= I[t[r + 1]])
  }
  return n
}
const V = "0123456789abcdef",
  I = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15,
  }
function Ke(e) {
  if (!Se(e, Ne)) throw new Error("Invalid mnemonic")
  return Ae(e)
}
function Le(e) {
  return H.fromMasterSeed(e)
}
function De(e, t = "m/44'/60'/0'/0/0") {
  const n = e.derive(t)
  if (!n.privateKey)
    throw new Error("No private key available")
  return n.privateKey
}
function Ge(e) {
  const t = xe(e, !1),
    n = re(t.slice(1))
  return ie(n.slice(-20))
}
function We(e) {
  const t = e.privateKey
  return N(t, "a private key should exist"), t
}
function q(e) {
  return BigInt(e)
}
const ze = h({ address: d(), private_key: d() }),
  T = R({
    address: "",
    key: new H({ privateKey: new Uint8Array(32).fill(1) }),
  })
async function Qe(e) {
  const t = {
    address: e.address,
    private_key: e.key.toJSON().xpriv,
  }
  await chrome.storage.sync.set({ wallet: t })
}
async function J() {
  const t = u(
    h({ wallet: P(ze) }),
    await chrome.storage.sync.get("wallet"),
  ).wallet
  t &&
    (T.value = {
      address: t.address,
      key: H.fromExtendedKey(t.private_key),
    })
}
async function Ve(e) {
  const t = await oe(e)
  N(t, "vault should exist to sign in")
  const n = Ke(t),
    r = Le(n),
    a = De(r),
    s = Ge(a),
    c = r.derive("m/44'/60'/0'/0/0"),
    i = { address: s, key: c }
  ;(T.value = i), Qe(i)
}
const Je = C(d(), ae(8)),
  Ze = C(d(), ae(1))
function Ye() {
  const [e, t] = $(""),
    [n, r] = $(
      "smile price bomb movie minimum treat hurdle adult wing come space cross",
    )
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        placeholder: "Mnemonics",
        value: n,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          r(s)
        },
      }),
      o("input", {
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (a) => {
          const s = a.currentTarget.value
          t(s)
        },
      }),
      o("button", {
        type: "button",
        className:
          "bg-[#FF5005] border-2 rounded-md p-2 cursor-pointer text-base",
        onClick: async () => {
          const a = u(Ze, n),
            s = u(Je, e)
          Ce(a, s), await ce(), (g.value = "password")
        },
        children: "Save wallet",
      }),
    ],
  })
}
function Xe() {
  const [e, t] = $("")
  return o("main", {
    className: "flex flex-col gap-2 p-2",
    children: [
      o("input", {
        placeholder: "Password",
        value: e,
        className:
          "p-2 border-2 rounded-md cursor-pointer text-base",
        onInput: (n) => {
          const r = n.currentTarget.value
          t(r)
        },
      }),
      o("button", {
        type: "button",
        className:
          "bg-[#FF5005] border-2 rounded-md p-2 cursor-pointer text-base",
        onClick: async () => {
          ;(await Me(e)) &&
            (await ce(), await Ve(e), (g.value = "wallet"))
        },
        children: "Unlock",
      }),
    ],
  })
}
const B = { chainId: 11155111 },
  F = C(
    d(),
    ke(
      "rpc.",
      'method names that begin with "rpc." are reserved for system extensions',
    ),
  ),
  le = p([te(b()), ne(d(), b())]),
  K = p([d(), ee(), Te()]),
  et = h({
    jsonrpc: l("2.0"),
    method: F,
    params: P(le),
    id: K,
  }),
  tt = h({
    data: P(b()),
    message: d(),
    code: p([
      l(-32e3),
      l(-32300),
      l(-32400),
      l(-32500),
      l(-32600),
      l(-32601),
      l(-32602),
      l(-32603),
      l(-32700),
      l(-32701),
      l(-32702),
    ]),
  }),
  nt = h({ id: K, jsonrpc: l("2.0"), error: tt }),
  rt = h({ id: K, jsonrpc: l("2.0"), result: b() }),
  at = p([nt, rt]),
  ue = p([x([F, le]), x([F])])
function st(e) {
  return typeof e == "string" && /^[-a-z0-9]{3,8}$/.test(e)
}
const ot = E(st)
function ct(e) {
  return (
    typeof e == "string" && /^[-a-zA-Z0-9]{1,32}$/.test(e)
  )
}
const it = E(ct)
function lt(e) {
  return (
    typeof e == "string" && /^[-:a-zA-Z0-9]{5,41}$/.test(e)
  )
}
const de = E(lt),
  ut = ":"
function fe({ namespace: e, reference: t }) {
  const n = u(ot, e),
    r = u(it, String(t)),
    a = n + ut + r
  return u(de, a)
}
function me(e) {
  return async (t) => {
    const [n, r] = t,
      a = u(et, {
        jsonrpc: "2.0",
        id: crypto.randomUUID(),
        method: n,
        params: dt(r),
      }),
      s = await fetch(e, {
        method: "POST",
        body: JSON.stringify(a),
        headers: { "Content-Type": "application/json" },
      })
        .then((i) => i.json())
        .catch((i) => {
          throw new Error(i)
        })
    return u(at, s)
  }
}
function dt(e) {
  if (e) return Array.isArray(e) ? e : Object.values(e)
}
function he(e) {
  return (t) => {
    const n = u(de, t),
      r = e.find(({ chainId: a }) => a === n)
    if (!r)
      throw new Error(
        "you need at least one transport for the targeted chain",
      )
    return r.transports
  }
}
function ft(e) {
  return (
    typeof e == "string" && /^0x[0-9,a-f,A-F]{40}$/.test(e)
  )
}
const y = E(ft)
function mt(e) {
  return typeof e == "string" && /^0x[0-9a-f]{64}$/.test(e)
}
const ht = E(mt)
function pt(e) {
  return (
    typeof e == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(e)
  )
}
const L = E(pt),
  _t = p([
    l("earliest"),
    l("finalized"),
    l("safe"),
    l("latest"),
    l("pending"),
  ]),
  U = p([L, _t, ht]),
  yt = p([
    x([y, U]),
    x([y]),
    h({ address: y, blockNumberOrTagOrHash: U }),
    h({ address: y }),
  ])
function gt(e) {
  return async (t) => {
    const n = "eth_getBalance",
      r = u(yt, e),
      a = u(ue, [n, r]),
      s = await Promise.any(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return u(L, s.result)
  }
}
const wt = p([
  x([y, U]),
  h({ address: y, blockNumberOrTagOrHash: U }),
])
function bt(e) {
  return async (t) => {
    const n = "eth_getTransactionCount",
      r = u(wt, e),
      a = u(ue, [n, r]),
      s = await Promise.race(t.map((i) => i(a)))
    if ("error" in s) throw new Error(s.error.message)
    return u(L, s.result)
  }
}
function pe(e) {
  return Array.isArray(e) ? Et(e) : vt(e)
}
function vt(e) {
  const t = St(e),
    n = t[0]
  if (t.length === 1 && n !== void 0 && n < 128) return t
  if (t.length <= 55) {
    const s = new Uint8Array(1 + t.length)
    return (s[0] = 128 + t.length), s.set(t, 1), s
  }
  const r = _e(t.length),
    a = new Uint8Array(1 + r.length + t.length)
  return (
    (a[0] = 183 + r.length),
    a.set(r, 1),
    a.set(t, 1 + r.length),
    a
  )
}
function Et(e) {
  const t = e.map((c) => pe(c)),
    n = t.reduce((c, i) => c + i.length, 0)
  if (n <= 55) {
    const c = new Uint8Array(1 + n)
    c[0] = 192 + n
    let i = 1
    for (const m of t) c.set(m, i), (i += m.length)
    return c
  }
  const r = _e(n),
    a = new Uint8Array(1 + r.length + n)
  ;(a[0] = 247 + r.length), a.set(r, 1)
  let s = 1 + r.length
  for (const c of t) a.set(c, s), (s += c.length)
  return a
}
function St(e) {
  if (e instanceof Uint8Array) return e
  if (typeof e == "string")
    return e.startsWith("0x")
      ? v(e)
      : new TextEncoder().encode(e)
  if (typeof e == "number" || typeof e == "bigint")
    return At(BigInt(e))
  throw new Error(`cannot convert ${typeof e} to bytes`)
}
function At(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return v(n)
}
function _e(e) {
  if (e === 0) return new Uint8Array([])
  const t = []
  let n = e
  for (; n > 0; ) t.unshift(n & 255), (n >>= 8)
  return new Uint8Array(t)
}
function _(e) {
  if (e === 0n) return new Uint8Array([])
  const t = e.toString(16),
    n = t.padStart(t.length + (t.length % 2), "0")
  return v(n)
}
function xt(e, t) {
  return (
    (G.hmacSha256Sync = (n, ...r) =>
      Re(Pe, n, G.concatBytes(...r))),
    Ue(e, t)
  )
}
function Nt(e) {
  return BigInt(e)
}
async function Tt(e, t, n) {
  const a = await bt([e, "latest"])(t(n))
  return q(a)
}
function kt() {
  return BigInt(B.chainId)
}
function It() {
  return 21000n
}
function Ut() {
  return 20000000000n
}
function Rt() {
  return 2000000000n
}
function Pt(e, t) {
  switch (e) {
    case "transfer": {
      const n = u(y, t[0]),
        r = u(C(d(), Ie()), t[1])
      return {
        to: n,
        value: q(r),
        data: new Uint8Array([]),
      }
    }
  }
  throw new Error(
    `there is no support for the sent ${e} method`,
  )
}
async function Ct({
  key: e,
  nonce: t,
  method: n,
  params: r,
}) {
  const { to: a, value: s, data: c } = Pt(n, r),
    i = {
      to: a,
      data: c,
      value: s,
      nonce: t,
      chain_id: kt(),
      gas_limit: It(),
      max_fee_per_gas: Ut(),
      max_priority_fee_per_gas: Rt(),
    },
    m = We(e)
  return Mt(i, m)
}
function Ot(e, t) {
  const n = ye(e, t)
  return re(n)
}
function Mt(e, t) {
  const n = Ht(e),
    r = Z(n),
    a = new Uint8Array([2]),
    s = Ot(a, r),
    c = xt(s, t),
    i = Ft(n, c),
    m = Z(i)
  return ye(a, m)
}
function ye(...e) {
  let t = 0
  for (const a of e) t += a.length
  const n = new Uint8Array(t)
  let r = 0
  for (const a of e) n.set(a, r), (r += a.length)
  return n
}
function $t(e) {
  const t = new Array(e.length)
  for (let n = 0; n < e.length; n++) {
    const r = e[n]
    N(r, "access list item should exist")
    const a = new Array(r.storage_keys.length)
    for (let s = 0; s < r.storage_keys.length; s++) {
      const c = r.storage_keys[s]
      N(c, "storage key should exist"), (a[s] = v(c))
    }
    t[n] = [v(r.address), a]
  }
  return t
}
function Ft(e, t) {
  const n = new Array(12)
  N(
    e[0] &&
      e[1] &&
      e[2] &&
      e[3] &&
      e[4] &&
      e[5] &&
      e[6] &&
      e[7] &&
      e[8],
    "all the required encoded fields must exist",
  ),
    (n[0] = e[0]),
    (n[1] = e[1]),
    (n[2] = e[2]),
    (n[3] = e[3]),
    (n[4] = e[4]),
    (n[5] = e[5]),
    (n[6] = e[6]),
    (n[7] = e[7]),
    (n[8] = e[8])
  const r = Nt(t.recovery)
  return (
    (n[9] = _(r)), (n[10] = _(t.r)), (n[11] = _(t.s)), n
  )
}
function Ht(e) {
  const t = new Array(9)
  return (
    (t[0] = _(e.chain_id)),
    (t[1] = _(e.nonce)),
    (t[2] = _(e.max_priority_fee_per_gas)),
    (t[3] = _(e.max_fee_per_gas)),
    (t[4] = _(e.gas_limit)),
    (t[5] = v(e.to)),
    (t[6] = _(e.value)),
    (t[7] = e.data),
    (t[8] = $t([])),
    t
  )
}
function Z(e) {
  return pe(e)
}
const jt = { ETHEREUM: "eip155" },
  qt = "https://ethereum-sepolia-rpc.publicnode.com",
  ge = fe({ namespace: jt.ETHEREUM, reference: B.chainId }),
  Bt = he([{ chainId: ge, transports: [me(qt)] }])
function Kt() {
  return o("main", {
    className: "flex flex-col gap-2 p-2 text-base",
    children: [
      o("h1", {
        className: "text-center",
        children: "You are about to sign",
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Method" }),
          o("p", {
            className: "font-bold",
            children: w.value.method,
          }),
        ],
      }),
      o("fieldset", {
        children: [
          o("legend", { children: "Params" }),
          o("ul", {
            children: w.value.params.map((e, t) => {
              const n = u(d(), e),
                r = `param-${n}`
              return o(
                "li",
                {
                  className: "flex gap-2",
                  children: [
                    o("span", {
                      className: "w-2 text-center",
                      children: t,
                    }),
                    o("span", {
                      className: "font-bold",
                      children: n,
                    }),
                  ],
                },
                r,
              )
            }),
          }),
        ],
      }),
      o("button", {
        type: "button",
        className:
          "bg-[#FF5005] border-2 rounded-md p-2 cursor-pointer text-base",
        onClick: async () => {
          const e = T.value.address,
            t = T.value.key,
            n = await Tt(e, Bt, ge),
            r = await Ct({
              key: t,
              nonce: n,
              method: w.value.method,
              params: w.value.params,
            }),
            a = {
              id: w.value.id,
              type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
              signed_transaction: ie(r),
            }
          chrome.runtime.sendMessage(a)
        },
        children: "Sign",
      }),
    ],
  })
}
const Lt = { ETHEREUM: "eip155" },
  Dt = "https://ethereum-sepolia-rpc.publicnode.com",
  we = fe({ namespace: Lt.ETHEREUM, reference: B.chainId }),
  Gt = he([{ chainId: we, transports: [me(Dt)] }]),
  Y = R(0n)
async function Wt(e) {
  const t = gt([e, "latest"])
  console.log("readable", t)
  const n = await t(Gt(we))
  return q(n)
}
function zt(e) {
  const t = 10n ** 18n,
    n = e / t,
    r = e % t,
    a = n.toString()
  if (r === 0n) return a
  const s = r
    .toString()
    .padStart(18, "0")
    .replace(/0+$/, "")
  return `${a}.${s}`
}
function Qt() {
  const e = T.value.address
  return (
    X(() => {
      async function t() {
        const n = await Wt(e)
        Y.value = n
      }
      t()
    }, []),
    o("main", {
      className: "flex flex-col gap-2 p-2",
      children: [
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Address:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: e,
            }),
          ],
        }),
        o("p", {
          className: "flex gap-1 text-base",
          children: [
            o("span", { children: "Balance:" }),
            o("span", {
              className:
                "underline underline-offset-2 decoration-[#FF5005]",
              children: Vt(zt(Y.value), 5),
            }),
            " ",
            "ETH",
          ],
        }),
      ],
    })
  )
}
function Vt(e, t) {
  const n = e.indexOf(".")
  return e.slice(0, n + t + 1)
}
function Jt() {
  return (
    X(() => {
      chrome.runtime.onMessage.addListener(async (e) => {
        const t = u(qe, e)
        switch (t.type) {
          case "ETHERNAUTA_REQUEST_CONNECT": {
            const n = await z()
            if ((await Q(), n)) {
              await J(), (g.value = "wallet")
              return
            }
            break
          }
          case "ETHERNAUTA_REQUEST_SIGN_TRANSACTION":
            {
              const n = await z()
              if ((await Q(), n)) {
                await J(),
                  (w.value = {
                    id: t.id,
                    method: t.method,
                    params: t.params,
                  }),
                  (g.value = "sign")
                return
              }
            }
            break
        }
      })
    }, []),
    o(ve, { children: Zt(g.value) })
  )
}
function Zt(e) {
  switch (e) {
    case "mnemonics":
      return o(Ye, {})
    case "password":
      return o(Xe, {})
    case "wallet":
      return o(Qt, {})
    case "sign":
      return o(Kt, {})
    default:
      return o("div", {
        children: ["there is no view for: ", e],
      })
  }
}
Ee(o(Jt, {}), document.querySelector("#app"))
