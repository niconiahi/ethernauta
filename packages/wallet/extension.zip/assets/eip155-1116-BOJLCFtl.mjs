const e = {
  name: "Core Blockchain Mainnet",
  shortName: "core",
  chain: "Core",
  icon: "core",
  rpc: [
    "https://rpc.coredao.org/",
    "https://rpc-core.icecreamswap.com",
    "https://core.drpc.org",
    "wss://core.drpc.org"
  ],
  faucets: [],
  features: [
    {
      name: "EIP155"
    },
    {
      name: "EIP1559"
    }
  ],
  nativeCurrency: {
    name: "Core Blockchain Native Token",
    symbol: "CORE",
    decimals: 18
  },
  infoURL: "https://www.coredao.org",
  chainId: 1116,
  networkId: 1116,
  explorers: [
    {
      name: "Core Scan",
      url: "https://scan.coredao.org",
      standard: "EIP3091"
    }
  ]
};
export {
  e as eip155_1116
};
