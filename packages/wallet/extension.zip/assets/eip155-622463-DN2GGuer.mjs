const t = {
  name: "Atlas",
  shortName: "atlas-testnet",
  title: "Atlas Testnet",
  chain: "ATLAS",
  icon: "atlas",
  rpc: ["https://rpc.testnet.atl.network"],
  faucets: [],
  nativeCurrency: {
    name: "TON",
    symbol: "TON",
    decimals: 18
  },
  infoURL: "https://atl.network",
  chainId: 622463,
  networkId: 622463,
  explorers: [
    {
      name: "Atlas Testnet Scan",
      url: "https://explorer.testnet.atl.network",
      standard: "EIP3091"
    }
  ]
};
export {
  t as eip155_622463
};
