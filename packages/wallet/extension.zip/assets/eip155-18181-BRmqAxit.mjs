const e = {
  name: "G8Chain Testnet",
  shortName: "G8Ct",
  chain: "G8C",
  icon: "G8Chain",
  rpc: ["https://testnet-rpc.oneg8.network"],
  faucets: ["https://faucet.oneg8.network"],
  nativeCurrency: {
    name: "G8Coin",
    symbol: "G8C",
    decimals: 18
  },
  infoURL: "https://oneg8.one",
  chainId: 18181,
  networkId: 18181,
  slip44: 1,
  explorers: [
    {
      name: "G8Chain",
      url: "https://testnet.oneg8.network",
      standard: "EIP3091"
    }
  ]
};
export {
  e as eip155_18181
};
