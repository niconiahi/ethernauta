import {
  e as T,
  o,
  a as _,
  s as e,
  l as a,
  b as p,
  f as A,
  r as u,
  g as N,
} from "./assets/index-DutXGR0P.mjs"
function d(n, c) {
  if (!n) throw new Error(`message: ${c}`)
}
const g = o({
    id: e(),
    type: a("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: e(),
    chainId: e(),
    to: _(e()),
    params: _(T([p(A()), u(e(), A())])),
  }),
  I = o({
    id: e(),
    type: a("ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION"),
    signed_transaction: e(),
  }),
  O = o({
    id: e(),
    type: a("ETHERNAUTA_RESPONSE_SIGNED_TYPED_DATA"),
    signature: e(),
  }),
  y = o({
    id: e(),
    type: a("ETHERNAUTA_RESPONSE_PERSONAL_SIGNED"),
    signature: e(),
  }),
  f = o({
    id: e(),
    type: a("ETHERNAUTA_RESPONSE_ADD_CHAIN_APPROVED"),
  }),
  h = g,
  P = o({
    id: e(),
    type: a("ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED"),
  }),
  C = o({
    id: e(),
    type: a("ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE"),
  }),
  m = T([I, O, y, f, P, C]),
  U = o({
    type: a("ETHERNAUTA_NOTIFICATION_POPUP_READY"),
  }),
  H = o({
    type: a("ETHERNAUTA_NOTIFICATION_CHAIN_SELECTED"),
    chainId: e(),
  }),
  b = T([U, H]),
  D = T([h, m, b])
function S(n) {
  return `pending_${n}`
}
chrome.runtime.onConnect.addListener((n) => {
  n.onDisconnect.addListener(async () => {
    const c = await chrome.storage.session.get(null)
    for (const [i, s] of Object.entries(c)) {
      if (!i.startsWith("pending_")) continue
      const { tab_id: t, request: E } = s,
        r = {
          id: E.id,
          type: "ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE",
        }
      chrome.tabs.sendMessage(t, r),
        await chrome.storage.session.remove(i)
    }
  })
})
chrome.runtime.onMessage.addListener(async (n, c) => {
  const i = N(D, n)
  if (i.type.startsWith("ETHERNAUTA_REQUEST")) {
    const s = N(h, n),
      t = c.tab?.id
    d(t, "request must come from a tab")
    const E = S(s.id)
    return (
      await chrome.storage.session.set({
        [E]: {
          tab_id: t,
          request: s,
        },
      }),
      chrome.action
        .openPopup()
        .then(() => {
          chrome.runtime.onMessage.addListener(
            function r(R) {
              R.type ===
                "ETHERNAUTA_NOTIFICATION_POPUP_READY" &&
                (chrome.runtime.onMessage.removeListener(r),
                chrome.runtime.sendMessage(s))
            },
          )
        })
        .catch(async () => {
          await chrome.storage.session.remove(E)
        }),
      !0
    )
  }
  if (i.type.startsWith("ETHERNAUTA_RESPONSE")) {
    const s = N(m, n),
      t = S(s.id),
      r = (await chrome.storage.session.get(t))[t]
    d(
      r,
      "there should be a pending request for this response",
    ),
      chrome.tabs.sendMessage(r.tab_id, s),
      await chrome.storage.session.remove(`pending_${s.id}`)
  }
  if (i.type === "ETHERNAUTA_NOTIFICATION_CHAIN_SELECTED") {
    const s = await chrome.tabs.query({})
    for (const t of s)
      t.id && chrome.tabs.sendMessage(t.id, i)
  }
})
