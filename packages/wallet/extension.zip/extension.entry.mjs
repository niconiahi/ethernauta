function k(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
var b
// @__NO_SIDE_EFFECTS__
function T(e) {
  return {
    lang: b?.lang,
    message: e?.message,
    abortEarly: b?.abortEarly,
    abortPipeEarly: b?.abortPipeEarly,
  }
}
var O
// @__NO_SIDE_EFFECTS__
function $(e) {
  return O?.get(e)
}
var x
// @__NO_SIDE_EFFECTS__
function I(e) {
  return x?.get(e)
}
var q
// @__NO_SIDE_EFFECTS__
function D(e, t) {
  return q?.get(e)?.get(t)
}
// @__NO_SIDE_EFFECTS__
function R(e) {
  const t = typeof e
  return t === "string"
    ? `"${e}"`
    : t === "number" || t === "bigint" || t === "boolean"
      ? `${e}`
      : t === "object" || t === "function"
        ? ((e &&
            Object.getPrototypeOf(e)?.constructor?.name) ??
          "null")
        : t
}
function p(e, t, s, n, r) {
  const i = r && "input" in r ? r.input : s.value,
    u = r?.expected ?? e.expects ?? null,
    a = r?.received ?? /* @__PURE__ */ R(i),
    o = {
      kind: e.kind,
      type: e.type,
      input: i,
      expected: u,
      received: a,
      message: `Invalid ${t}: ${u ? `Expected ${u} but r` : "R"}eceived ${a}`,
      requirement: e.requirement,
      path: r?.path,
      issues: r?.issues,
      lang: n.lang,
      abortEarly: n.abortEarly,
      abortPipeEarly: n.abortPipeEarly,
    },
    l = e.kind === "schema",
    c =
      r?.message ??
      e.message ??
      /* @__PURE__ */ D(e.reference, o.lang) ??
      (l ? /* @__PURE__ */ I(o.lang) : null) ??
      n.message ??
      /* @__PURE__ */ $(o.lang)
  c !== void 0 &&
    (o.message =
      typeof c == "function"
        ? // @ts-expect-error
          c(o)
        : c),
    l && (s.typed = !1),
    s.issues ? s.issues.push(o) : (s.issues = [o])
}
// @__NO_SIDE_EFFECTS__
function h(e) {
  return {
    version: 1,
    vendor: "valibot",
    validate(t) {
      return e["~run"]({ value: t }, /* @__PURE__ */ T())
    },
  }
}
// @__NO_SIDE_EFFECTS__
function P(e, t) {
  return (
    Object.hasOwn(e, t) &&
    t !== "__proto__" &&
    t !== "prototype" &&
    t !== "constructor"
  )
}
// @__NO_SIDE_EFFECTS__
function U(e, t) {
  const s = [...new Set(e)]
  return s.length > 1
    ? `(${s.join(` ${t} `)})`
    : (s[0] ?? "never")
}
var C = class extends Error {
  /**
   * Creates a Valibot error with useful information.
   *
   * @param issues The error issues.
   */
  constructor(e) {
    super(e[0].message),
      (this.name = "ValiError"),
      (this.issues = e)
  }
}
// @__NO_SIDE_EFFECTS__
function M(e, t, s) {
  return typeof e.fallback == "function"
    ? // @ts-expect-error
      e.fallback(t, s)
    : // @ts-expect-error
      e.fallback
}
// @__NO_SIDE_EFFECTS__
function H(e, t, s) {
  return typeof e.default == "function"
    ? // @ts-expect-error
      e.default(t, s)
    : // @ts-expect-error
      e.default
}
// @__NO_SIDE_EFFECTS__
function A(e, t) {
  return {
    kind: "schema",
    type: "array",
    reference: A,
    expects: "Array",
    async: !1,
    item: e,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(s, n) {
      const r = s.value
      if (Array.isArray(r)) {
        ;(s.typed = !0), (s.value = [])
        for (let i = 0; i < r.length; i++) {
          const u = r[i],
            a = this.item["~run"]({ value: u }, n)
          if (a.issues) {
            const o = {
              type: "array",
              origin: "value",
              input: r,
              key: i,
              value: u,
            }
            for (const l of a.issues)
              l.path ? l.path.unshift(o) : (l.path = [o]),
                s.issues?.push(l)
            if (
              (s.issues || (s.issues = a.issues),
              n.abortEarly)
            ) {
              s.typed = !1
              break
            }
          }
          a.typed || (s.typed = !1), s.value.push(a.value)
        }
      } else p(this, "type", s, n)
      return s
    },
  }
}
// @__NO_SIDE_EFFECTS__
function g(e, t) {
  return {
    kind: "schema",
    type: "literal",
    reference: g,
    expects: /* @__PURE__ */ R(e),
    async: !1,
    literal: e,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(s, n) {
      return (
        s.value === this.literal
          ? (s.typed = !0)
          : p(this, "type", s, n),
        s
      )
    },
  }
}
// @__NO_SIDE_EFFECTS__
function m(e, t) {
  return {
    kind: "schema",
    type: "object",
    reference: m,
    expects: "Object",
    async: !1,
    entries: e,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(s, n) {
      const r = s.value
      if (r && typeof r == "object") {
        ;(s.typed = !0), (s.value = {})
        for (const i in this.entries) {
          const u = this.entries[i]
          if (
            i in r ||
            ((u.type === "exact_optional" ||
              u.type === "optional" ||
              u.type === "nullish") && // @ts-expect-error
              u.default !== void 0)
          ) {
            const a =
                i in r
                  ? // @ts-expect-error
                    r[i]
                  : /* @__PURE__ */ H(u),
              o = u["~run"]({ value: a }, n)
            if (o.issues) {
              const l = {
                type: "object",
                origin: "value",
                input: r,
                key: i,
                value: a,
              }
              for (const c of o.issues)
                c.path ? c.path.unshift(l) : (c.path = [l]),
                  s.issues?.push(c)
              if (
                (s.issues || (s.issues = o.issues),
                n.abortEarly)
              ) {
                s.typed = !1
                break
              }
            }
            o.typed || (s.typed = !1),
              (s.value[i] = o.value)
          } else if (u.fallback !== void 0)
            s.value[i] = /* @__PURE__ */ M(u)
          else if (
            u.type !== "exact_optional" &&
            u.type !== "optional" &&
            u.type !== "nullish" &&
            (p(this, "key", s, n, {
              input: void 0,
              expected: `"${i}"`,
              path: [
                {
                  type: "object",
                  origin: "key",
                  input: r,
                  key: i,
                  // @ts-expect-error
                  value: r[i],
                },
              ],
            }),
            n.abortEarly)
          )
            break
        }
      } else p(this, "type", s, n)
      return s
    },
  }
}
// @__NO_SIDE_EFFECTS__
function j(e, t, s) {
  return {
    kind: "schema",
    type: "record",
    reference: j,
    expects: "Object",
    async: !1,
    key: e,
    value: t,
    message: s,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(n, r) {
      const i = n.value
      if (i && typeof i == "object") {
        ;(n.typed = !0), (n.value = {})
        for (const u in i)
          if (/* @__PURE__ */ P(i, u)) {
            const a = i[u],
              o = this.key["~run"]({ value: u }, r)
            if (o.issues) {
              const c = {
                type: "object",
                origin: "key",
                input: i,
                key: u,
                value: a,
              }
              for (const f of o.issues)
                (f.path = [c]), n.issues?.push(f)
              if (
                (n.issues || (n.issues = o.issues),
                r.abortEarly)
              ) {
                n.typed = !1
                break
              }
            }
            const l = this.value["~run"]({ value: a }, r)
            if (l.issues) {
              const c = {
                type: "object",
                origin: "value",
                input: i,
                key: u,
                value: a,
              }
              for (const f of l.issues)
                f.path ? f.path.unshift(c) : (f.path = [c]),
                  n.issues?.push(f)
              if (
                (n.issues || (n.issues = l.issues),
                r.abortEarly)
              ) {
                n.typed = !1
                break
              }
            }
            ;(!o.typed || !l.typed) && (n.typed = !1),
              o.typed && (n.value[o.value] = l.value)
          }
      } else p(this, "type", n, r)
      return n
    },
  }
}
// @__NO_SIDE_EFFECTS__
function y(e) {
  return {
    kind: "schema",
    type: "string",
    reference: y,
    expects: "string",
    async: !1,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(t, s) {
      return (
        typeof t.value == "string"
          ? (t.typed = !0)
          : p(this, "type", t, s),
        t
      )
    },
  }
}
// @__NO_SIDE_EFFECTS__
function _(e) {
  let t
  if (e)
    for (const s of e)
      t ? t.push(...s.issues) : (t = s.issues)
  return t
}
// @__NO_SIDE_EFFECTS__
function v(e, t) {
  return {
    kind: "schema",
    type: "union",
    reference: v,
    expects: /* @__PURE__ */ U(
      e.map((s) => s.expects),
      "|",
    ),
    async: !1,
    options: e,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(s, n) {
      let r, i, u
      for (const a of this.options) {
        const o = a["~run"]({ value: s.value }, n)
        if (o.typed)
          if (o.issues) i ? i.push(o) : (i = [o])
          else {
            r = o
            break
          }
        else u ? u.push(o) : (u = [o])
      }
      if (r) return r
      if (i) {
        if (i.length === 1) return i[0]
        p(this, "type", s, n, {
          issues: /* @__PURE__ */ _(i),
        }),
          (s.typed = !0)
      } else {
        if (u?.length === 1) return u[0]
        p(this, "type", s, n, {
          issues: /* @__PURE__ */ _(u),
        })
      }
      return s
    },
  }
}
// @__NO_SIDE_EFFECTS__
function d() {
  return {
    kind: "schema",
    type: "unknown",
    reference: d,
    expects: "unknown",
    async: !1,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(e) {
      return (e.typed = !0), e
    },
  }
}
function E(e, t, s) {
  const n = e["~run"]({ value: t }, /* @__PURE__ */ T(s))
  if (n.issues) throw new C(n.issues)
  return n.value
}
const G = /* @__PURE__ */ m({
    id: /* @__PURE__ */ y(),
    type: /* @__PURE__ */ g(
      "ETHERNAUTA_REQUEST_SIGN_TRANSACTION",
    ),
    method: /* @__PURE__ */ y(),
    params: /* @__PURE__ */ v([
      /* @__PURE__ */ A(/* @__PURE__ */ d()),
      /* @__PURE__ */ j(
        /* @__PURE__ */ y(),
        /* @__PURE__ */ d(),
      ),
    ]),
  }),
  V = /* @__PURE__ */ m({
    id: /* @__PURE__ */ y(),
    type: /* @__PURE__ */ g(
      "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
    ),
    signed_transaction: /* @__PURE__ */ y(),
  }),
  Q = /* @__PURE__ */ m({
    id: /* @__PURE__ */ y(),
    type: /* @__PURE__ */ g("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  N = /* @__PURE__ */ v([G, Q]),
  w = /* @__PURE__ */ v([V]),
  K = /* @__PURE__ */ v([N, w])
function S(e) {
  return `pending_${e}`
}
chrome.runtime.onMessage.addListener(async (e, t) => {
  const s = E(K, e)
  if (s.type.startsWith("ETHERNAUTA_REQUEST")) {
    const n = E(N, e)
    console.log("receiving request", n)
    const r = t.tab?.id
    k(r, "request must come from a tab")
    const i = S(n.id)
    return (
      await chrome.storage.session.set({
        [i]: {
          tab_id: r,
          request: n,
        },
      }),
      chrome.action
        .openPopup()
        .then(() => {
          chrome.runtime.sendMessage(n)
        })
        .catch(async () => {}),
      !0
    )
  }
  if (s.type.startsWith("ETHERNAUTA_RESPONSE")) {
    const n = E(w, e)
    console.log("returning response", n)
    const r = S(n.id),
      u = (await chrome.storage.session.get(r))[r]
    k(
      u,
      "there should be a pending request for this response",
    ),
      chrome.tabs.sendMessage(u.tab_id, n),
      await chrome.storage.session.remove(`pending_${n.id}`)
  }
})
