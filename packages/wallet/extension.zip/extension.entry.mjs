import {
  u as h,
  o as a,
  a as m,
  s as e,
  l as E,
  b as S,
  r as A,
  c as u,
  p as d,
} from "./assets/index-BYCloSbW.mjs"
function _(s, r) {
  if (!s) throw new Error(`message: ${r}`)
}
const g = a({
    signature: e(),
    names: S(e()),
  }),
  y = a({
    id: e(),
    type: E("ETHERNAUTA_REQUEST_SIGN_TRANSACTION"),
    method: e(),
    chainId: e(),
    to: m(e()),
    params: m(h([S(u()), A(e(), u())])),
    _function: m(g),
  }),
  O = a({
    id: e(),
    type: E("ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION"),
    signed_transaction: e(),
  }),
  p = y,
  f = a({
    id: e(),
    type: E("ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED"),
  }),
  P = a({
    id: e(),
    type: E("ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE"),
  }),
  R = h([O, f, P]),
  U = a({
    type: E("ETHERNAUTA_POPUP_READY"),
  }),
  l = h([p, R, U])
function T(s) {
  return `pending_${s}`
}
chrome.runtime.onConnect.addListener((s) => {
  s.onDisconnect.addListener(async () => {
    const r = await chrome.storage.session.get(null)
    for (const [i, t] of Object.entries(r)) {
      if (!i.startsWith("pending_")) continue
      const { tab_id: n, request: c } = t,
        o = {
          id: c.id,
          type: "ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE",
        }
      chrome.tabs.sendMessage(n, o),
        await chrome.storage.session.remove(i)
    }
  })
})
chrome.runtime.onMessage.addListener(async (s, r) => {
  const i = d(l, s)
  if (i.type.startsWith("ETHERNAUTA_REQUEST")) {
    const t = d(p, s),
      n = r.tab?.id
    _(n, "request must come from a tab")
    const c = T(t.id)
    return (
      await chrome.storage.session.set({
        [c]: {
          tab_id: n,
          request: t,
        },
      }),
      chrome.action
        .openPopup()
        .then(() => {
          chrome.runtime.onMessage.addListener(
            function o(N) {
              N.type === "ETHERNAUTA_POPUP_READY" &&
                (chrome.runtime.onMessage.removeListener(o),
                chrome.runtime.sendMessage(t))
            },
          )
        })
        .catch(async () => {
          await chrome.storage.session.remove(c)
        }),
      !0
    )
  }
  if (i.type.startsWith("ETHERNAUTA_RESPONSE")) {
    const t = d(R, s),
      n = T(t.id),
      o = (await chrome.storage.session.get(n))[n]
    _(
      o,
      "there should be a pending request for this response",
    ),
      chrome.tabs.sendMessage(o.tab_id, t),
      await chrome.storage.session.remove(`pending_${t.id}`)
  }
})
