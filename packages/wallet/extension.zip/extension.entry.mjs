function _(e, t) {
  if (!e) throw new Error(`message: ${t}`)
}
var g
// @__NO_SIDE_EFFECTS__
function k(e) {
  return {
    lang: g?.lang,
    message: e?.message,
    abortEarly: g?.abortEarly,
    abortPipeEarly: g?.abortPipeEarly,
  }
}
var j
// @__NO_SIDE_EFFECTS__
function I(e) {
  return j?.get(e)
}
var w
// @__NO_SIDE_EFFECTS__
function U(e) {
  return w?.get(e)
}
var D
// @__NO_SIDE_EFFECTS__
function x(e, t) {
  return D?.get(e)?.get(t)
}
// @__NO_SIDE_EFFECTS__
function R(e) {
  const t = typeof e
  return t === "string"
    ? `"${e}"`
    : t === "number" || t === "bigint" || t === "boolean"
      ? `${e}`
      : t === "object" || t === "function"
        ? ((e &&
            Object.getPrototypeOf(e)?.constructor?.name) ??
          "null")
        : t
}
function f(e, t, s, n, r) {
  const i = r && "input" in r ? r.input : s.value,
    u = r?.expected ?? e.expects ?? null,
    a = r?.received ?? /* @__PURE__ */ R(i),
    o = {
      kind: e.kind,
      type: e.type,
      input: i,
      expected: u,
      received: a,
      message: `Invalid ${t}: ${u ? `Expected ${u} but r` : "R"}eceived ${a}`,
      requirement: e.requirement,
      path: r?.path,
      issues: r?.issues,
      lang: n.lang,
      abortEarly: n.abortEarly,
      abortPipeEarly: n.abortPipeEarly,
    },
    c = e.kind === "schema",
    l =
      r?.message ??
      e.message ??
      /* @__PURE__ */ x(e.reference, o.lang) ??
      (c ? /* @__PURE__ */ U(o.lang) : null) ??
      n.message ??
      /* @__PURE__ */ I(o.lang)
  l !== void 0 &&
    (o.message =
      typeof l == "function"
        ? // @ts-expect-error
          l(o)
        : l),
    c && (s.typed = !1),
    s.issues ? s.issues.push(o) : (s.issues = [o])
}
// @__NO_SIDE_EFFECTS__
function h(e) {
  return {
    version: 1,
    vendor: "valibot",
    validate(t) {
      return e["~run"]({ value: t }, /* @__PURE__ */ k())
    },
  }
}
// @__NO_SIDE_EFFECTS__
function C(e, t) {
  return (
    Object.hasOwn(e, t) &&
    t !== "__proto__" &&
    t !== "prototype" &&
    t !== "constructor"
  )
}
// @__NO_SIDE_EFFECTS__
function $(e, t) {
  const s = [...new Set(e)]
  return s.length > 1
    ? `(${s.join(` ${t} `)})`
    : (s[0] ?? "never")
}
var q = class extends Error {
  /**
   * Creates a Valibot error with useful information.
   *
   * @param issues The error issues.
   */
  constructor(e) {
    super(e[0].message),
      (this.name = "ValiError"),
      (this.issues = e)
  }
}
// @__NO_SIDE_EFFECTS__
function H(e, t, s) {
  return typeof e.fallback == "function"
    ? // @ts-expect-error
      e.fallback(t, s)
    : // @ts-expect-error
      e.fallback
}
// @__NO_SIDE_EFFECTS__
function M(e, t, s) {
  return typeof e.default == "function"
    ? // @ts-expect-error
      e.default(t, s)
    : // @ts-expect-error
      e.default
}
// @__NO_SIDE_EFFECTS__
function A(e, t) {
  return {
    kind: "schema",
    type: "array",
    reference: A,
    expects: "Array",
    async: !1,
    item: e,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(s, n) {
      const r = s.value
      if (Array.isArray(r)) {
        ;(s.typed = !0), (s.value = [])
        for (let i = 0; i < r.length; i++) {
          const u = r[i],
            a = this.item["~run"]({ value: u }, n)
          if (a.issues) {
            const o = {
              type: "array",
              origin: "value",
              input: r,
              key: i,
              value: u,
            }
            for (const c of a.issues)
              c.path ? c.path.unshift(o) : (c.path = [o]),
                s.issues?.push(c)
            if (
              (s.issues || (s.issues = a.issues),
              n.abortEarly)
            ) {
              s.typed = !1
              break
            }
          }
          a.typed || (s.typed = !1), s.value.push(a.value)
        }
      } else f(this, "type", s, n)
      return s
    },
  }
}
// @__NO_SIDE_EFFECTS__
function E(e, t) {
  return {
    kind: "schema",
    type: "literal",
    reference: E,
    expects: /* @__PURE__ */ R(e),
    async: !1,
    literal: e,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(s, n) {
      return (
        s.value === this.literal
          ? (s.typed = !0)
          : f(this, "type", s, n),
        s
      )
    },
  }
}
// @__NO_SIDE_EFFECTS__
function m(e, t) {
  return {
    kind: "schema",
    type: "object",
    reference: m,
    expects: "Object",
    async: !1,
    entries: e,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(s, n) {
      const r = s.value
      if (r && typeof r == "object") {
        ;(s.typed = !0), (s.value = {})
        for (const i in this.entries) {
          const u = this.entries[i]
          if (
            i in r ||
            ((u.type === "exact_optional" ||
              u.type === "optional" ||
              u.type === "nullish") && // @ts-expect-error
              u.default !== void 0)
          ) {
            const a =
                i in r
                  ? // @ts-expect-error
                    r[i]
                  : /* @__PURE__ */ M(u),
              o = u["~run"]({ value: a }, n)
            if (o.issues) {
              const c = {
                type: "object",
                origin: "value",
                input: r,
                key: i,
                value: a,
              }
              for (const l of o.issues)
                l.path ? l.path.unshift(c) : (l.path = [c]),
                  s.issues?.push(l)
              if (
                (s.issues || (s.issues = o.issues),
                n.abortEarly)
              ) {
                s.typed = !1
                break
              }
            }
            o.typed || (s.typed = !1),
              (s.value[i] = o.value)
          } else if (u.fallback !== void 0)
            s.value[i] = /* @__PURE__ */ H(u)
          else if (
            u.type !== "exact_optional" &&
            u.type !== "optional" &&
            u.type !== "nullish" &&
            (f(this, "key", s, n, {
              input: void 0,
              expected: `"${i}"`,
              path: [
                {
                  type: "object",
                  origin: "key",
                  input: r,
                  key: i,
                  // @ts-expect-error
                  value: r[i],
                },
              ],
            }),
            n.abortEarly)
          )
            break
        }
      } else f(this, "type", s, n)
      return s
    },
  }
}
// @__NO_SIDE_EFFECTS__
function N(e, t, s) {
  return {
    kind: "schema",
    type: "record",
    reference: N,
    expects: "Object",
    async: !1,
    key: e,
    value: t,
    message: s,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(n, r) {
      const i = n.value
      if (i && typeof i == "object") {
        ;(n.typed = !0), (n.value = {})
        for (const u in i)
          if (/* @__PURE__ */ C(i, u)) {
            const a = i[u],
              o = this.key["~run"]({ value: u }, r)
            if (o.issues) {
              const l = {
                type: "object",
                origin: "key",
                input: i,
                key: u,
                value: a,
              }
              for (const y of o.issues)
                (y.path = [l]), n.issues?.push(y)
              if (
                (n.issues || (n.issues = o.issues),
                r.abortEarly)
              ) {
                n.typed = !1
                break
              }
            }
            const c = this.value["~run"]({ value: a }, r)
            if (c.issues) {
              const l = {
                type: "object",
                origin: "value",
                input: i,
                key: u,
                value: a,
              }
              for (const y of c.issues)
                y.path ? y.path.unshift(l) : (y.path = [l]),
                  n.issues?.push(y)
              if (
                (n.issues || (n.issues = c.issues),
                r.abortEarly)
              ) {
                n.typed = !1
                break
              }
            }
            ;(!o.typed || !c.typed) && (n.typed = !1),
              o.typed && (n.value[o.value] = c.value)
          }
      } else f(this, "type", n, r)
      return n
    },
  }
}
// @__NO_SIDE_EFFECTS__
function p(e) {
  return {
    kind: "schema",
    type: "string",
    reference: p,
    expects: "string",
    async: !1,
    message: e,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(t, s) {
      return (
        typeof t.value == "string"
          ? (t.typed = !0)
          : f(this, "type", t, s),
        t
      )
    },
  }
}
// @__NO_SIDE_EFFECTS__
function S(e) {
  let t
  if (e)
    for (const s of e)
      t ? t.push(...s.issues) : (t = s.issues)
  return t
}
// @__NO_SIDE_EFFECTS__
function v(e, t) {
  return {
    kind: "schema",
    type: "union",
    reference: v,
    expects: /* @__PURE__ */ $(
      e.map((s) => s.expects),
      "|",
    ),
    async: !1,
    options: e,
    message: t,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(s, n) {
      let r, i, u
      for (const a of this.options) {
        const o = a["~run"]({ value: s.value }, n)
        if (o.typed)
          if (o.issues) i ? i.push(o) : (i = [o])
          else {
            r = o
            break
          }
        else u ? u.push(o) : (u = [o])
      }
      if (r) return r
      if (i) {
        if (i.length === 1) return i[0]
        f(this, "type", s, n, {
          issues: /* @__PURE__ */ S(i),
        }),
          (s.typed = !0)
      } else {
        if (u?.length === 1) return u[0]
        f(this, "type", s, n, {
          issues: /* @__PURE__ */ S(u),
        })
      }
      return s
    },
  }
}
// @__NO_SIDE_EFFECTS__
function b() {
  return {
    kind: "schema",
    type: "unknown",
    reference: b,
    expects: "unknown",
    async: !1,
    get "~standard"() {
      return /* @__PURE__ */ h(this)
    },
    "~run"(e) {
      return (e.typed = !0), e
    },
  }
}
function d(e, t, s) {
  const n = e["~run"]({ value: t }, /* @__PURE__ */ k(s))
  if (n.issues) throw new q(n.issues)
  return n.value
}
const L = /* @__PURE__ */ m({
    id: /* @__PURE__ */ p(),
    type: /* @__PURE__ */ E(
      "ETHERNAUTA_REQUEST_SIGN_TRANSACTION",
    ),
    method: /* @__PURE__ */ p(),
    params: /* @__PURE__ */ v([
      /* @__PURE__ */ A(/* @__PURE__ */ b()),
      /* @__PURE__ */ N(
        /* @__PURE__ */ p(),
        /* @__PURE__ */ b(),
      ),
    ]),
  }),
  V = /* @__PURE__ */ m({
    id: /* @__PURE__ */ p(),
    type: /* @__PURE__ */ E(
      "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
    ),
    signed_transaction: /* @__PURE__ */ p(),
  }),
  G = /* @__PURE__ */ m({
    id: /* @__PURE__ */ p(),
    type: /* @__PURE__ */ E("ETHERNAUTA_REQUEST_CONNECT"),
  }),
  O = /* @__PURE__ */ v([L, G]),
  Q = /* @__PURE__ */ m({
    id: /* @__PURE__ */ p(),
    type: /* @__PURE__ */ E(
      "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED",
    ),
  }),
  W = /* @__PURE__ */ m({
    id: /* @__PURE__ */ p(),
    type: /* @__PURE__ */ E(
      "ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE",
    ),
  }),
  P = /* @__PURE__ */ v([V, Q, W]),
  K = /* @__PURE__ */ m({
    type: /* @__PURE__ */ E("ETHERNAUTA_POPUP_READY"),
  }),
  X = /* @__PURE__ */ v([O, P, K])
function T(e) {
  return `pending_${e}`
}
chrome.runtime.onConnect.addListener((e) => {
  e.onDisconnect.addListener(async () => {
    const t = await chrome.storage.session.get(null)
    for (const [s, n] of Object.entries(t)) {
      if (!s.startsWith("pending_")) continue
      const { tab_id: r, request: i } = n,
        u = {
          id: i.id,
          type: "ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE",
        }
      chrome.tabs.sendMessage(r, u),
        await chrome.storage.session.remove(s)
    }
  })
})
chrome.runtime.onMessage.addListener(async (e, t) => {
  const s = d(X, e)
  if (s.type.startsWith("ETHERNAUTA_REQUEST")) {
    const n = d(O, e),
      r = t.tab?.id
    _(r, "request must come from a tab")
    const i = T(n.id)
    return (
      await chrome.storage.session.set({
        [i]: {
          tab_id: r,
          request: n,
        },
      }),
      chrome.action
        .openPopup()
        .then(() => {
          chrome.runtime.onMessage.addListener(
            function u(a) {
              a.type === "ETHERNAUTA_POPUP_READY" &&
                (chrome.runtime.onMessage.removeListener(u),
                chrome.runtime.sendMessage(n))
            },
          )
        })
        .catch(async () => {
          await chrome.storage.session.remove(i)
        }),
      !0
    )
  }
  if (s.type.startsWith("ETHERNAUTA_RESPONSE")) {
    const n = d(P, e),
      r = T(n.id),
      u = (await chrome.storage.session.get(r))[r]
    _(
      u,
      "there should be a pending request for this response",
    ),
      chrome.tabs.sendMessage(u.tab_id, n),
      await chrome.storage.session.remove(`pending_${n.id}`)
  }
})
