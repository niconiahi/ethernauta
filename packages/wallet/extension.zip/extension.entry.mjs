import { j as i, m as h, q as T, n as m, h as p, g as N, l as u, o as d, s as A } from "./assets/event-BBZ13nRM.mjs";
const _ = d({
  tab_id: m(),
  request: d({ id: A() })
});
function E(n) {
  return `pending_${n}`;
}
chrome.runtime.onConnect.addListener((n) => {
  n.onDisconnect.addListener(async () => {
    const r = await chrome.storage.session.get(null);
    for (const [a, e] of Object.entries(r)) {
      if (!a.startsWith("pending_")) continue;
      const { tab_id: s, request: o } = i(
        _,
        e
      ), t = {
        id: o.id,
        type: "ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE"
      };
      chrome.tabs.sendMessage(s, t), await chrome.storage.session.remove(a);
    }
  });
});
chrome.runtime.onMessage.addListener(
  async (n, r) => {
    const a = i(h, n);
    if (a.type.startsWith("ETHERNAUTA_REQUEST")) {
      const e = i(
        T,
        n
      ), s = i(m(), r.tab?.id);
      if (e.method === "wallet_getCapabilities" || e.method === "wallet_getCallsStatus") {
        try {
          const t = e.method === "wallet_getCapabilities" ? p() : await N(
            e.params[0]
          ), c = {
            id: e.id,
            type: "ETHERNAUTA_RESPONSE_SIGNED_TRANSACTION",
            signed_transaction: JSON.stringify(t)
          };
          chrome.tabs.sendMessage(s, c);
        } catch {
          const t = {
            id: e.id,
            type: "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED"
          };
          chrome.tabs.sendMessage(s, t);
        }
        return !0;
      }
      const o = E(e.id);
      return await chrome.storage.session.set({
        [o]: {
          tab_id: s,
          request: e
        }
      }), chrome.action.openPopup().then(() => {
        chrome.runtime.onMessage.addListener(
          function t(c) {
            c.type === "ETHERNAUTA_NOTIFICATION_POPUP_READY" && (chrome.runtime.onMessage.removeListener(
              t
            ), chrome.runtime.sendMessage(e));
          }
        );
      }).catch(async () => {
        await chrome.storage.session.remove(o);
      }), !0;
    }
    if (a.type.startsWith("ETHERNAUTA_RESPONSE")) {
      const e = i(
        u,
        n
      ), s = E(e.id), o = await chrome.storage.session.get(s), t = i(
        _,
        o[s]
      );
      chrome.tabs.sendMessage(
        t.tab_id,
        e
      ), await chrome.storage.session.remove(
        `pending_${e.id}`
      );
    }
    if (a.type === "ETHERNAUTA_NOTIFICATION_CHAIN_SELECTED" || a.type === "ETHERNAUTA_NOTIFICATION_ACCOUNTS_CHANGED") {
      const e = await chrome.tabs.query({});
      for (const s of e)
        s.id && chrome.tabs.sendMessage(s.id, a);
    }
  }
);
