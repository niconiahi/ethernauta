import { a as D, A as B, t as m, s as c, R as v, f as S, c as E, b as T, h as Q, p as N, C as W, d as y, m as L } from "./assets/calls-status-D_9GJ-4U.mjs";
const h = D(B), g = {
  UNSUPPORTED_METHOD: 4200,
  INVALID_PARAMS: -32602
};
function p(e, a, t) {
  return Object.assign(
    new Error(a),
    { code: e }
  );
}
function d(e) {
  return p(
    g.UNSUPPORTED_METHOD,
    `method not supported: ${e}`
  );
}
function q(e) {
  return p(g.INVALID_PARAMS, e);
}
function O() {
  const e = {
    connect: /* @__PURE__ */ new Set(),
    disconnect: /* @__PURE__ */ new Set(),
    chainChanged: /* @__PURE__ */ new Set(),
    accountsChanged: /* @__PURE__ */ new Set(),
    message: /* @__PURE__ */ new Set()
  };
  return {
    on(a, t) {
      e[a].add(t);
    },
    removeListener(a, t) {
      e[a].delete(t);
    },
    emit(a, t) {
      for (const n of e[a])
        n(t);
    }
  };
}
function Y(e) {
  const a = O();
  return {
    request: e.request,
    on: a.on,
    removeListener: a.removeListener,
    emit: a.emit
  };
}
const I = "eip6963:announceProvider", j = "eip6963:requestProvider";
function z(e) {
  const a = Object.freeze({
    info: Object.freeze(e.info),
    provider: e.provider
  });
  function t() {
    window.dispatchEvent(
      new CustomEvent(I, { detail: a })
    );
  }
  t(), window.addEventListener(j, t);
}
const b = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAIAAABMXPacAAAABmJLR0QA/wD/AP+gvaeTAAAgAElEQVR4nO1deVxM6/+fpanRXpI2SWSphNByc1XULZfK7ko3O8mVvnSF8C1fUUJSssRtcct2cdNCIkuWcK8WhOqWFjJM2tRMzcyZ3x/n9zu/5z7nzJkz01S+v9/3/YeX5nzO83zOs3/Wh077N4GKioq5ubmJiYmxsbGpqamBgQGTycSe8ng8LpfL4XA+fvzY2Nj48uXLjo6OfuSWOuj9zQAZxowZ4+joaGdnZ2dnZ21tzWKxKL6IIEhlZWVpaWlJScmdO3eePHkiEol6ldX/O2AymVOnTj148GBVVZVYQWhqajp79qy/v7+urm5/f99XDDMzs3379nE4HEW1Ox48Hi89Pd3V1ZVO/6qnfl/D09MzOztbJBL1XtNDqKioCAoKYrPZ/f3p/Q0nJ6c7d+70WbtD4HA4oaGhAwYM6O9m6A/Y2treuHGjv5oeRH19/ZIlS/q7PfoQAwYMiIqKEgqF/d3yf8OdO3dGjx7d323T+3B3d//rr7/6u7WJ0dnZuXXrVgaD0d+N1DtgsVixsbEIgvR3O0tBfn6+vr5+f7cWKWxtbUeMGCHTK4aGhvfu3SP84FevXrW2tvZxK6PIy8sjPHq9e/fO2dlZpg/U1tZ2dHTsi2PV6dOnxWKxSCRas2YNxVecnJzev3+P/86mpqa1a9cyGIzq6upeb2wiGBsbT5gwoaCgAP9IKBSuXbuW4gdaW1t/+vRJLBa/fPlSQ0ND3qalAGNjY4zFv/76i8orM2fO7OzshD4PQZC0tLRBgwahNP3VASYmJigDCxYs4HK5eIKoqCgq35icnIy90rsHKi0tLT6fj9b05MkTqfR+fn7d3d3QVzU0NLi4uIBk/bUtm5qaYjwYGRnl5OTgaU6cOAFq/Qhx5MgRjP67776Tq2kpw9fXt6qq6smTJxMmTCCnDAwMxK+wWVlZenp6EKUC1T4yYejQoSAbdDo9LCwMfz7+5ZdfyFUXenp6V65cefv27aFDh74WJYevry904EEQZNu2bYT89VcHDBs2DM/M9OnT8cvR4cOHe7/NFAd3d/euri7wA/h8/uLFiyXR19bW9mGz/y/Mzc0J+Rk9evTbt28h4vDw8N5qL8XC1ta2ra0NZL2lpQVa9EH4+Pj0l3Bw8OBBJSUlQq6MjY3Lysogej8/v95qNUVBR0enpqYGZLqjo+Pbb78lJNbV1T1x4kT/imaPHz8eNWoUIXt6enovXrwAiXk83qRJkxTbYorcMeh0emZmppeXF/YLn8+fNWvWrVu38MQzZsxISUmhInNyudzy8vKampp3795xOJz379+3tLTw+XwejycQCEQiEZvNZrFY6urqqqqqhoaGBgYG+vr6w4YNGzVqlJmZmVTVQmdnZ0hIyLFjx/CPUPkRlDrfvn07efJkLpcrle1+QEhICDheRCKRj48PnozBYOzdu5dk4HM4nCtXrmzevNnZ2Rl/ZJIJbDZ73LhxS5cuPXny5IsXL0hMDsePHydcjszMzCAb0dWrV3vCUm9hwoQJ0JE/LCwMT8Zms3/77Tf893d3d9+8eTM4OLhXVZI6Ojrz589PSUn5+PEjnodr164RyrFTpkyBzhRLly7tPSblAYPBKCoqAlm8dOkS/sSprKwMCTtCoTA3N3fx4sVaWlp9zLCjo2N8fDx04iwsLFRVVcXTr1q1CiRrbm42NjbuFc7i4+Pb29tXrlwp01vr1q0D+auoqFBXV4doGAwGOPYrKiq2bNliZGSkON7lgbKy8pw5c0CDaE5ODqH7xZkzZ8BvzMzMlKmixYsX83g8KcsXg8FAl5G7d+9SL3rw4MHNzc3goP7mm2/wZHv37kUJ7ty54+3t/bWp3UeNGnX8+HFUbZWWloYn0NTUhHRWbm5u1MvHzH/Qrva3bUdJSQntfMJpKAm7du3S1tbG/oyNjX348CFE4+fnt3Xr1qysrIiIiD///JN64TQaTUdHZ/To0RYWFoaGhoaGhvr6+tra2mw2W1NTE6Ph8XjNzc3Nzc0tLS3v3r2rq6urq6urqqr6+PEjxVrevHkTEBCwY8eOTZs2BQUF3b9//+TJkyBBW1ubv7//3bt3saFz4MABW1tbBEGolK+iooL+h0xlraysjPbSs2fPKPJtYmKCqefEYvGbN2/wFTg6Ol6/fp1wWhBCT09v5syZu3fvzsvL+/Dhg7gH4HK5d+7cSUhI8PPzgzQ/JDAwMIiJiSE8Dhw/fhwsf8WKFRTLvHv3LvoKpoJFQVdVVfXz89PR0aHRaEwmMzIykkajNTY2xsXFoRSlpaXXr1+XVG5CQsL69euxP729vbOysiAafX19qSMR3RU9PT09PT1tbW17aYFqaGi4ceNGdnb2jRs3pPouslgsgUAA/airq/v69WtMkV5TUzNy5EihUEhYgoODw5QpU1Bl6tq1a1HV0759+1pbW2k0Wmdn54ULF2hxcXFSx9GUKVMIKzA2NgaHf35+viyt8d8YO3ZsdHR0XV1dT0a6rODxeJmZmfPmzcNWBupYsWIFWNSiRYsIyUaNGiXV8eDWrVu06OhociIEQezs7AjriIiIwMiEQqGNjQ31zxg8eHBISEhJSYncjagQNDU1xcfHjxw5kjrnTCbz5cuXWAlPnz4lJBs9erRUV7Pr16/TlZWV586di66PbDYb1flxudwDBw7QaLSurq6ioqKioiJ8BQwGo6amBrNpXLhwQdJYgGBmZhYSErJixQqKHlFcLre6urqmpqampqa+vp7L5ba0tLS2tra0tKBLBJvNRovS1dU1MjIaMmQI+q+1tbWZmRmVKhAEuXbt2qFDhwoKCqjQz50799KlS9ifU6dOLSwsxJN98803jo6OqIAdFBSEnrm3b9/e1NREo9G+fPkCL9fYJlxRUSGVCQ8PD6wnEQSRap+h0WhjxoxJTU3F28ggtLS0ZGVlhYeHe3l59VBQ0NXVdXNzCw0NvXjxYlNTk9QJcffuXUmqQxB0Ov3JkyfYW6dOnZL6SmFhIUpMdhag0+moiubNmzdSSzx//jzGwbVr18iJTU1NMzIyyKfks2fP9u7dO3XqVEkq4h6CyWQ6Ojru3r0b9VYn4eT69etjxowhL83T0xOjb21tlTqbb9++Lb0DaDQaqiS5f/8+eXFsNrujowPjQNIujVLu3r0bb5fHUFtbu2fPHplW4Z7D0NAwODj48ePHkrjq7u6OiYkhd3EAHW3mzZtHXuOlS5fEYjGCIKDMRIDAwMD79+/PnDmTvDh3d3dwvEgic3JyevXqFeEXIgiSnZ09ffr0/hWJbWxsTpw48eXLF0Im6+vrPTw8JL1ra2uLzaSzZ8+SV2Rvb//gwYMdO3Yohu8DBw6gFX/58sXKygpPwGKxoqKiCGe6UCg8d+7cuHHjFMOKIqCrqxsREQEqVMCBcuzYMbxqC8XRo0dRMg6H06fm+OfPn6PMEVp6zczMIOUohtzc3K/WB1ZLS2vfvn08Hg/P9ps3b8aOHYt/RU1N7c2bNyiNTKfwHkFPTw/dq3fv3o1/6uzsjLqJQaisrASNZV8tzMzMLl++jOe/o6OD0CY8fvx41AYeHBwsR3XyzBpXV9eCgoL09PQff/xRLBaDj1atWpWYmAipc0Ui0d69eyMjI7u6uuSoDoO2traJiYm+vr66urqGhoaamhr4tLW1lcvlcrncz58/f/jwAa9FkAnz589PSEgYPHgw+CM65lDxE/zd09Pz6tWrFy9e7KM4g6CgoNLSUvzBKyQkBG9ofPv2LckZSRJYLJaNjY2vr+++ffuysrJevnwpaZ8khEAgqKqqun79ekJCQmBgoJOTkxwum3p6erm5ufjCk5KS8AeHwMDAkpISWauQEzExMcOHD4d+DAsLw/N67tw5KacuAOrq6p6env/6179u374NnnEVAgRBqqqqMjIyVq9ejWdeEuh0+tatW/EqncTERPyWm5SU1EsSDAy8fO/v7w+NfaFQ+I9//INKaebm5hs2bMjLywP1er2NmpqaY8eOSdJxQfDy8sLPvz179kBkmpqafWxY/W84OTlBNusvX754enqSv6WiouLn5/fo0aM+a3RCFBcXBwYGSm04W1tbyDcCQZA5c+YorhXlhYaGBmSoa21tJV/0tbS0du7cyeFwhELh1xAp1tbW1t7efvjwYXLNnaWlZWNjI/QiRWVfL+LkyZMgTzwez8nJSRIxg8EIDAxMS0sLCwubNm2amZkZ3gWz77FgwQIrK6s1a9acPn16z549khxGaTTa6NGjIS+KfvYRGjt2LCjrIghC3XtywIABDx486PPWJgCPxwM1oOSqkWnTpgkEAvB1b2/vHjViT3D16lWQlaNHj1J8kcFgoMqprwQtLS3U5djg4GDw3crKyl5XZ+no6Pj6+kI/jho1Cjz51NfXg24K5Dh8+HCfN7IUNDQ0DBkyhCL/2dnZ4LuzZs2CCBYsWEDxiCUFdDrd39+fw+Hk5uZCj/bv3w8yQeL+D2Hz5s3oKzwery/zQ0hFaWkpxXPk8OHDQbMSXh8cHh6OxsENHDiQYrMQYPLkyU+fPkXrgDqATqe/e/cO46CiokJqIBUKJyen1NTUVatWoQYATU1Nd3f3nTt35uTkULFYKQrV1dXp6ek//fTTpEmTBg0aZGlpuXTp0qSkpKNHjyorK1P5kJSUFKw0BEEgZ5Pw8HD0UWNjo7+/P+UmB2Bubg5aUaAOsLS0BL8nJCREnjqIKvX394+Li7t//75Uy6VM6O7u/uOPP+Li4vz9/ak7CJHA3t4eLB86fWAdgGLZsmWSypEoOltbW5OY2VxdXcE/f/vtNxl4l4zq6urq6mrUM1BDQ8Pe3t7R0dHe3n7KlClyCJkNDQ0PHz589OjRo0ePiouLu7u7FcIkiidPntTV1WE+CS4uLr/++qskYkkxIGSYM2cO2IfQDAAdxGpqamQuXUaoqKisWrWqpaWF4njPysqytbXtba7S0tKwGl+9egU+gmbAvn37JBUi5/kJ1GdR92OUG11dXadOnbKxsZHqNtLW1rZixQovL68+4ApUf0J7AATx39XXIOTsAHAZff/+vXyFyIq6ujo3N7egoKDOzk5CgqysLCsrq+Tk5L7hp7a2Fvu/uro6ZJ8AofgOALcH1NOxbyAWi+Pj4wn9fAsLC318fBoaGvqMmfb2dvBPkng3eTqA3MQMntX6PiMk6lkGAfWU6ks2oA8n8elX/AwAjY498QYYOHDglClT8KI8m8329vaWZN8gNPKQfKSlpSWho9Xw4cOnTp0qC79/AyT6UJSEIChAidGTDhgwYMCtW7cyMzPBqAIdHZ0bN27s2bNHkts3YQeQsGFjY/PixQtIm+Li4lJaWipTlAsEyPRNohEiGRx9YkKj0Wg0mrOzM+pKBv7Y0NAQExMTFhb29OnTxMTEhoaGcePGBQYGDho0CK9gwUAoE5B0wMWLF9evX5+amurk5JSZmUmn02fNmrV27drq6urY2Fg8vYODQ3FxsVQXAmiCytcBEjF37lwSOeDz58/YI7xxjhA5OTnZ2dmEcb9hYWFg0qwPHz7Mnz+fRqNZWVkR+ugtWbIEf/Y/dOgQnvLbb791c3Oj0+kaGhoXL14EVU/Xrl3Dnx0ZDEZoaGh3d7ckTywQ8+fPBxmYPHky9giSA0jyTEicAdCAIhlf1JegmTNnlpSULFmyBAwCZDAYkZGRR48enTJlirGxcV1dXWFhoZGR0blz57y9vSdOnIgvh/oMKC8vLykpaW5uDggIWLBgwfDhwydOnKiurl5UVFReXk6n05lMJraXGhgYpKWlubu7U/wo6ksQCeTcA8A5RbED0FeMjY1v3bq1a9cudMtiMBgNDQ2pqak+Pj58Pv/58+dGRkYnTpx4+fLlokWLdu3aBUmYKKjvAU1NTf7+/lZWVg8ePMjPz3d3d3/37l1tba2VlVViYmJ9fT2W+8HDw6OkpARtfYqgvgkrfg8AS6QYJoiByWRGRES4urr6+fk1NjYaGhr6+/vjVYaPHj0iXKBpNJqqqurTp0/Lysq4XC6DwdDV1R06dOinT58IiW/fvh0dHb1t2zY3Nzf8lquurq6kpLRjx46dO3fKOoShZiUZiIrvALAyinIAxISLi0txcbEkNWFnZ+eyZcvQRBw+Pj4DBgxISUnBnu7cuVOqm/HEiRMnTZp07ty51tbWf/7zn9OmTbO3t8eT2djYREZG4h9RmdbQh5MMRMULYmCJFLd4PNmgQYOys7MJibdv366trZ2YmPj+/fuzZ89Cih0qNZaUlGzatOn9+/epqamOjo5+fn6Q4Iri0KFDhB1DBVAHkHCleEEMBMUliJAJwm4WCAQBAQGPHz9et26djo5OXl5eWVmZrFyJRKI9e/aoqqqi0dW5ubmg6kYqqMwASEzptw6QbwkiAYvFwlzYBQLBzz//LB9jGRkZlZWV6P8tLCysra0pvigWiyXJgCCoL0EkUMApiGLFFy5ckFVrJBAIli9f/uLFC+j3QYMGxcTElJaWNjQ0fP78uby8PDY2FsxBiUIkEq1evVoOXeGVK1eoXEFDpZNQyCOIzZ49GxQlILsz6Ke3bds2imW6ubkRJuohRF1dHaGiZurUqaA5GgOfzw8JCcGfZIYOHXr//n2KlSIIEhcXR/GyGi8vL/BdUGSBBDGSJpI4A6CBA/Uh6H1PXRC7efOmra3to0ePpFJevnx5/Pjx9+7dA3+k0+kbN268efMmYeyqiopKTEzMzZs3DQ0Nwd9ra2tdXFwiIiKkzr/29vaFCxdu3LiRYmwB1E8kK4E8q9OECRNIZgCYmW/Xrl0ylaykpBQVFSVpDHZ2dm7cuBH/liRvfTw4HA6hPOXq6trQ0CDprVevXllaWsr0IT/88ANYAhjoCc0A6jk9/hdqamqgvzjUAcXFxdijgwcPgo8o+sj7+vrifb5LS0sJ41WnTp1K0nZ4CIXC8PBwvGiqp6eXmZmJp09PTyexZ2GAEsGsXLkSLASceVAHyBkWl5iYKKkDbt68iT2CTID6+vqpqalUMg6NHj0azAuZlpaGfwtdduRzUSkoKICWIxT+/v5YAIhAIAgNDZXKKp1O37RpExTxAMWkgN0DdoB8OUxoNBqNzWZjAflQLPzZs2exCvBh8h8+fCgtLaXii6GhoXH+/Hkej0eYDJ/6siMJHA6HMJu2jY1NSUlJdXW1o6OjVCa1tLQuXrwoFounTZsG/p6QkIBVBBnpsA7gcrnUA3KI60Zzq0IzYN++fVjd+LwG6Kmjra0N71GKB51OJ3QpsLOzg3LAygeRSBQVFUWoKaNiw5o8eTIaAIEPcr9y5QpWCyQqoh1QVFQkNeUBJZiamkIjZfXq1VjdfD4fWvfBoIGkpCRZ74nqybIjCZKWI6lsYME/+HH2+vVrrPwLFy6Aj6ytrcePHy9TdbLBxcUF/DwoWN7BwQE0fZSVlVHfhfT09Ajz+PcckpYjQgwcOBBygd6/fz9IwGazwfAewiSpvQgdHR3QNx0fl7FhwwawD9rb26nEbowfP76+vr43Wh+FUCikknPVyckJzOCFIEh0dDS0Xtna2oIlS82uoXiA0UWEiZdnzJgBhcyfPn2a/HQErqqScPz4cRMTk3Hjxs2cOXP58uWhoaEBAQGurq76+voLFy6EwgXxaG9vJ1n68atfW1sbah+FsH79erBYcs+4XkFGRgZWvaT7ZExMTLBERShevXpFmHQBRX5+PnnzZWdnk++cUEI3QkhKeotf/crLyyXtoui5CIUkW1DvYvny5SCvFhYW4FNsW1ZSUoqOjgbXqy9fvkhymQfFCzyeP39OxUc6JiaGvAMIR+u3334LyXopKSnY8QFSMdHpdFAb9vvvv1NpMQXDxMQEZPenn34Cn86ZM+fAgQNYTsKZM2dC8YXJycn45YikA7q6ukjiF0EwGAzCm6kkdQB+2QHVIQwGY+PGjVDg7aRJk8ACqd/opWCUl5djTED559TU1Do7O8vKyrAFZ8iQIQ8fPgT5fvnyJXSLy61bt0ga7v79+1jCThIsWrSIJEEX1AHKyspZWVng0+LiYkyEHDp06L1790QiERT+Bk4yfHhM3wGMtePz+ZDPD5rtms/nb968GZ3CLBYrJiYGXI6g9MDkI1csFldVVZGcaOl0OhqcRV4I2F4+Pj5gU8bHx2MahR9++AFN4ZSTkwPVAkqIxcXFPW9JOQEmThSLxUFBQeBTLS0tbEkpKCjADCZeXl6YXxcUVSK1A8Ri8efPnyGVAAo1NTXCPD/kHYDtZDweb+HCheiPmpqaqamp6O/l5eVQ9KSdnR1YGppruH/AZDLBjQtvuWWxWJGRkajA0tzcjGkmJk6ciEoJcnSAWCwWCASBgYHgi8bGxn/88QeVdyV1AKZoc3BwwC6WO336ND7PDZauDUUfhOKQITIyEuSGMDjW2dkZu6jq7NmzaJ5qNCu3fB2A4ujRo6ampqqqqvPnz5cpxzdhB4wYMYLJZKJ+iWKx+OPHj7Nnz8Z/i4qKClhXaWmpoltURlhYWIBrblJSEiGZpqbmr7/+itI0NjbOmDEDNStCHYAl1+xVgB2wbNky9MfvvvsOE1mys7MlRVuASjCxWAwmLu83YInZxWIxn88nudtj2bJlaHo1BEHQdSk9PR0k6McOQPnh8/nBwcGSjKx0Oh08+HV2dqKzuSeQxzNu2LBhYGTkL7/8glnPVVRUtmzZgrcpMhgMBEFSUlIKCwvT09Pt7e1RgVaO2ILa2lr0FGhvb29ubs5kMt+9e1dUVPTp06c5c+YQrhskEP+PrZvJZFZUVCxevJgkum/GjBmgYHz58uXm5mbsTxMTEy6Xy+fzZfwgWWBhYZGXl1dfXw+GKCkrK4MatM7OTgMDA+hFBwcH7DI9VDZGiTMyMkCyO3fukA/eCxcukA86Dw8PqZnwwRmwdOlS9Me7d+9ih30zMzNCDQQ418V/90en0WiZmZlVVVW9pZVTVVUNDw/HrMQ//vgj+DQoKAjk7MiRI/gS9u/ff+zYMewjUf8UKOEs9IUgOBwOxdGNGpEodoC/vz/6I5othU6nr1u3LjExEV8sFDABOVWOGjUK0/5mZWURXhMqP7y8vKDMSmVlZeDqwWazwTuzhUIhPjEuk8k8fvx4XV3djBkzaDQaen6l2AEXL16U9UY3T09PSZptwg4YPHiwubl5QUFBfn4+XkfCZrOhxGDQee/UqVPg046Oji1btlDxT5BOsWXLlujoaOjHsWPH2tvbY/cK8Pn82NhYzGTBZDLj4+OdnZ3FgDeRSCQKCAgIDw/Pyck5c+YMRecnGo3W1dU1bNgwkgzVkkBlOcY43LBhQ3BwcG5uLnoJNUS2efNmcFBnZ2eD91kPGjQIsnaoqqpGR0crKSnt3btXVrZhoHekgN0rEokOHDgAtSCbzYauBYaWKQyzZ8/GEqNAMwDMR957AGcAmntWLBYLhcJdu3YRhgiYmpqCHjQIguCv9FyzZg0+1WZAQICcjQ4B9IFAT/GEZN7e3mD1zc3NknLaDRkyBD10nzt3Dvy9vzqAxFqppKQEeTZKSsphaWlZWlqKkXG5XCqBZpRgaWmJ7jAXLlzQ1dUloYQMGoWFhZLWQSUlpfDwcOgUBFlv+qADFi9enJeXRxLkDon6ra2tJJd6sNnsuLg4VDKl4m4kA1JSUqj4mFhYWED+bhEREST0kKcCxRnQ0dFRVFSUnJwcGxsbFRWVmJh49epV6gkYwQ7Q1dUliUxyc3ODcnqtW7dOaiN4e3u/fv1ajmTJ8kBTUxO6CQoS1kUiEaFNlRDkM6CrqysjI8PDw0PS3VMjR47csWOHVCdGiur7oUOHQolCb9y4AUmOko6bfZTD2NDQ8NmzZ5C/Bo1Gg9TC5MlEQeTl5RE2GYIgZ86cwUcAEILFYm3YsEFSArTu7m4qfkoGBgYVFRXgi01NTVDPubu783i8uXPnUuFK8bCyskJ1nCKRCFLQDxw4EBqGXC6XimuQlZUVejUEiA8fPkja9klgYGCAd2vk8Xgk2cMw6OjoQBeciUQiiAdtbW1UzhAKhfI4P/cQrq6u4IUfDQ0N0OY8ceJEaDNobGwk8YfAwGazwbtPXrx4IXeKNzqdDvrBP3/+nIq3mrq6OmQ6FYvFO3fuhMhApxAEQTZv3iwfk/LA19cXn+kcMi7SaLTvv/8eEiA+f/5MxRmWRqO5urrW1tYWFxf3XN24efNmgUAQHR1NJR2ikZERligSQ0ZGBrT0Q0Z5FOTHDYVBW1sbn7utra0NL5vQcDoilJLieqKlpdXDC+UxULwNztbWFr+B37hxg7Dnjhw5AlEiCEI99WuPsHDhQrDirq4ukrueQkND8YxGRUX1MN0vk8kcM2aMs7Pz999/b2tr2/OJMmPGDDBhCIrCwkJJwhSdTk9OTgaJExISesiDDMBs1iKRCLNlS0JQUBDeUyEnJ0e+rLITJ05MS0uDvIyEQuHdu3dXr14tx/lPTU0tPj4ez2FBQQF52AyLxcIEz8rKSoXJvVSgpqaG3tBGGM+Fx6pVq/BXBXA4HCrCHQYtLa309HRyr5PXr19TuQwSg4uLC2aCB3H+/HkqN90OGDCgsLBQIBDIHW4vPyZMmCApYcO8efPwpi43NzfC661yc3OpXINgbm4OmgNJ0NXVRcUFWkdHJyEhAd+dCILs378fv0LOnTuXUA2jq6tLpbq+w7p168Ri8fHjx/F9YGJiQnjBW1dX14kTJ0i2Sh0dncrKSiqtjzUiiXykpqYWGhoK5pzC0NraumDBAvwrCxcuFAgE2dnZfXpdnhyws7PDTqgnT54kzMYXFxdHmDS9o6PjwIEDhHoxyHuQClpaWvCSM5vNDg4Ohm6DwVBUVETofoq2PkpDccntH+jp6WH+PyiSk5MJd0UHB4eysjLCVujs7ISMG25ubrK2PgrIR2bw4MGS1ERfvnwJDg4mdHxftmwZuHt1dXURJvHqfzAYjOvXr+O/LT8/n1AvyGKxwsLC2tvb8a9AyjsSXxUej4f6uTA7QrgAAAKeSURBVBBCIBCAPjIMBoNw2fn9998lbUKhoaH4TaKqqqp/rqsix88//wwx+unTJ1SqfPLkiSSF+8CBA8PDw8FGRBAEvEBQT0+P8KalhoaGOXPmoFa5MWPGEIZfi8Xi1atXg9VBd648ePBAUt5QFot1+vRpsVhcUVGBHwGHDx9WXMspCAYGBpAebeHChSwWa/fu3QKBoLq6msSH0sDAIDY2Fu2G8vJy8BEk9KH4/PkzpAem0+lgyAoGyOKGXt4hEokyMzOhDPwQP6iT5Pnz5zU1NQ0NDUHdanNzM2Hu5P6Hnp7en3/+if9yOzu7srIyHo+3cuVKktc1NDQCAgKguyDwE0ssIQukqakpfrmArga3traOiYkhD/SYPn16Y2Pjp0+fQL2pr68vWiCHw5kwYQJZK/QvtLW1Hz582NjYCEm5LBZr+/bt7e3thP7GJIBuqkGB+XhBgDT4Ylxaf3IoKSlFRER0d3efOnUKL6Vfvny5rq5OnqsY+hjq6uoODg6Ej9AVv6SkhCQrLoQdO3bgO0DSwg1GTqOgkhoHxeTJkx8/fnzixIkRI0YQEgwePFghd5/0P9TU1NasWbN9+3Zy+z6KVatW4Ttg69ateEoDAwP8dn358mWpVSgrK3t4eKxYsUJRytd/G1DxzbKyssJ3wPv37/GNlZSUhKdU1O1C/69BqCwrLi7G8itpaGjExcXhacRyJ+r5D0DgrTooEAQpKyt79OiRpJhIfB6d/0AeqKioQE6PVCAQCL7q8+K/F8aNGyfTnfJiIOjuP1AMPDw88CZDSYDS2P0HisGYMWPwLgsQWlpa+sFL5/8P6HT6/Pnz8/Pz8Wlpamtr9+/f36PbS/sDX7d9RzI0NTVtbGyMjY3V1dU/fvxYU1ODz3D8b4H/AgzSMHzIaCzLAAAAAElFTkSuQmCC", G = /* @__PURE__ */ new Set([
  "eth_chainId",
  "eth_accounts",
  "net_version",
  "wallet_getCapabilities",
  "wallet_getPermissions"
]), U = /* @__PURE__ */ new Set([
  "eth_blockNumber",
  "eth_call",
  "eth_getBalance",
  "eth_getCode",
  "eth_getStorageAt",
  "eth_estimateGas",
  "eth_gasPrice",
  "eth_getTransactionReceipt",
  "eth_getTransactionByHash",
  "eth_getTransactionByBlockHashAndIndex",
  "eth_getTransactionByBlockNumberAndIndex",
  "eth_getTransactionCount",
  "eth_getBlockByNumber",
  "eth_getBlockByHash",
  "eth_getBlockTransactionCountByHash",
  "eth_getBlockTransactionCountByNumber",
  "eth_getLogs",
  "eth_getProof",
  "eth_feeHistory",
  "eth_maxPriorityFeePerGas",
  "eth_blobBaseFee",
  "eth_protocolVersion",
  "eth_syncing",
  "net_listening",
  "net_peerCount",
  "web3_clientVersion",
  "web3_sha3"
]), X = /* @__PURE__ */ new Set([
  "eth_requestAccounts",
  "wallet_requestPermissions",
  "eth_sendTransaction",
  "eth_signTransaction",
  "personal_sign",
  "eth_sign",
  "eth_signTypedData_v4",
  "wallet_switchEthereumChain",
  "wallet_sendCalls",
  "wallet_sendSetCodeTransaction"
]), Z = /* @__PURE__ */ new Set([
  "wallet_getCallsStatus"
]);
function M(e) {
  if (!e.startsWith("0x"))
    throw q(`expected 0x-prefixed hex: ${e}`);
  return BigInt(e).toString(10);
}
function x(e) {
  async function a(n) {
    switch (n.method) {
      case "eth_chainId":
        return e.get_active_chain();
      case "eth_accounts":
        return e.get_accounts();
      case "net_version":
        return M(e.get_active_chain());
      case "wallet_getCapabilities":
        return e.get_capabilities();
      case "wallet_getPermissions":
        return e.get_permissions();
      default:
        throw d(n.method);
    }
  }
  async function t(n) {
    if (n.method === "wallet_getCallsStatus") {
      const o = n.params?.[0];
      if (typeof o != "string")
        throw q(
          "wallet_getCallsStatus expects [batch_id]"
        );
      return e.read_calls_status(o);
    }
    throw d(n.method);
  }
  return async function(r) {
    if (G.has(r.method))
      return a(r);
    if (U.has(r.method))
      return e.rpc_call(
        e.get_active_chain(),
        r.method,
        r.params
      );
    if (X.has(r.method))
      return e.forward_to_popup(r);
    if (Z.has(r.method))
      return t(r);
    throw d(r.method);
  };
}
const P = {
  id: 1,
  rpc_url: "https://ethereum-rpc.publicnode.com"
};
let k = P, u = m(P), i = [];
async function H(e) {
  const a = Number.parseInt(e.slice(2), 16), t = await S(a);
  if (!t) return;
  const n = m(t), r = n !== u;
  k = t, u = n, r && f.emit("chainChanged", n);
}
function A(e) {
  const a = e.length !== i.length || e.some((t, n) => t !== i[n]);
  i = e, a && f.emit("accountsChanged", e);
}
function C() {
  return i.length === 0 ? [] : [
    {
      parentCapability: "eth_accounts",
      caveats: [
        {
          type: "restrictReturnedAccounts",
          value: i
        }
      ]
    }
  ];
}
async function R(e, a, t) {
  const n = Q(k.rpc_url), r = N(W, [a, t ?? []]), o = await n(r);
  if ("error" in o)
    throw {
      code: o.error.code,
      message: o.error.message,
      data: o.error.data
    };
  return o.result;
}
function w(e) {
  return new Promise((a, t) => {
    const n = crypto.randomUUID();
    window.addEventListener(
      "message",
      function r(o) {
        const l = c(
          y,
          o.data
        );
        if (!l.success) return;
        const s = l.output;
        if (s.id === n) {
          if (window.removeEventListener("message", r), "error" in s) {
            t({
              code: s.error.code,
              message: s.error.message,
              data: s.error.data
            });
            return;
          }
          a(s.result);
        }
      }
    ), window.postMessage(
      L({
        id: n,
        method: e.method,
        params: e.params,
        chainId: u
      }),
      window.location.origin
    );
  });
}
async function V(e) {
  if (e.method === "wallet_requestPermissions") {
    const t = await w({
      method: "eth_requestAccounts"
    }), n = c(h, t);
    return A(n.success ? n.output : []), C();
  }
  const a = await w(e);
  if (e.method === "eth_requestAccounts") {
    const t = c(h, a);
    A(t.success ? t.output : []);
  }
  return a;
}
const K = x({
  get_active_chain: () => u,
  get_accounts: () => i,
  get_capabilities: () => T(),
  get_permissions: C,
  rpc_call: R,
  forward_to_popup: V,
  read_calls_status: (e) => E(e)
}), f = Y({
  request: K
});
window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  const a = c(
    v,
    e.data
  );
  if (!a.success) return;
  const t = a.output;
  if (t.method === "chainChanged") {
    const n = t.params, r = Array.isArray(n) ? n[0] : void 0;
    typeof r == "string" && H(r);
    return;
  }
  if (t.method === "accountsChanged") {
    const n = t.params, r = Array.isArray(n) ? n[0] : n, o = c(h, r);
    o.success && A(o.output);
    return;
  }
});
z({
  info: {
    uuid: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    name: "Ethernauta",
    icon: b,
    rdns: "com.ethernauta.wallet"
  },
  provider: f
});
