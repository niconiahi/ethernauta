window.wallet = {
  sign: async (t, e) =>
    new Promise((o) => {
      const s = crypto.randomUUID()
      window.addEventListener("message", function i(n) {
        n.data.type.startsWith("ETHERNAUTA_RESPONSE") &&
          n.data.id === s &&
          (window.removeEventListener("message", i),
          o(n.data.signed_transaction))
      })
      const a = {
        type: "ETHERNAUTA_REQUEST_SIGN_TRANSACTION",
        id: s,
        method: t,
        params: e,
      }
      window.postMessage(a, "*")
    }),
  connect: async () =>
    new Promise(() => {
      const e = {
        type: "ETHERNAUTA_REQUEST_CONNECT",
        id: crypto.randomUUID(),
      }
      window.postMessage(e, "*")
    }),
}
