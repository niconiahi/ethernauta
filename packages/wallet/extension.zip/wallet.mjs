window.wallet = {
  sign: async (t, o) =>
    new Promise((i, E) => {
      const e = crypto.randomUUID()
      window.addEventListener("message", function s(n) {
        if (
          n.data.type.startsWith("ETHERNAUTA_RESPONSE") &&
          n.data.id === e
        ) {
          if (
            (window.removeEventListener("message", s),
            n.data.type ===
              "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED")
          ) {
            E(new Error("Transaction rejected by user"))
            return
          }
          if (
            n.data.type ===
            "ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE"
          ) {
            E(new Error("Extension closed"))
            return
          }
          i(n.data.signed_transaction)
        }
      })
      const r = {
        type: "ETHERNAUTA_REQUEST_SIGN_TRANSACTION",
        id: e,
        method: t,
        params: o,
      }
      window.postMessage(r, window.location.origin)
    }),
  connect: () => {
    const t = {
      type: "ETHERNAUTA_REQUEST_CONNECT",
      id: crypto.randomUUID(),
    }
    window.postMessage(t, window.location.origin)
  },
}
