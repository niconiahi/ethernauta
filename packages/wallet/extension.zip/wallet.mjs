import {
  c as Dt,
  t as ft,
  o as j,
  a as J,
  b,
  n as Pt,
  s as y,
  p as L,
  u as H,
  d as st,
} from "./assets/index-DutXGR0P.mjs"
const C = {
  USER_REJECTED_REQUEST: 4001,
  UNSUPPORTED_METHOD: 4200,
  UNRECOGNIZED_CHAIN: 4902,
  INVALID_PARAMS: -32602,
}
function Z(i, t, e) {
  const n = new Error(t)
  return (n.code = i), e !== void 0 && (n.data = e), n
}
function R(i) {
  return Z(
    C.UNSUPPORTED_METHOD,
    `method not supported: ${i}`,
  )
}
function Tt(i) {
  return Z(
    C.UNRECOGNIZED_CHAIN,
    `unrecognized chain id: ${i}`,
    { chainId: i },
  )
}
function ht(i) {
  return Z(C.INVALID_PARAMS, i)
}
function qt() {
  const i = /* @__PURE__ */ new Map()
  return {
    on(t, e) {
      const n = i.get(t)
      if (n) {
        n.add(e)
        return
      }
      i.set(t, /* @__PURE__ */ new Set([e]))
    },
    removeListener(t, e) {
      i.get(t)?.delete(e)
    },
    emit(t, e) {
      const n = i.get(t)
      if (n) for (const r of n) r(e)
    },
  }
}
function kt(i) {
  return (
    typeof i == "string" &&
    /^0x([1-9a-f]+[0-9a-f]*|0)$/.test(i)
  )
}
const dt = Dt(kt),
  Ot = j({
    chainId: dt,
    chainName: y(),
    nativeCurrency: j({
      name: y(),
      symbol: y(),
      decimals: Pt(),
    }),
    rpcUrls: b(L(y(), H())),
    blockExplorerUrls: J(b(L(y(), H()))),
    iconUrls: J(b(L(y(), H()))),
  }),
  It = ft([Ot]),
  Ut = j({
    chainId: dt,
  }),
  Qt = ft([Ut]),
  Bt = /* @__PURE__ */ new Set([
    "eth_chainId",
    "net_version",
    "eth_accounts",
    "wallet_getCapabilities",
    "wallet_getPermissions",
  ]),
  Wt = /* @__PURE__ */ new Set([
    "wallet_switchEthereumChain",
  ]),
  bt = /* @__PURE__ */ new Set([
    "wallet_sendCalls",
    "wallet_getCallsStatus",
    "wallet_showCallsStatus",
  ])
function Lt(i) {
  const t = st(Qt, i)
  if (!t.success)
    throw ht(
      "wallet_switchEthereumChain expects [{ chainId }]",
    )
  return t.output[0].chainId
}
function Ht(i) {
  const t = st(It, i)
  if (t.success) return t.output[0].chainId
}
function Rt(i) {
  if (!i.startsWith("0x"))
    throw ht(`expected 0x-prefixed hex: ${i}`)
  return BigInt(i).toString(10)
}
function xt(i) {
  const { on_signable_request: t } = i,
    e = new Set(i.chains)
  let n = i.chains[0] ?? "0x1",
    r = []
  const a = qt()
  function o() {
    return {}
  }
  function c() {
    return r.length === 0
      ? []
      : [
          {
            parentCapability: "eth_accounts",
            caveats: [
              {
                type: "restrictReturnedAccounts",
                value: r,
              },
            ],
          },
        ]
  }
  function v(u) {
    u !== n && ((n = u), a.emit("chainChanged", u))
  }
  function l(u) {
    const d =
      u.length !== r.length || u.some((p, W) => p !== r[W])
    ;(r = u), d && a.emit("accountsChanged", u)
  }
  async function m(u) {
    switch (u.method) {
      case "eth_chainId":
        return n
      case "net_version":
        return Rt(n)
      case "eth_accounts":
        return r
      case "wallet_getCapabilities":
        return o()
      case "wallet_getPermissions":
        return c()
      case "wallet_switchEthereumChain": {
        const d = Lt(u.params)
        if (!e.has(d)) throw Tt(d)
        return v(d), null
      }
      default:
        throw R(u.method)
    }
  }
  async function w(u) {
    if (bt.has(u.method)) throw R(u.method)
    if (Bt.has(u.method) || Wt.has(u.method)) return m(u)
    if (!t) throw R(u.method)
    if (u.method === "wallet_requestPermissions") {
      const p = await t({
          method: "eth_requestAccounts",
        }),
        W = Array.isArray(p) ? p : []
      return l(W), c()
    }
    const d = await t(u)
    if (u.method === "eth_requestAccounts") {
      const p = Array.isArray(d) ? d : []
      l(p)
    }
    if (u.method === "wallet_addEthereumChain") {
      const p = Ht(u.params)
      p && e.add(p)
    }
    return d
  }
  return {
    request: w,
    on: a.on,
    removeListener: a.removeListener,
    emit: a.emit,
    set_active_chain: v,
    set_accounts: l,
    get_active_chain() {
      return n
    },
    get_accounts() {
      return r
    },
    add_chain(u) {
      e.add(u)
    },
    has_chain(u) {
      return e.has(u)
    },
  }
}
const jt = "eip6963:announceProvider",
  Yt = "eip6963:requestProvider"
function zt(i) {
  const t = Object.freeze({
    info: Object.freeze(i.info),
    provider: i.provider,
  })
  function e() {
    window.dispatchEvent(new CustomEvent(jt, { detail: t }))
  }
  e(), window.addEventListener(Yt, e)
}
const Gt =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAIAAABMXPacAAAABmJLR0QA/wD/AP+gvaeTAAAgAElEQVR4nO1deVxM6/+fpanRXpI2SWSphNByc1XULZfK7ko3O8mVvnSF8C1fUUJSssRtcct2cdNCIkuWcK8WhOqWFjJM2tRMzcyZ3x/n9zu/5z7nzJkz01S+v9/3/YeX5nzO83zOs3/Wh077N4GKioq5ubmJiYmxsbGpqamBgQGTycSe8ng8LpfL4XA+fvzY2Nj48uXLjo6OfuSWOuj9zQAZxowZ4+joaGdnZ2dnZ21tzWKxKL6IIEhlZWVpaWlJScmdO3eePHkiEol6ldX/O2AymVOnTj148GBVVZVYQWhqajp79qy/v7+urm5/f99XDDMzs3379nE4HEW1Ox48Hi89Pd3V1ZVO/6qnfl/D09MzOztbJBL1XtNDqKioCAoKYrPZ/f3p/Q0nJ6c7d+70WbtD4HA4oaGhAwYM6O9m6A/Y2treuHGjv5oeRH19/ZIlS/q7PfoQAwYMiIqKEgqF/d3yf8OdO3dGjx7d323T+3B3d//rr7/6u7WJ0dnZuXXrVgaD0d+N1DtgsVixsbEIgvR3O0tBfn6+vr5+f7cWKWxtbUeMGCHTK4aGhvfu3SP84FevXrW2tvZxK6PIy8sjPHq9e/fO2dlZpg/U1tZ2dHTsi2PV6dOnxWKxSCRas2YNxVecnJzev3+P/86mpqa1a9cyGIzq6upeb2wiGBsbT5gwoaCgAP9IKBSuXbuW4gdaW1t/+vRJLBa/fPlSQ0ND3qalAGNjY4zFv/76i8orM2fO7OzshD4PQZC0tLRBgwahNP3VASYmJigDCxYs4HK5eIKoqCgq35icnIy90rsHKi0tLT6fj9b05MkTqfR+fn7d3d3QVzU0NLi4uIBk/bUtm5qaYjwYGRnl5OTgaU6cOAFq/Qhx5MgRjP67776Tq2kpw9fXt6qq6smTJxMmTCCnDAwMxK+wWVlZenp6EKUC1T4yYejQoSAbdDo9LCwMfz7+5ZdfyFUXenp6V65cefv27aFDh74WJYevry904EEQZNu2bYT89VcHDBs2DM/M9OnT8cvR4cOHe7/NFAd3d/euri7wA/h8/uLFiyXR19bW9mGz/y/Mzc0J+Rk9evTbt28h4vDw8N5qL8XC1ta2ra0NZL2lpQVa9EH4+Pj0l3Bw8OBBJSUlQq6MjY3Lysogej8/v95qNUVBR0enpqYGZLqjo+Pbb78lJNbV1T1x4kT/imaPHz8eNWoUIXt6enovXrwAiXk83qRJkxTbYorcMeh0emZmppeXF/YLn8+fNWvWrVu38MQzZsxISUmhInNyudzy8vKampp3795xOJz379+3tLTw+XwejycQCEQiEZvNZrFY6urqqqqqhoaGBgYG+vr6w4YNGzVqlJmZmVTVQmdnZ0hIyLFjx/CPUPkRlDrfvn07efJkLpcrle1+QEhICDheRCKRj48PnozBYOzdu5dk4HM4nCtXrmzevNnZ2Rl/ZJIJbDZ73LhxS5cuPXny5IsXL0hMDsePHydcjszMzCAb0dWrV3vCUm9hwoQJ0JE/LCwMT8Zms3/77Tf893d3d9+8eTM4OLhXVZI6Ojrz589PSUn5+PEjnodr164RyrFTpkyBzhRLly7tPSblAYPBKCoqAlm8dOkS/sSprKwMCTtCoTA3N3fx4sVaWlp9zLCjo2N8fDx04iwsLFRVVcXTr1q1CiRrbm42NjbuFc7i4+Pb29tXrlwp01vr1q0D+auoqFBXV4doGAwGOPYrKiq2bNliZGSkON7lgbKy8pw5c0CDaE5ODqH7xZkzZ8BvzMzMlKmixYsX83g8KcsXg8FAl5G7d+9SL3rw4MHNzc3goP7mm2/wZHv37kUJ7ty54+3t/bWp3UeNGnX8+HFUbZWWloYn0NTUhHRWbm5u1MvHzH/Qrva3bUdJSQntfMJpKAm7du3S1tbG/oyNjX348CFE4+fnt3Xr1qysrIiIiD///JN64TQaTUdHZ/To0RYWFoaGhoaGhvr6+tra2mw2W1NTE6Ph8XjNzc3Nzc0tLS3v3r2rq6urq6urqqr6+PEjxVrevHkTEBCwY8eOTZs2BQUF3b9//+TJkyBBW1ubv7//3bt3saFz4MABW1tbBEGolK+iooL+h0xlraysjPbSs2fPKPJtYmKCqefEYvGbN2/wFTg6Ol6/fp1wWhBCT09v5syZu3fvzsvL+/Dhg7gH4HK5d+7cSUhI8PPzgzQ/JDAwMIiJiSE8Dhw/fhwsf8WKFRTLvHv3LvoKpoJFQVdVVfXz89PR0aHRaEwmMzIykkajNTY2xsXFoRSlpaXXr1+XVG5CQsL69euxP729vbOysiAafX19qSMR3RU9PT09PT1tbW17aYFqaGi4ceNGdnb2jRs3pPouslgsgUAA/airq/v69WtMkV5TUzNy5EihUEhYgoODw5QpU1Bl6tq1a1HV0759+1pbW2k0Wmdn54ULF2hxcXFSx9GUKVMIKzA2NgaHf35+viyt8d8YO3ZsdHR0XV1dT0a6rODxeJmZmfPmzcNWBupYsWIFWNSiRYsIyUaNGiXV8eDWrVu06OhociIEQezs7AjriIiIwMiEQqGNjQ31zxg8eHBISEhJSYncjagQNDU1xcfHjxw5kjrnTCbz5cuXWAlPnz4lJBs9erRUV7Pr16/TlZWV586di66PbDYb1flxudwDBw7QaLSurq6ioqKioiJ8BQwGo6amBrNpXLhwQdJYgGBmZhYSErJixQqKHlFcLre6urqmpqampqa+vp7L5ba0tLS2tra0tKBLBJvNRovS1dU1MjIaMmQI+q+1tbWZmRmVKhAEuXbt2qFDhwoKCqjQz50799KlS9ifU6dOLSwsxJN98803jo6OqIAdFBSEnrm3b9/e1NREo9G+fPkCL9fYJlxRUSGVCQ8PD6wnEQSRap+h0WhjxoxJTU3F28ggtLS0ZGVlhYeHe3l59VBQ0NXVdXNzCw0NvXjxYlNTk9QJcffuXUmqQxB0Ov3JkyfYW6dOnZL6SmFhIUpMdhag0+moiubNmzdSSzx//jzGwbVr18iJTU1NMzIyyKfks2fP9u7dO3XqVEkq4h6CyWQ6Ojru3r0b9VYn4eT69etjxowhL83T0xOjb21tlTqbb9++Lb0DaDQaqiS5f/8+eXFsNrujowPjQNIujVLu3r0bb5fHUFtbu2fPHplW4Z7D0NAwODj48ePHkrjq7u6OiYkhd3EAHW3mzZtHXuOlS5fEYjGCIKDMRIDAwMD79+/PnDmTvDh3d3dwvEgic3JyevXqFeEXIgiSnZ09ffr0/hWJbWxsTpw48eXLF0Im6+vrPTw8JL1ra2uLzaSzZ8+SV2Rvb//gwYMdO3Yohu8DBw6gFX/58sXKygpPwGKxoqKiCGe6UCg8d+7cuHHjFMOKIqCrqxsREQEqVMCBcuzYMbxqC8XRo0dRMg6H06fm+OfPn6PMEVp6zczMIOUohtzc3K/WB1ZLS2vfvn08Hg/P9ps3b8aOHYt/RU1N7c2bNyiNTKfwHkFPTw/dq3fv3o1/6uzsjLqJQaisrASNZV8tzMzMLl++jOe/o6OD0CY8fvx41AYeHBwsR3XyzBpXV9eCgoL09PQff/xRLBaDj1atWpWYmAipc0Ui0d69eyMjI7u6uuSoDoO2traJiYm+vr66urqGhoaamhr4tLW1lcvlcrncz58/f/jwAa9FkAnz589PSEgYPHgw+CM65lDxE/zd09Pz6tWrFy9e7KM4g6CgoNLSUvzBKyQkBG9ofPv2LckZSRJYLJaNjY2vr+++ffuysrJevnwpaZ8khEAgqKqqun79ekJCQmBgoJOTkxwum3p6erm5ufjCk5KS8AeHwMDAkpISWauQEzExMcOHD4d+DAsLw/N67tw5KacuAOrq6p6env/6179u374NnnEVAgRBqqqqMjIyVq9ejWdeEuh0+tatW/EqncTERPyWm5SU1EsSDAy8fO/v7w+NfaFQ+I9//INKaebm5hs2bMjLywP1er2NmpqaY8eOSdJxQfDy8sLPvz179kBkmpqafWxY/W84OTlBNusvX754enqSv6WiouLn5/fo0aM+a3RCFBcXBwYGSm04W1tbyDcCQZA5c+YorhXlhYaGBmSoa21tJV/0tbS0du7cyeFwhELh1xAp1tbW1t7efvjwYXLNnaWlZWNjI/QiRWVfL+LkyZMgTzwez8nJSRIxg8EIDAxMS0sLCwubNm2amZkZ3gWz77FgwQIrK6s1a9acPn16z549khxGaTTa6NGjIS+KfvYRGjt2LCjrIghC3XtywIABDx486PPWJgCPxwM1oOSqkWnTpgkEAvB1b2/vHjViT3D16lWQlaNHj1J8kcFgoMqprwQtLS3U5djg4GDw3crKyl5XZ+no6Pj6+kI/jho1Cjz51NfXg24K5Dh8+HCfN7IUNDQ0DBkyhCL/2dnZ4LuzZs2CCBYsWEDxiCUFdDrd39+fw+Hk5uZCj/bv3w8yQeL+D2Hz5s3oKzwery/zQ0hFaWkpxXPk8OHDQbMSXh8cHh6OxsENHDiQYrMQYPLkyU+fPkXrgDqATqe/e/cO46CiokJqIBUKJyen1NTUVatWoQYATU1Nd3f3nTt35uTkULFYKQrV1dXp6ek//fTTpEmTBg0aZGlpuXTp0qSkpKNHjyorK1P5kJSUFKw0BEEgZ5Pw8HD0UWNjo7+/P+UmB2Bubg5aUaAOsLS0BL8nJCREnjqIKvX394+Li7t//75Uy6VM6O7u/uOPP+Li4vz9/ak7CJHA3t4eLB86fWAdgGLZsmWSypEoOltbW5OY2VxdXcE/f/vtNxl4l4zq6urq6mrUM1BDQ8Pe3t7R0dHe3n7KlClyCJkNDQ0PHz589OjRo0ePiouLu7u7FcIkiidPntTV1WE+CS4uLr/++qskYkkxIGSYM2cO2IfQDAAdxGpqamQuXUaoqKisWrWqpaWF4njPysqytbXtba7S0tKwGl+9egU+gmbAvn37JBUi5/kJ1GdR92OUG11dXadOnbKxsZHqNtLW1rZixQovL68+4ApUf0J7AATx39XXIOTsAHAZff/+vXyFyIq6ujo3N7egoKDOzk5CgqysLCsrq+Tk5L7hp7a2Fvu/uro6ZJ8AofgOALcH1NOxbyAWi+Pj4wn9fAsLC318fBoaGvqMmfb2dvBPkng3eTqA3MQMntX6PiMk6lkGAfWU6ks2oA8n8elX/AwAjY498QYYOHDglClT8KI8m8329vaWZN8gNPKQfKSlpSWho9Xw4cOnTp0qC79/AyT6UJSEIChAidGTDhgwYMCtW7cyMzPBqAIdHZ0bN27s2bNHkts3YQeQsGFjY/PixQtIm+Li4lJaWipTlAsEyPRNohEiGRx9YkKj0Wg0mrOzM+pKBv7Y0NAQExMTFhb29OnTxMTEhoaGcePGBQYGDho0CK9gwUAoE5B0wMWLF9evX5+amurk5JSZmUmn02fNmrV27drq6urY2Fg8vYODQ3FxsVQXAmiCytcBEjF37lwSOeDz58/YI7xxjhA5OTnZ2dmEcb9hYWFg0qwPHz7Mnz+fRqNZWVkR+ugtWbIEf/Y/dOgQnvLbb791c3Oj0+kaGhoXL14EVU/Xrl3Dnx0ZDEZoaGh3d7ckTywQ8+fPBxmYPHky9giSA0jyTEicAdCAIhlf1JegmTNnlpSULFmyBAwCZDAYkZGRR48enTJlirGxcV1dXWFhoZGR0blz57y9vSdOnIgvh/oMKC8vLykpaW5uDggIWLBgwfDhwydOnKiurl5UVFReXk6n05lMJraXGhgYpKWlubu7U/wo6ksQCeTcA8A5RbED0FeMjY1v3bq1a9cudMtiMBgNDQ2pqak+Pj58Pv/58+dGRkYnTpx4+fLlokWLdu3aBUmYKKjvAU1NTf7+/lZWVg8ePMjPz3d3d3/37l1tba2VlVViYmJ9fT2W+8HDw6OkpARtfYqgvgkrfg8AS6QYJoiByWRGRES4urr6+fk1NjYaGhr6+/vjVYaPHj0iXKBpNJqqqurTp0/Lysq4XC6DwdDV1R06dOinT58IiW/fvh0dHb1t2zY3Nzf8lquurq6kpLRjx46dO3fKOoShZiUZiIrvALAyinIAxISLi0txcbEkNWFnZ+eyZcvQRBw+Pj4DBgxISUnBnu7cuVOqm/HEiRMnTZp07ty51tbWf/7zn9OmTbO3t8eT2djYREZG4h9RmdbQh5MMRMULYmCJFLd4PNmgQYOys7MJibdv366trZ2YmPj+/fuzZ89Cih0qNZaUlGzatOn9+/epqamOjo5+fn6Q4Iri0KFDhB1DBVAHkHCleEEMBMUliJAJwm4WCAQBAQGPHz9et26djo5OXl5eWVmZrFyJRKI9e/aoqqqi0dW5ubmg6kYqqMwASEzptw6QbwkiAYvFwlzYBQLBzz//LB9jGRkZlZWV6P8tLCysra0pvigWiyXJgCCoL0EkUMApiGLFFy5ckFVrJBAIli9f/uLFC+j3QYMGxcTElJaWNjQ0fP78uby8PDY2FsxBiUIkEq1evVoOXeGVK1eoXEFDpZNQyCOIzZ49GxQlILsz6Ke3bds2imW6ubkRJuohRF1dHaGiZurUqaA5GgOfzw8JCcGfZIYOHXr//n2KlSIIEhcXR/GyGi8vL/BdUGSBBDGSJpI4A6CBA/Uh6H1PXRC7efOmra3to0ePpFJevnx5/Pjx9+7dA3+k0+kbN268efMmYeyqiopKTEzMzZs3DQ0Nwd9ra2tdXFwiIiKkzr/29vaFCxdu3LiRYmwB1E8kK4E8q9OECRNIZgCYmW/Xrl0ylaykpBQVFSVpDHZ2dm7cuBH/liRvfTw4HA6hPOXq6trQ0CDprVevXllaWsr0IT/88ANYAhjoCc0A6jk9/hdqamqgvzjUAcXFxdijgwcPgo8o+sj7+vrifb5LS0sJ41WnTp1K0nZ4CIXC8PBwvGiqp6eXmZmJp09PTyexZ2GAEsGsXLkSLASceVAHyBkWl5iYKKkDbt68iT2CTID6+vqpqalUMg6NHj0azAuZlpaGfwtdduRzUSkoKICWIxT+/v5YAIhAIAgNDZXKKp1O37RpExTxAMWkgN0DdoB8OUxoNBqNzWZjAflQLPzZs2exCvBh8h8+fCgtLaXii6GhoXH+/Hkej0eYDJ/6siMJHA6HMJu2jY1NSUlJdXW1o6OjVCa1tLQuXrwoFounTZsG/p6QkIBVBBnpsA7gcrnUA3KI60Zzq0IzYN++fVjd+LwG6Kmjra0N71GKB51OJ3QpsLOzg3LAygeRSBQVFUWoKaNiw5o8eTIaAIEPcr9y5QpWCyQqoh1QVFQkNeUBJZiamkIjZfXq1VjdfD4fWvfBoIGkpCRZ74nqybIjCZKWI6lsYME/+HH2+vVrrPwLFy6Aj6ytrcePHy9TdbLBxcUF/DwoWN7BwQE0fZSVlVHfhfT09Ajz+PcckpYjQgwcOBBygd6/fz9IwGazwfAewiSpvQgdHR3QNx0fl7FhwwawD9rb26nEbowfP76+vr43Wh+FUCikknPVyckJzOCFIEh0dDS0Xtna2oIlS82uoXiA0UWEiZdnzJgBhcyfPn2a/HQErqqScPz4cRMTk3Hjxs2cOXP58uWhoaEBAQGurq76+voLFy6EwgXxaG9vJ1n68atfW1sbah+FsH79erBYcs+4XkFGRgZWvaT7ZExMTLBERShevXpFmHQBRX5+PnnzZWdnk++cUEI3QkhKeotf/crLyyXtoui5CIUkW1DvYvny5SCvFhYW4FNsW1ZSUoqOjgbXqy9fvkhymQfFCzyeP39OxUc6JiaGvAMIR+u3334LyXopKSnY8QFSMdHpdFAb9vvvv1NpMQXDxMQEZPenn34Cn86ZM+fAgQNYTsKZM2dC8YXJycn45YikA7q6ukjiF0EwGAzCm6kkdQB+2QHVIQwGY+PGjVDg7aRJk8ACqd/opWCUl5djTED559TU1Do7O8vKyrAFZ8iQIQ8fPgT5fvnyJXSLy61bt0ga7v79+1jCThIsWrSIJEEX1AHKyspZWVng0+LiYkyEHDp06L1790QiERT+Bk4yfHhM3wGMtePz+ZDPD5rtms/nb968GZ3CLBYrJiYGXI6g9MDkI1csFldVVZGcaOl0OhqcRV4I2F4+Pj5gU8bHx2MahR9++AFN4ZSTkwPVAkqIxcXFPW9JOQEmThSLxUFBQeBTLS0tbEkpKCjADCZeXl6YXxcUVSK1A8Ri8efPnyGVAAo1NTXCPD/kHYDtZDweb+HCheiPmpqaqamp6O/l5eVQ9KSdnR1YGppruH/AZDLBjQtvuWWxWJGRkajA0tzcjGkmJk6ciEoJcnSAWCwWCASBgYHgi8bGxn/88QeVdyV1AKZoc3BwwC6WO336ND7PDZauDUUfhOKQITIyEuSGMDjW2dkZu6jq7NmzaJ5qNCu3fB2A4ujRo6ampqqqqvPnz5cpxzdhB4wYMYLJZKJ+iWKx+OPHj7Nnz8Z/i4qKClhXaWmpoltURlhYWIBrblJSEiGZpqbmr7/+itI0NjbOmDEDNStCHYAl1+xVgB2wbNky9MfvvvsOE1mys7MlRVuASjCxWAwmLu83YInZxWIxn88nudtj2bJlaHo1BEHQdSk9PR0k6McOQPnh8/nBwcGSjKx0Oh08+HV2dqKzuSeQxzNu2LBhYGTkL7/8glnPVVRUtmzZgrcpMhgMBEFSUlIKCwvT09Pt7e1RgVaO2ILa2lr0FGhvb29ubs5kMt+9e1dUVPTp06c5c+YQrhskEP+PrZvJZFZUVCxevJgkum/GjBmgYHz58uXm5mbsTxMTEy6Xy+fzZfwgWWBhYZGXl1dfXw+GKCkrK4MatM7OTgMDA+hFBwcH7DI9VDZGiTMyMkCyO3fukA/eCxcukA86Dw8PqZnwwRmwdOlS9Me7d+9ih30zMzNCDQQ418V/90en0WiZmZlVVVW9pZVTVVUNDw/HrMQ//vgj+DQoKAjk7MiRI/gS9u/ff+zYMewjUf8UKOEs9IUgOBwOxdGNGpEodoC/vz/6I5othU6nr1u3LjExEV8sFDABOVWOGjUK0/5mZWURXhMqP7y8vKDMSmVlZeDqwWazwTuzhUIhPjEuk8k8fvx4XV3djBkzaDQaen6l2AEXL16U9UY3T09PSZptwg4YPHiwubl5QUFBfn4+XkfCZrOhxGDQee/UqVPg046Oji1btlDxT5BOsWXLlujoaOjHsWPH2tvbY/cK8Pn82NhYzGTBZDLj4+OdnZ3FgDeRSCQKCAgIDw/Pyck5c+YMRecnGo3W1dU1bNgwkgzVkkBlOcY43LBhQ3BwcG5uLnoJNUS2efNmcFBnZ2eD91kPGjQIsnaoqqpGR0crKSnt3btXVrZhoHekgN0rEokOHDgAtSCbzYauBYaWKQyzZ8/GEqNAMwDMR957AGcAmntWLBYLhcJdu3YRhgiYmpqCHjQIguCv9FyzZg0+1WZAQICcjQ4B9IFAT/GEZN7e3mD1zc3NknLaDRkyBD10nzt3Dvy9vzqAxFqppKQEeTZKSsphaWlZWlqKkXG5XCqBZpRgaWmJ7jAXLlzQ1dUloYQMGoWFhZLWQSUlpfDwcOgUBFlv+qADFi9enJeXRxLkDon6ra2tJJd6sNnsuLg4VDKl4m4kA1JSUqj4mFhYWED+bhEREST0kKcCxRnQ0dFRVFSUnJwcGxsbFRWVmJh49epV6gkYwQ7Q1dUliUxyc3ODcnqtW7dOaiN4e3u/fv1ajmTJ8kBTUxO6CQoS1kUiEaFNlRDkM6CrqysjI8PDw0PS3VMjR47csWOHVCdGiur7oUOHQolCb9y4AUmOko6bfZTD2NDQ8NmzZ5C/Bo1Gg9TC5MlEQeTl5RE2GYIgZ86cwUcAEILFYm3YsEFSArTu7m4qfkoGBgYVFRXgi01NTVDPubu783i8uXPnUuFK8bCyskJ1nCKRCFLQDxw4EBqGXC6XimuQlZUVejUEiA8fPkja9klgYGCAd2vk8Xgk2cMw6OjoQBeciUQiiAdtbW1UzhAKhfI4P/cQrq6u4IUfDQ0N0OY8ceJEaDNobGwk8YfAwGazwbtPXrx4IXeKNzqdDvrBP3/+nIq3mrq6OmQ6FYvFO3fuhMhApxAEQTZv3iwfk/LA19cXn+kcMi7SaLTvv/8eEiA+f/5MxRmWRqO5urrW1tYWFxf3XN24efNmgUAQHR1NJR2ikZERligSQ0ZGBrT0Q0Z5FOTHDYVBW1sbn7utra0NL5vQcDoilJLieqKlpdXDC+UxULwNztbWFr+B37hxg7Dnjhw5AlEiCEI99WuPsHDhQrDirq4ukrueQkND8YxGRUX1MN0vk8kcM2aMs7Pz999/b2tr2/OJMmPGDDBhCIrCwkJJwhSdTk9OTgaJExISesiDDMBs1iKRCLNlS0JQUBDeUyEnJ0e+rLITJ05MS0uDvIyEQuHdu3dXr14tx/lPTU0tPj4ez2FBQQF52AyLxcIEz8rKSoXJvVSgpqaG3tBGGM+Fx6pVq/BXBXA4HCrCHQYtLa309HRyr5PXr19TuQwSg4uLC2aCB3H+/HkqN90OGDCgsLBQIBDIHW4vPyZMmCApYcO8efPwpi43NzfC661yc3OpXINgbm4OmgNJ0NXVRcUFWkdHJyEhAd+dCILs378fv0LOnTuXUA2jq6tLpbq+w7p168Ri8fHjx/F9YGJiQnjBW1dX14kTJ0i2Sh0dncrKSiqtjzUiiXykpqYWGhoK5pzC0NraumDBAvwrCxcuFAgE2dnZfXpdnhyws7PDTqgnT54kzMYXFxdHmDS9o6PjwIEDhHoxyHuQClpaWvCSM5vNDg4Ohm6DwVBUVETofoq2PkpDccntH+jp6WH+PyiSk5MJd0UHB4eysjLCVujs7ISMG25ubrK2PgrIR2bw4MGS1ERfvnwJDg4mdHxftmwZuHt1dXURJvHqfzAYjOvXr+O/LT8/n1AvyGKxwsLC2tvb8a9AyjsSXxUej4f6uTA7QrgAAAKeSURBVBBCIBCAPjIMBoNw2fn9998lbUKhoaH4TaKqqqp/rqsix88//wwx+unTJ1SqfPLkiSSF+8CBA8PDw8FGRBAEvEBQT0+P8KalhoaGOXPmoFa5MWPGEIZfi8Xi1atXg9VBd648ePBAUt5QFot1+vRpsVhcUVGBHwGHDx9WXMspCAYGBpAebeHChSwWa/fu3QKBoLq6msSH0sDAIDY2Fu2G8vJy8BEk9KH4/PkzpAem0+lgyAoGyOKGXt4hEokyMzOhDPwQP6iT5Pnz5zU1NQ0NDUHdanNzM2Hu5P6Hnp7en3/+if9yOzu7srIyHo+3cuVKktc1NDQCAgKguyDwE0ssIQukqakpfrmArga3traOiYkhD/SYPn16Y2Pjp0+fQL2pr68vWiCHw5kwYQJZK/QvtLW1Hz582NjYCEm5LBZr+/bt7e3thP7GJIBuqkGB+XhBgDT4Ylxaf3IoKSlFRER0d3efOnUKL6Vfvny5rq5OnqsY+hjq6uoODg6Ej9AVv6SkhCQrLoQdO3bgO0DSwg1GTqOgkhoHxeTJkx8/fnzixIkRI0YQEgwePFghd5/0P9TU1NasWbN9+3Zy+z6KVatW4Ttg69ateEoDAwP8dn358mWpVSgrK3t4eKxYsUJRytd/G1DxzbKyssJ3wPv37/GNlZSUhKdU1O1C/69BqCwrLi7G8itpaGjExcXhacRyJ+r5D0DgrTooEAQpKyt79OiRpJhIfB6d/0AeqKioQE6PVCAQCL7q8+K/F8aNGyfTnfJiIOjuP1AMPDw88CZDSYDS2P0HisGYMWPwLgsQWlpa+sFL5/8P6HT6/Pnz8/Pz8Wlpamtr9+/f36PbS/sDX7d9RzI0NTVtbGyMjY3V1dU/fvxYU1ODz3D8b4H/AgzSMHzIaCzLAAAAAElFTkSuQmCC",
  F = {
    name: "Ethereum Mainnet",
    chainId: 1,
  },
  K = {
    name: "Ethereum Sepolia",
    chainId: 11155111,
  }
var D, vt
function Zt(i) {
  return i.children
}
;(D = {
  __e: function (i, t, e, n) {
    for (var r, a, o; (t = t.__); )
      if ((r = t.__c) && !r.__)
        try {
          if (
            ((a = r.constructor) &&
              a.getDerivedStateFromError != null &&
              (r.setState(a.getDerivedStateFromError(i)),
              (o = r.__d)),
            r.componentDidCatch != null &&
              (r.componentDidCatch(i, n || {}),
              (o = r.__d)),
            o)
          )
            return (r.__E = r)
        } catch (c) {
          i = c
        }
    throw i
  },
}),
  (vt = function (i) {
    return i != null && i.constructor == null
  }),
  typeof Promise == "function" &&
    Promise.prototype.then.bind(Promise.resolve())
var Y,
  _,
  x,
  $,
  tt = 0,
  lt = [],
  s = D,
  it = s.__b,
  et = s.__r,
  nt = s.diffed,
  rt = s.__c,
  ot = s.unmount,
  at = s.__
function Xt(i, t) {
  s.__h && s.__h(_, i, tt || t), (tt = 0)
  var e = _.__H || (_.__H = { __: [], __h: [] })
  return i >= e.__.length && e.__.push({}), e.__[i]
}
function _t(i, t) {
  var e = Xt(Y++, 7)
  return (
    Jt(e.__H, t) &&
      ((e.__ = i()), (e.__H = t), (e.__h = i)),
    e.__
  )
}
function Mt() {
  for (var i; (i = lt.shift()); )
    if (i.__P && i.__H)
      try {
        i.__H.__h.forEach(k),
          i.__H.__h.forEach(z),
          (i.__H.__h = [])
      } catch (t) {
        ;(i.__H.__h = []), s.__e(t, i.__v)
      }
}
;(s.__b = function (i) {
  ;(_ = null), it && it(i)
}),
  (s.__ = function (i, t) {
    i && t.__k && t.__k.__m && (i.__m = t.__k.__m),
      at && at(i, t)
  }),
  (s.__r = function (i) {
    et && et(i), (Y = 0)
    var t = (_ = i.__c).__H
    t &&
      (x === _
        ? ((t.__h = []),
          (_.__h = []),
          t.__.forEach(function (e) {
            e.__N && (e.__ = e.__N), (e.u = e.__N = void 0)
          }))
        : (t.__h.forEach(k),
          t.__h.forEach(z),
          (t.__h = []),
          (Y = 0))),
      (x = _)
  }),
  (s.diffed = function (i) {
    nt && nt(i)
    var t = i.__c
    t &&
      t.__H &&
      (t.__H.__h.length &&
        ((lt.push(t) !== 1 &&
          $ === s.requestAnimationFrame) ||
          (($ = s.requestAnimationFrame) || Vt)(Mt)),
      t.__H.__.forEach(function (e) {
        e.u && (e.__H = e.u), (e.u = void 0)
      })),
      (x = _ = null)
  }),
  (s.__c = function (i, t) {
    t.some(function (e) {
      try {
        e.__h.forEach(k),
          (e.__h = e.__h.filter(function (n) {
            return !n.__ || z(n)
          }))
      } catch (n) {
        t.some(function (r) {
          r.__h && (r.__h = [])
        }),
          (t = []),
          s.__e(n, e.__v)
      }
    }),
      rt && rt(i, t)
  }),
  (s.unmount = function (i) {
    ot && ot(i)
    var t,
      e = i.__c
    e &&
      e.__H &&
      (e.__H.__.forEach(function (n) {
        try {
          k(n)
        } catch (r) {
          t = r
        }
      }),
      (e.__H = void 0),
      t && s.__e(t, e.__v))
  })
var ut = typeof requestAnimationFrame == "function"
function Vt(i) {
  var t,
    e = function () {
      clearTimeout(n),
        ut && cancelAnimationFrame(t),
        setTimeout(i)
    },
    n = setTimeout(e, 35)
  ut && (t = requestAnimationFrame(e))
}
function k(i) {
  var t = _,
    e = i.__c
  typeof e == "function" && ((i.__c = void 0), e()), (_ = t)
}
function z(i) {
  var t = _
  ;(i.__c = i.__()), (_ = t)
}
function Jt(i, t) {
  return (
    !i ||
    i.length !== t.length ||
    t.some(function (e, n) {
      return e !== i[n]
    })
  )
}
var Ft = Symbol.for("preact-signals")
function B() {
  if (A > 1) A--
  else {
    var i,
      t = !1
    for (
      (function () {
        var r = I
        for (I = void 0; r !== void 0; )
          r.S.v === r.v && (r.S.i = r.i), (r = r.o)
      })();
      g !== void 0;
    ) {
      var e = g
      for (g = void 0, O++; e !== void 0; ) {
        var n = e.u
        if (
          ((e.u = void 0), (e.f &= -3), !(8 & e.f) && At(e))
        )
          try {
            e.c()
          } catch (r) {
            t || ((i = r), (t = !0))
          }
        e = n
      }
    }
    if (((O = 0), A--, t)) throw i
  }
}
function Kt(i) {
  if (A > 0) return i()
  ;(G = ++$t), A++
  try {
    return i()
  } finally {
    B()
  }
}
var f = void 0
function X(i) {
  var t = f
  f = void 0
  try {
    return i()
  } finally {
    f = t
  }
}
var g = void 0,
  A = 0,
  O = 0,
  $t = 0,
  G = 0,
  I = void 0,
  U = 0
function pt(i) {
  if (f !== void 0) {
    var t = i.n
    if (t === void 0 || t.t !== f)
      return (
        (t = {
          i: 0,
          S: i,
          p: f.s,
          n: void 0,
          t: f,
          e: void 0,
          x: void 0,
          r: t,
        }),
        f.s !== void 0 && (f.s.n = t),
        (f.s = t),
        (i.n = t),
        32 & f.f && i.S(t),
        t
      )
    if (t.i === -1)
      return (
        (t.i = 0),
        t.n !== void 0 &&
          ((t.n.p = t.p),
          t.p !== void 0 && (t.p.n = t.n),
          (t.p = f.s),
          (t.n = void 0),
          (f.s.n = t),
          (f.s = t)),
        t
      )
  }
}
function h(i, t) {
  ;(this.v = i),
    (this.i = 0),
    (this.n = void 0),
    (this.t = void 0),
    (this.l = 0),
    (this.W = t?.watched),
    (this.Z = t?.unwatched),
    (this.name = t?.name)
}
h.prototype.brand = Ft
h.prototype.h = function () {
  return !0
}
h.prototype.S = function (i) {
  var t = this,
    e = this.t
  e !== i &&
    i.e === void 0 &&
    ((i.x = e),
    (this.t = i),
    e !== void 0
      ? (e.e = i)
      : X(function () {
          var n
          ;(n = t.W) == null || n.call(t)
        }))
}
h.prototype.U = function (i) {
  var t = this
  if (this.t !== void 0) {
    var e = i.e,
      n = i.x
    e !== void 0 && ((e.x = n), (i.e = void 0)),
      n !== void 0 && ((n.e = e), (i.x = void 0)),
      i === this.t &&
        ((this.t = n),
        n === void 0 &&
          X(function () {
            var r
            ;(r = t.Z) == null || r.call(t)
          }))
  }
}
h.prototype.subscribe = function (i) {
  var t = this
  return T(
    function () {
      var e = t.value,
        n = f
      f = void 0
      try {
        i(e)
      } finally {
        f = n
      }
    },
    { name: "sub" },
  )
}
h.prototype.valueOf = function () {
  return this.value
}
h.prototype.toString = function () {
  return this.value + ""
}
h.prototype.toJSON = function () {
  return this.value
}
h.prototype.peek = function () {
  var i = this
  return X(function () {
    return i.value
  })
}
Object.defineProperty(h.prototype, "value", {
  get: function () {
    var i = pt(this)
    return i !== void 0 && (i.i = this.i), this.v
  },
  set: function (i) {
    if (i !== this.v) {
      if (O > 100) throw new Error("Cycle detected")
      ;(function (e) {
        A !== 0 &&
          O === 0 &&
          e.l !== G &&
          ((e.l = G), (I = { S: e, v: e.v, i: e.i, o: I }))
      })(this),
        (this.v = i),
        this.i++,
        U++,
        A++
      try {
        for (var t = this.t; t !== void 0; t = t.x) t.t.N()
      } finally {
        B()
      }
    }
  },
})
function M(i, t) {
  return new h(i, t)
}
function At(i) {
  for (var t = i.s; t !== void 0; t = t.n)
    if (t.S.i !== t.i || !t.S.h() || t.S.i !== t.i)
      return !0
  return !1
}
function mt(i) {
  for (var t = i.s; t !== void 0; t = t.n) {
    var e = t.S.n
    if (
      (e !== void 0 && (t.r = e),
      (t.S.n = t),
      (t.i = -1),
      t.n === void 0)
    ) {
      i.s = t
      break
    }
  }
}
function Et(i) {
  for (var t = i.s, e = void 0; t !== void 0; ) {
    var n = t.p
    t.i === -1
      ? (t.S.U(t),
        n !== void 0 && (n.n = t.n),
        t.n !== void 0 && (t.n.p = n))
      : (e = t),
      (t.S.n = t.r),
      t.r !== void 0 && (t.r = void 0),
      (t = n)
  }
  i.s = e
}
function E(i, t) {
  h.call(this, void 0),
    (this.x = i),
    (this.s = void 0),
    (this.g = U - 1),
    (this.f = 4),
    (this.W = t?.watched),
    (this.Z = t?.unwatched),
    (this.name = t?.name)
}
E.prototype = new h()
E.prototype.h = function () {
  if (((this.f &= -3), 1 & this.f)) return !1
  if ((36 & this.f) == 32 || ((this.f &= -5), this.g === U))
    return !0
  if (
    ((this.g = U), (this.f |= 1), this.i > 0 && !At(this))
  )
    return (this.f &= -2), !0
  var i = f
  try {
    mt(this), (f = this)
    var t = this.x()
    ;(16 & this.f || this.v !== t || this.i === 0) &&
      ((this.v = t), (this.f &= -17), this.i++)
  } catch (e) {
    ;(this.v = e), (this.f |= 16), this.i++
  }
  return (f = i), Et(this), (this.f &= -2), !0
}
E.prototype.S = function (i) {
  if (this.t === void 0) {
    this.f |= 36
    for (var t = this.s; t !== void 0; t = t.n) t.S.S(t)
  }
  h.prototype.S.call(this, i)
}
E.prototype.U = function (i) {
  if (
    this.t !== void 0 &&
    (h.prototype.U.call(this, i), this.t === void 0)
  ) {
    this.f &= -33
    for (var t = this.s; t !== void 0; t = t.n) t.S.U(t)
  }
}
E.prototype.N = function () {
  if (!(2 & this.f)) {
    this.f |= 6
    for (var i = this.t; i !== void 0; i = i.x) i.t.N()
  }
}
Object.defineProperty(E.prototype, "value", {
  get: function () {
    if (1 & this.f) throw new Error("Cycle detected")
    var i = pt(this)
    if (
      (this.h(),
      i !== void 0 && (i.i = this.i),
      16 & this.f)
    )
      throw this.v
    return this.v
  },
})
function ct(i, t) {
  return new E(i, t)
}
function wt(i) {
  var t = i.m
  if (((i.m = void 0), typeof t == "function")) {
    A++
    var e = f
    f = void 0
    try {
      t()
    } catch (n) {
      throw ((i.f &= -2), (i.f |= 8), V(i), n)
    } finally {
      ;(f = e), B()
    }
  }
}
function V(i) {
  for (var t = i.s; t !== void 0; t = t.n) t.S.U(t)
  ;(i.x = void 0), (i.s = void 0), wt(i)
}
function ti(i) {
  if (f !== this) throw new Error("Out-of-order effect")
  Et(this),
    (f = i),
    (this.f &= -2),
    8 & this.f && V(this),
    B()
}
function S(i, t) {
  ;(this.x = i),
    (this.m = void 0),
    (this.s = void 0),
    (this.u = void 0),
    (this.f = 32),
    (this.name = t?.name)
}
S.prototype.c = function () {
  var i = this.S()
  try {
    if (8 & this.f || this.x === void 0) return
    var t = this.x()
    typeof t == "function" && (this.m = t)
  } finally {
    i()
  }
}
S.prototype.S = function () {
  if (1 & this.f) throw new Error("Cycle detected")
  ;(this.f |= 1), (this.f &= -9), wt(this), mt(this), A++
  var i = f
  return (f = this), ti.bind(this, i)
}
S.prototype.N = function () {
  2 & this.f || ((this.f |= 2), (this.u = g), (g = this))
}
S.prototype.d = function () {
  ;(this.f |= 8), 1 & this.f || V(this)
}
S.prototype.dispose = function () {
  this.d()
}
function T(i, t) {
  var e = new S(i, t)
  try {
    e.c()
  } catch (r) {
    throw (e.d(), r)
  }
  var n = e.d.bind(e)
  return (n[Symbol.dispose] = n), n
}
var yt,
  q,
  ii =
    typeof window < "u" &&
    !!window.__PREACT_SIGNALS_DEVTOOLS__,
  St = []
T(function () {
  yt = this.N
})()
function N(i, t) {
  D[i] = t.bind(null, D[i] || function () {})
}
function Q(i) {
  if (q) {
    var t = q
    ;(q = void 0), t()
  }
  q = i && i.S()
}
function Nt(i) {
  var t = this,
    e = i.data,
    n = ni(e)
  n.value = e
  var r = _t(function () {
      for (var c = t, v = t.__v; (v = v.__); )
        if (v.__c) {
          v.__c.__$f |= 4
          break
        }
      var l = ct(function () {
          var d = n.value.value
          return d === 0 ? 0 : d === !0 ? "" : d || ""
        }),
        m = ct(function () {
          return !Array.isArray(l.value) && !vt(l.value)
        }),
        w = T(function () {
          if (((this.N = gt), m.value)) {
            var d = l.value
            c.__v &&
              c.__v.__e &&
              c.__v.__e.nodeType === 3 &&
              (c.__v.__e.data = d)
          }
        }),
        u = t.__$u.d
      return (
        (t.__$u.d = function () {
          w(), u.call(this)
        }),
        [m, l]
      )
    }, []),
    a = r[0],
    o = r[1]
  return a.value ? o.peek() : o.value
}
Nt.displayName = "ReactiveTextNode"
Object.defineProperties(h.prototype, {
  constructor: { configurable: !0, value: void 0 },
  type: { configurable: !0, value: Nt },
  props: {
    configurable: !0,
    get: function () {
      var i = this
      return {
        data: {
          get value() {
            return i.value
          },
        },
      }
    },
  },
  __b: { configurable: !0, value: 1 },
})
N("__b", function (i, t) {
  if (typeof t.type == "string") {
    var e,
      n = t.props
    for (var r in n)
      if (r !== "children") {
        var a = n[r]
        a instanceof h &&
          (e || (t.__np = e = {}),
          (e[r] = a),
          (n[r] = a.peek()))
      }
  }
  i(t)
})
N("__r", function (i, t) {
  if ((i(t), t.type !== Zt)) {
    Q()
    var e,
      n = t.__c
    n &&
      ((n.__$f &= -2),
      (e = n.__$u) === void 0 &&
        (n.__$u = e =
          (function (r, a) {
            var o
            return (
              T(
                function () {
                  o = this
                },
                { name: a },
              ),
              (o.c = r),
              o
            )
          })(
            function () {
              var r
              ii && ((r = e.y) == null || r.call(e)),
                (n.__$f |= 1),
                n.setState({})
            },
            typeof t.type == "function"
              ? t.type.displayName || t.type.name
              : "",
          ))),
      Q(e)
  }
})
N("__e", function (i, t, e, n) {
  Q(), i(t, e, n)
})
N("diffed", function (i, t) {
  Q()
  var e
  if (typeof t.type == "string" && (e = t.__e)) {
    var n = t.__np,
      r = t.props
    if (n) {
      var a = e.U
      if (a)
        for (var o in a) {
          var c = a[o]
          c !== void 0 &&
            !(o in n) &&
            (c.d(), (a[o] = void 0))
        }
      else (a = {}), (e.U = a)
      for (var v in n) {
        var l = a[v],
          m = n[v]
        l === void 0
          ? ((l = ei(e, v, m)), (a[v] = l))
          : l.o(m, r)
      }
      for (var w in n) r[w] = n[w]
    }
  }
  i(t)
})
function ei(i, t, e, n) {
  var r = t in i && i.ownerSVGElement === void 0,
    a = M(e),
    o = e.peek()
  return {
    o: function (c, v) {
      ;(a.value = c), (o = c.peek())
    },
    d: T(function () {
      this.N = gt
      var c = a.value.value
      o !== c
        ? ((o = void 0),
          r
            ? (i[t] = c)
            : c != null && (c !== !1 || t[4] === "-")
              ? i.setAttribute(t, c)
              : i.removeAttribute(t))
        : (o = void 0)
    }),
  }
}
N("unmount", function (i, t) {
  if (typeof t.type == "string") {
    var e = t.__e
    if (e) {
      var n = e.U
      if (n) {
        e.U = void 0
        for (var r in n) {
          var a = n[r]
          a && a.d()
        }
      }
    }
    t.__np = void 0
  } else {
    var o = t.__c
    if (o) {
      var c = o.__$u
      c && ((o.__$u = void 0), c.d())
    }
  }
  i(t)
})
N("__h", function (i, t, e, n) {
  ;(n < 3 || n === 9) && (t.__$f |= 2), i(t, e, n)
})
function ni(i, t) {
  return _t(function () {
    return M(i, t)
  }, [])
}
var ri = function (i) {
  queueMicrotask(function () {
    queueMicrotask(i)
  })
}
function oi() {
  Kt(function () {
    for (var i; (i = St.shift()); ) yt.call(i)
  })
}
function gt() {
  St.push(this) === 1 && (D.requestAnimationFrame || ri)(oi)
}
const Ct = [
  {
    id: K.chainId,
    name: K.name,
    rpc_url: "https://ethereum-sepolia-rpc.publicnode.com",
  },
  {
    id: F.chainId,
    name: F.name,
    rpc_url: "https://ethereum-rpc.publicnode.com",
  },
]
M(Ct[0])
function ai(i) {
  return `0x${i.id.toString(16)}`
}
const ui = Ct.map(ai)
function ci(i) {
  return new Promise((t, e) => {
    const n = crypto.randomUUID()
    window.addEventListener("message", function a(o) {
      if (
        !o.data?.type?.startsWith("ETHERNAUTA_RESPONSE") ||
        o.data.id !== n
      )
        return
      if (
        (window.removeEventListener("message", a),
        o.data.type ===
          "ETHERNAUTA_RESPONSE_TRANSACTION_REJECTED")
      ) {
        e({
          code: C.USER_REJECTED_REQUEST,
          message: "User rejected request",
        })
        return
      }
      if (
        o.data.type ===
        "ETHERNAUTA_RESPONSE_NATIVE_EXTENSION_CLOSE"
      ) {
        e({
          code: C.USER_REJECTED_REQUEST,
          message: "Extension closed",
        })
        return
      }
      if (
        o.data.type ===
          "ETHERNAUTA_RESPONSE_SIGNED_TYPED_DATA" ||
        o.data.type ===
          "ETHERNAUTA_RESPONSE_PERSONAL_SIGNED"
      ) {
        t(o.data.signature)
        return
      }
      if (
        o.data.type ===
        "ETHERNAUTA_RESPONSE_ADD_CHAIN_APPROVED"
      ) {
        t(null)
        return
      }
      const c = o.data.signed_transaction
      if (i.method === "eth_requestAccounts") {
        try {
          t(JSON.parse(c))
        } catch {
          t(c)
        }
        return
      }
      t(c)
    })
    const r = {
      type: "ETHERNAUTA_REQUEST_SIGN_TRANSACTION",
      id: n,
      method: i.method,
      chainId: P.get_active_chain(),
      params: i.params,
    }
    window.postMessage(r, window.location.origin)
  })
}
const P = xt({
  chains: ui,
  on_signable_request: ci,
})
window.addEventListener("message", (i) => {
  if (
    i.source !== window ||
    i.data?.type !==
      "ETHERNAUTA_NOTIFICATION_CHAIN_SELECTED"
  )
    return
  const t = i.data.chainId
  P.has_chain(t) && P.set_active_chain(t)
})
zt({
  info: {
    uuid: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    name: "Ethernauta",
    icon: Gt,
    rdns: "com.ethernauta.wallet",
  },
  provider: P,
})
window.ethereum = P
