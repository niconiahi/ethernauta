import{d as e,y as o}from"./preact-10.26.9-Cg_eOskk.mjs";import{c as r}from"./robot3-1.1.1-B9XTajXJ.mjs";const s=r(o,e);export{s as u};
