import { u, E } from "./preact-10.26.9-DQkfSBBY.mjs";
import { u as useMachine } from "./preact-robot-1.1.0-C4n8myxM.mjs";
import { a as createMachine, s as state, t as transition } from "./robot3-1.1.1-P4ZK1Zn7.mjs";
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) return;
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) processPreload(link);
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") continue;
      for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
    }
  }).observe(document, {
    childList: true,
    subtree: true
  });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep) return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
function Locked({
  state: state2,
  send
}) {
  const current = state2.name;
  return /* @__PURE__ */ u("div", { children: [
    /* @__PURE__ */ u("span", { children: [
      "the current state is ",
      current
    ] }),
    /* @__PURE__ */ u(
      "button",
      {
        type: "button",
        onClick: () => {
          send("unlock");
        },
        children: "unlock"
      }
    )
  ] });
}
function Unlocked({
  state: state2,
  send
}) {
  const current = state2.name;
  return /* @__PURE__ */ u("div", { children: [
    /* @__PURE__ */ u("span", { children: [
      "the current state is ",
      current
    ] }),
    /* @__PURE__ */ u(
      "button",
      {
        type: "button",
        onClick: () => {
          send("lock");
        },
        children: "lock"
      }
    )
  ] });
}
function context() {
  return {
    user: "Andy"
  };
}
const controller_machine = createMachine(
  {
    locked: state(transition("unlock", "unlocked")),
    unlocked: state(transition("lock", "locked"))
  },
  context
);
function Controller() {
  const [state2, send] = useMachine(controller_machine);
  const current = state2.name;
  switch (current) {
    case "locked": {
      return /* @__PURE__ */ u(Locked, { state: state2, send });
    }
    case "unlocked": {
      return /* @__PURE__ */ u(Unlocked, { state: state2, send });
    }
    default: {
      return /* @__PURE__ */ u(Locked, { state: state2, send });
    }
  }
}
E(
  /* @__PURE__ */ u(Controller, {}),
  // biome-ignore lint: the element exists
  document.querySelector("#app")
);
