import { d, y } from "./preact-10.26.9-DQkfSBBY.mjs";
import { c as createUseMachine } from "./robot3-1.1.1-P4ZK1Zn7.mjs";
const useMachine = createUseMachine(y, d);
export {
  useMachine as u
};
