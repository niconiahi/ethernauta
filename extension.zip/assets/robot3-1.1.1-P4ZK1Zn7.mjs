function valueEnumerable$1(value) {
  return { enumerable: true, value };
}
function valueEnumerableWritable(value) {
  return { enumerable: true, writable: true, value };
}
let d = {};
let truthy = () => true;
let empty = () => ({});
let identity = (a) => a;
let callBoth = (par, fn, self, args) => par.apply(self, args) && fn.apply(self, args);
let callForward = (par, fn, self, [a, b]) => fn.call(self, par.call(self, a, b), b);
let create$1 = (a, b) => Object.freeze(Object.create(a, b));
function stack(fns, def, caller) {
  return fns.reduce((par, fn) => {
    return function(...args) {
      return caller(par, fn, this, args);
    };
  }, def);
}
function fnType(fn) {
  return create$1(this, { fn: valueEnumerable$1(fn) });
}
let reduceType = {};
fnType.bind(reduceType);
let guardType = {};
fnType.bind(guardType);
function filter(Type, arr) {
  return arr.filter((value) => Type.isPrototypeOf(value));
}
function makeTransition(from, to, ...args) {
  let guards = stack(filter(guardType, args).map((t) => t.fn), truthy, callBoth);
  let reducers = stack(filter(reduceType, args).map((t) => t.fn), identity, callForward);
  return create$1(this, {
    from: valueEnumerable$1(from),
    to: valueEnumerable$1(to),
    guards: valueEnumerable$1(guards),
    reducers: valueEnumerable$1(reducers)
  });
}
let transitionType = {};
let immediateType = {};
let transition = makeTransition.bind(transitionType);
makeTransition.bind(immediateType, null);
function enterImmediate(machine2, service2, event) {
  return transitionTo(service2, machine2, event, this.immediates) || machine2;
}
function transitionsToMap(transitions) {
  let m = /* @__PURE__ */ new Map();
  for (let t of transitions) {
    if (!m.has(t.from)) m.set(t.from, []);
    m.get(t.from).push(t);
  }
  return m;
}
let stateType = { enter: identity };
function state(...args) {
  let transitions = filter(transitionType, args);
  let immediates = filter(immediateType, args);
  let desc = {
    final: valueEnumerable$1(args.length === 0),
    transitions: valueEnumerable$1(transitionsToMap(transitions))
  };
  if (immediates.length) {
    desc.immediates = valueEnumerable$1(immediates);
    desc.enter = valueEnumerable$1(enterImmediate);
  }
  return create$1(stateType, desc);
}
let machine = {
  get state() {
    return {
      name: this.current,
      value: this.states[this.current]
    };
  }
};
function createMachine(current, states, contextFn = empty) {
  if (typeof current !== "string") {
    contextFn = states || empty;
    states = current;
    current = Object.keys(states)[0];
  }
  if (d._create) d._create(current, states);
  return create$1(machine, {
    context: valueEnumerable$1(contextFn),
    current: valueEnumerable$1(current),
    states: valueEnumerable$1(states)
  });
}
function transitionTo(service2, machine2, fromEvent, candidates) {
  let { context } = service2;
  for (let { to, guards, reducers } of candidates) {
    if (guards(context, fromEvent)) {
      service2.context = reducers.call(service2, context, fromEvent);
      let original = machine2.original || machine2;
      let newMachine = create$1(original, {
        current: valueEnumerable$1(to),
        original: { value: original }
      });
      if (d._onEnter) d._onEnter(machine2, to, service2.context, context, fromEvent);
      let state2 = newMachine.state.value;
      service2.machine = newMachine;
      let ret = state2.enter(newMachine, service2, fromEvent);
      service2.onChange(service2);
      return ret;
    }
  }
}
function send(service2, event) {
  let eventName = event.type || event;
  let { machine: machine2 } = service2;
  let { value: state2, name: currentStateName } = machine2.state;
  if (state2.transitions.has(eventName)) {
    return transitionTo(service2, machine2, event, state2.transitions.get(eventName)) || machine2;
  } else {
    if (d._send) d._send(eventName, currentStateName);
  }
  return machine2;
}
let service = {
  send(event) {
    send(this, event);
  }
};
function interpret(machine2, onChange, initialContext, event) {
  let s = Object.create(service, {
    machine: valueEnumerableWritable(machine2),
    context: valueEnumerableWritable(machine2.context(initialContext, event)),
    onChange: valueEnumerable$1(onChange)
  });
  s.send = s.send.bind(s);
  s.machine = s.machine.state.value.enter(s.machine, s, event);
  return s;
}
const { create, freeze } = Object;
function valueEnumerable(value) {
  return { enumerable: true, value };
}
function createCurrent(service2) {
  return freeze(create(service2.machine.state, {
    context: valueEnumerable(service2.context || {}),
    service: valueEnumerable(service2)
  }));
}
function createUseMachine(useEffect, useState) {
  return function useMachine(providedMachine, initialContext) {
    let [machine2, setMachine] = useState(providedMachine);
    let [service2, setService] = useState(runInterpreter);
    let mounted = true;
    function runInterpreter(arg, data) {
      let m = arg || machine2;
      return interpret(m, (service3) => {
        if (!mounted) {
          return;
        }
        let currentService = service3;
        while (currentService.child) {
          currentService = currentService.child;
        }
        setCurrent(createCurrent(currentService));
      }, data || initialContext);
    }
    let [current, setCurrent] = useState(createCurrent(service2));
    useEffect(() => {
      mounted = true;
      if (machine2 !== providedMachine) {
        setMachine(providedMachine);
        let newService = runInterpreter(providedMachine, initialContext);
        setService(newService);
        setCurrent(createCurrent(newService));
      }
      return () => {
        mounted = false;
      };
    }, [providedMachine]);
    return [current, service2.send, service2];
  };
}
export {
  createMachine as a,
  createUseMachine as c,
  state as s,
  transition as t
};
